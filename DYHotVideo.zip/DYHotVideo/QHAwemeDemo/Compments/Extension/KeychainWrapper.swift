//
//  KeychainItemWrapper.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/24.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import Foundation

class KeychainWrapper: NSObject {
    class func getDeviceId() {
        
    }
}
