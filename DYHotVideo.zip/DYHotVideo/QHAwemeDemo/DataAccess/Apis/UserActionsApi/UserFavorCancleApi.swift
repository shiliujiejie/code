//
//  UserFavorCancleApi.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/5.
//  Copyright © 2019年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork


/// 用户取消收藏
class UserFavorCancleApi: XSVideoBaseAPI {
    
    static let kVideo_ids = "video_id"
    
    static let kUrlValue = "/\(ConstValue.kApiVersion)/video/user/collect/cancel"
    static let kMethodValue = "POST"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return ConstValue.kIsEncryptoApi ? super.methodName() : "\(ConstValue.kApiVersion)/video/user/collect/cancel"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func requestType() -> NicooAPIManagerRequestType {
        return ConstValue.kIsEncryptoApi ? super.requestType() : .post
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var allParams: [String: Any] = [UserFavorCancleApi.kUrl: UserFavorCancleApi.kUrlValue,
                                        UserFavorCancleApi.kMethod: UserFavorCancleApi.kMethodValue]
        allParams[UserFavorCancleApi.kParams] = params ?? [String: Any]()
        return super.reform(ConstValue.kIsEncryptoApi ? allParams : params)
    }
    
}
