//
//  LoginManager.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/21.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 登录拦截器
class LoginManager: NSObject {
    
    private let viewModel = RegisterLoginViewModel()
    private let userInfo = UserInfoViewModel()
    
    /// 登录
    ///
    /// - Parameter successHandler: 成功回调
    func login(_ successHandler:(() -> Void)?) {
//        let loginVC = LoginController()
//        loginVC.loginSuccessCallBack = successHandler
//        let loginNav = UINavigationController(rootViewController: loginVC)
//        UIViewController.currentViewController()?.present(loginNav, animated: true, completion: nil)
    }
    
    /// 退出登录
    func logout(_ successhandler:(() -> Void)?) {
    
        UserDefaults.standard.removeObject(forKey: UserDefaults.kUserToken)
    }
    
    /// 自动登录成功回调
    private func loginCallBackHandler() {
        viewModel.loadLoginApiSuccess = { [weak self] in
            self?.loadUserInfoData()
        }
    }
    
    /// 请求用户信息
    private func loadUserInfoData() {
        userInfo.loadUserInfo()
    }
}



/// APP 信息单利
class AppInfo: NSObject {
    static private let shareModel: AppInfo = AppInfo()
    class func share() -> AppInfo {
        return shareModel
    }
    var id: Int?
    var title: String?
    var remark: String?
    var platform: String?
    var version_code: String?
    var package_path: String?
    var share_url: String?
    var share_text: String?
    var potato_invite_link: String? //土豆群跳转地址
    var extend: String?
    var official_url: String?   // 官网
    var static_url: String?   // 上传图片
    var file_upload_url: String? // 上传视频
    var force: ForceUpdate?
    var updated_at: String?
    var help_url: String?
    var wallet_url: String?
    
}
