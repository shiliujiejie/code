

import Foundation

/// 视频列表model
struct VideoListModel: Codable {
    var current_page: Int?
    var data: [VideoModel]?
}

/// 首页数据源列表
struct VideoHomeListModel: Codable {
    var current_page: Int?
    var data: [HomeVideoModel]?
}

/// 首页视频类型。 "V" - 正常视频  "A" - 广告
enum HomeVideoType: String, Codable {
    case videoType = "V"   // 视频
    case adType = "A"  // 广告
}

/// 首页model
struct HomeVideoModel: Codable {
    var type: HomeVideoType?
    var video: VideoModel?
    var ad: AdvertiseModel?
}

/// 视频Model
struct VideoModel: Codable {
    
    var id: Int?
    var title: String?
    var intro: String?
    var cover_path: String?
    var cover_oss_filename: String?
    var play_count: Int?
    var play_url_m3u8: String?
    var play_url_mp4: String?

    var recommend: Recommend?     // 是否点过❤️
    var comment_count: Int?       // 评论数
    var recommend_count: Int? = 0 // 点赞数
    var view_flag: Bool? = false  // 当前用户是否可以播放 本视频
    var keys: [VideoKey]?         // 视频标签
    
    var check: CheckStatu?        // 用于作品的审核状态
    var isLocalUpload: Bool? = false // 是否为本地上传Model
    var localUrl: URL?
}

/// 是否点👍
enum Recommend: Int, Codable {
    case notRecommend = 0
    case recommend = 1
    
    var isFavor: Bool {
        switch self {
        case .recommend:
            return true
        case .notRecommend:
            return false
        }
    }
}

/// 作品审核状态
///
/// - waitForCheck: 待审核
/// - passCheck: 已审核通过
/// - notPassCheck: 未审核通过
//  - uploading: 本地添加的，正在上传状态
enum CheckStatu: Int, Codable {
    case waitForCheck = 0
    case passCheck = 1
    case notPassCheck = -1
    // 下面两个是本地的状态
    case uploading = 2
    case uploadFailed = 3
}

/// 首页广告
struct AdvertiseModel: Codable {
    var id: Int?
    var ad_type: String?
    var title: String?
    var remark: String?
    var redirect_url: String?   // 广告去哪
    var cover_path: String?     // 封面
    var play_url_m3u8: String?
    var recommend_count: Int?   // 点赞数
    var recommend: Recommend?   // 是否点过❤️
    var comment_count: Int?     // 评论数
}

/// 视频key
struct VideoKey: Codable {
    var key_id: Int?
    var title: String?
    var pivot: Pivot?
}

struct Pivot: Codable {
    var video_id: Int?
    var key_id: Int?
}

/// 系列分类列表model
struct CateTypeListModel: Codable {
    var current_page: Int?
    var data: [VideoCategoryModel]?
}

/// 视频大分类列表MOdel
struct VideoCategoryModel: Codable {
    var id: Int?
    var key_id: Int?
    var keys_title: String?
    var keys_cover: String?
    var view_key_title: String?
    var intro: String?
    var cover_filename: String?
    var page: String?
    var recommend: Int?
    var updated_at: String?
    var updated_at_string: String?
    var video_lists:[VideoModel]?
    var relation_keys: [VideoKey]?
}



/// 视频评论列表MOdel
struct VideoCommentListModel: Codable {
    var current_page: Int?
    var data: [VideoCommentModel]?
}

struct VideoCommentModel: Codable {
    var id: Int?
    var video_id: Int?
    var ad_id: Int?
    var user_id: Int?
    var global_type: String?
    var content: String?
    var status: Int?
    var name: String?
    var nikename: String?
    var email: String?
    var cover_path: String?
    var created_at: String?
    var updated_at: String?
}

/// 搜索联想
struct SearchMagicListModel: Codable {
    var current_page: Int?
    var data: [SearchMagicKeyModel]?
}

struct SearchMagicKeyModel: Codable {
    var id: Int?
    var title: String?
}
