//
//  PresentPlayController.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/3.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import DouYPlayer

/// 模态出来的播放页面
class PresentPlayController: UIViewController {

    var currentIndex:Int = 0
    var currentPlayIndex: Int = 0
    
    var urls = [String]()
    
    lazy var screenScaleBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "icon_home_comment"), for: .normal)
        button.addTarget(self, action: #selector(screenScaleSizeChange(_:)), for: .touchUpInside)
        button.isHidden = true
        return button
    }()
    lazy var playerView: NicooPlayerView = {
        let player = NicooPlayerView(frame: view.bounds, bothSidesTimelable: true)
        player.videoLayerGravity = .resizeAspect
        player.videoNameShowOnlyFullScreen = true
        player.delegate = self
        player.customViewDelegate = self
        return player
    }()
    
    lazy var leftBackButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "navBackWhite"), for: .normal)
        button.backgroundColor = UIColor(white: 0.9, alpha: 0.2)
        button.layer.cornerRadius = 17.5
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(backButtonClick), for: .touchUpInside)
        return button
    }()
    
    let flowLayout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        //每个Item之间最小的间距
        layout.minimumInteritemSpacing = 0
        //每行之间最小的间距
        layout.minimumLineSpacing = 0
        return layout
    }()
    
    lazy var collection: UICollectionView = {
        let collectionView = UICollectionView(frame: view.bounds, collectionViewLayout: flowLayout)
        collectionView.backgroundColor = UIColor.clear
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.scrollsToTop = false
        collectionView.register(PresentPlayCell.classForCoder(), forCellWithReuseIdentifier: PresentPlayCell.cellId)
        return collectionView
    }()
    /// 点击去充值按钮
    var goVerbOrRefreshActionhandler:((_ goVerb: Bool) -> Void)?
    
    var isRefreshOperation = false
    var isFirstIn = true
    var viewModelForPlay: VideoViewModel!
    private let userInfoViewModel = UserInfoViewModel()
    private let videoViewModel = VideoViewModel()
    
    deinit {
        print("release ---- PresentPlayVC")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(white: 0, alpha: 0.3)
        setUpUI()
        collection.scrollToItem(at: IndexPath.init(item: currentIndex, section: 0), at: .top, animated: false)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if currentIndex > viewModelForPlay.getVideoList().count - 4 {
            viewModelForPlay.loadNextPage()
        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        playerView.playerStatu = PlayerStatus.Pause
    }
    
    private func setUpUI() {
        view.addSubview(collection)
        if #available(iOS 11.0, *) {
            collection.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        view.addSubview(leftBackButton)
        view.addSubview(screenScaleBtn)
        layoutPageSubviews()
    }
    
    @objc func screenScaleSizeChange(_ sender: UIButton) {
        if playerView.videoLayerGravity == .resizeAspect {
            playerView.videoLayerGravity = .resize
        } else if playerView.videoLayerGravity == .resize {
            playerView.videoLayerGravity = .resizeAspect
        }
    }
    
    @objc func backButtonClick() {
        self.dismiss(animated: true, completion: nil)
    }

}


// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension PresentPlayController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModelForPlay.getVideoList().count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PresentPlayCell.cellId, for: indexPath) as! PresentPlayCell
        cell.backgroundColor = UIColor.darkText
        let models = viewModelForPlay.getVideoList()
        if models.count > indexPath.row {
            let videoModel = models[indexPath.row]
            cell.imageBackGroup.kfSetHeaderImageWithUrl(videoModel.cover_path, placeHolder: nil)
            cell.introLable.text = videoModel.title ?? ""
            cell.commentItem.msgLable.text = getStringWithNumber(videoModel.comment_count ?? 0)
            cell.favorLable.text =  getStringWithNumber(videoModel.recommend_count ?? 0)
            cell.favorBtn.dyState = (videoModel.recommend?.isFavor ?? false) ? DYButton.DYButtonState.selected : DYButton.DYButtonState.cancel
            if let keyModels = videoModel.keys, keyModels.count > 0 {
                if let keyTitle = keyModels[0].title , keyTitle.count > 2 {
                    let subTitle =  (keyTitle as NSString).substring(to: 1)
                    cell.seriesButton.setTitle(subTitle, for: .normal)
                } else {
                     cell.seriesButton.setTitle(keyModels[0].title ?? "系列", for: .normal)
                }
    
            }
            /// 第一次进入，播放第currentIndex条
            if indexPath.row == currentIndex && isFirstIn {
                self.playVideo(video: models[currentIndex], cell: cell, indexPath: indexPath)
            }
        }
        cell.commentItemClick = { [weak self] in
            let commentVC = CommentsController()
            commentVC.videoId = self?.viewModelForPlay.videoList[indexPath.row].id ?? 0
            commentVC.modalPresentationStyle = .overCurrentContext
            commentVC.definesPresentationContext = true
            commentVC.view.backgroundColor = UIColor(white: 0.0, alpha: 0.4)
            self?.present(commentVC, animated: true, completion: nil)
        }
        cell.shareItemClick = { [weak self] in
            self?.share()
        }
        cell.videoFavorItemClick = { [weak self] (isFavor) in
            guard let strongSelf = self else { return  0 }
            strongSelf.userInfoViewModel.addVideoFavor([UserFavorAddApi.kVideo_id: models[indexPath.row].id ?? 0, UserFavorAddApi.kStatus: isFavor ? 0 : 1, UserFavorAddApi.kAction: UserFavorAddApi.kDefaultAction])
            if let appraiseCount = strongSelf.viewModelForPlay.getVideoList()[indexPath.row].recommend_count {
                let favorCount = isFavor ?  appraiseCount - 1 : appraiseCount + 1
                strongSelf.viewModelForPlay.videoList[indexPath.row].recommend_count = favorCount
                strongSelf.viewModelForPlay.videoList[indexPath.row].recommend = Recommend(rawValue: isFavor ? 0 : 1)
                return favorCount
            }
            return 0
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
    }
}


// MARK: - UICollectionViewDelegateFlowLayout
extension PresentPlayController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return UIScreen.main.bounds.size;
    }
}

// MARK: - play video
extension PresentPlayController {
    private func playVideo(video: VideoModel, cell: PresentPlayCell, indexPath: IndexPath) {
        videoViewModel.loadVideoAuthData(params: [VideoAuthApi.kVideo_id: video.id ?? 0], succeedHandler: { [weak self] in
            guard let strongSelf = self else { return }
            cell.startLoadingPlayItemAnim(true)
            let urlstrMp4 = video.play_url_mp4
            if let urlStrM3u8 = video.play_url_m3u8, !urlStrM3u8.isEmpty {
                let url = URL(string: urlStrM3u8)
                strongSelf.playerView.video_id = video.id
                strongSelf.playerView.isNotPermission = false
                strongSelf.playerView.playVideo(url, "", cell.imageBackGroup)
            } else {
                let url = URL(string: urlstrMp4 ?? "")
                strongSelf.playerView.video_id = video.id
                strongSelf.playerView.isNotPermission = false
                strongSelf.playerView.playVideo(url, "", cell.imageBackGroup)
            }
            
            strongSelf.isFirstIn = false
            strongSelf.currentPlayIndex = strongSelf.currentIndex
            
        }) { [weak self] (errorMsg) in
            guard let strongSelf = self else { return }
            cell.startLoadingPlayItemAnim(true)
            if errorMsg == "403" {
                strongSelf.playerView.isNotPermission = true
                strongSelf.playerView.playVideo(URL(string: "http://123.mp4"), "", cell.imageBackGroup)
                strongSelf.playerView.showLoadedFailedView("noPermission", nil)
            } else {
                strongSelf.playerView.isNotPermission = false
                strongSelf.playerView.playVideo(URL(string: "http://123.mp4"), "", cell.imageBackGroup)
            }
            strongSelf.isFirstIn = false
            strongSelf.currentPlayIndex = strongSelf.currentIndex
        }
    }
    
}

// MARK: - UIScrollViewDelegate
extension PresentPlayController: UIScrollViewDelegate {
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        DispatchQueue.main.async {
            /// 禁用手势
            let translatedPoint = scrollView.panGestureRecognizer.translation(in: scrollView)
            scrollView.panGestureRecognizer.isEnabled = false
            
            if translatedPoint.y < -50 && self.currentIndex < (self.viewModelForPlay.getVideoList().count - 1) {
                /// 上滑
                self.currentIndex += 1
            }
            if translatedPoint.y > 50 && self.currentIndex > 0 {
                /// 下滑
                self.currentIndex -= 1
            }
            if self.currentIndex == self.viewModelForPlay.sourceCount - 1 && self.viewModelForPlay.getVideoList().count > self.viewModelForPlay.sourceCount {
                self.collection.reloadData()
                self.viewModelForPlay.sourceCount = self.viewModelForPlay.getVideoList().count
            }
            let indexPath = IndexPath(row: self.currentIndex, section: 0)
            UIView.animate(withDuration: 0.15, delay: 0.0, options: .curveEaseOut, animations: {
                if self.viewModelForPlay.getVideoList().count > indexPath.row {
                    self.collection.scrollToItem(at: indexPath, at: .top, animated: true)
                }
            }, completion: { finished in
                scrollView.panGestureRecognizer.isEnabled = true
                if let cell = self.collection.cellForItem(at: indexPath) as? PresentPlayCell {
                    if self.currentPlayIndex != self.currentIndex { // 上下滑
                        //先移除动画
                        cell.startLoadingPlayItemAnim(false)
                        self.playVideo(video: self.viewModelForPlay.getVideoList()[indexPath.row], cell: cell, indexPath: indexPath)
                    }
                }
                if self.currentIndex == self.viewModelForPlay.getVideoList().count - 4 {
                    print("给您补给数据。。， ")
                    self.viewModelForPlay.loadNextPage()
                    // 这里先不刷新
                }
            })
        }
    }
}


// MARK: - NicooPlayerDelegate
extension PresentPlayController: NicooPlayerDelegate, NicooCustomMuneDelegate {
    
    func customActionForPalyer(_ player: NicooPlayerView, _ resUnavailable: Bool) {
        if resUnavailable {
            goVerbOrRefreshActionhandler?(false)
            self.dismiss(animated: true, completion: nil)
        } else {
            // 跳转到,
            goVerbOrRefreshActionhandler?(true)
            self.dismiss(animated: false, completion: nil)
        }
    }
    
    func retryToPlayVideo(_ player: NicooPlayerView, _ videoModel: NicooVideoModel?, _ fatherView: UIView?) {
        print("网络不可用时调用")
        let url = URL(string: videoModel?.videoUrl ?? "")
        if  let sinceTime = videoModel?.videoPlaySinceTime, sinceTime > 0 {
            player.replayVideo(url, videoModel?.videoName, fatherView, sinceTime)
        } else {
            player.playVideo(url, videoModel?.videoName, fatherView)
        }
    }
    
    func showOrHideLoadingview(_ isPlayingOrFailed: Bool) {
        let indexPath = IndexPath(row: self.currentIndex, section: 0)
        if let cell = collection.cellForItem(at: indexPath) as? PresentPlayCell {
            cell.startLoadingPlayItemAnim(!isPlayingOrFailed)
        }
    }
    
}

// MARK: - Layout
private extension PresentPlayController {
    
    func layoutPageSubviews() {
        layoutLeftBackButton()
        layoutScaleChangeBtn()
    }
    
    func layoutScaleChangeBtn() {
        screenScaleBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-20)
            make.top.equalTo(80)
            make.width.height.equalTo(50)
        }
    }
    
    func layoutLeftBackButton() {
        leftBackButton.snp.makeConstraints { (make) in
            make.leading.equalTo(16)
            make.top.equalTo(ConstValue.kStatusBarHeight + 10)
            make.width.height.equalTo(35)
        }
    }
}
