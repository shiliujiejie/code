//
//  PresentPlayCell.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/4.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

class PresentPlayCell: UICollectionViewCell {
    
    static let cellId = "PresentPlayCell"
    
    let imageBackGroup: UIImageView = {
        let imageView = UIImageView()
        imageView.isUserInteractionEnabled = true
        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = UIColor.clear
        return imageView
    }()
    let imagePlace: UIImageView = {
        let imageView = UIImageView()
        imageView.isUserInteractionEnabled = true
        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = UIColor(red: 17/255.0, green: 19/255.0, blue: 27/255.0, alpha: 0.99)
        imageView.image = UIImage(named: "placeholderV")
        return imageView
    }()
    // 加载
    var playerStatusBar: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.clear
        view.isHidden = true
        return view
    }()
    /// Right  Side  Menus
    lazy var favorBtn: DYButton = {
        let button = DYButton(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
        button.addTarget(self, action: #selector(favorCurrentVideo(_:)), for: .touchUpInside)
        return button
    }()
    lazy var favorLable: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .center
        lable.textColor = UIColor.white
        lable.font = UIFont.systemFont(ofSize: 12)
        lable.text = "34.4w"
        return lable
    }()
    lazy var commentItem: DYControltem = {
        let item = DYControltem(frame: CGRect.zero)
        return item
    }()
    lazy var shareItem: DYControltem = {
        let item = DYControltem(frame: CGRect.zero)
        return item
    }()
    lazy var seriesButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("Ser", for: .normal)
        button.setTitleColor(UIColor.darkGray, for: .normal)
        button.layer.cornerRadius = 25
        button.backgroundColor = ConstValue.kIconBgColor
        button.setTitleColor(ConstValue.kTitleYelloColor, for: .normal)
        button.layer.masksToBounds = true
        button.layer.borderColor = UIColor.lightGray.cgColor
        button.layer.borderWidth = 1.0
        button.addTarget(self, action: #selector(showDetailsAction(_:)), for: .touchUpInside)
        return button
    }()
    lazy var seriesAddButton: UIButton = {
        let button = UIButton(type: .custom)
        button.backgroundColor = UIColor.clear
        button.setImage(UIImage(named: "VideoSeriesAdd"), for: .normal)
        button.layer.cornerRadius = 11
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(showDetailsAction(_:)), for: .touchUpInside)
        return button
    }()
    /// Left Side Menus
    lazy var nameLable: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .left
        lable.textColor = UIColor.white
        lable.font = UIFont.systemFont(ofSize: 16)
        return lable
    }()
    lazy var introLable: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .left
        lable.numberOfLines = 2
        lable.textColor = UIColor(white: 1, alpha: 0.8)
        lable.font = UIFont.systemFont(ofSize: 14)
        lable.text = ""
        return lable
    }()
    
    var commentItemClick:(() -> Void)?
    var shareItemClick:(() -> Void)?
    var videoFavorItemClick:((_ isFavor: Bool) -> Int)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
   
    //MARK: Private
    
    func setUpUI() {
        contentView.addSubview(imageBackGroup)
        contentView.insertSubview(imagePlace, at: 0)
        contentView.addSubview(playerStatusBar)
        contentView.addSubview(favorLable)
        contentView.addSubview(favorBtn)
        contentView.addSubview(shareItem)
        contentView.addSubview(commentItem)
        contentView.addSubview(seriesButton)
        contentView.addSubview(seriesAddButton)
        contentView.addSubview(introLable)
        contentView.addSubview(nameLable)
        layoutPageSubviews()
        configItems()
    }
    
    func configItems() {
        shareItem.iconImage = "icon_home_share"
        shareItem.title =  "分享"
        commentItem.iconImage = "icon_home_comment"
        commentItem.title = ""
        shareItem.itemClickHandle = { [weak self] in
            self?.shareItemClick?()
        }
        commentItem.itemClickHandle = { [weak self] in
            self?.commentItemClick?()
        }
    }
    
    //MARK: Action
    
    @objc func showDetailsAction(_ sender: Any) {
        
    }
    
    @objc func favorCurrentVideo(_ sender: DYButton) {
        if sender.dyState == .cancel {
            print("不喜欢这个Video")
            let appriseCount = videoFavorItemClick?(true)
            favorLable.text = "\(appriseCount ?? 0)"
        }
        if sender.dyState == .selected {
            print("喜欢这个Video")
            let appriseCount = videoFavorItemClick?(false)
            favorLable.text = "\(appriseCount ?? 0)"
        }
    }
    
    func startLoadingPlayItemAnim(_ isStart: Bool = true) {
        if isStart {
            playerStatusBar.backgroundColor = UIColor.orange
            playerStatusBar.isHidden = false
            playerStatusBar.layer.removeAllAnimations()
            
            let animationGroup = CAAnimationGroup()
            animationGroup.duration = 0.85
            animationGroup.beginTime = CACurrentMediaTime()
            animationGroup.repeatCount = .infinity
            animationGroup.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
            
            let scaleAnimX = CABasicAnimation()
            scaleAnimX.keyPath = "transform.scale.x"
            scaleAnimX.fromValue = 1.0
            scaleAnimX.toValue = 10.0 * UIScreen.main.bounds.width
            
            let scaleAnimY = CABasicAnimation()
            scaleAnimY.keyPath = "transform.scale.y"
            scaleAnimY.fromValue = 1.0
            scaleAnimY.toValue = 0.2
            
            let alphaAnim = CABasicAnimation()
            alphaAnim.keyPath = "opacity"
            alphaAnim.fromValue = 1.0
            alphaAnim.toValue = 0.35
            
            animationGroup.animations = [scaleAnimX, scaleAnimY, alphaAnim]
            playerStatusBar.layer.add(animationGroup, forKey: nil)
        } else {
            playerStatusBar.layer.removeAllAnimations()
            playerStatusBar.isHidden = true
        }
        
    }
    
    override public func layoutSubviews() {
        super.layoutSubviews()
        playerStatusBar.frame = CGRect(x: self.bounds.midX - 0.5, y: self.bounds.maxY - 48 - safeAreaBottomHeight, width: 0.1, height: 2.0)
    }
    
}

// MARK: - layout
private extension PresentPlayCell {
    
    func layoutPageSubviews() {
        layoutImagePlace()
        layoutImageBackground()
        layoutShareItem()
        layoutCommentItem()
        layoutFavorLable()
        layoutFavorButton()
        layoutSeriesButton()
        layoutIntrolLable()
        layoutNameLable()
    }
    
    func layoutImageBackground() {
        imageBackGroup.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    func layoutImagePlace() {
        imagePlace.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    func layoutFavorButton() {
        favorBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-13)
            make.bottom.equalTo(favorLable.snp.top)
            make.width.height.equalTo(50)
        }
    }
    func layoutFavorLable() {
        favorLable.snp.makeConstraints { (make) in
            make.centerX.equalTo(commentItem)
            make.bottom.equalTo(commentItem.snp.top).offset(-10)
            make.height.equalTo(20)
            make.width.equalTo(60)
        }
    }
    
    func layoutSeriesButton() {
        seriesButton.snp.makeConstraints { (make) in
            make.trailing.equalTo(-12)
            make.bottom.equalTo(favorBtn.snp.top).offset(-25)
            make.width.height.equalTo(50)
        }
        seriesAddButton.snp.makeConstraints { (make) in
            make.centerX.equalTo(seriesButton)
            make.centerY.equalTo(seriesButton.snp.bottom)
            make.width.height.equalTo(22)
        }
    }
    
    func layoutCommentItem() {
        commentItem.snp.makeConstraints { (make) in
            make.trailing.equalTo(-10)
            make.bottom.equalTo(shareItem.snp.top).offset(-10)
            make.width.equalTo(50)
            make.height.equalTo(60)
        }
    }
    
    func layoutShareItem() {
        shareItem.snp.makeConstraints { (make) in
            make.trailing.equalTo(-10)
            make.bottom.equalTo(-(115 + safeAreaBottomHeight))
            make.width.equalTo(50)
            make.height.equalTo(60)
        }
    }
    
    func layoutIntrolLable() {
        introLable.snp.makeConstraints { (make) in
            make.leading.equalTo(10)
            make.centerY.equalTo(shareItem)
            make.trailing.equalTo(shareItem.snp.leading).offset(-40)
            make.height.equalTo(45)
        }
    }
    
    func layoutNameLable() {
        nameLable.snp.makeConstraints { (make) in
            make.leading.equalTo(introLable)
            make.bottom.equalTo(introLable.snp.top)
            make.height.equalTo(25)
            make.trailing.equalTo(introLable)
        }
    }
    
}
