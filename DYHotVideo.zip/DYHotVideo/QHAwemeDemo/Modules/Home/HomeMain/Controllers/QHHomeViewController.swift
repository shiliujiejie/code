//
//  QHHomeViewController.swift
//  QHAwemeDemo
//
//  Created by Anakin chen on 2017/10/16.
//  Copyright © 2017年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import SnapKit
import MJRefresh
import DouYPlayer
import AVFoundation

class QHHomeViewController: QHBaseViewController, UICollectionViewDelegateFlowLayout, UICollectionViewDataSource {
   
    var currentIndex:Int = 0
    var currentPlayIndex: Int = 0
    //var sourceCount: Int = 0
    
    lazy var screenScaleBtn: UIButton = {
        let button = UIButton(type: .custom)
       // button.setImage(UIImage(named: "icon_home_comment"), for: .normal)
        button.setTitle(UserModel.share().userInfo?.channel?.title ?? "默认线路", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        button.addTarget(self, action: #selector(channelsChange(_:)), for: .touchUpInside)
       // button.isHidden = true
        return button
    }()
    lazy var arrowBtn: UIButton = {
        let button = UIButton(type: .custom)
         button.setImage(UIImage(named: "mainLineArrow"), for: .normal)
        button.setImage(UIImage(named: "mainLineArrow_S"), for: .selected)
        button.addTarget(self, action: #selector(channelsChange(_:)), for: .touchUpInside)
        // button.isHidden = true
        return button
    }()
    private let adTimerlabel: UILabel = {
        let lab = UILabel()
        lab.text = "广告时间，3秒后可操作"
        lab.textColor = UIColor.white
        lab.font = UIFont.systemFont(ofSize: 15)
        lab.backgroundColor = UIColor(white: 0.1, alpha: 0.5)
        lab.layer.cornerRadius = 15
        lab.layer.masksToBounds = true
        lab.textAlignment = .center
        lab.isHidden = true
        return lab
    }()
    lazy var playerView: NicooPlayerView = {
        let player = NicooPlayerView(frame: view.bounds, bothSidesTimelable: true)
        player.videoLayerGravity = .resizeAspect
        player.videoNameShowOnlyFullScreen = true
        player.delegate = self
        player.customViewDelegate = self
        return player
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        let loadmore = MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.viewModel.loadNextPage()
        })
        loadmore?.setTitle("", for: .idle)
        loadmore?.setTitle("", for: .pulling)
        loadmore?.setTitle("", for: .noMoreData)
        return loadmore!
    }()
   
    private let viewModel = VideoViewModel()
    private let userInfoViewModel = UserInfoViewModel()
    private let registerViewModel = RegisterLoginViewModel()
    
    var isRefreshOperation = false
    
    var isFirstIn = true
    
    var timer: Timer!
    var timer1: Timer?
    var adtime: Int = 3
    
    @IBOutlet weak var mainCV: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        NotificationCenter.default.addObserver(self, selector: #selector(didUserBeenKickedOut), name: Notification.Name.kUserBeenKickedOutNotification, object: nil)
        setUpUI()
        addViewModelCallBack()
        loadData()
        loadAdInfoApi()
        /// 延迟三秒弹起。版本更新框
        perform(#selector(checkAppVersionInfo), with: nil, afterDelay: 3)
        NotificationCenter.default.addObserver(self, selector: #selector(applicationResignActivity(_:)), name: UIApplication.willResignActiveNotification, object: nil)
        /// 进入App后屏幕保持常亮
        UIApplication.shared.isIdleTimerDisabled = true
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        playerView.playerStatu = PlayerStatus.Playing
        /// 新手奖励
        showNewUserSatisfyAlert()
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        playerView.playerStatu = PlayerStatus.Pause
    }
    
    // 掉线提醒
    @objc private func didUserBeenKickedOut() {
        DLog("didUserBeenKickedOut  ===== Main")
        if let delegate = UIApplication.shared.delegate as? AppDelegate {
            delegate.window?.rootViewController?.showDialog(title: "被挤掉提示", message: XSAlertMessages.kNotAvailTokenAlertMsg, okTitle: "确认", cancelTitle: "取消", okHandler: {
                self.goAndUpdate(ConstValue.kAppDownLoadLoadUrl)
            }, cancelHandler: nil)
        }
    }
    
    //MARK: - Actions
    /// - 切换线路
    @objc func channelsChange(_ sender: UIButton) {
        arrowBtn.isSelected = true
        let mainLine = MainLineController()
        if let chanels = SystemMsg.share().videoChannels, chanels.count > 0 {
            for i in 0 ..< chanels.count {
                let channel = chanels[i]
                let line = LineModel(videoChannel: channel, isSelected: (channel.key ?? "") == (UserModel.share().userInfo?.channel?.key ?? ""))
                if line.isSelected {
                    mainLine.currentIndex = i
                }
                mainLine.lines.append(line)
            }
        } else {
            let channelUser = UserModel.share().userInfo?.channel
            if channelUser != nil {
                let line = LineModel(videoChannel: channelUser!, isSelected: true)
                mainLine.lines.append(line)
            } else {
                XSAlert.show(type: .error, text: "没有可用的线路。")
                return
            }
        }
        mainLine.dissMisssCallBack = {
            self.arrowBtn.isSelected = false
        }
        mainLine.successCallBack = {
            DLog("线路切换成功，当前线路：\(UserModel.share().userInfo?.channel?.title ?? "默认线路")")
            self.arrowBtn.isSelected = false
            self.screenScaleBtn.setTitle(UserModel.share().userInfo?.channel?.title ?? "默认线路", for: .normal)
            self.loadData()
        }
        mainLine.modalPresentationStyle = .overCurrentContext
        mainLine.definesPresentationContext = true
        mainLine.view.backgroundColor = UIColor(white: 0.0, alpha: 0.3)
        present(mainLine, animated: false, completion: nil)
    }
    
    @objc func applicationResignActivity(_ sender: NSNotification) {
        if GYCircleConst.getGestureWithKey(gestureFinalSaveKey) != nil {
            let gestureVC = GestureViewController()
            // 登录成功， 进入抖音
            gestureVC.lockLoginSuccess = {
                gestureVC.dismiss(animated: false, completion: nil)
            }
            gestureVC.type = GestureViewControllerType.login
            gestureVC.navBarHiden = true
            UIViewController.currentViewController()?.present(gestureVC, animated: false, completion: nil)
        }
    }
  
    //MARK: Private Funcs
    private func setUpUI() {
        //固定设置layut，或者通过UICollectionViewDelegateFlowLayout设置，这样可以动态调整
        if let layout = mainCV.collectionViewLayout as? UICollectionViewFlowLayout {
            //每个Item之间最小的间距
            layout.minimumInteritemSpacing = 0
            //每行之间最小的间距
            layout.minimumLineSpacing = 0
        }
        if #available(iOS 11.0, *) {
            mainCV.contentInsetAdjustmentBehavior = .never
        } else {
            self.automaticallyAdjustsScrollViewInsets = false
        }
        mainCV.scrollsToTop = false
        mainCV.isScrollEnabled = false
        mainCV.allowsSelection = true
        mainCV.mj_footer = loadMoreView
        view.addSubview(screenScaleBtn)
        view.addSubview(arrowBtn)
        view.addSubview(adTimerlabel)
        layoutPageSubviews()
    }
    
    /// 跳转到系列列表页面
    private func p_showDetails() {
        let currentModel = viewModel.getHomeList()[currentIndex]
        if (currentModel.type ?? .videoType) == .videoType {
            let videoModel = currentModel.video
            let vc = SeriesVideosController()
            vc.isSeriesVideo = true
            if let keyModels = videoModel?.keys, keyModels.count > 0 {
                vc.keyId = keyModels[0].key_id ?? 1
                vc.keys = keyModels
            }
            self.navigationController?.pushViewController(vc, animated: true)
        } else {
            /// 跳转到广告页面
            print("跳转到广告页面 === \(currentModel.ad?.redirect_url ?? "")")
            goAndUpdate(currentModel.ad?.redirect_url ?? "")
        }
    }
    
    private func getCurrentVC() -> QHRootScrollViewController? {
        var next = view.superview
        while (next != nil) {
            let nextResponder = next?.next
            if (nextResponder is QHRootScrollViewController) {
                return nextResponder as? QHRootScrollViewController
            }
            next = next?.superview
        }
        return nil
    }
    
    /// 是否禁用滑动跳转到系列
    private func isPanGuestureEnable(_ enable: Bool) {
        (self.navigationController as! QHNavigationController).pan?.isEnabled = enable
    }
    
    //MARK: - UICollectionViewDataSource
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.getHomeList().count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell : QHHomeCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: QHHomeCollectionViewCell.cellId, for: indexPath) as! QHHomeCollectionViewCell
        cell.backgroundColor = UIColor.darkText
        cell.selectedBackgroundView = UIView()
        cell.delegate = self
        let homeModels = viewModel.getHomeList()
        let homeModel = homeModels[indexPath.row]
        let isVideo = (homeModel.type ?? .videoType) == .videoType
        if isVideo {  /// 视频类型
            let videoModel = homeModel.video
            cell.bgImage.kfSetHeaderImageWithUrl(videoModel?.cover_path, placeHolder: nil)
            cell.introLable.text = videoModel?.title ?? ""
            cell.nameLable.text = ""
            cell.nameLable.isHidden = true
            cell.commentItem.msgLable.text = getStringWithNumber(videoModel?.comment_count ?? 0)
            cell.favorLable.text = getStringWithNumber(videoModel?.recommend_count ?? 0)
            cell.favorBtn.dyState = (videoModel?.recommend?.isFavor ?? false) ? .selected : .cancel
            if let keyModels = videoModel?.keys, keyModels.count > 0 {
                if let keyTitle = keyModels[0].title , keyTitle.count > 2 {
                    let subTitle =  (keyTitle as NSString).substring(to: 1)
                    cell.seriesButton.setTitle(subTitle, for: .normal)
                } else {
                    cell.seriesButton.setTitle(keyModels[0].title ?? "系列", for: .normal)
                }
            }
            cell.adClickButton.snp.updateConstraints { (make) in
                make.height.equalTo(0)
            }
            cell.adClickButton.isHidden = true
            cell.adCoverTap.isHidden = true
        } else { /// 广告
            let adModel = homeModel.ad
            cell.bgImage.kfSetHeaderImageWithUrl(adModel?.cover_path, placeHolder: nil)
            cell.nameLable.text = adModel?.title ?? ""
            cell.nameLable.isHidden = false
            cell.introLable.text = adModel?.remark ?? ""
            cell.commentItem.msgLable.text = getStringWithNumber(adModel?.comment_count ?? 0)
            cell.favorLable.text = getStringWithNumber(adModel?.recommend_count ?? 0)
            cell.favorBtn.dyState = (adModel?.recommend?.isFavor ?? false) ? .selected : .cancel
            cell.seriesButton.setTitle("广告", for: .normal)
            cell.adClickButton.snp.updateConstraints { (make) in
                make.height.equalTo(35)
            }
            cell.adClickButton.isHidden = false
            cell.adCoverTap.isHidden = false
        }
        
        /// 第一次进入，播放第一条
        if indexPath.row == 0 && isFirstIn {
            self.playVideo(homeModel: homeModels[0], cell: cell, indexPath: indexPath)
        }
        cell.adTapActionHandler = { [weak self] in
            let isAd = (homeModel.type ?? .videoType) == .adType
            if isAd {
                self?.goAndUpdate(homeModel.ad?.redirect_url ?? "")
            }
        }
        
        cell.commentItemClick = { [weak self] in
            let commentVC = CommentsController()
            if isVideo {
                commentVC.videoId = homeModel.video?.id ?? 0
            } else {
                commentVC.adId = homeModel.ad?.id ?? 0
            }
            commentVC.isAd = !isVideo
            commentVC.modalPresentationStyle = .overCurrentContext
            commentVC.definesPresentationContext = true
            commentVC.view.backgroundColor = UIColor(white: 0.0, alpha: 0.4)
            self?.present(commentVC, animated: true, completion: nil)
        }
        cell.shareItemClick = { [weak self] in
            self?.share()
        }
        cell.videoFavorItemClick = { [weak self] (isFavor) in
            guard let strongSelf = self else { return  0 }
            if isVideo {
                strongSelf.userInfoViewModel.addVideoFavor([UserFavorAddApi.kVideo_id: homeModel.video?.id ?? 0, UserFavorAddApi.kStatus: isFavor ? 0 : 1, UserFavorAddApi.kAction: UserFavorAddApi.kDefaultAction])
                if let appraiseCount = strongSelf.viewModel.getHomeList()[indexPath.row].video?.recommend_count {
                    let favorCount = isFavor ?  appraiseCount - 1 : appraiseCount + 1
                    strongSelf.viewModel.homeModels[indexPath.row].video?.recommend_count = favorCount
                    strongSelf.viewModel.homeModels[indexPath.row].video?.recommend = Recommend(rawValue: isFavor ? 0 : 1)
                    return favorCount
                }
            } else {
                strongSelf.userInfoViewModel.addAdFavor([UserAdFavorAddApi.kAd_id: homeModel.ad?.id ?? 0, UserAdFavorAddApi.kStatus: isFavor ? 0 : 1, UserAdFavorAddApi.kAction: UserAdFavorAddApi.kDefaultAction])
                if let appraiseCount = strongSelf.viewModel.getHomeList()[indexPath.row].ad?.recommend_count {
                    let favorCount = isFavor ?  appraiseCount - 1 : appraiseCount + 1
                    strongSelf.viewModel.homeModels[indexPath.row].ad?.recommend_count = favorCount
                    strongSelf.viewModel.homeModels[indexPath.row].ad?.recommend = Recommend(rawValue: isFavor ? 0 : 1)
                    return favorCount
                }
            }
            return 0
        }
        return cell
    }
    
    //MARK: - UICollectionViewDelegate
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return UIScreen.main.bounds.size
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        
    }
 
}

// MARK: - Show Alerts
private extension QHHomeViewController {
    
    /// 提示新手奖励
    func showNewUserSatisfyAlert() {
        let isShow = UserDefaults.standard.bool(forKey: UserDefaults.knewUserSatisfiedShow)
        if !isShow {
            let alertController = AlertManagerController(newUserCard: [AlertManagerController.kWelfCardString : "获得折扣福利卡一张", AlertManagerController.kWelfCardTiem : "快去优惠折扣中心查看吧。"])
            alertController.modalPresentationStyle = .overCurrentContext
            alertController.commitActionHandler = {
                self.perform(#selector(self.showAddPhoneAlert), with: nil, afterDelay: 1)
                UserDefaults.standard.set(true, forKey: UserDefaults.knewUserSatisfiedShow)
            }
            self.modalPresentationStyle = .currentContext
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    /// 账号丢失风险提示
    private func showServerWarningAlert() {
        let userPhone = UserModel.share().userInfo?.mobile
        if userPhone != nil && !userPhone!.isEmpty { // 已经绑定手机号
            return
        }
        let systemModel = SystemAlertModel.init(title: "亲爱的抖友们", englishTitle: "System Tips", msgInfo: "", tipsMsg: nil, commitTitle: "绑定手机", isLinkType: true)
        let controller = AlertManagerController(systemAlert: systemModel)
        controller.modalPresentationStyle = .overCurrentContext
        controller.commitActionHandler = { [weak self] in
            let verbPhone = VerbPhoneController()
            self?.navigationController?.pushViewController(verbPhone, animated: true)
        }
        self.modalPresentationStyle = .currentContext
        self.present(controller, animated: true, completion: nil)
    }
    
    /// 系统公告
    private func showSystemMsgAlert() {
        if let message = SystemMsg.share().systemMsgs, message.count > 0 {
            let controller = AlertManagerController(system: message)
            controller.modalPresentationStyle = .overCurrentContext
            controller.commitActionHandler = { [weak self] in
                self?.showServerWarningAlert()
            }
            controller.closeActionHandler = {
                self.showServerWarningAlert()
            }
            self.modalPresentationStyle = .currentContext
            self.present(controller, animated: true, completion: nil)
        } else {
            showServerWarningAlert()
        }
    }
    
    private func showHelpAlert() {
        let alert = UIAlertController.init(title: "提示(已安装点取消)", message: "近期苹果大量封杀成人视频，请务必安装修复文件，以便您能随时找回抖阴", preferredStyle: .alert)
        let actionOk = UIAlertAction.init(title: "安装助手", style: .default) { (action) in
            self.goAndUpdate(AppInfo.share().help_url)
        }
        let cancle = UIAlertAction.init(title: "取消", style: .cancel, handler: nil)
        alert.addAction(actionOk)
        alert.addAction(cancle)
        self.present(alert, animated: false, completion: nil)
    }
    
    /// 提示用户绑定手机号
    @objc func showAddPhoneAlert() {
        let alertController = AlertManagerController.init(addPhone: 3)
        alertController.modalPresentationStyle = .overCurrentContext
        alertController.commitActionHandler = {
            let verbPhoneVc = VerbPhoneController()
            self.navigationController?.pushViewController(verbPhoneVc, animated: true)
        }
        self.modalPresentationStyle = .currentContext
        self.present(alertController, animated: true, completion: nil)
    }
    
    
}

// MARK: - LoadData
private extension QHHomeViewController {
    
    /// 请求视频列表
    func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        if !viewModel.isRefreshOperation {
            if let delegate = UIApplication.shared.delegate as? AppDelegate {
                XSProgressHUD.showCustomAnimation(msg: nil, onView: delegate.window!, imageNames: nil, bgColor: nil, animated: false)
            }
        } else {
            viewModel.isRefreshOperation = false
        }
        viewModel.loadHomeData()
    }
    
    /// 请求并下载开屏广告
    func loadAdInfoApi() {
        registerViewModel.loadAdInfo()
    }
    
    /// 添加viewModel 数据请求回调
    func addViewModelCallBack() {
        viewModel.requestListSuccessHandle = { [weak self] in
            guard let strongSelf = self else { return }
            if let delegate = UIApplication.shared.delegate as? AppDelegate {
                XSProgressHUD.hide(for: delegate.window!, animated: true)
            }
            //XSProgressHUD.hide(for: strongSelf.view, animated: false)
            if strongSelf.currentIndex != 0 {
                strongSelf.mainCV.scrollToItem(at: IndexPath.init(item: 0, section: 0), at: .top, animated: false)
            }
            strongSelf.isFirstIn = true
            strongSelf.currentIndex = 0
            strongSelf.currentPlayIndex = 0
            strongSelf.mainCV.mj_footer.endRefreshing()
            //strongSelf.sourceCount = strongSelf.viewModel.getVideoList().count
            if strongSelf.viewModel.sourceCount > 0 {
                strongSelf.mainCV.isScrollEnabled = true
            }
            strongSelf.mainCV.reloadData()
        }
        viewModel.requestFailedHandle = { [weak self] (msg) in
            guard let strongSelf = self else { return }
            if let delegate = UIApplication.shared.delegate as? AppDelegate {
               XSProgressHUD.hide(for: delegate.window!, animated: true)
            }
            //XSProgressHUD.hide(for: strongSelf.view, animated: false)
            NicooErrorView.showErrorMessage(.noNetwork, on: strongSelf.view, clickHandler: {
                strongSelf.loadData()
            })
        }
    }
}

// MARK: - Show AppUpdateInfo
private extension QHHomeViewController {
    
    @objc func checkAppVersionInfo() {
        let appInfo = AppInfo.share()
        guard let versionNew = appInfo.version_code else { return }
        guard let numVersionNew = versionNew.removeAllPoints() else { return }
        guard let numVersionCurrent = getCurrentAppVersion().removeAllPoints() else { return }
        if Int(numVersionNew) != nil && Int(numVersionCurrent) != nil && Int(numVersionNew)! > Int(numVersionCurrent)! {
            let controller = AlertManagerController()
             controller.alertType = .updateInfo
            controller.modalPresentationStyle = .overCurrentContext
            controller.commitActionHandler = { [weak self] in
                self?.goAndUpdate(String(format: "%@", appInfo.package_path ?? ConstValue.kAppDownLoadLoadUrl))
            }
            controller.cancleActionHandler = { [weak self] in
                self?.goAndUpdate(String(format: "%@", appInfo.official_url ?? ConstValue.kAppDownLoadLoadUrl))
            }
            self.modalPresentationStyle = .currentContext
            self.present(controller, animated: true, completion: nil)
        } else {
            let isShow = UserDefaults.standard.bool(forKey: UserDefaults.knewUserSatisfiedShow)
            if isShow {
                showSystemMsgAlert()
                showHelpAlert()
            }
        }
    }
    
    func getCurrentAppVersion() -> String {
        let filePath = Bundle.main.path(forResource: "Info", ofType: "plist")
        let dictionary = NSDictionary(contentsOfFile: filePath!)
        return dictionary!["CFBundleShortVersionString"] as! String
    }
    
    func goAndUpdate(_ downLoadUrl: String?) {
        if let urlstring = downLoadUrl {
            let downUrl = String(format: "%@", urlstring)
            if let url = URL(string: downUrl) {
                DLog(downUrl)
                if #available(iOS 10, *) {
                    UIApplication.shared.open(url, options: [:],
                                              completionHandler: {
                                                (success) in
                    })
                } else {
                    UIApplication.shared.openURL(url)
                }
            }
        }
    }
}

// MARK: - play video
extension QHHomeViewController {
    
    private func playVideo(homeModel: HomeVideoModel, cell: QHHomeCollectionViewCell, indexPath: IndexPath) {
        if (homeModel.type ?? .videoType) == .videoType {
                /// 这里让那个播放器的进度条可以操作
            self.playerView.timeProgressEnabled(true)
            //isPanGuestureEnable(true)
            let video = homeModel.video
            videoTypeConfig(video: video, cell: cell)
        } else {
            self.playerView.timeProgressEnabled(false)
            //isPanGuestureEnable(false)
            let adModel = homeModel.ad
            adTypeConfig(adModel: adModel, cell: cell)
        }
    }
    
    private func videoTypeConfig(video: VideoModel?, cell: QHHomeCollectionViewCell) {
        viewModel.loadVideoAuthData(params: [VideoAuthApi.kVideo_id: video?.id ?? 0], succeedHandler: { [weak self] in
            guard let strongSelf = self else { return }
            cell.startLoadingPlayItemAnim(true)
            let urlstrMp4 = video?.play_url_mp4
            if let urlStrM3u8 = video?.play_url_m3u8, !urlStrM3u8.isEmpty {
                let url = URL(string: urlStrM3u8)
                strongSelf.playerView.video_id = video?.id
                strongSelf.playerView.isNotPermission = false
                strongSelf.playerView.playVideo(url, "", cell.bgImage)
            } else {
                let url = URL(string: urlstrMp4 ?? "")
                strongSelf.playerView.video_id = video?.id
                strongSelf.playerView.isNotPermission = false
                strongSelf.playerView.playVideo(url, "", cell.bgImage)
            }
            strongSelf.isFirstIn = false
            strongSelf.currentPlayIndex = strongSelf.currentIndex
            
        }) { [weak self] (errorMsg) in
            guard let strongSelf = self else { return }
            cell.startLoadingPlayItemAnim(true)
            if errorMsg == "403" {
                strongSelf.playerView.isNotPermission = true
                strongSelf.playerView.playVideo(URL(string: "http://123.mp4"), "", cell.bgImage)
                strongSelf.playerView.showLoadedFailedView("noPermission", nil)
            } else {
                strongSelf.playerView.isNotPermission = false
                strongSelf.playerView.playVideo(URL(string: "http://123.mp4"), "", cell.bgImage)
            }
            strongSelf.isFirstIn = false
            strongSelf.currentPlayIndex = strongSelf.currentIndex
        }
    }
    
    private func adTypeConfig(adModel: AdvertiseModel?, cell: QHHomeCollectionViewCell) {
        cell.startLoadingPlayItemAnim(true)
        mainCV.isScrollEnabled = false
        print("看广告了")
        adTimerlabel.isHidden = false
        timer = Timer.new(after: 3.seconds) { [weak self] in
            print("可以开始滑了")
            self?.mainCV.isScrollEnabled = true
            self?.timer1?.invalidate()
            self?.adTimerlabel.isHidden = true
            self?.adtime = 3
            self?.adTimerlabel.text = "广告时间，\(self?.adtime ?? 3 )秒后可操作"
        }
        timer1 = Timer.every(1.0.seconds) { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.adtime = strongSelf.adtime - 1
            self?.adTimerlabel.text = "广告时间，\(strongSelf.adtime)秒后可操作"
        }
       
        RunLoop.current.add(timer, forMode: .default)
        if let urlStrM3u8 = adModel?.play_url_m3u8, !urlStrM3u8.isEmpty {
            let url = URL(string: urlStrM3u8)
            self.playerView.isNotPermission = false
            self.playerView.playVideo(url, "", cell.bgImage)
        } else {
            self.playerView.isNotPermission = false
            self.playerView.playVideo(URL(string: "http://123.mp4"), "", cell.bgImage)
        }
        self.isFirstIn = false
        self.currentPlayIndex = self.currentIndex
    }
    
}

// MARK: - UIGestureRecognizerDelegate
extension QHHomeViewController: UIGestureRecognizerDelegate {
    
    func showDetails(_ view: QHHomeCollectionViewCell) {
        /// 如果要让广告的滑动不起效， 可以在这里拦截掉， 不走 p_showDetails
        if viewModel.getHomeList().count > 0 {
             p_showDetails()
        }
    }
    
}

// MARK: - QHHomeCollectionViewCellDelegate
extension QHHomeViewController: QHHomeCollectionViewCellDelegate {
    
    func sliderTouch(_ isTouch: Bool) {
        if let vc = getCurrentVC() {
            vc.mainScrollV.isScrollEnabled = !isTouch
            (self.navigationController as! QHNavigationController).pan?.isEnabled = !isTouch
        }
    }
    
    func showDetails() {
        if viewModel.getHomeList().count > 0 {
            p_showDetails()
        }
    }
}

// MARK: - UIScrollViewDelegate
extension QHHomeViewController: UIScrollViewDelegate {
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        DispatchQueue.main.async {
            /// 禁用手势
            let translatedPoint = scrollView.panGestureRecognizer.translation(in: scrollView)
            scrollView.panGestureRecognizer.isEnabled = false
            
            if translatedPoint.y < -50 && self.currentIndex < (self.viewModel.getHomeList().count - 1) {
                /// 上滑
                self.currentIndex += 1
            }
            if translatedPoint.y > 50 && self.currentIndex > 0 {
                /// 下滑
                self.currentIndex -= 1
            }
            if self.currentIndex == self.viewModel.sourceCount - 1 && self.viewModel.getHomeList().count >  self.viewModel.sourceCount {
                self.mainCV.reloadData()
                self.viewModel.sourceCount = self.viewModel.getHomeList().count
            }
            let indexPath = IndexPath(row: self.currentIndex, section: 0)
            UIView.animate(withDuration: 0.15, delay: 0.0, options: .curveEaseOut, animations: {
                self.mainCV.scrollToItem(at: indexPath, at: .top, animated: true)
            }, completion: { finished in
                scrollView.panGestureRecognizer.isEnabled = true
                if let cell = self.mainCV.cellForItem(at: indexPath) as? QHHomeCollectionViewCell {
                    if self.currentPlayIndex != self.currentIndex { // 上下滑动
                        cell.startLoadingPlayItemAnim(false)
                        self.playVideo(homeModel: self.viewModel.getHomeList()[indexPath.row], cell: cell, indexPath: indexPath)
                    }
                }
                if self.currentIndex == self.viewModel.getHomeList().count - 4 {
                    DLog("给您补给数据。。， ")
                    self.viewModel.loadHomeDataNextPage()
                    // 这里先不刷新
                }
            })
        }
    }
}

// MARK: - NicooPlayerDelegate

extension QHHomeViewController: NicooPlayerDelegate, NicooCustomMuneDelegate {
    
    func retryToPlayVideo(_ player: NicooPlayerView, _ videoModel: NicooVideoModel?, _ fatherView: UIView?) {
        DLog("网络不可用时调用")
        let url = URL(string: videoModel?.videoUrl ?? "")
        if  let sinceTime = videoModel?.videoPlaySinceTime, sinceTime > 0 {
            player.replayVideo(url, videoModel?.videoName, fatherView, sinceTime)
        } else {
            player.playVideo(url, videoModel?.videoName, fatherView)
        }
    }
    
    func customActionForPalyer(_ player: NicooPlayerView, _ resUnavailable: Bool) {
        if resUnavailable {
            self.loadData()
        } else {
            // 跳转到
            let vipVC = VipCardsController()
            navigationController?.pushViewController(vipVC, animated: true)
        }
    }
    
    func showOrHideLoadingview(_ isPlayingOrFailed: Bool) {
        let indexPath = IndexPath(row: self.currentIndex, section: 0)
        if let cell = self.mainCV.cellForItem(at: indexPath) as? QHHomeCollectionViewCell {
            cell.startLoadingPlayItemAnim(!isPlayingOrFailed)
        }
    }
    
    func enableScrollAndPanGestureOrNoteWith(isEnable: Bool) {
       // (self.navigationController as! QHNavigationController).pan?.isEnabled = isEnable
//        if let vc = getCurrentVC() {
//            vc.mainScrollV.isScrollEnabled = isEnable
//        }
    }
    
}

// MARK: - Layout
private extension QHHomeViewController {
    
    func layoutPageSubviews() {
        layoutScaleChangeBtn()
        layoutArrowBtn()
        layoutAdTimerLable()
    }
    
    func layoutScaleChangeBtn() {
        screenScaleBtn.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(ConstValue.kStatusBarHeight + 8)
            make.height.equalTo(30)
        }
    }
    
    func layoutArrowBtn() {
        arrowBtn.snp.makeConstraints { (make) in
            make.leading.equalTo(screenScaleBtn.snp.trailing).offset(5)
            make.centerY.equalTo(screenScaleBtn)
        }
    }
    func layoutAdTimerLable() {
        adTimerlabel.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.top.equalTo(ConstValue.kStatusBarHeight + 50)
            make.height.equalTo(30)
            make.width.equalTo(180)
        }
    }
}
