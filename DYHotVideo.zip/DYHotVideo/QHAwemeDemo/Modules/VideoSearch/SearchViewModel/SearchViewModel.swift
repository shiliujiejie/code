//
//  SearchViewModel.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/10.
//  Copyright © 2019年 pro5. All rights reserved.
//

import UIKit
import NicooNetwork

/// 搜索ViewModel
class SearchViewModel: NSObject {

    /// 每个区的数据类型
    enum SectionType {
        case videoList      // 热搜列表
        case hisSearchLis     // 历史搜所
    }
    
    private lazy var hotListApi: VideoListApi = {
        let api = VideoListApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    
    var sectionItem = [[AnyObject]]()
    
    var videoList: [VideoModel]?
    var historyList: [String]?
    
    var loadDataCallBack:(() -> Void)?
    
    func loadHotSearchList() {
        loadHistSearchList()
        let _ = hotListApi.loadData()
    }
   
}

// MARK: - Privite Funcs
extension SearchViewModel {
    
    private func loadHistSearchList () {
        if let hisList = UserDefaults.standard.array(forKey: UserDefaults.kSearchHistory) as? [String], hisList.count > 0 {
            historyList = hisList
            sectionItem.append(hisList as [AnyObject])
        }
        loadDataCallBack?()
    }
    
    private func loadListDataSuccess(_ listModel: VideoListModel) {
        if let list = listModel.data, list.count > 0 {
            videoList = list
            sectionItem.append(list as [AnyObject])
        }
    }
    
    private func loadListDataFail() {
        loadDataCallBack?()
    }
    
    func getSectionCount() -> Int {
        return sectionItem.count
    }
    
    func getSectionType(_ index: Int) -> SectionType {
        if sectionItem[index] is [VideoModel] {
            return .videoList
        } else {
            return .hisSearchLis
        }
    }
    
    func getHistorySearchList() -> [String] {
        return historyList ?? [String]()
    }
    
    func getHotList() -> [VideoModel] {
        return videoList ?? [VideoModel]()
    }
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension SearchViewModel: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        var params = [String: Any]()
        params[VideoListApi.kPlay_count] = "desc"
        params[VideoListApi.kPageCount] = 8
        return params
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        if let list = manager.fetchJSONData(VideoReformer()) as? VideoListModel {
            loadListDataSuccess(list)
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        loadListDataFail()
    }
    
}
