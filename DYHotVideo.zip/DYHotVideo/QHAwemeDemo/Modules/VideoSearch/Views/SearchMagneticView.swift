//
//  SearchMagneticView.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/21.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

/// 搜索磁力联想
class SearchMagneticView: UIView {
    
    static let cellId = "SearchMagneticViewCell"

    lazy var tableView: UITableView = {
        let table = UITableView()
        table.backgroundColor = UIColor.clear
        table.rowHeight = 35
        table.showsVerticalScrollIndicator = false
        table.allowsSelection = true
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .none
        table.register(UITableViewCell.classForCoder(), forCellReuseIdentifier: SearchMagneticView.cellId)
        return table
    }()
    var itmClickActionHandler:((_ indexModel: SearchMagicKeyModel) -> Void)?
    var keyModels: [SearchMagicKeyModel]?
  
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor(white: 0.1, alpha: 0.98)
        addSubview(tableView)
        layoutTableView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setModel(models: [SearchMagicKeyModel]) {
        if models.count > 0 {
            keyModels = models
            tableView.reloadData()
        }
    }
    
}


// MARK: - UITableViewDelegate, UITableViewDataSource
extension SearchMagneticView: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return keyModels?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: SearchMagneticView.cellId, for: indexPath)
        if let keyModel = keyModels?[indexPath.row] {
            cell.backgroundColor = UIColor.clear
            cell.contentView.backgroundColor = UIColor.clear
            cell.textLabel?.text = " \(keyModel.title ?? "")"
            cell.textLabel?.textColor = UIColor.white
            cell.textLabel?.font = UIFont.systemFont(ofSize: 15)
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if let keyModel = keyModels?[indexPath.row] {
             itmClickActionHandler?(keyModel)
        }
       
    }
    
    
}

// MARK: - Layout
private extension SearchMagneticView {
    
    func layoutPageSubview() {
        layoutTableView()
    }
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
}
