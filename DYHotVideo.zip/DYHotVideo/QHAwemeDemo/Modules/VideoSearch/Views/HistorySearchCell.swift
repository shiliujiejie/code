//
//  HistorySearchCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/25.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

class HistorySearchCell: UITableViewCell {
    
    static let cellId = "HistorySearchCell"

    private let customLayout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: (ConstValue.kScreenWdith - 60)/3, height: 35)
        //layout.estimatedItemSize = CGSize(width: (ConstValue.kScreenWdith - 60)/3, height: 35)
        layout.minimumLineSpacing = 15.0
        layout.sectionInset = UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 15)
        return layout
    }()
    private lazy var collectionView: UICollectionView = {
        let collection = UICollectionView.init(frame: self.bounds, collectionViewLayout: customLayout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.clear
        collection.showsVerticalScrollIndicator = false
        collection.register(TagCell.classForCoder(), forCellWithReuseIdentifier: TagCell.cellId)
        return collection
    }()
    private var items: [String]?
    
    var itemClickHandler:((_ itemTitle: String) ->Void)?
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.backgroundColor = UIColor.clear
        contentView.backgroundColor = UIColor.clear
        contentView.addSubview(collectionView)
        layoutCollection()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setHistorySearchData(_ list: [String]) {
        items = list
        collectionView.reloadData()
    }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension HistorySearchCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return items?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: TagCell.cellId, for: indexPath) as! TagCell
        if items != nil && items!.count > indexPath.row {
            cell.tagLabel.text = items![indexPath.row]
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        if items != nil && items!.count > indexPath.row {
            let itemTitle = items![indexPath.row]
            itemClickHandler?(itemTitle)
        }
    }
    
}

// MARK: - Layout
private extension HistorySearchCell {
    
    private func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(10)
            make.center.equalToSuperview()
            make.leading.trailing.equalToSuperview()
            make.height.equalTo(50)
        }
    }
    
}
