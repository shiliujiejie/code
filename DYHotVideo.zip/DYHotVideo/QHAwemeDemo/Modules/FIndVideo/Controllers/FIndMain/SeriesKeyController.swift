//
//  SeriesKeyController.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/14.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import NicooNetwork

class SeriesKeyController: UIViewController {

    static let videoItemWidth: CGFloat = (ConstValue.kScreenWdith - 80)/4
    static let videoItemHieght: CGFloat = 35
    static let videoItemSize: CGSize = CGSize(width: videoItemWidth, height: videoItemHieght)

    private let layout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 10
        layout.minimumInteritemSpacing = 10
        layout.sectionInset = UIEdgeInsets(top: 10 ,left: 10, bottom: 10, right: 10)
        return layout
    }()
    lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.clear
        collection.register(TagCell.classForCoder(), forCellWithReuseIdentifier: TagCell.cellId)
        return collection
    }()
    private lazy var moreButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitleColor(UIColor.white, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        button.setTitle("加载更多", for: .normal)
        button.setTitle("收起更多", for: .selected)
        button.addTarget(self, action: #selector(moreButtonClick(_:)), for: .touchUpInside)
        button.isHidden = true
        return button
    }()
    private lazy var moreButtonImg: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "doubleArrowDown"), for: .normal)
        button.setImage(UIImage(named: "doubleArrowUp"), for: .selected)
        button.addTarget(self, action: #selector(moreButtonClick(_:)), for: .touchUpInside)
        button.isHidden = true
        return button
    }()
    
    private lazy var videoKeyApi: VideoSeriesListApi =  {
        let api = VideoSeriesListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    /// 所有数据源
    var cateModels = [VideoCategoryModel]()
    /// 最多8条的数据源
    var fakeModels = [VideoCategoryModel]()
    /// 用于展示的数据源
    var showModels = [VideoCategoryModel]()
    
    var isRefreshOperation = false
    
    var moreButtonCLickHandler:((_ sender: UIButton) -> Void)?
    var loadDataSuccessCallback:((_ sourceCount: Int) -> Void)?
    
    // MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.clear
        view.addSubview(collectionView)
        view.addSubview(moreButton)
        view.addSubview(moreButtonImg)
        layoutPageSubviews()
        loadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    
    @objc func moreButtonClick(_ sender: UIButton) {
        moreButtonCLickHandler?(sender)
        sender.isSelected = !sender.isSelected
        if sender == moreButton {
            moreButtonImg.isSelected = sender.isSelected
        } else {
            moreButton.isSelected = sender.isSelected
        }
    }
    
}

// MARK: - Private - Funcs
private extension SeriesKeyController {
    
    func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        let _ = videoKeyApi.loadData()
    }

    func succeedRequest(_ model: CateTypeListModel) {
        if let models = model.data {
            cateModels = models
            if cateModels.count <= 8 {
                moreButton.isHidden = true
                moreButtonImg.isHidden = true
                moreButton.snp.updateConstraints { (make) in
                    make.height.equalTo(0)
                }
                // 数据少于8条， 直接添加进去
                fakeModels.append(contentsOf: cateModels)
            } else {
                moreButton.isHidden = false
                moreButtonImg.isHidden = false
                moreButton.snp.updateConstraints { (make) in
                    make.height.equalTo(35)
                }
                //  数据多余8条， 添加前8条
                for i in 0 ..< 8 {
                    let model = cateModels[i]
                    fakeModels.append(model)
                }
            }
            showModels = fakeModels
        }
        loadDataSuccessCallback?(cateModels.count)
        collectionView.reloadData()
    }

    func failedRequest(_ manager: NicooBaseAPIManager) {
        NicooErrorView.showErrorMessage("加载失败，点击刷新", on: self.view, customerTopMargin: nil) {
             self.loadData()
        }
    }
}


// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension SeriesKeyController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return showModels.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cellForRow(with: indexPath)
        return cell
    }
    
    /// 配置cell
    func cellForRow(with indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: TagCell.cellId, for: indexPath) as! TagCell
        cell.tagLabel.text = cateModels[indexPath.row].keys_title ?? "未知"
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        let model = cateModels[indexPath.row]
        let serVC = SeriesVideosController()
        serVC.keyCateModel = model
        serVC.keyId = model.key_id ?? 1
        navigationController?.pushViewController(serVC, animated: true)

    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return SeriesKeyController.videoItemSize
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension SeriesKeyController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        return [VideoSeriesListApi.kType: "FAXIAN1"]
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        if let videoList = manager.fetchJSONData(VideoReformer()) as? CateTypeListModel {
            if manager is VideoSeriesListApi {
               succeedRequest(videoList)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
       failedRequest(manager)
    }
}


// MARK: - Layout
private extension SeriesKeyController {
    
    func layoutPageSubviews() {
        layoutMoreBtn()
        layoutCollection()
    }
    
    func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.bottom.equalTo(moreButton.snp.top).offset(0)
        }
    }
    
    func layoutMoreBtn() {
        moreButton.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview().offset(-20)
            make.bottom.equalToSuperview().offset(-5)
            make.height.equalTo(35)
        }
        moreButtonImg.snp.makeConstraints { (make) in
            make.leading.equalTo(moreButton.snp.trailing).offset(5)
            make.centerY.equalTo(moreButton)
            make.height.equalTo(20)
            
        }
    }
    
}
