//
//  QHMessageViewController.swift
//  QHAwemeDemo
//
//  Created by Anakin chen on 2017/10/16.
//  Copyright © 2017年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

class QHMessageViewController: QHBaseViewController {
    
    lazy var keyVC: SeriesKeyController = {
         let keyVC = SeriesKeyController()
        return keyVC
    }()
    lazy var videoVc: FindVideosController = {
        let videoVC = FindVideosController()
        return videoVC
    }()
    private lazy var navBar: QHNavigationBar = {
        let bar = QHNavigationBar()
        bar.titleLabel.textColor = UIColor.white
        bar.backgroundColor = UIColor.clear
        bar.backButton.isHidden = true
        bar.delegate = self
        return bar
    }()
    private lazy var searchBar: UISearchBar = {
        let searchBar = UISearchBar(frame: CGRect(x: 20, y: 10, width: ConstValue.kScreenWdith - 40, height: 30))
        searchBar.placeholder = "～老湿你好，请多多指教"
        searchBar.changeFont(UIFont.systemFont(ofSize: 14))
        searchBar.backgroundColor = UIColor.clear
        searchBar.backgroundImage = UIImage()
        //searchBar.isUserInteractionEnabled = false
        searchBar.changeTextFieldBackgroundColor(UIColor(red: 56/255.0, green: 59/255.0, blue: 71/255.0, alpha: 0.99))
        return searchBar
    }()
    private lazy var searchFakeBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.addTarget(self, action: #selector(searchBtnClick), for: .touchUpInside)
        return button
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(navBar)
        navBar.addSubview(searchBar)
        navBar.addSubview(searchFakeBtn)
        self.addChild(videoVc)
        view.addSubview(videoVc.view)
        self.addChild(keyVC)
        view.addSubview(keyVC.view)
        
        layoutPageSubviews()
    
        addVcCallBack()
    }

    @objc func searchBtnClick() {
        let searchVC = SearchController()
        let nav = QHNavigationController(rootViewController: searchVC)
        self.present(nav, animated: true, completion: nil)
    }
    
    func addVcCallBack() {
        keyVC.moreButtonCLickHandler = { [weak self] (sender) in
            guard let strongSelf = self else { return }
            if sender.isSelected {
                strongSelf.keyVC.view.snp.updateConstraints({ (make) in
                    make.height.equalTo(140)
                })
                strongSelf.keyVC.showModels = strongSelf.keyVC.fakeModels
                strongSelf.keyVC.collectionView.reloadData()
            } else {
                let leaseCount = strongSelf.keyVC.cateModels.count%4 > 0 ? 1 : 0
                let height: CGFloat = CGFloat((strongSelf.keyVC.cateModels.count/4 + leaseCount) * 45) + 45.0
                strongSelf.keyVC.view.snp.updateConstraints({ (make) in
                    make.height.equalTo(height)
                })
                strongSelf.keyVC.showModels = strongSelf.keyVC.cateModels
                strongSelf.keyVC.collectionView.reloadData()
            }
        }
        keyVC.loadDataSuccessCallback = { [weak self] (count) in
            guard let strongSelf = self else { return }
           // let lineCount = count >= 8 ? 140 :  count
            let leaseCount = count%4 > 0 ? 1 : 0
            let height: CGFloat = CGFloat((count/4 + leaseCount) * 45) + 15.0
            strongSelf.keyVC.view.snp.updateConstraints({ (make) in
                make.height.equalTo(count >= 8 ? 140 : height)
            })
        }
    }

}

// MARK: - QHNavigationBarDelegate
extension QHMessageViewController:  QHNavigationBarDelegate  {
    
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}

// MARK: - Layout
private extension QHMessageViewController {
    
    func layoutPageSubviews() {
        layoutNavBar()
        layoutSearchBar()
        layoutSearchBtn()
        layoutKeyVC()
        layoutVideoVC()
    }
    
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
    }
    
    func layoutSearchBar() {
        searchBar.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(navBar.navBarView).offset(5)
            make.bottom.equalTo(-2)
        }
    }
    func layoutSearchBtn() {
        searchFakeBtn.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(navBar.navBarView)
            make.bottom.equalTo(-5)
        }
    }
    
    func layoutKeyVC() {
        keyVC.view.snp.makeConstraints { (make) in
            make.top.equalTo(navBar.snp.bottom)
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.height.equalTo(140)
        }
    }
    
    func layoutVideoVC() {
        videoVc.view.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(keyVC.view.snp.bottom)
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
        }
    }
    
}
