//
//  Scroll_V_ItemCell.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/14.
//  Copyright © 2019年 pro5. All rights reserved.
//

import UIKit

/// 竖屏图片滚动的item Cell ，不带缩放（用于： 猜你喜欢， 历史播放记录）
class Scroll_V_ItemCell: UICollectionViewCell {
    
    static let cellId = "Scroll_V_ItemCell"
    
    var videoImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.layer.cornerRadius = 3
        imageView.contentMode = .scaleAspectFill
        imageView.layer.masksToBounds = true
        imageView.backgroundColor = UIColor.clear
        return imageView
    }()
    var videoNameLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 12)
        lable.textColor = UIColor.white
        lable.textAlignment = .left
        lable.text = "变态姐姐这逼天真好"
        return lable
    }()
    var coverLable: UILabel = {
        let lable = UILabel()
        lable.backgroundColor = UIColor(white: 0.0, alpha: 0.35)
        return lable
    }()
    var collectionBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "favorIconAcount"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        return button
    }()
    var favorCountLab: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.text = "4533"
        lable.font = UIFont.systemFont(ofSize: 12)
        lable.textAlignment = .left
        return lable
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.clear
        addSubview(videoImageView)
        addSubview(videoNameLable)
        addSubview(coverLable)
        addSubview(collectionBtn)
        addSubview(favorCountLab)
        layoutPageSubviews()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}

private extension Scroll_V_ItemCell {
    
    func layoutPageSubviews() {
        layoutVideoImageView()
        layoutNameLable()
        layoutCoverLable()
        layoutCollectionBtn()
        layoutFavorLable()
    }
    func layoutVideoImageView() {
        videoImageView.snp.makeConstraints { (make) in
            make.centerX.top.equalToSuperview()
            make.width.equalTo(180 * 5/7)
            make.height.equalTo(180)
        }
    }
    func layoutNameLable() {
        videoNameLable.snp.makeConstraints { (make) in
            make.leading.equalTo(5)
            make.trailing.equalTo(-5)
            make.top.equalTo(videoImageView.snp.bottom).offset(5)
            make.height.equalTo(25)
        }
    }
    func layoutCoverLable() {
        coverLable.snp.makeConstraints { (make) in
            make.leading.equalTo(videoImageView)
            make.trailing.equalTo(videoImageView)
            make.bottom.equalTo(videoImageView)
            make.height.equalTo(25)
        }
    }
    func layoutCollectionBtn() {
        collectionBtn.snp.makeConstraints { (make) in
            make.left.equalTo(10)
            make.centerY.equalTo(coverLable)
            make.height.equalTo(20)
            make.width.equalTo(20)
        }
    }
    
    func layoutFavorLable() {
        favorCountLab.snp.makeConstraints { (make) in
            make.leading.equalTo(collectionBtn.snp.trailing)
            make.trailing.equalToSuperview().offset(-5)
             make.centerY.equalTo(coverLable)
            make.height.equalTo(20)
        }
    }
}
