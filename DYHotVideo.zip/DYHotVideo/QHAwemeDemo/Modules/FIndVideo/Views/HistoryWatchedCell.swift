//
//  HistoryWatchedCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/6.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 历史观看cell
class HistoryWatchedCell: UITableViewCell {
   
    static let cellId = "HistoryWatchedCell"
    
    private let customLayout: CustomFlowSingleLayout = {
        let layout = CustomFlowSingleLayout()
        layout.itemSize = CGSize(width: 180 * 5/7, height: 220)
       // layout.
        return layout
    }()
    lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 220), collectionViewLayout: customLayout)
        collection.backgroundColor = UIColor.clear
        collection.showsHorizontalScrollIndicator = false
        collection.delegate = self
        collection.dataSource = self
        collection.register(Scroll_V_ItemCell.classForCoder(), forCellWithReuseIdentifier: Scroll_V_ItemCell.cellId)
        return collection
    }()
    private(set) var videoList: [VideoModel]?
    var itemClickHandlerIn: ((_ index: Int) -> Void)?
   
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = UIColor.clear
        self.backgroundColor = UIColor.clear
        contentView.addSubview(collectionView)
        layoutCollection()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setVideoList(_ list: [VideoModel]) {
        videoList = list
        collectionView.reloadData()
    }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension HistoryWatchedCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return videoList?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: Scroll_V_ItemCell.cellId, for: indexPath) as! Scroll_V_ItemCell
        if let model = videoList?[indexPath.row] {
            cell.videoImageView.kfSetVerticalImageWithUrl(model.cover_path)
            cell.videoNameLable.text = model.title ?? ""
            cell.favorCountLab.text = "\(model.comment_count ?? 0)"
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        if let videos = videoList, videos.count > indexPath.row {
            itemClickHandlerIn?(indexPath.row)
        }
        
    }
    
}

// MARK: - Layout
private extension HistoryWatchedCell {
    
    private func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
}
