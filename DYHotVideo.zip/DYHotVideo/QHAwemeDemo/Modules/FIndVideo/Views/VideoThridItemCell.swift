//
//  VideoThridItemCell.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/13.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit

/// 一排3个视频 cell
class VideoThridItemCell: UICollectionViewCell {
    
    static let cellId = "VideoThridItemCell"
    
    var videoImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.layer.cornerRadius = 3
        imageView.contentMode = .scaleAspectFill
        imageView.layer.masksToBounds = true
        imageView.backgroundColor = UIColor.clear
        return imageView
    }()
    var videoNameLable: UILabel = {
        let lable = UILabel()
        lable.font = UIFont.systemFont(ofSize: 13)
        lable.textColor = UIColor.white
        lable.text = ""
        lable.textAlignment = .left
        return lable
    }()
   
    var coverLable: UILabel = {
        let lable = UILabel()
        lable.backgroundColor = UIColor(white: 0.0, alpha: 0.35)
        return lable
    }()
    var collectionBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "favorIconAcount"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        return button
    }()
    var favorCountLab: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.white
        lable.text = "0"
        lable.font = UIFont.systemFont(ofSize: 12)
        lable.textAlignment = .left
        return lable
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.clear
        addSubview(videoImageView)
        addSubview(videoNameLable)
        addSubview(coverLable)
        addSubview(collectionBtn)
        addSubview(favorCountLab)
        layoutPageSubviews()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}

private extension VideoThridItemCell {
    
    func layoutPageSubviews() {
        layoutVideoImageView()
        layoutNameLable()
        layoutCoverLable()
        layoutCollectionBtn()
        layoutFavorLable()
    }
    func layoutVideoImageView() {
        let itemWith = (ConstValue.kScreenWdith - 20)/3
        videoImageView.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.width.equalTo(itemWith)
            make.height.equalTo(itemWith * 1.3)
        }
    }
    func layoutNameLable() {
        videoNameLable.snp.makeConstraints { (make) in
            make.leading.equalTo(5)
            make.trailing.equalTo(-5)
            make.top.equalTo(videoImageView.snp.bottom).offset(5)
            make.height.equalTo(20)
        }
    }
    func layoutCoverLable() {
        coverLable.snp.makeConstraints { (make) in
            make.leading.equalTo(videoImageView)
            make.trailing.equalTo(videoImageView)
            make.bottom.equalTo(videoImageView)
            make.height.equalTo(25)
        }
    }
    func layoutCollectionBtn() {
        collectionBtn.snp.makeConstraints { (make) in
            make.left.equalTo(10)
            make.centerY.equalTo(coverLable)
            make.height.equalTo(20)
            make.width.equalTo(20)
        }
    }
    
    func layoutFavorLable() {
        favorCountLab.snp.makeConstraints { (make) in
            make.leading.equalTo(collectionBtn.snp.trailing)
            make.trailing.equalToSuperview().offset(-5)
            make.centerY.equalTo(coverLable)
            make.height.equalTo(20)
        }
    }
}
