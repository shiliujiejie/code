//
//  TagCell.swift
//  GroupTagDemo
//
//  Created by Janise on 2019/1/24.
//  Copyright © 2019年 Janise. All rights reserved.
//

import UIKit

class TagCell: UICollectionViewCell {
    
    static let cellId = "TagCell"
    
    lazy var tagLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.white
        label.font = UIFont.systemFont(ofSize: 13)
        label.numberOfLines = 1
        label.textAlignment = .center
        return label
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = UIColor(red: 56/255.0, green: 59/255.0, blue: 71/255.0, alpha: 0.99)
        contentView.addSubview(tagLabel)
        contentView.layer.cornerRadius = 15
        contentView.layer.masksToBounds = true
        layoutPageSubviews()
       
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

private extension TagCell {
    
    func layoutPageSubviews() {
        tagLabel.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
}
