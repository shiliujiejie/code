//
//  LuckCardsCell.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/13.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

/// 福利卡
class LuckCardsCell: UITableViewCell {
    
    static let cellId = "LuckCardsCell"
    
    @IBOutlet weak var cardContainView: UIView!
    @IBOutlet weak var cardImage: UIImageView!
    @IBOutlet weak var cardValueLab: UILabel!
    
    @IBOutlet weak var cardUtis: UILabel!
    @IBOutlet weak var cardExplainLab: UILabel!
    
    @IBOutlet weak var fakeLable: UILabel!
    @IBOutlet weak var lineConst: NSLayoutConstraint!
    @IBOutlet weak var cardActionBtn: UIButton!
    @IBOutlet weak var inviteCountLab: UILabel!
    
    var cardActionForHandler:(() -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.contentView.backgroundColor = UIColor.clear
        self.backgroundColor = UIColor.clear
        fakeLable.textColor = UIColor.darkText
        cardActionBtn.layer.cornerRadius = 15
        cardActionBtn.layer.masksToBounds = true
    }

    @IBAction func actionForCard(_ sender: UIButton) {
        cardActionForHandler?()
    }
    
    
}
