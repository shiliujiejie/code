//
//  ConvertLuckCardCell.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/26.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

/// 兑换福利卷按钮
class ConvertLuckCardCell: UITableViewCell {

    static let cellId = "ConvertLuckCardCell"
    
    @IBOutlet weak var containerView: UIView!
    
    @IBOutlet weak var addButton: UIButton!
    
    @IBOutlet weak var msglable: UILabel!
    
    var addActionHandler:(() -> Void)?
    override func awakeFromNib() {
        super.awakeFromNib()
        containerView.layer.cornerRadius = 8
        containerView.layer.masksToBounds = true
        containerView.backgroundColor = UIColor(red:  35/255.0  , green: 38/255.0, blue: 53/255.0, alpha: 0.99)
        msglable.textColor = ConstValue.kTitleYelloColor
    }

    
    @IBAction func addActionHandler(_ sender: UIButton) {
        addActionHandler?()
    }
}
