//
//  DrawCashHead.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/6/1.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

class DrawCashHead: UIView {

    @IBOutlet weak var titlelab: UILabel!
    @IBOutlet weak var moneyValue: UITextField!
    
    @IBOutlet weak var moneyUtis: UILabel!
    
    @IBOutlet weak var sxfLab: UILabel!
    
    @IBOutlet weak var allDrawBtn: UIButton!
    
    var actionHandler:(() -> Void)?
    var allMoney: Float = 0.00
    override func awakeFromNib() {
        moneyValue.delegate = self
    }
    
    @IBAction func allDrawAction(_ sender: UIButton) {
        actionHandler?()
    }
}

// MARK: - UITextFieldDelegate
extension DrawCashHead: UITextFieldDelegate {
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if let num = textField.text, !num.isEmpty {
            if let value = Float(num) {
                if value < 200 {
                    XSAlert.show(type: .error, text: "最小提现金额200元")
                    return
                } else if value > allMoney {
                    moneyValue.text = String(format: "%.2f", allMoney)
                    if allMoney >= 200.00 {
                         sxfLab.attributedText =  TextSpaceManager.configColorString(allString: "服务费: ￥\(String(format: "%.2f", Float(allMoney/20.0)))", attribStr: "￥\(String(format: "%.2f", Float(allMoney/20.0)))")
                    }
                    return
                } else {
                    moneyValue.text = String(format: "%.2f", value)
                    sxfLab.attributedText =  TextSpaceManager.configColorString(allString: "服务费: ￥\(String(format: "%.2f", Float(value/20.0)))", attribStr: "￥\(String(format: "%.2f", Float(value/20.0)))")
                }
            }
        }
    }
}
