//
//  DrawCashAlCell.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/6/1.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

class DrawCashAlCell: UITableViewCell {

    static let cellId = "DrawCashAlCell"
    
    @IBOutlet weak var alipayTf: UITextField!
    
    @IBOutlet weak var nameTf: UITextField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    
}
