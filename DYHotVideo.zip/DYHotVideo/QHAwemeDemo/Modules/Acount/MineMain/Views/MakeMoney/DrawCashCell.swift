//
//  DrawCashCell.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/6/1.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

class DrawCashCell: UITableViewCell {
    
    static let cellId = "DrawCashCell"
    @IBOutlet weak var titlelab: UILabel!
    
    @IBOutlet weak var inputTextfile: UITextField!
    
    @IBOutlet weak var bankName: UITextField!
    
    @IBOutlet weak var bankCard: UITextField!
    
    @IBOutlet weak var bankKh: UITextField!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

   
    
}

