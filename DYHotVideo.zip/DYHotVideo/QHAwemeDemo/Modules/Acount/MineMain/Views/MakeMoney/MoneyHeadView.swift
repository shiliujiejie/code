//
//  MoneyHeadView.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/5/31.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

class MoneyHeadView: UIView {

    @IBOutlet weak var userHeadBtn: UIButton!
    
    @IBOutlet weak var userName: UILabel!
    @IBOutlet weak var myMoneyLab: UILabel!
    @IBOutlet weak var userType: UILabel!
    @IBOutlet weak var outMoneyBtn: UIButton!
    
    @IBOutlet weak var moneyA: UILabel!
    @IBOutlet weak var moneyB: UILabel!
    @IBOutlet weak var moneyC: UILabel!
    @IBOutlet weak var moneyAll: UILabel!
    
    @IBOutlet weak var adBtn: UIButton!
    
    var actionHandler:((_ actionId: Int) ->Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        userHeadBtn.layer.borderColor = UIColor.groupTableViewBackground.cgColor
        userHeadBtn.layer.borderWidth = 0.8
        
        let userInfo = UserModel.share().userInfo
        userName.text = userInfo?.nikename ?? "匿名"
        if let headerTitle = userInfo?.nikename , headerTitle.count > 2 {
            let subTitle =  (headerTitle as NSString).substring(to: 1)
            userHeadBtn.setTitle(subTitle, for: .normal)
        } else {
            userHeadBtn.setTitle(userInfo?.nikename ?? "", for: .normal)
        }
        moneyA.attributedText = TextSpaceManager.configColorString(allString: "¥ 0.00", attribStr: "¥", UIColor.white, 10.0)
        moneyB.attributedText = TextSpaceManager.configColorString(allString: "¥ 0.00", attribStr: "¥", UIColor.white, 10.0)
        moneyAll.attributedText = TextSpaceManager.configColorString(allString: "¥ 0.00", attribStr: "¥", UIColor.white, 10.0)
        moneyAll.adjustsFontSizeToFitWidth = true
        moneyAll.minimumScaleFactor = 0.5
        moneyA.adjustsFontSizeToFitWidth = true
        moneyA.minimumScaleFactor = 0.5
        moneyB.adjustsFontSizeToFitWidth = true
        moneyB.minimumScaleFactor = 0.5
        moneyC.adjustsFontSizeToFitWidth = true
        moneyC.minimumScaleFactor = 0.5
    }
    
    @IBAction func actionClick(_ sender: UIButton) {
        actionHandler?(sender.tag)
    }
    
}
