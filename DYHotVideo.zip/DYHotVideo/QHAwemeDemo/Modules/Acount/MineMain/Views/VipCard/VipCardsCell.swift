//
//  VipCardsCell.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/12.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

class VipCardsCell: UITableViewCell {
    
    static let cellId = "VipCardsCell"

    @IBOutlet weak var cardImageBg: UIImageView!
    @IBOutlet weak var pricceLable: UILabel!
    @IBOutlet weak var tipsLab: UILabel!
    @IBOutlet weak var msglable: UILabel!
    @IBOutlet weak var buyButton: UIButton!
    
    var buyCardActionHandler:(() -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = UIColor.clear
       // pricceLable.text = "7.9"
        tipsLab.layer.cornerRadius = 12.5
        tipsLab.layer.masksToBounds = true
        tipsLab.backgroundColor = UIColor(red: 193/255.0, green: 197/255.0, blue: 206/255.0, alpha: 0.99)
        tipsLab.isHidden = true
    }

    @IBAction func buyAction(_ sender: UIButton) {
        buyCardActionHandler?()
    }
    
    
}
