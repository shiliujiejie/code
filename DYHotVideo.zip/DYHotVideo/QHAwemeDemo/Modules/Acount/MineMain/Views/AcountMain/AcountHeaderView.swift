//
//  AcountHeaderView.swift
//  LTScrollView_Example
//
//  Created by mac on 2019/3/11.
//  Copyright © 2019年 CocoaPods. All rights reserved.
//

import UIKit

class AcountHeaderView: UIView {

    static let xibId = "AcountHeaderView"
    
    @IBOutlet weak var headerImage: UIImageView!
    @IBOutlet weak var nickName: UILabel!
    @IBOutlet weak var bgImage: UIImageView!
    @IBOutlet weak var scoreBtn: UIButton!
    @IBOutlet weak var userIdLab: UILabel!
    @IBOutlet weak var headLable: UILabel!
    
    @IBOutlet weak var recordFakeLab: UILabel!
    @IBOutlet weak var vipCardBtn: UIButton!
    @IBOutlet weak var priceCard: UIButton!
    @IBOutlet weak var hireStarBtn: UIButton!
    @IBOutlet weak var recommentBtn: UIButton!
    @IBOutlet weak var inviteFriendBtn: UIButton!
    
    @IBOutlet weak var vipTitle: UILabel!
    @IBOutlet weak var priceCardTitle: UILabel!
    @IBOutlet weak var starTitle: UILabel!
    @IBOutlet weak var inviteTitle: UILabel!
    @IBOutlet weak var recoTitle: UILabel!
    
    @IBOutlet weak var welfCardCountLable: UILabel!
    @IBOutlet weak var cardBgImageView: UIImageView!
    @IBOutlet weak var cardItembgView: UIView!
    @IBOutlet weak var cardItemDays: UIView!
    @IBOutlet weak var cardItemCounts: UIView!
    @IBOutlet weak var cardItemTime: UIView!
    @IBOutlet weak var cardTipsBtn: UIButton!
    @IBOutlet weak var cardNameImage: UIImageView!
    
    /// 剩余天数
    @IBOutlet weak var leaseDayCountLab: UILabel!
    @IBOutlet weak var imgTopMargin: NSLayoutConstraint!
    @IBOutlet weak var leaseDayTitle: UILabel!
    /// 剩余次数
    @IBOutlet weak var leaseCountLab: UILabel!
    /// 剩余次数title
    @IBOutlet weak var leaseCountTitle: UILabel!
    /// 到期时间
    @IBOutlet weak var endTimeLab: UILabel!
    @IBOutlet weak var endTimeTitle: UILabel!
    
    var buttonItemClickHandler:((_ itemTag: Int) -> Void)?
    var inviteRecordClickHandler:(() -> Void)?
    var upVipCardLevelActionHandler:(() -> Void)?
    
    override func awakeFromNib() {
         super.awakeFromNib()
        headerImage.backgroundColor = UIColor(red: 22/255.0, green: 24/255.0, blue: 36/255.0, alpha: 0.95)
        cardItembgView.backgroundColor = UIColor(white: 1, alpha: 0.15)
        recordFakeLab.layer.cornerRadius = 15
        recordFakeLab.layer.masksToBounds = true
        recordFakeLab.backgroundColor = UIColor(white: 0.3, alpha: 0.5)
        scoreBtn.tintColor = ConstValue.kTitleYelloColor
        headLable.layer.cornerRadius = 25
        headLable.layer.masksToBounds = true
        headLable.backgroundColor = ConstValue.kIconBgColor
        headLable.textColor = ConstValue.kTitleYelloColor
        welfCardCountLable.layer.cornerRadius = 9
        welfCardCountLable.layer.masksToBounds = true
    }
    

    @IBAction func inviteRecordClick(_ sender: UIButton) {
        inviteRecordClickHandler?()
    }
    
    @IBAction func ItemButtonClick(_ sender: UIButton) {
        print("itemClick = \(sender)")
        buttonItemClickHandler?(sender.tag)
    }
    
    @IBAction func upCardLevelAction(_ sender: UIButton) {
        upVipCardLevelActionHandler?()
    }
    
    func setCardLayer(cardLayer: VipCardLayer) {
        cardBgImageView.image = UIImage(named: cardLayer.cardBgName ?? "")
        cardTipsBtn.setBackgroundImage(UIImage(named: cardLayer.cardTipsName ?? ""), for: .normal)
        cardNameImage.image = UIImage(named: cardLayer.cardName ?? "")
        if cardLayer.cardType == .card_Normal || cardLayer.cardType == .card_Novice || cardLayer.cardType == .card_TiYan {
            leaseDayTitle.textColor = UIColor.darkText
            leaseDayCountLab.textColor = UIColor.darkText
            leaseCountLab.textColor = UIColor.darkText
            leaseCountTitle.textColor = UIColor.darkText
            endTimeLab.textColor = UIColor.darkText
            endTimeTitle.textColor =  UIColor.darkText
        } else if cardLayer.cardType == .card_YouXiang ||  cardLayer.cardType == .card_GuiBing {
            leaseDayTitle.textColor = UIColor(red: 122/255.0, green: 74/255.0, blue: 49/255.0, alpha: 1)
            leaseDayCountLab.textColor = UIColor(red: 122/255.0, green: 74/255.0, blue: 49/255.0, alpha: 1)
            leaseCountLab.textColor = UIColor(red: 122/255.0, green: 74/255.0, blue: 49/255.0, alpha: 1)
            leaseCountTitle.textColor = UIColor(red: 122/255.0, green: 74/255.0, blue: 49/255.0, alpha: 1)
            endTimeLab.textColor = UIColor(red: 122/255.0, green: 74/255.0, blue: 49/255.0, alpha: 1)
            endTimeTitle.textColor =  UIColor(red: 122/255.0, green: 74/255.0, blue: 49/255.0, alpha: 1)
        } else {
            leaseDayTitle.textColor = UIColor(red: 213/255.0, green: 174/255.0, blue: 114/255.0, alpha: 1)
            leaseDayCountLab.textColor = UIColor(red: 213/255.0, green: 174/255.0, blue: 114/255.0, alpha: 1)
            leaseCountLab.textColor = UIColor(red: 213/255.0, green: 174/255.0, blue: 114/255.0, alpha: 1)
            leaseCountTitle.textColor = UIColor(red: 213/255.0, green: 174/255.0, blue: 114/255.0, alpha: 1)
            endTimeLab.textColor = UIColor(red: 213/255.0, green: 174/255.0, blue: 114/255.0, alpha: 1)
            endTimeTitle.textColor = UIColor(red: 213/255.0, green: 174/255.0, blue: 114/255.0, alpha: 1)
        }
       
        
    }
}
