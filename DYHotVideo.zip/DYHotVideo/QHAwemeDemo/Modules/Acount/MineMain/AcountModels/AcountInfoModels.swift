//
//  AcountInfoModels.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/17.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import Foundation


// MARK: - ----- 订单列表model
struct OrderListModel: Codable {
    var current_page: Int?
    var data:[OrderInfoModel]?
}

// MARK: - ----- 订单model
struct OrderInfoModel: Codable {
    var id: Int?
    var order_no: String?  // 订单号
    var order_type: Int? //订单类型
    var vc_title: String?
    var vc_daily_until: Int?
    var pay_status_label: String?
    var pay_status: Int?
    var paid_at: String?
    var price_original: String?
    var price_current: String?
    var status: Int? // ding
  
}


struct VipCardListModel: Codable {
    var current_page: Int?
    var data: [VipCardModel]?
}

// MARK: - -----  VIP cards
struct VipCardModel: Codable {
    var id: Int?
    var title: String?  // 卡片名
    var key: VipKey? //卡片类型
    var remark: String?
    var daily_until: Int? // 使用天数
    var view_count_daily: Int? // 每天使用次数 ,0 表示无限次数 或者没有次数。取决于卡的类型
    var price_original: String? // 正常价格
    var price_current: String?  // 当前价格
    var level: Int? // 卡等级 1 - 6
    var sort: Int? // 排序号
    var status: Int? //
    var display: Int?
    var created_at: String?
}


/// VIP 卡类型
///
/// - card_Novice: 新手卡
/// - card_Normal: 游客卡
/// - card_TiYan: 体验卡
/// - card_YouXiang: 优享卡
/// - card_GuiBing: 贵宾卡
/// - card_ZhiZun: 至尊卡
enum VipKey: String, Codable {
    case card_Novice = "NOVICE"
    case card_Normal = "NORMAL"
    case card_TiYan  = "TIYAN"
    case card_YouXiang = "YOUXIANG"
    case card_GuiBing  = "GUIBING"
    case card_ZhiZun  = "ZHIZUN"
}


// MARK: - 已获得 折扣卡 列表
struct  WelfareGetCardList: Codable {
    var current_page: Int?
    var data:[WelfareGetCard]?
}

// MARK: - 折扣卡 统一
struct WelfareGetCard: Codable {
    var id: Int?
    var vc_id: Int?
    var wc_id: Int?
   
    var title: String?
    var remark: String?
    var discount: String?   // 折扣
    var invite_mini: Int?
    
    var user_id: Int?
    var created_at: String?
    var status: Int?
    var expire: String? // 有效期
}

// MARK: - 未获得卡
struct WelfareUnowedCard: Codable {
    var id: Int?
    var invite_count: Int?
    var title: String?
    var remark: String?
    var discount: String?   // 折扣
    var invite_mini: Int?

}


// MARK: - 用户邀请历史列表 model
struct InviteListModel: Codable {
    var current_page: Int?
    var data: [inviteUserModel]?
}

struct inviteUserModel: Codable {
    var code: String?
    var owner_user_id: Int?
    var name: String?
    var nikename: String?
    var mobile: String?
    var use_user_id: Int?
    var created_at: String?
}


// MARK: - 订单详情
struct OrderDetailModel: Codable {
    var id: Int?
    var title: String?
    var remark: String?
    var price_original: String?
    var price_current: String?
    var welfareCard: [WelfareGetCard]?
}

/// 是否强制更新
enum GoPay: Int, Codable {
    case enable = 0
    case disable = 1
    var allowPay: Bool {
        switch self {
        case .enable:
            return true
        case .disable:
            return false
        }
    }
}
// MARK: - 订单model
struct OrderAddModel: Codable {
    var oid: String?
    var payUrl: String?
    var sign: String?
    var target: GoPay?
}

/// 是否强制更新
enum PayTypeState: Int, Codable {
    case disable = 0
    case enable = 1
    var allowPay: Bool {
        switch self {
        case .enable:
            return true
        case .disable:
            return false
        }
    }
}

// MARK: - 支付方式列表
struct PayTypeModel: Codable {
    var id: Int?
    var title: String?
    var key: String?
    var status: PayTypeState?
    var created_at: String?
    var updated_at: String?
}


// MARK: - 问题列表
struct QuestionModel: Codable {
    var key: String?
    var value: String?
}

/// 审核状态
///
/// - reviewFailed: 审核失败
/// - newReviewStatu: 咩有申请过资质
/// - waitForReview: 等待审核
/// - passedReview: 通过审核
enum UploadReviewStatu: Int, Codable {
    case reviewFailed = -1      // 审核失败
    case newReviewStatu = 0     // 没有申请过
    case waitForReview = 1      // 等待审核
    case passedReview =  2      // 审核通过
}

// MARK: - 上传资质校验
struct ApplyCheckInfoModel: Codable {
    var upload_review_fail: Int?                     // 审核已失败次数
    var upload_review_max_fail: Int?                 // 最大允许审核失败次数
    var upload_review: UploadReviewStatu?            // 审核状态 -1： 审核失败 0:未审核 1:待审核 2:已审核
}


// MARK: - 个人分销金额详情

enum UserWalletLevel: String, Codable {
    case daRen = "P"
    case normal = "A"
}
struct WalletInfo: Codable {
    var id: Int?
    var user_id: Int?
    var money: String?
    var bonus: String?
    var bonus_a: String?
    var bonus_b: String?
    var bonus_c: String?
    var bonus_extra: String?
    var sales_type: UserWalletLevel?
}

// MARK: - 个人收益提现历史
struct WalletRecordLs: Codable {
    var current_page: Int?
    var data: [WalletRecord]?
    var total: Int?
}
struct WalletRecord: Codable {
    var user_id: Int?
    var record_sn: String?
    var record_type: String?
    var record_event: Int?
    var money: String?
    var record_type_label: String?
    var created_at: String?
}
