//
//  LuckCardChirdController.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/13.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import NicooNetwork

class LuckCardUnownedController: UIViewController {

    private lazy var tableView: UITableView = {
        let table = UITableView()
        table.backgroundColor = UIColor.clear
        table.showsVerticalScrollIndicator = false
        table.allowsSelection = true
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .none
        table.register(UINib(nibName: "LuckCardsCell", bundle: Bundle.main), forCellReuseIdentifier: LuckCardsCell.cellId)
        table.register(UINib(nibName: "ConvertLuckCardCell", bundle: Bundle.main), forCellReuseIdentifier: ConvertLuckCardCell.cellId)
        return table
    }()
    private lazy var cardListApi: WelfareUnownedCardApi = {
        let api = WelfareUnownedCardApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    

    var cards = [WelfareUnowedCard]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(tableView)
        layoutPageSubviews()
        loadData()
    }
    
    private func loadData() {
        let _ = cardListApi.loadData()
    }
    

}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension LuckCardUnownedController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return (ConstValue.kScreenWdith-20)/3.55 + 20
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cards.count + 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: ConvertLuckCardCell.cellId, for: indexPath) as! ConvertLuckCardCell
            cell.selectedBackgroundView = UIView()
            return cell
        }
        else {
            let cell = tableView.dequeueReusableCell(withIdentifier: LuckCardsCell.cellId, for: indexPath) as! LuckCardsCell
            let model = cards[indexPath.row - 1]
            /// 适配背景图
            cell.lineConst.constant = (ConstValue.kScreenWdith-20)/3.55
            cell.cardImage.image = UIImage(named: "luckCardNotGet")
            cell.fakeLable.isHidden = false
            cell.cardActionBtn.isHidden = false
            cell.fakeLable.text = "去推广"
            cell.cardValueLab.text = model.discount ?? "7.9"
            cell.inviteCountLab.text = "已邀: \(model.invite_count ?? 0)/\(model.invite_mini ?? 0)"
            cell.cardExplainLab.text = "\(model.remark ?? "")"
            cell.selectedBackgroundView = UIView()
            
            return cell
        }
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        if indexPath.row == 0 {
            let luckCode = LuckCardCodeController()
            navigationController?.pushViewController(luckCode, animated: true)
        } else {
            let vc = InviteContenController()
            navigationController?.pushViewController(vc, animated: true)
        }
       
    }
    
    
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension LuckCardUnownedController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is WelfareUnownedCardApi {
            if let cardList = manager.fetchJSONData(UserReformer()) as? [WelfareUnowedCard] {
                cards = cardList
                tableView.reloadData()
                if cards.count == 0 {
                    NicooErrorView.showErrorMessage(.noData, on: view, clickHandler: nil)
                }
            }
        }
        
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is WelfareUnownedCardApi {
            NicooErrorView.showErrorMessage(.noNetwork, on: view, topMargin: nil) {
                self.loadData()
            }
        }
    }
}



// MARK: - Layout
private extension LuckCardUnownedController {
    
    func layoutPageSubviews() {
        layoutTableView()
    }
    
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(ConstValue.kStatusBarHeight + 50)
            } else {
                make.bottom.equalToSuperview().offset(ConstValue.kStatusBarHeight + 50)
            }
            make.leading.top.trailing.equalToSuperview()
        }
    }
    
    
    
}
