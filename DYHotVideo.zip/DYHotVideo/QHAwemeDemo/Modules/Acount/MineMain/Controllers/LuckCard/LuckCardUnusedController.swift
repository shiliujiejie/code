//
//  LuckCardUnusedController.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/18.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import NicooNetwork
import MJRefresh

class LuckCardUnusedController: UIViewController {
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    private lazy var navBar: QHNavigationBar = {
        let bar = QHNavigationBar()
        bar.titleLabel.text = "福利卡"
        bar.titleLabel.textColor = UIColor.white
        bar.backgroundColor = UIColor.clear
        bar.delegate = self
        return bar
    }()

    private lazy var tableView: UITableView = {
        let table = UITableView()
        table.backgroundColor = UIColor.clear
        table.showsVerticalScrollIndicator = false
        table.allowsSelection = true
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .none
        table.register(UINib(nibName: "LuckCardsCell", bundle: Bundle.main), forCellReuseIdentifier: LuckCardsCell.cellId)
        table.mj_header = refreshView
        table.mj_footer = loadMoreView
        return table
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        return MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
    }()
    lazy private var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.isRefreshOperation = true
            weakSelf?.loadData()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        mjRefreshHeader?.stateLabel.font = ConstValue.kRefreshLableFont
        mjRefreshHeader?.lastUpdatedTimeLabel.font = ConstValue.kRefreshLableFont
        return mjRefreshHeader!
    }()
    
    /// 是否是下拉刷新操作
    private var isRefreshOperation = false
    private lazy var cardListApi: WelfareUnusedCardApi = {
        let api = WelfareUnusedCardApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    
    var needFetch: Bool = true   // 是否需要发请求
    var cards = [WelfareGetCard]()
    var choseCardHandler:((_ selectedIndex: Int) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        if !needFetch {
            view.addSubview(navBar)
        }
        view.addSubview(tableView)
        layoutPageSubviews()
        loadMoreView.isHidden = true
        if needFetch {
            loadData()
        }
    }
    
    private func loadData() {
        NicooErrorView.removeErrorMeesageFrom(self.view)
        if !isRefreshOperation {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        } else {
            isRefreshOperation = false
        }
        let _ = cardListApi.loadData()
    }
    
    private func loadNextPage() {
        let _ = cardListApi.loadNextPage()
    }
    
    private func welfareCardListSuccess(_ listModel: WelfareGetCardList) {
        if let models = listModel.data, let currentPage = listModel.current_page {
            if currentPage ==  1 {
                cards = models
                if cards.count == 0 {
                    NicooErrorView.showErrorMessage("你还没有福利卡, 快去分享获得吧～", on: view, customerTopMargin: nil, clickHandler: nil)
                }
                if cards.count == WelfareUnusedCardApi.kDefaultCount {
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
            } else {
                cards.append(contentsOf: models)
                if models.count == WelfareUnusedCardApi.kDefaultCount {
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
            }
        }
        endRefreshing()
        tableView.reloadData()
    }
    
    private func  endRefreshing() {
        tableView.mj_header.endRefreshing()
        tableView.mj_footer.endRefreshing()
    }
    
    
}

// MARK: - QHNavigationBarDelegate
extension LuckCardUnusedController:  QHNavigationBarDelegate  {
    
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension LuckCardUnusedController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return (ConstValue.kScreenWdith-20)/3.55 + 20
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cards.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: LuckCardsCell.cellId, for: indexPath) as! LuckCardsCell
        /// 适配背景图
        cell.lineConst.constant = (ConstValue.kScreenWdith-20)/3.55
        cell.cardImage.image = UIImage(named: "luckCardNotGet")
        cell.cardActionBtn.isHidden = false
        cell.fakeLable.isHidden = false
        let model = cards[indexPath.row]
        cell.fakeLable.text = " 使用"
        cell.cardValueLab.text = model.discount ?? "7.9"
        cell.inviteCountLab.text = "\(model.title ?? "")"
        cell.cardExplainLab.text = "有效期至\(model.expire ?? "")"
        cell.selectedBackgroundView = UIView()
       
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        if !needFetch {
            choseCardHandler?(indexPath.row)
        } else {
            let vipCardVC = VipCardsController()
            navigationController?.pushViewController(vipCardVC, animated: true)
        }
       
    }
    
    
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension LuckCardUnusedController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is WelfareUnusedCardApi {
            if let welfareCardList = manager.fetchJSONData(UserReformer()) as? WelfareGetCardList {
                welfareCardListSuccess(welfareCardList)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is WelfareUnusedCardApi {
            NicooErrorView.showErrorMessage(.noNetwork, on: view) {
                self.loadData()
            }
        }
    }
}



// MARK: - Layout
private extension LuckCardUnusedController {
    
    func layoutPageSubviews() {
        if !needFetch {
            layoutNavBar()
        }
        layoutTableView()
    }
    
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(ConstValue.kStatusBarHeight + 50)
            } else {
                make.bottom.equalToSuperview().offset(ConstValue.kStatusBarHeight + 50)
            }
            make.leading.trailing.equalToSuperview()
            if needFetch {
               make.top.equalTo(0)
            } else {
                make.top.equalTo(navBar.snp.bottom)
            }
        }
    }
    
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
    }
    
    
    
}
