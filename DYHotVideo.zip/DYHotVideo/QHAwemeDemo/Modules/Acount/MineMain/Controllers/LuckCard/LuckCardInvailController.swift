//
//  LuckCardInvailController.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/18.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import NicooNetwork
import MJRefresh

class LuckCardInvailController: UIViewController {

    private lazy var tableView: UITableView = {
        let table = UITableView()
        table.backgroundColor = UIColor.clear
        table.showsVerticalScrollIndicator = false
        table.allowsSelection = false
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .none
        table.register(UINib(nibName: "LuckCardsCell", bundle: Bundle.main), forCellReuseIdentifier: LuckCardsCell.cellId)
        table.mj_header = refreshView
        table.mj_footer = loadMoreView
        return table
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        return MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
    }()
    lazy private var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.isRefreshOperation = true
            weakSelf?.loadData()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        mjRefreshHeader?.stateLabel.font = ConstValue.kRefreshLableFont
        mjRefreshHeader?.lastUpdatedTimeLabel.font = ConstValue.kRefreshLableFont
        return mjRefreshHeader!
    }()
    
    /// 是否是下拉刷新操作
    private var isRefreshOperation = false
    private lazy var cardListApi: WelfareInvailCardApi = {
        let api = WelfareInvailCardApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    
    var cards = [WelfareGetCard]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(tableView)
        layoutPageSubviews()
        loadMoreView.isHidden = true
        loadData()
    }
    
    private func loadData() {
        NicooErrorView.removeErrorMeesageFrom(self.view)
        if !isRefreshOperation {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        } else {
            isRefreshOperation = false
        }
        let _ = cardListApi.loadData()
    }
    
    private func loadNextPage() {
        let _ = cardListApi.loadNextPage()
    }
    
    private func welfareCardListSuccess(_ listModel: WelfareGetCardList) {
        if let models = listModel.data, let currentPage = listModel.current_page {
            if currentPage ==  1 {
                cards = models
                if cards.count == 0 {
                    NicooErrorView.showErrorMessage("你还没有福利卡, 快去分享获得吧～", on: view, customerTopMargin: nil, clickHandler: nil)
                }
                if cards.count == WelfareInvailCardApi.kDefaultCount {
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
            } else {
                cards.append(contentsOf: models)
                if models.count == WelfareInvailCardApi.kDefaultCount {
                    loadMoreView.isHidden = false
                } else {
                    loadMoreView.isHidden = true
                }
            }
        }
        endRefreshing()
        tableView.reloadData()
    }
    
    private func  endRefreshing() {
        tableView.mj_header.endRefreshing()
        tableView.mj_footer.endRefreshing()
    }
    
    
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension LuckCardInvailController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return (ConstValue.kScreenWdith-20)/3.55 + 20
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cards.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: LuckCardsCell.cellId, for: indexPath) as! LuckCardsCell
        /// 适配背景图
        cell.lineConst.constant = (ConstValue.kScreenWdith-20)/3.55
        let model = cards[indexPath.row]
        cell.cardImage.image = UIImage(named: (model.status ?? 1) == 2 ? "luckCardUsed" : "luckCardFailed")
        cell.cardActionBtn.isHidden = true
        cell.fakeLable.isHidden = true
        cell.cardValueLab.text = model.discount ?? "7.9"
        cell.inviteCountLab.text = "\(model.title ?? "")"
        cell.cardExplainLab.text = "有效期至\(model.expire ?? "")"
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        
    }
    
    
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension LuckCardInvailController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is WelfareInvailCardApi {
            if let welfareCardList = manager.fetchJSONData(UserReformer()) as? WelfareGetCardList {
                welfareCardListSuccess(welfareCardList)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is WelfareInvailCardApi {
            NicooErrorView.showErrorMessage(.noNetwork, on: view) {
                self.loadData()
            }
        }
    }
}



// MARK: - Layout
private extension LuckCardInvailController {
    
    func layoutPageSubviews() {
        
        layoutTableView()
    }
    
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-ConstValue.kStatusBarHeight - 50)
            } else {
                make.bottom.equalToSuperview().offset(-ConstValue.kStatusBarHeight - 50)
            }
            make.leading.top.trailing.equalToSuperview()
        }
    }
    
    
}
