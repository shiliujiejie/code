//
//  IDCardInfoController.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/4/17.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

class IDCardInfoController: UIViewController {
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .default
    }
    
    private lazy var navBar: QHNavigationBar = {
        let bar = QHNavigationBar()
        bar.titleLabel.text = "身份卡"
        bar.titleLabel.textColor = UIColor.darkText
        bar.backgroundColor = UIColor(white: 0.98, alpha: 1.0)
        bar.backButton.setImage(UIImage(named: "icon_angle_left_s_"), for: .normal)
        bar.delegate = self
        return bar
    }()
    var isPresent = false

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        view.addSubview(navBar)
        layoutPageSubviews()
        loadCardView()
    }

    private func loadCardView() {
        guard let card = Bundle.main.loadNibNamed("IDCardView", owner: nil, options: nil)?[0] as? IDCardView else { return }
        view.addSubview(card)
        layoutCardView(card)
        if isPresent {
            navBar.backButton.setImage(UIImage(named: "recordClose"), for: .normal)
            navBar.backgroundColor = UIColor.clear
            navBar.titleLabel.textColor = UIColor.white
             navBar.titleLabel.text = ""
            card.actionHandler = { [weak self] (id) in
                self?.dismiss(animated: false, completion: nil)
            }
        }
        
    }
    
}

// MARK: - QHNavigationBarDelegate
extension IDCardInfoController:  QHNavigationBarDelegate  {
    
    func backAction() {
        if isPresent {
            dismiss(animated: false, completion: nil)
            return
        }
        navigationController?.popViewController(animated: true)
    }
}

private extension IDCardInfoController {
    func layoutPageSubviews() {
        layoutNavBar()
    }
    
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
    }
    
    func layoutCardView(_ card: IDCardView) {
        card.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(navBar.snp.bottom)
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
        }
    }
}
