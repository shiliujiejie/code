//
//  MakeMoneyController.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/5/31.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import NicooNetwork

class MakeMoneyController: UIViewController {

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    private lazy var navBar: QHNavigationBar = {
        let bar = QHNavigationBar()
        bar.titleLabel.text = "赚钱"
        bar.titleLabel.textColor = UIColor.white
        bar.backgroundColor = UIColor.clear
        bar.delegate = self
        return bar
    }()
    private let headerView: UIView = {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 284))
        return view
    }()
    private var header: MoneyHeadView = {
        guard let view = Bundle.main.loadNibNamed("MoneyHeadView", owner: nil, options: nil)?[0] as? MoneyHeadView else { return MoneyHeadView() }
        view.frame = CGRect(x: 0, y: 0, width: view.bounds.width, height: 284)
        return view
    }()
    private let lineView: UIView = {
        let view = UIView()
        view.backgroundColor = ConstValue.kTitleYelloColor
        return view
    }()
    private lazy var feedBackBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("如有疑问，请提交问题反馈", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        button.setTitleColor(ConstValue.kTitleYelloColor, for: .normal)
        button.addTarget(self, action: #selector(feedBackBtnClick(_:)), for: .touchUpInside)
        return button
    }()
    private lazy var tableView: UITableView = {
        let table = UITableView()
        table.backgroundColor = UIColor.clear
        table.showsVerticalScrollIndicator = false
        table.allowsSelection = true
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .none
        table.register(OrderExplainCell.classForCoder(), forCellReuseIdentifier: OrderExplainCell.cellId)
        return table
    }()
    private lazy var walletApi: UserWalletApi = {
        let api = UserWalletApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    
    
    var walletModel = WalletInfo()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpSubviews()
    }
    
    private func setUpSubviews() {
        view.backgroundColor = UIColor(r: 22, g: 24, b: 36)
        view.addSubview(navBar)
        headerView.addSubview(header)
        view.addSubview(headerView)
        view.addSubview(feedBackBtn)
        view.addSubview(lineView)
        view.addSubview(tableView)
        addHeaderActionCallBack()
        
        tableView.tableHeaderView = headerView
        layoutPageSubviews()
        loadData()
    }
    
    private func loadData() {
        let _ = walletApi.loadData()
    }
    
    private func addHeaderActionCallBack() {
        header.actionHandler = { [weak self] (action) in
            if action == 1 {
                let drawvc = DrawCashController()
                drawvc.allMoney = self?.walletModel.money ?? "0.00"
                self?.navigationController?.pushViewController(drawvc, animated: true)
            }
            if action == 2 {
                let uploadLicense = UploadLicenseController()
                uploadLicense.webType = .typeFenxiao
                self?.navigationController?.pushViewController(uploadLicense, animated: true)
            }
        }
    }
    
    private func configUserHeader() {
        header.myMoneyLab.text = "余额: ¥\(walletModel.money ?? "0.00")"
        header.moneyA.attributedText = TextSpaceManager.configColorString(allString: "¥\(walletModel.bonus_a ?? "0.00")", attribStr: "¥", UIColor.white, 10.0)
        header.moneyB.attributedText = TextSpaceManager.configColorString(allString: "¥\(walletModel.bonus_b ?? "0.00")", attribStr: "¥", UIColor.white, 10.0)
        if (walletModel.sales_type ?? UserWalletLevel.normal) == .daRen {
              header.moneyC.attributedText = TextSpaceManager.configColorString(allString: "¥\(walletModel.bonus_c ?? "0.00")", attribStr: "¥", UIColor.white, 10.0)
        }

        header.moneyAll.attributedText = TextSpaceManager.configColorString(allString: "¥\(walletModel.bonus ?? "0.00")", attribStr: "¥", UIColor.white, 10.0)
        header.userType.text = (walletModel.sales_type ?? UserWalletLevel.normal) == .daRen ? "分享达人" : "普通用户"
    }
    
    @objc private func feedBackBtnClick(_ sender: UIButton) {
        let feedBack = HelpController()
        navigationController?.pushViewController(feedBack, animated: true)
    }

}

// MARK: - QHNavigationBarDelegate
extension MakeMoneyController:  QHNavigationBarDelegate  {
    
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}

// MARK: - UITableViewDataSource, UITableViewDelegate
extension MakeMoneyController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 50))
        view.backgroundColor = UIColor.clear
        let lable = UILabel(frame: CGRect(x: 25, y: 10, width: ConstValue.kScreenWdith - 50, height: 30))
        lable.font = UIFont.boldSystemFont(ofSize: 16)
        lable.textColor = UIColor.white
        lable.text = "规则说明"
        view.addSubview(lable)
        let lineView = UIView(frame: CGRect(x: 25, y: 49.5, width: ConstValue.kScreenWdith - 50, height: 0.5))
        lineView.backgroundColor = UIColor(red: 14/255.0 , green: 15/255.0, blue: 24/255.0, alpha: 0.99)
        view.addSubview(lineView)
        return view
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: OrderExplainCell.cellId, for: indexPath) as! OrderExplainCell
        let attributedString = NSMutableAttributedString(string: "A、所有用户均享有A、B两级收益,如果你有用户资源,可申请开通分享达人,享受A、B、C三级收益\r\r联系方式：douyinkefu1@gmail.com\r\rB、分享达人邀请A级用户人数≥1000人时可获得额外收益额外收益=邀请A级用户人数×0.6元\r\rC、最小提现金额100元,1-2个工作日内到账", attributes: [
            .font: UIFont.systemFont(ofSize: 14),
            .foregroundColor: UIColor(white: 0.7, alpha: 1.0)
            ])
        attributedString.addAttribute(.foregroundColor, value: UIColor(red: 251.0 / 255.0, green: 211.0 / 255.0, blue: 16.0 / 255.0, alpha: 1.0), range: NSRange(location: 54, length: 23))
        cell.msgLable.attributedText = attributedString
        cell.selectionStyle = .none
        return cell
    }
    
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension MakeMoneyController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if  manager is UserWalletApi {
            if let wallet = manager.fetchJSONData(UserReformer()) as? WalletInfo {
                walletModel = wallet
                configUserHeader()
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is UserWalletApi {
            XSAlert.show(type: .error, text: manager.errorMessage)
        }
    }
}


// MARK: - Description
private extension MakeMoneyController {
    
    func layoutPageSubviews() {
        layoutNavBar()
        layoutTableHeaderView()
        layoutBottomView()
        layoutTableView()
    }
    
    func layoutTableHeaderView() {
        header.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            make.bottom.equalTo(feedBackBtn.snp.top)
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(navBar.snp.bottom).offset(0)
        }
    }
    
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
    }
    
    func layoutBottomView() {
        feedBackBtn.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-10)
            } else {
                make.bottom.equalToSuperview().offset(-10)
            }
        }
        lineView.snp.makeConstraints { (make) in
            make.top.equalTo(feedBackBtn.snp.bottom).offset(-6)
            make.height.equalTo(0.5)
            make.leading.trailing.equalTo(feedBackBtn)
        }
    }
  
  
    
}
