//
//  InviteCodeController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/19.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import DouYinScan

class InviteCodeController: UIViewController {
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }

    @IBOutlet weak var bgImageView: UIImageView!
    @IBOutlet weak var titleLab: UILabel!

    @IBOutlet weak var qrCodeImage: UIImageView!
    @IBOutlet weak var saveQRCodeBtn: UIButton!
    @IBOutlet weak var inviteFrientBtn: UIButton!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var scanCodeTItle: UILabel!
    
    @IBOutlet weak var arrowDownBtn: UIButton!
    @IBOutlet weak var inviteCodeLab: UILabel!
    
    @IBOutlet weak var webLable: UILabel!
    @IBOutlet weak var titLab: UILabel!
    var codeImage: UIImage?

    @IBOutlet weak var topMagin: NSLayoutConstraint!
    var isLeftSide = true
    var downActionHandler:(() -> Void)?
    var backActionHandler:(() -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configUI()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
        backButton.isHidden = isLeftSide
        loadQRcode()
        getUserInviteCode()
    }
    
    @IBAction func backButtonClick(_ sender: UIButton) {
        backActionHandler?()
    }
    @objc func updataShareInfo(_ sender: Notification) {
        loadQRcode()
        getUserInviteCode()
    }
    
    private func configUI() {
        
        saveQRCodeBtn.layer.cornerRadius = 20
        saveQRCodeBtn.layer.masksToBounds = true
        inviteFrientBtn.layer.cornerRadius = 20
        inviteFrientBtn.layer.masksToBounds = true
        backButton.backgroundColor = UIColor(white: 0.9, alpha: 0.2)
        backButton.layer.cornerRadius = 15
        backButton.layer.masksToBounds = true
        if UIDevice.current.isiPhoneXSeriesDevices() {
            topMagin.constant = 45.0
        } else {
            topMagin.constant = 20.0
        }
    
        titleLab.text = "成功邀请好友安装使用APP,并填写您的推广码.\n可享受每日无限次数观看"
        titleLab.textColor = UIColor(red:235/255.0, green: 217/255.0, blue: 3/255.0, alpha: 1.0)
        titLab.text = "推广分享"
        
        scanCodeTItle.textColor = UIColor(red:120/255.0, green: 72/255.0, blue: 47/255.0, alpha: 1.0)
        
        saveQRCodeBtn.setTitle("保存二维码", for: .normal)
        saveQRCodeBtn.backgroundColor = UIColor(white: 0.3, alpha: 0.8)
        inviteFrientBtn.backgroundColor = UIColor(white: 0.3, alpha: 0.8)
        inviteFrientBtn.setTitle("复制推广链接", for: .normal)
        saveQRCodeBtn.setTitleColor(UIColor(red:235/255.0, green: 217/255.0, blue: 3/255.0, alpha: 1.0), for: .normal)
        inviteFrientBtn.setTitleColor(UIColor(red:235/255.0, green: 217/255.0, blue: 3/255.0, alpha: 1.0), for: .normal)
        webLable.text = AppInfo.share().official_url ?? ConstValue.kAppDownLoadLoadUrl
    }
    
    func getUserInviteCode() {
        if let userInviteCode = UserModel.share().userInfo?.code {
           inviteCodeLab.text = userInviteCode
        } else {
            if let codeSave = UserDefaults.standard.object(forKey: UserDefaults.kUserInviteCode) as? String {
                 inviteCodeLab.text = codeSave
            }
        }
    }
    
    func screenSnapshot(save: Bool) -> UIImage? {
        guard let window = UIApplication.shared.keyWindow else { return nil }
        // 用下面这行而不是UIGraphicsBeginImageContext()，因为前者支持Retina
        UIGraphicsBeginImageContextWithOptions(window.bounds.size, false, 0.0)
        window.layer.render(in: UIGraphicsGetCurrentContext()!)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        if save { UIImageWriteToSavedPhotosAlbum(image ?? codeImage!, self, nil, nil) }
        return image
    }
    
    @IBAction func saveQrcode(_ sender: UIButton) {
        let image = screenSnapshot(save: true)
        if  image != nil {
            let showMessage = "保存成功！"
            XSAlert.show(type: .success, text: showMessage)
        }
    }
    
    @IBAction func inviteReward(_ sender: UIButton) {
        downActionHandler?()
    }
    
    @IBAction func inviteFriends(_ sender: Any) {
        var downString = ConstValue.kAppDownLoadLoadUrl
        if let downloadString = AppInfo.share().share_url {
            if downloadString.hasSuffix("/") {
                downString = downloadString
            } else {
                downString = String(format: "%@%@", downloadString, "/")
            }
        }
        
        if let userInviteCode = UserModel.share().userInfo?.code {
            downString = String(format: "%@%@",downString, userInviteCode)
        } else {
            if let codeSave = UserDefaults.standard.object(forKey: UserDefaults.kUserInviteCode) as? String {
                downString = String(format: "%@%@", downString, codeSave)
            } else {
                downString = String(format: "%@", downString)
            }
        }
        var textShare = "抖阴小视频"
        if let textToShare = AppInfo.share().share_text {
            if textToShare.contains("{{share_url}}") {
                textShare = textToShare.replacingOccurrences(of: "{{share_url}}", with: downString)
            }
        }
        UIPasteboard.general.string = String(format: "%@", textShare)
        XSAlert.show(type: .success, text: "复制成功！")
        //UIPasteboard.general.addItems(<#T##items: [[String : Any]]##[[String : Any]]#>)
        //UIPasteboard.general.va
    }
    
    @objc private func saveImage(image: UIImage, didFinishSavingWithError error: NSError?, contextInfo: AnyObject) {
        let showMessage = "保存成功！"
        if error != nil{
        } else{ }
        XSAlert.show(type: .success, text: showMessage)
    }
    
}

extension InviteCodeController {
    
    func loadQRcode() {
        var downString = String(format: "%@", ConstValue.kAppDownLoadLoadUrl)
        if let downloadString = AppInfo.share().share_url {
            if downloadString.hasSuffix("/") {
                downString = downloadString
            } else {
                downString = String(format: "%@%@", downloadString, "/")
            }
        }
        if let userInviteCode = UserModel.share().userInfo?.code {
            downString = String(format: "%@%@",downString, userInviteCode)
        } else {
            if let codeSave = UserDefaults.standard.object(forKey: UserDefaults.kUserInviteCode) as? String {
                downString = String(format: "%@%@", downString, codeSave)
            } else {
                downString = String(format: "%@", downString)
            }
        }
        let qrImg = ScanWrapper.createCode(codeType: "CIQRCodeGenerator", codeString: downString, size: CGSize(width: 200, height: 200), qrColor: UIColor.black, bkColor: UIColor.clear)
        let logoImg = UIImage(named: "iconShare")
        qrCodeImage.image = ScanWrapper.addImageLogo(srcImg: qrImg!, logoImg: logoImg!, logoSize: CGSize(width: 30, height: 30))
        codeImage = qrCodeImage.image
    }
}
