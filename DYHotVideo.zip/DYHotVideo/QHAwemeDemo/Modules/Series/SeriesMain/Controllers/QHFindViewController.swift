//
//  QHFindViewController.swift
//  QHAwemeDemo
//
//  Created by Anakin chen on 2017/10/16.
//  Copyright © 2017年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import NicooNetwork
import MJRefresh

class QHFindViewController: QHBaseViewController {
    
    static let videoItemWidth: CGFloat = (ConstValue.kScreenWdith - 6)/2
    static let videoItemHieght: CGFloat = videoItemWidth * 1.36 + 60
    static let videoItemSize: CGSize = CGSize(width: videoItemWidth, height: videoItemHieght)
    
    private lazy var navBar: QHNavigationBar = {
        let bar = QHNavigationBar()
        bar.titleLabel.text = "系列"
        bar.titleLabel.textColor = UIColor.white
        bar.backgroundColor = UIColor.clear
        bar.backButton.isHidden = true
        bar.delegate = self
        return bar
    }()
    private lazy var layoutBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("切换布局", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        button.setTitleColor(UIColor(red: 235/255.0, green: 217/255.0, blue: 3/255.0, alpha: 1.0), for: .normal)
        button.addTarget(self, action: #selector(layoutBtnClick(_:)), for: .touchUpInside)
        button.isHidden = true
        return button
    }()
    private let layoutFlow: CustomFlowLayout = {
        let layout = CustomFlowLayout()
        layout.itemSize = CGSize(width: ConstValue.kScreenWdith-80, height: ConstValue.kScreenHeight - ConstValue.kStatusBarHeight - 88 - 120)
        return layout
    }()
   
    private let layout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = videoItemSize
        layout.minimumLineSpacing = 2   // 垂直最小间距
        layout.minimumInteritemSpacing = 1 // 水平最小间距
        layout.sectionInset = UIEdgeInsets(top: 1, left: 1, bottom: 5, right: 1)
        return layout
    }()
    private lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.clear
        collection.showsVerticalScrollIndicator = false
        collection.register(UINib.init(nibName: "SeriesMainCell", bundle: Bundle.main), forCellWithReuseIdentifier: SeriesMainCell.cellId)
        collection.mj_header = refreshView
        //collection.mj_footer = loadMoreView
        collection.isHidden = false
        return collection
    }()
    private lazy var collectionScroll: UICollectionView = {
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layoutFlow)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.clear
        collection.showsVerticalScrollIndicator = false
        collection.register(UINib.init(nibName: "SeriesMainCell", bundle: Bundle.main), forCellWithReuseIdentifier: SeriesMainCell.cellId)
        //collection.mj_footer = loadMoreView
        collection.isHidden = true
        return collection
    }()
    
    lazy private var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.isRefreshOperation = true
            weakSelf?.loadData()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        mjRefreshHeader?.stateLabel.font = ConstValue.kRefreshLableFont
        mjRefreshHeader?.lastUpdatedTimeLabel.font = ConstValue.kRefreshLableFont
        return mjRefreshHeader!
    }()
    private lazy var videoCateApi: VideoSeriesListApi =  {
        let api = VideoSeriesListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    var cateModels = [VideoCategoryModel]()
    
    var isRefreshOperation = false

    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navBar.navBarView.addSubview(layoutBtn)
        view.addSubview(navBar)
        view.addSubview(collectionView)
        view.addSubview(collectionScroll)
        layoutPageSubviews()
        loadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
 
    
    @objc func layoutBtnClick(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        if sender.isSelected {
            collectionView.isHidden = true
            collectionScroll.isHidden = false
        } else {
            collectionScroll.isHidden = true
            collectionView.isHidden = false
        }
        collectionScroll.reloadData()
        collectionView.reloadData()
       
    }
 
}

// MARK: - QHNavigationBarDelegate
extension QHFindViewController:  QHNavigationBarDelegate  {
    
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}

// MARK: - Private - Funcs
private extension QHFindViewController {
    
    func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        if !isRefreshOperation {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        }
        let _ = videoCateApi.loadData()
    }
    
    func loadNextPage() {
        let _ = videoCateApi.loadNextPage()
    }
    
    func endRefreshing() {
        collectionView.mj_header.endRefreshing()
        //collectionView.mj_footer.endRefreshing()
    }
    
    func succeedRequest(_ models: CateTypeListModel) {
        if let modelList = models.data {
            cateModels = modelList
            layoutBtn.isHidden = cateModels.count == 0
            endRefreshing()
            collectionView.reloadData()
            collectionScroll.reloadData()
            isRefreshOperation = true
        }
    }
    
    func failedRequest(_ manager: NicooBaseAPIManager) {
        endRefreshing()
        //XSAlert.show(type: .error, text: "数据走丢了。")
        if !isRefreshOperation {
            NicooErrorView.showErrorMessage(.noNetwork, on: self.view) {
                self.loadData()
            }
        }
       
    }
}


// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension QHFindViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return cateModels.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cellForRow(with: indexPath)
        return cell
    }
    
    /// 配置cell
    func cellForRow(with indexPath: IndexPath) -> UICollectionViewCell {
        if layoutBtn.isSelected {
            let cell = collectionScroll.dequeueReusableCell(withReuseIdentifier: SeriesMainCell.cellId, for: indexPath) as! SeriesMainCell
            let model = cateModels[indexPath.row]
            cell.nameLable.text = "\(model.view_key_title ?? "")"
            cell.thumpUpButton.setTitle("\(model.recommend ?? 0)", for: .normal)
            cell.weekLable.text = "第\(indexPath.row + 1)期"
            cell.timeLable.text = model.updated_at_string ?? ""
            cell.seriesPicture.kfSetVerticalImageWithUrl(model.cover_filename)
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SeriesMainCell.cellId, for: indexPath) as! SeriesMainCell
            let model = cateModels[indexPath.row]
            cell.nameLable.text = "\(model.view_key_title ?? "")"
            cell.thumpUpButton.setTitle("\(model.recommend ?? 0)", for: .normal)
            cell.weekLable.text = "第\(indexPath.row + 1)期"
            cell.timeLable.text = model.updated_at_string ?? ""
            cell.seriesPicture.kfSetVerticalImageWithUrl(model.cover_filename)
            return cell
        }
      
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let serivc = SpecialTopicDetailController()
        let model = cateModels[indexPath.row]
        serivc.model = model
        navigationController?.pushViewController(serivc, animated: true)
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension QHFindViewController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        return [VideoSeriesListApi.kType: "XILIE"]
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if let videoCateList = manager.fetchJSONData(VideoReformer()) as? CateTypeListModel {
            if manager is VideoSeriesListApi {
                succeedRequest(videoCateList)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is VideoSeriesListApi {
            failedRequest(manager)
        }
    }
}


// MARK: - Layout
private extension QHFindViewController {
    
    func layoutPageSubviews() {
        layoutNavBar()
        layoutLayoutBtnBtn()
        layoutCollection()
        layoutCollectionScroll()
    }
    
    func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(navBar.snp.bottom)
            make.leading.trailing.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-44)
            } else {
                make.bottom.equalToSuperview().offset(-44)
            }
        }
    }
    
    func layoutCollectionScroll() {
        collectionScroll.snp.makeConstraints { (make) in
            make.top.equalTo(navBar.snp.bottom).offset(20)
            make.leading.trailing.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-44)
            } else {
                make.bottom.equalToSuperview().offset(-44)
            }
        }
    }
    
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
    }
    
    func layoutLayoutBtnBtn() {
        layoutBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-12)
            make.centerY.equalToSuperview()
            make.width.equalTo(65)
            make.height.equalTo(35)
        }
    }
}
