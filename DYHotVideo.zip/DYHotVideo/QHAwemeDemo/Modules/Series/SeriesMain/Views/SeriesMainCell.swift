//
//  SeriesMainCell.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/3.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

class SeriesMainCell: UICollectionViewCell {

    static let cellId = "SeriesMainCell"
    
    @IBOutlet weak var covorOneview: UIView!
    @IBOutlet weak var coverTwoView: UIView!
    @IBOutlet weak var seriesPicture: UIImageView!
    
    @IBOutlet weak var timeLable: UILabel!
    @IBOutlet weak var weekLable: UILabel!
    @IBOutlet weak var nameLable: UILabel!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var thumpUpButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        contentView.backgroundColor = UIColor.clear
        bottomView.backgroundColor = UIColor(white: 0.0, alpha: 0.2)
        covorOneview.layer.cornerRadius = 10
        covorOneview.layer.masksToBounds = true
        covorOneview.backgroundColor = UIColor(red: 43/255.0 , green: 46/255.0, blue: 60/255.0, alpha: 1)
        coverTwoView.layer.cornerRadius = 10
        coverTwoView.layer.masksToBounds = true
        coverTwoView.backgroundColor = UIColor(red: 80/255.0 , green: 83/255.0, blue: 97/255.0, alpha: 1)
        seriesPicture.layer.cornerRadius = 10
        seriesPicture.layer.masksToBounds = true
        thumpUpButton.backgroundColor = UIColor(white: 0.0, alpha: 0.5)
        thumpUpButton.layer.cornerRadius = 10
        thumpUpButton.layer.masksToBounds = true
    }

}
