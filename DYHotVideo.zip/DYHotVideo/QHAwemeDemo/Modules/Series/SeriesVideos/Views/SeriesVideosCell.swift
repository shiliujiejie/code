//
//  SeriesVideosCell.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/7.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

class SeriesVideosCell: UICollectionViewCell {
    
    static let cellId = "SeriesVideosCell"

    @IBOutlet weak var videoImage: UIImageView!
    @IBOutlet weak var titleLab: UILabel!
    @IBOutlet weak var commentCount: UILabel!
    @IBOutlet weak var favorCount: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

}
