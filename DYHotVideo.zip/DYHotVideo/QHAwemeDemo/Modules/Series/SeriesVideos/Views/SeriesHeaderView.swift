//
//  SeriesHeaderView.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/14.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit

class SeriesHeaderView: UIView {
    
    static let reusableId = "SeriesHeaderView"

    @IBOutlet weak var newBtn: UIButton!
    @IBOutlet weak var serHeaderImg: UIButton!
    @IBOutlet weak var serName: UILabel!
    @IBOutlet weak var serKeys: UILabel!
    @IBOutlet weak var countTitle: UILabel!
    @IBOutlet weak var itemBgview: UIView!
    @IBOutlet weak var playMoreBtn: UIButton!
    
    var loadPlayMoreDataHandler:(() -> Void)?
    var loadNewDataHandler:(() -> Void)?
    override func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = UIColor.clear
        itemBgview.backgroundColor = UIColor(white: 0.2, alpha: 0.3)
        newBtn.setBackgroundImage(UIImage.imageFromColor(UIColor(white: 0.8, alpha: 0.5), frame: CGRect(x: 0, y: 0, width: 80, height: 30)), for: .selected)
        newBtn.setTitleColor(ConstValue.kTitleYelloColor, for: .selected)
        playMoreBtn.setBackgroundImage(UIImage.imageFromColor(UIColor(white: 0.7, alpha: 0.5), frame: CGRect(x: 0, y: 0, width: 80, height: 30)), for: .selected)
        playMoreBtn.setTitleColor(ConstValue.kTitleYelloColor, for: .selected)
        playMoreBtn.layer.cornerRadius = 15
        playMoreBtn.layer.masksToBounds = true
        newBtn.layer.cornerRadius = 15
        newBtn.layer.masksToBounds = true
        playMoreBtn.isSelected = true
        serHeaderImg.layer.cornerRadius = 30.0
        serHeaderImg.layer.masksToBounds = true
        serHeaderImg.setTitleColor(ConstValue.kTitleYelloColor, for: .normal)
        serHeaderImg.backgroundColor = ConstValue.kIconBgColor
        
    }
    
    @IBAction func playMoreBtnClick(_ sender: UIButton) {
        if !sender.isSelected {
            sender.isSelected = true
            newBtn.isSelected = false
            loadPlayMoreDataHandler?()
        }
    }
    
    @IBAction func newBtnClick(_ sender: UIButton) {
        if !sender.isSelected {
            sender.isSelected = true
            playMoreBtn.isSelected = false
            loadNewDataHandler?()
        }
    }
}
