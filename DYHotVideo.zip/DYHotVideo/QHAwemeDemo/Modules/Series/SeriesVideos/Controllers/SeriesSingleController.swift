//
//  SeriesSingleController.swift
//  QHAwemeDemo
//
//  Created by mac on 2019/3/14.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import MJRefresh
import NicooNetwork

/// 系列
class SeriesSingleController: UIViewController {

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    private lazy var navBar: QHNavigationBar = {
        let bar = QHNavigationBar()
        bar.titleLabel.text = "系列"
        bar.titleLabel.textColor = UIColor.white
//        bar.backButton.layer.cornerRadius = 17
//        bar.backButton.layer.masksToBounds = true
//        bar.backButton.backgroundColor = UIColor(white: 0.0, alpha: 0.3)
        bar.backgroundColor = UIColor.clear
        //bar.lineView.backgroundColor = UIColor.clear
        bar.delegate = self
        return bar
    }()
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        let collection = UICollectionView.init(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.clear
        collection.showsVerticalScrollIndicator = false
        collection.register(VideoThridItemCell.classForCoder(), forCellWithReuseIdentifier: VideoThridItemCell.cellId)
        collection.register(SpecialTopicHeaderCell.classForCoder(), forCellWithReuseIdentifier: SpecialTopicHeaderCell.cellId)
        collection.register(UINib(nibName: "SeriesHeaderView", bundle: Bundle.main), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: SeriesHeaderView.reusableId)
        collection.mj_footer = loadMoreView
        return collection
    }()
    
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        return MJRefreshAutoNormalFooter(refreshingBlock: {
            // weakSelf?.loadNextPage()
        })
    }()
    //    private lazy var videoListApi: SpecialVideoInfoApi = {
    //        let api = SpecialVideoInfoApi()
    //        api.paramSource = self
    //        api.delegate = self
    //        return api
    //    }()
    var isRefreshOperation = false
    var special_id: Int?
    var headerInfoHeight: CGFloat = 0.0
    
    var videoList = [VideoModel]()
    var videoCount: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        addPageSubviews()
        loadMoreView.isHidden = true
        // loadActorVideoList()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    func addPageSubviews() {
        view.addSubview(collectionView)
        view.addSubview(navBar)
        layoutPageSubviews()
    }
    
    
    
    
}

// MARK: - QHNavigationBarDelegate
extension SeriesSingleController:  QHNavigationBarDelegate  {
    
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource

extension SeriesSingleController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return  12
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cellForRow(with: indexPath)
        return cell
    }
    
    /// 配置cell
    func cellForRow(with indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: VideoThridItemCell.cellId, for: indexPath) as! VideoThridItemCell
        
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        
    }
    
}

// MARK: - UICollectionViewDelegateFlowLayout

extension SeriesSingleController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let bookItemWidth: CGFloat = (ConstValue.kScreenWdith - 20)/3
        let bookItemHieght: CGFloat = bookItemWidth * 1.3 + 35
        return CGSize(width: bookItemWidth, height: bookItemHieght)
    }
    
    /// 边距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        if section == 0 {
            return UIEdgeInsets.zero
        }
        return UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 5)
    }
    
    /// 垂直最小间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    
    /// 水平最小间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        // 当然这里也是可以根据数据类型来判断
        return 5
    }
    
    /// sectionHeader高度
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: ConstValue.kScreenWdith, height: 160)
    }
    
    /// sectionFooter 高度
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        return CGSize.zero
    }
    
    
}

// MARK: - UIScrollViewDelegate
extension SeriesSingleController: UIScrollViewDelegate {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        if scrollView.contentOffset.y > 230 {
            navBar.backgroundColor = ConstValue.kVcViewColor
        } else {
            navBar.backgroundColor = UIColor.clear
        }
    }
    
}


// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension SeriesSingleController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        _ = [String: Any]()
        //        if manager is SpecialVideoInfoApi {
        //            params[SpecialVideoInfoApi.kSpecial_id] = self.special_id
        //            return params
        //        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        //        if manager is SpecialVideoInfoApi {
        //            if let videoList = manager.fetchJSONData(SpecialTopicReformer()) as? VideoListModel {
        //                requestVideoListSuccess(videoList)
        //            }
        //        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        //        if manager is SpecialVideoInfoApi {
        //            requestLisDataFail(manager)
        //        }
    }
}

// MARK: - Layout
private extension SeriesSingleController {
    
    func layoutPageSubviews() {
        layoutNavBar()
        layoutCollectionView()
        
    }
    
    func layoutCollectionView() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(navBar.snp.bottom)
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalTo(0)
            }
        }
    }
    
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
    }
    
}
