//
//  SpecialTopicDetailController.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/6.
//  Copyright © 2018年 pro5. All rights reserved.
//

import UIKit
import NicooNetwork
import MJRefresh

class SpecialTopicDetailController: UIViewController {

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    let scalePresentAnimation = ScalePresentAnimationForSerDetail()
    let scaleDismissAnimation = ScaleDismissAnimationForSerDetail()
    
    private lazy var navBar: QHNavigationBar = {
        let bar = QHNavigationBar()
        bar.titleLabel.text = ""
        bar.titleLabel.textColor = UIColor.white
        bar.backButton.layer.cornerRadius = 17
        bar.backButton.layer.masksToBounds = true
        bar.backButton.backgroundColor = UIColor(white: 0.0, alpha: 0.3)
        bar.backgroundColor = UIColor.clear
        bar.lineView.backgroundColor = UIColor.clear
        bar.delegate = self
        return bar
    }()
    lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        let collection = UICollectionView.init(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.clear
        collection.showsVerticalScrollIndicator = false
        collection.register(VideoThridItemCell.classForCoder(), forCellWithReuseIdentifier: VideoThridItemCell.cellId)
        collection.register(SpecialTopicHeaderCell.classForCoder(), forCellWithReuseIdentifier: SpecialTopicHeaderCell.cellId)
        collection.mj_footer = loadMoreView
        collection.mj_header = refreshView
        return collection
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        let loadmore = MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.viewModel.loadSeriesVideoNextPage()
        })
        loadmore?.setTitle("", for: .idle)
        loadmore?.setTitle("已经到底了", for: .noMoreData)
        return loadmore!
    }()
    lazy private var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.viewModel.isRefreshOperation = true
            weakSelf?.loadData()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        mjRefreshHeader?.stateLabel.font = ConstValue.kRefreshLableFont
        mjRefreshHeader?.lastUpdatedTimeLabel.font = ConstValue.kRefreshLableFont
        return mjRefreshHeader!
    }()
    private let viewModel = VideoViewModel()
    
    var keyId = 1
    var model: VideoCategoryModel?
    /// 选中index
    var selectIndex:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        addPageSubviews()
        loadMoreView.isHidden = true
        loadData()
        addViewModelCallBack()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    
    func addPageSubviews() {
        view.addSubview(collectionView)
        view.addSubview(navBar)
        layoutPageSubviews()
    }
    
    private func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        if !viewModel.isRefreshOperation {
            XSProgressHUD.showCustomAnimation(msg: nil, onView: view, imageNames: nil, bgColor: nil, animated: false)
        } else {
            viewModel.isRefreshOperation = false
        }
        viewModel.loadSeriesVideoData([SeriesVideoListApi.kKeyId : model?.id ?? 1])
    }
    
    private func addViewModelCallBack() {
        viewModel.requestListSuccessHandle = { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.endRefreshing()
            strongSelf.collectionView.reloadData()
            strongSelf.loadMoreView.isHidden = strongSelf.viewModel.noMore
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
        }
        viewModel.requestMoreListSuccessHandle = { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.endRefreshing()
            strongSelf.collectionView.reloadSections([1])
            strongSelf.loadMoreView.isHidden = strongSelf.viewModel.noMore
        }
        viewModel.requestFailedHandle = { [weak self] (msg) in
            guard let strongSelf = self else { return }
            strongSelf.endRefreshing()
            NicooErrorView.showErrorMessage("小姐姐走丢了，点击这里重试～", on: strongSelf.view, customerTopMargin: ConstValue.kStatusBarHeight + 430, clickHandler: {
                self?.loadData()
            })
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
        }
        viewModel.showNodataCallBackHandler = { [weak self] in
            guard let strongSelf = self else { return }
            NicooErrorView.showErrorMessage("还没有小姐姐来过这里，去别处看看吧～", on: strongSelf.view, customerTopMargin: ConstValue.kStatusBarHeight + 430, clickHandler: nil)
        }
    }
    
    private func endRefreshing() {
        collectionView.mj_header.endRefreshing()
        collectionView.mj_footer.endRefreshing()
    }

}

// MARK: - QHNavigationBarDelegate
extension SpecialTopicDetailController:  QHNavigationBarDelegate  {
    
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource

extension SpecialTopicDetailController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return section == 0 ? 1 : viewModel.getVideoList().count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cellForRow(with: indexPath)
        return cell
    }
    
    /// 配置cell
    func cellForRow(with indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.section == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SpecialTopicHeaderCell.cellId, for: indexPath) as! SpecialTopicHeaderCell
//            cell.imageBg.kfSetHorizontalImageWithUrl(videosModel?.intro_img)
            cell.infoTitle.text = model?.view_key_title ?? "观阴大湿"
            cell.infoLable.text = model?.intro ?? "这里大概是外星人在自慰吧"
            cell.imageBg.kfSetVerticalImageWithUrl(model?.cover_filename)
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: VideoThridItemCell.cellId, for: indexPath) as! VideoThridItemCell
            if viewModel.getVideoList().count > indexPath.row {
                let model = viewModel.getVideoList()[indexPath.row]
                cell.videoImageView.kfSetVerticalImageWithUrl( model.cover_path)
                cell.videoNameLable.text = model.title ?? ""
                cell.favorCountLab.text = "\(model.recommend_count ?? 0)"
            }
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        if indexPath.section == 1 {
            let controller = SeriesPlayController()
            controller.videos = viewModel.getVideoList()
            controller.currentIndex = indexPath.row
            controller.currentPlayIndex = indexPath.row
            selectIndex = indexPath.row
            controller.transitioningDelegate = self
            controller.modalPresentationStyle = .overCurrentContext
            controller.goVerbOrRefreshActionHandler = { [weak self] (isVerb) in
                if isVerb {
                    let vipvc = VipCardsController()
                    self?.navigationController?.pushViewController(vipvc, animated: false)
                } else {
                    self?.collectionView.mj_header.beginRefreshing()
                }
            }
            self.present(controller, animated: true, completion: nil)
        }
        
    }
    
}

// MARK: - UICollectionViewDelegateFlowLayout

extension SpecialTopicDetailController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if indexPath.section == 0 {
            let height: CGFloat = 430.0
            return CGSize(width: ConstValue.kScreenWdith, height: height)
        } else {
            let bookItemWidth: CGFloat = (ConstValue.kScreenWdith - 20)/3
            let bookItemHieght: CGFloat = bookItemWidth * 1.3 + 35
            return CGSize(width: bookItemWidth, height: bookItemHieght)
        }
    }
    
    /// 边距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        if section == 0 {
            return UIEdgeInsets.zero
        }
        return UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 5)
    }
    
    /// 垂直最小间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    
    /// 水平最小间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        // 当然这里也是可以根据数据类型来判断
        return 5
    }
    
}


// MARK: - UIViewControllerTransitioningDelegate
extension SpecialTopicDetailController :UIViewControllerTransitioningDelegate {
    
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        
        return  scalePresentAnimation  //ScreenShotAnimation(presentingStyle: .presenting)
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        
        return  scaleDismissAnimation // ScreenShotAnimation(presentingStyle: .dismissing)
    }
}


// MARK: - UIScrollViewDelegate
extension SpecialTopicDetailController: UIScrollViewDelegate {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        if scrollView.contentOffset.y > 320-ConstValue.kStatusBarHeight {
           navBar.backgroundColor = ConstValue.kVcViewColor
           navBar.titleLabel.text = model?.view_key_title ?? "系列"
        } else {
            navBar.backgroundColor = UIColor.clear
            navBar.titleLabel.text = ""
        }
    }
    
}

// MARK: - Layout
private extension SpecialTopicDetailController {
    
    func layoutPageSubviews() {
        layoutNavBar()
        layoutCollectionView()
        
    }
    
    func layoutCollectionView() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(-ConstValue.kStatusBarHeight)
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalTo(0)
            }
        }
    }
    
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
    }
    
}
