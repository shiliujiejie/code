//
//  ViewController.swift
//  AFDownLoad
//
//  Created by mac on 2019/7/10.
//  Copyright © 2019年 mac. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

    @IBOutlet weak var progressView: UIProgressView!
    
    var downLoadRequest: DownloadRequest!
    //用于停止下载时，保存已下载的部分
    var resumeData: Data?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // 注册APP被挂起 + 进入前台通知
        NotificationCenter.default.addObserver(self, selector: #selector(applicationResignActivity(_:)), name: UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(applicationBecomeActivity(_:)), name: UIApplication.didBecomeActiveNotification, object: nil)

    }

    @IBAction func startAction(_ sender: UIButton) {
        downLoadWithPath("http://dldir1.qq.com/qqfile/qq/QQ7.9/16621/QQ7.9.exe")
    }
    
    @IBAction func pauseAction(_ sender: Any) {
        downLoadRequest.cancel()
      
    }
    
    @IBAction func ctioncontinue(_ sender: UIButton) {
        continueDownLoad("http://dldir1.qq.com/qqfile/qq/QQ7.9/16621/QQ7.9.exe")
    }
    
}

extension ViewController {
    /// 根目录
    func rootFilePath() -> String? {
        let docDir = NSSearchPathForDirectoriesInDomains(.cachesDirectory, .userDomainMask, true)[0]
        let filePath = (docDir as NSString).appendingPathComponent("downLoadSource")
        if !FileManager.default.fileExists(atPath: filePath) {
            do {
                try FileManager.default.createDirectory(atPath: filePath, withIntermediateDirectories: true, attributes: nil)
            } catch {
                print(error)
                return nil
            }
        }
        return filePath
    }
    
    func downLoadWithPath(_ urlString: String) {
        guard let rootFilePath = self.rootFilePath() else {
            return
        }
        //下载文件的保存路径
        let destination: DownloadRequest.DownloadFileDestination = { _, _ in
            
            let videoPath = rootFilePath + "/\(urlString.components(separatedBy: "/").last ?? "")"
            let fileUrl = URL(fileURLWithPath: videoPath)
             print("videoPath ========== \(videoPath)")
            return (fileUrl, [.removePreviousFile, .createIntermediateDirectories])
        }
       
       downLoadRequest = Alamofire.download(urlString, to: destination)
            .downloadProgress { progress in
                print("Download Progress : \(progress.fractionCompleted)")
                DispatchQueue.main.async {
                    self.progressView.progress = Float(progress.fractionCompleted)
                }
            }

            .responseData { response in
                if let _ = response.result.value {
                    // let _ = SwiftAdFileConfig.saveVideoToLocal(adModel.adUrl, data: data)
                    /// 存入当前需要展示的广告模型
                    
                }
                if let error = response.error {
                    if (error as NSError).code  == NSURLErrorCancelled {
                        print("cancel - download")
                        self.resumeData = response.resumeData
                    } else if (error as NSError).code == NSURLErrorNetworkConnectionLost || (error as NSError).code == NSURLErrorTimedOut
                    {
                        print(" failed - Network")
                    } else {
                        print(" failed - download")
                    }
                }
        }
    
        
    }
    
    func continueDownLoad(_ urlString: String) {
        guard let rootFilePath = self.rootFilePath() else {
            return
        }
        //下载文件的保存路径
        let destination: DownloadRequest.DownloadFileDestination = { _, _ in
            
            let videoPath = rootFilePath + "/\(urlString.components(separatedBy: "/").last ?? "")"
            let fileUrl = URL(fileURLWithPath: videoPath)
             print("videoPath ========== \(videoPath)")
            return (fileUrl, [.removePreviousFile, .createIntermediateDirectories])
        }
        if let resumedata = self.resumeData {
            downLoadRequest = Alamofire.download(resumingWith: resumedata, to: destination)
                .downloadProgress(closure: { (progress) in
                    print("Download Progress : \(progress.fractionCompleted)")
                    DispatchQueue.main.async {
                        self.progressView.progress = Float(progress.fractionCompleted)
                    }
                })
           
            .responseData { (response) in
                if let data = response.result.value {
                    print("下载完成 === 将数据路径。存放本地")
                }
                if let error = response.error {
                    if (error as NSError).code  == NSURLErrorCancelled {
                        print("continue - cancel - download")
                        self.resumeData = response.resumeData
                    } else if (error as NSError).code == NSURLErrorNetworkConnectionLost || (error as NSError).code == NSURLErrorTimedOut
                    {
                         print("continue - failed - download")
                    } else {
                         print("continue - failed - download111")
                    }
                }
            }
        }
    }
}

 // MARK: - APP将要被挂起
extension ViewController {
    /// - Parameter sender: 记录被挂起前的播放状态，进入前台时恢复状态
    @objc func applicationResignActivity(_ sender: NSNotification) {
        print("applicationResignActivity")
    }
    
    // MARK: - APP进入前台，恢复播放状态
    @objc func applicationBecomeActivity(_ sender: NSNotification) {
        print("applicationBecomeActivity")
    }
}

extension ViewController {
    

    
}

