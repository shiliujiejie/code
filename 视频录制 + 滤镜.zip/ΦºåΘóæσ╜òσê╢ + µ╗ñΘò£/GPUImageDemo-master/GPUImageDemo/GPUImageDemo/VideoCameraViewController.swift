//
//  VideoCameraViewController.swift
//  GPUImageDemo
//
//  Created by 唐三彩 on 2017/7/5.
//  Copyright © 2017年 唐三彩. All rights reserved.
//

import UIKit
import GPUImage
import AVKit
import AssetsLibrary

import Photos


class VideoCameraViewController: UIViewController {

    @IBOutlet weak var beautyViewBottomCons: NSLayoutConstraint!
    
    @IBOutlet weak var timeLab: UILabel!
    @IBOutlet weak var recordButton: UIButton!
    //MARK: - lazy
    //视频源
    fileprivate lazy var camera : GPUImageVideoCamera? = GPUImageVideoCamera(sessionPreset: AVCaptureSession.Preset.high.rawValue, cameraPosition: .front)
//AVCaptureSessionPreset1280x720 AVCaptureSessionPreset3840x2160
    @IBOutlet weak var videoButton: UIButton!
    //预览图层
    fileprivate lazy var preview : GPUImageView = {
        let view = GPUImageView(frame: CGRect(x: -2, y: 0, width:self.view.bounds.width + 5 , height: UIScreen.main.bounds.size.height))
        return view
    }()
    
    private lazy var progressView: CycleProgressView = {
       let progress = CycleProgressView.init(frame: CGRect(x: view.bounds.width/2 - 40, y: view.bounds.height - 120, width: 80, height: 80), lineWidth: 5.0)
        return progress
    }()
   
    //初始化滤镜
    let bilateralFilter = GPUImageBilateralFilter()     //磨皮
    let exposureFilter = GPUImageExposureFilter()       //曝光
    let brightnessFilter = GPUImageBrightnessFilter()   //美白
    let satureationFilter = GPUImageSaturationFilter()  //饱和
    
    let contrastFilter = GPUImageContrastFilter()  // 对比度
    let whiteBalance =  GPUImageWhiteBalanceFilter()  // 白平衡 （冷暖色调）
    
    let sepiaFilter = GPUImageSepiaFilter()  //怀旧
    let sharpenFilter = GPUImageSharpenFilter()         // 锐化
    
    //视频保存路径
    fileprivate lazy var fileURL : URL = {
        let tempath = NSTemporaryDirectory() + "/videoFolder"
        if FileManager.default.fileExists(atPath: tempath) == false {
            try! FileManager.default.createDirectory(atPath: tempath, withIntermediateDirectories: true, attributes: nil)
        }
        let dataFormatter =  DateFormatter()
        dataFormatter.dateFormat = "yyyyMMddHHmmss"
        let nowstr = dataFormatter.string(from: Date())
        let pth = tempath + "/\(nowstr)" + "merge.mp4"
        return URL(fileURLWithPath: pth)
    }()
    
    //保存视频对象
    fileprivate lazy var movieWriter : GPUImageMovieWriter = { [unowned self] in
        //创建写入对象
        let writer = GPUImageMovieWriter(movieURL: self.fileURL, size: CGSize(width:  self.view.bounds.width + 5, height: UIScreen.main.bounds.size.height + 10))
        return writer!
    }()
    
    var timer : Timer?
    var currentTime = 0.0
 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        recordButton.layer.cornerRadius = 30
        recordButton.layer.masksToBounds = true
        setupCamera()
        
    }
    
  
    fileprivate func setupCamera() {
        //设置camera方向
        camera?.outputImageOrientation = .portrait
        camera?.horizontallyMirrorFrontFacingCamera = true
        
        //添加预览图层
        view.insertSubview(preview, at: 0)
        
        //获取滤镜组
        let filterGroup = getGroupFilters(false)
        
        
        //设置GPUImage的响应链
        camera?.addTarget(filterGroup)
        filterGroup.addTarget(preview)
        
        
        camera?.delegate = self
        //开始采集视频
        camera?.startCapture()
        
        //设置writer属性
        movieWriter.encodingLiveVideo = true
        //将writer设置成滤镜的target
        filterGroup.addTarget(movieWriter)
        
        //设置camera的编码
        camera?.audioEncodingTarget = movieWriter
        // 初始y暗色 位0
        sepiaFilter.intensity = 0.0
        
    }
    
    //创建滤镜组
    fileprivate func getGroupFilters(_ normal: Bool) -> GPUImageFilterGroup {
        let filterGroup = GPUImageFilterGroup()
        
        //设置滤镜链接关系
        bilateralFilter.addTarget(brightnessFilter)
        brightnessFilter.addTarget(exposureFilter)
        exposureFilter.addTarget(satureationFilter)
        satureationFilter.addTarget(contrastFilter)
        contrastFilter.addTarget(sharpenFilter)
        sharpenFilter.addTarget(sepiaFilter)
        sepiaFilter.addTarget(whiteBalance)
        
        //设置group起始点 终点
        filterGroup.initialFilters = [bilateralFilter]
        
        filterGroup.terminalFilter = whiteBalance
        
        return filterGroup
    }
    
    func showAllProt() {
        print("bilateral(磨皮) === \(bilateralFilter.distanceNormalizationFactor)\n brightness（美白） === \(brightnessFilter.brightness)\n exposure（曝光） === \(exposureFilter.exposure)\n satureation（饱和度） === \(satureationFilter.saturation)\n contrast(对比度) === \(contrastFilter.contrast)\n sharpen(锐化) === \(sharpenFilter.sharpness)\n sepiaFilter(怀旧) == \(sepiaFilter.intensity)\n whiteBalance === \(whiteBalance.temperature)\n tint === \(whiteBalance.tint)")
    }
    
    @IBAction func huaijiuANniu(_ sender: UIButton) {
        camera?.removeAllTargets()
        let groups = getGroupFilters(false)
        camera?.addTarget(groups)
        groups.addTarget(preview)
    }
    
    @IBAction func startRecord(_ sender: UIButton) {
        
        //开始写入
        movieWriter.startRecording()
        recordButton.isEnabled = false
    
        timer = Timer.new(every: 1.0.seconds) { (timer) in
             self.updateTimer()
        }
        timer?.start(modes: .common)
        
        view.addSubview(progressView)
    }
    
    @objc func updateTimer(){
        currentTime += 1.0
        let second = Int(currentTime)%60 >= 10 ? "\(Int(currentTime)%60)" : "0\(Int(currentTime)%60)"
        let mins = Int(currentTime/60.0) >= 10 ? "\(Int(currentTime/60.0))" : "0\(Int(currentTime/60.0))"
        timeLab.text = String(format: "%@:%@", mins, second)
        progressView.setProgress(value: CGFloat(currentTime/1200.0))
        
    }
    
    
    //获取合成视频之后的路径  我这里直接将合成后的视频 移动到系统相册
    func getVideoMargeFilePath() -> String {
        let tempath = NSTemporaryDirectory() + "videoFolder"
        if FileManager.default.fileExists(atPath: tempath) == false {
            try! FileManager.default.createDirectory(atPath: tempath, withIntermediateDirectories: true, attributes: nil)
        }
        let dataFormatter =  DateFormatter()
        dataFormatter.dateFormat = "yyyyMMddHHmmss"
        let nowstr = dataFormatter.string(from: Date())
        let pth = tempath + "/\(nowstr)" + "merge.mp4"
        return pth
    }
    
    // 计算文件大小
    func fileSizeWithPath() {
        if let dataFile = try? Data(contentsOf: fileURL)  {
           let size = Float(dataFile.count/1024/1024)
            print("fileSize = \(size)M \n filePath = \(fileURL)")
        }
    }
    
 
}

//MARK: - 事件方法
extension VideoCameraViewController {
    //切换镜头
    @IBAction func rotateCamera(_ sender: UIBarButtonItem) {
       
        let posint = camera?.cameraPosition()
        if posint == AVCaptureDevice.Position.front {
            print("isFrontFacingCameraPresent")
        } else if posint == AVCaptureDevice.Position.back {
            print("isBackFacingCameraPresent")
        }
        camera?.rotateCamera()
    }
    
    //开启关闭滤镜
    @IBAction func switchBeautyEffect(_ sender: UISwitch) {
        if sender.isOn {
            camera?.removeAllTargets()
            let groups = getGroupFilters(false)
            camera?.addTarget(groups)
            groups.addTarget(preview)
        } else {
            camera?.removeAllTargets()
            camera?.addTarget(preview)
        }
    }
    
    //显示滤镜调整View
    @IBAction func adjustBeautyEffect(_ sender: UIBarButtonItem) {
        adjustBeautyView(constant: -80)
        showAllProt()
    }
    //完成隐藏
    @IBAction func finishedBeautyEffect(_ sender: UIButton) {
        adjustBeautyView(constant: 370)
        showAllProt()
    }
    
    private func adjustBeautyView(constant : CGFloat) {
        beautyViewBottomCons.constant = constant
        UIView.animate(withDuration: 0.3) { 
            self.view.layoutIfNeeded()
        }
    }
    
    //饱和值
    @IBAction func changeSatureation(_ sender: UISlider) {
        // 0 - 2.0
        print("saturation = \(sender.value)")
        satureationFilter.saturation = CGFloat(sender.value)
    }
    
    //美白值
    @IBAction func changeBrightness(_ sender: UISlider) {
        // -1.0 --> 1.0
        print("brightness = \(sender.value)")
        brightnessFilter.brightness = CGFloat(sender.value)
    }
    
    //曝光度
    @IBAction func changeExposure(_ sender: UISlider) {
        // -10.0 to 10.0
        print("exposure = \(CGFloat(sender.value))")
        exposureFilter.exposure = CGFloat(sender.value)
    }
    
    //磨皮
    @IBAction func changeBilateral(_ sender: UISlider) {
        /// 数值越大，表示拍摄距离越近，越多麻子
        print("Bilateral = \(CGFloat(sender.value))")
        bilateralFilter.distanceNormalizationFactor = CGFloat(sender.value)
    }
    
    // 对比度
    @IBAction func duibiduValueChange(_ sender: UISlider) {
        // 0 -- 4.0
        print("saturation = \(CGFloat(sender.value))")
        contrastFilter.contrast =  CGFloat(sender.value) * 4.0
    }
    
    @IBAction func sperdnessValue(_ sender: UISlider) {
        // -4.0 -> 4.0
        sharpenFilter.sharpness = CGFloat(sender.value)
    }
    
    @IBAction func sediaoValueChange(_ sender: UISlider) {
        //（最大值10000，最小值1000，正常值5000）
        whiteBalance.temperature = 5000
        // 最大值1000，最小值-1000，正常值0.0）
        whiteBalance.tint = CGFloat(sender.value)
        print("whiteBalance.tint = \(CGFloat(sender.value))")
    }
    
    @IBAction func huaijiuValueChange(_ sender: UISlider) {
        /// default is 1.0   0.0 表示滤镜没有效果
        //sepiaFilter.intensity =  CGFloat(sender.value) * 2
        //（最大值10000，最小值1000，正常值5000）
        whiteBalance.temperature = CGFloat(sender.value)
        // 最大值1000，最小值-1000，正常值0.0）
        whiteBalance.tint = 0.0
        print("whiteBalance.temperature = \(CGFloat(sender.value))")
    }
    
    
    
    func stopTimer()  {
        guard let timer = timer else {
            return
        }
        timer.invalidate()
    }
}

//MARK: - GPUImageVideoCameraDelegate
extension VideoCameraViewController : GPUImageVideoCameraDelegate {
    func willOutputSampleBuffer(_ sampleBuffer: CMSampleBuffer!) {
      //  print("采集到画面")
    }
}

//MARK: - stop 播放事件
extension VideoCameraViewController {
    
    @IBAction func stopRecording(_ sender: UIBarButtonItem) {
        stopTimer()
        camera?.stopCapture()
        camera?.removeAllTargets()
        preview.removeFromSuperview()
        movieWriter.finishRecording()
        saveMovieToCameraRoll() {
            DispatchQueue.main.async {
               print("wancheng  写入操作")
                self.recordButton.isEnabled = false
                self.timeLab.textColor = UIColor.orange
                //self.navigationController?.popViewController(animated: true)
                self.currentTime = 0
            }
        }
        
    }
    
    @IBAction func playVideo(_ sender: UIBarButtonItem) {
       // 这里可以做 原片播放， +  产品内置播放
        let playerVc = AVPlayerViewController()
        playerVc.player = AVPlayer(url: fileURL)
        playerVc.player?.play()
        present(playerVc, animated: true, completion: nil)
    }
    
    func saveMovieToCameraRoll(_ finishBlock: @escaping () -> Void) {
        ALAssetsLibrary().writeVideoAtPath(toSavedPhotosAlbum: fileURL as URL!) { (url, error) in
            if let errorDescription = error?.localizedDescription {
                print("写入视频错误：\(errorDescription)")
            } else {
                //这里暂时不执行删除沙盒文件操作， 等到上传成功后再做
                //self.checkForAndDeleteFile()
                print("写入视频成功 = ")
                self.fileSizeWithPath()
                //self.getVideoFirstImage()
                self.getImageLastImage()
            }
            
            finishBlock()
        }
    }
    
    // 截取视频第一帧 图片
    func getVideoFirstImage() {
        let urlAsset = AVURLAsset(url: fileURL)
        let seconds = urlAsset.duration.seconds
        print("second: \(seconds)")
        //生成视频截图
        let generator = AVAssetImageGenerator(asset: urlAsset)
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: 240, height: 320)
        let time = CMTimeMakeWithSeconds(0.0,preferredTimescale: 600)
        var actualTime:CMTime = CMTimeMake(value: 0,timescale: 1)
        if let imageRef:CGImage = try? generator.copyCGImage(at: time, actualTime: &actualTime) {
            let frameImg = UIImage(cgImage: imageRef)
             print("displayImage = \(frameImg)")
            //显示截图
            videoButton.setBackgroundImage(frameImg, for: .normal)
        } else {
            //截图失败，显示默认图片
            videoButton.setBackgroundImage(UIImage(named: "onepice"), for: .normal)
        }
       
    }
    
    /// 截取视频最后一帧 图片
    func getImageLastImage() {
        //1. 获取视频时长
        let urlAsset = AVURLAsset(url: fileURL)
        let seconds = urlAsset.duration.seconds
        
        //2. 截图配置
        let generator = AVAssetImageGenerator(asset: urlAsset)
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        generator.requestedTimeToleranceBefore = .zero
        generator.requestedTimeToleranceAfter = .zero
        
        //3. 分段截图时间数组
        var times: [NSValue] = []
        for i in 1...Int(seconds) {
            let timeM = CMTimeMake(value: Int64(i), timescale: 1)
            if Int(timeM.seconds)%5 == 1 { // 每五秒取一帧
                let timeV = NSValue(time: timeM)
                times.append(timeV)
            }
        }
        print("times: \(times), count: \(times.count)")
        //4. 开始截图
        generator.generateCGImagesAsynchronously(forTimes: times) { [weak self]
            (requestedTime, cgimage, actualTime, result, error) in
            
            switch result {
            case .cancelled, .failed: break
            case .succeeded:
                guard let image = cgimage else {
                    return
                }
                let displayImage = UIImage(cgImage: image)
                if let dataImage = displayImage.pngData() {
                     print("dataImage.size = \(dataImage.count/1024)KB")
                }
               
                print("displayImage = \(displayImage)")
                DispatchQueue.main.async {
                    self?.videoButton.setBackgroundImage(displayImage, for: .normal)
                }
            }
        }
    }
    
    // 此步骤应该在上传成功之后来做。// 因为保存之后删除沙河中的文件，会导致上传时必须去相册w里面取。
    func checkForAndDeleteFile() {
        let fm = FileManager.default
        let url = fileURL
        let exist = fm.fileExists(atPath: url.path)
        
        if exist {
            print("删除之前的临时文件")
            do {
                try fm.removeItem(at: url as URL)
            } catch let error as NSError {
                print(error.localizedDescription)
            }
        }
    }
    
}
