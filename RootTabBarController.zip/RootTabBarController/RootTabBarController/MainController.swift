//
//  MainController.swift
//  RootTabBarController
//
//  Created by mac on 2019/6/14.
//  Copyright © 2019年 mac. All rights reserved.
//

import UIKit

class MainController: UIViewController {

    private lazy var button: UIButton = {
        let btn = UIButton(type: .custom)
        btn.frame = CGRect(x: 0, y: 0, width: screenWidth, height: 200)
        btn.setTitle("点击", for: .normal)
        btn.addTarget(self, action: #selector(click), for: .touchDown)
        btn.backgroundColor = UIColor.red
        return btn
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(button)
        view.backgroundColor = UIColor.white
    }

    @objc func click() {
        let vc = UIViewController()
        vc.title = "next"
        vc.view.backgroundColor = UIColor.yellow
        navigationController?.pushViewController(vc, animated: true)
    }

}
