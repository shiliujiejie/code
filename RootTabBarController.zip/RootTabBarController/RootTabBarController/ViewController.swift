//
//  ViewController.swift
//  RootTabBarController
//
//  Created by mac on 2019/6/14.
//  Copyright © 2019年 mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        configTabBar()
    }

    
    private func configTabBar() {
        
        let tabBarNormalImages = ["Main_N","book_N","task_N","acount_N"]
        let tabBarSelectedImages = ["Main_S","book_S","task_S","acount_S"]
        let tabBarTitles = ["首页","消息","功能","我的"]
        
        var tabBars =  [RootTabBarModel]()
        
        for i in 0 ..< tabBarNormalImages.count {
           
            let rootModel = RootTabBarModel.init(title: tabBarTitles[i], imageNormal: tabBarNormalImages[i], imageSelected: tabBarSelectedImages[i], controller: MainController())
            tabBars.append(rootModel)
        }
        let tabbarVC = RootTabBarViewController.init(config: getConfigModel(), tabBars: tabBars)
        self.addChild(tabbarVC)
        self.view.addSubview(tabbarVC.view)
    }
    
    /// 定制 tabbar 和 navgationBar 样式
    ///
    /// - Returns: RootTabBarConfig 对象
    private func getConfigModel() -> RootTabBarConfig {
        let rootConfig = RootTabBarConfig()
        rootConfig.tabBarStyle = .center
        rootConfig.isAnimation = true
        rootConfig.animation = .scaleUp
       // rootConfig.tabBarBackgroundColor = UIColor(r: 0, g: 0, b: 0, a: 0.6)
       // rootConfig.titleColorNormal = UIColor.white
        rootConfig.centerViewController = PresentController()
        
        return rootConfig
    }

}

