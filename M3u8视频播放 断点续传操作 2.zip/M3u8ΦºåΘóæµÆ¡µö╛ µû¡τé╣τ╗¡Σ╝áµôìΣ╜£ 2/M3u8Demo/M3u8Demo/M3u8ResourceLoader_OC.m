//
//  M3u8ResourceLoader_OC.m
//  M3u8Demo
//
//  Created by heweisheng on 2019/2/20.
//  Copyright © 2019年 owen. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "M3u8ResourceLoader_OC.h"

@interface M3u8ResourceLoader_OC() {
    NSString *m3u8_url_vir;
    NSString *m3u8_url;
}

@end

@implementation M3u8ResourceLoader_OC

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    return [M3u8ResourceLoader_OC shared];
}

- (instancetype)copyWithZone:(NSZone *)zone {
    return [M3u8ResourceLoader_OC shared];
}

- (instancetype)mutableCopyWithZone:(NSZone *)zone {
    return [M3u8ResourceLoader_OC shared];
}

+ (M3u8ResourceLoader_OC *)shared {
    static M3u8ResourceLoader_OC *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[super allocWithZone: nil] init];
    });
    return instance;
} 

- (M3u8ResourceLoader_OC *)init {
    self = [super init];
    m3u8_url_vir = @"m3u8Scheme://fake.m3u8";
    return self;
}

- (BOOL)resourceLoader:(AVAssetResourceLoader *)resourceLoader shouldWaitForLoadingOfRequestedResource:(AVAssetResourceLoadingRequest *)loadingRequest {
    NSString *url = [[[loadingRequest request] URL] absoluteString];
    if (!url) {
        return false;
    }
    if ([url hasSuffix: @".ts"]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            NSString *newUrl = [url stringByReplacingOccurrencesOfString: self->m3u8_url_vir withString: @"http://192.168.1.197:50009/m3u8"];
            NSURL *url = [[NSURL alloc] initWithString: newUrl];
            if (url) {
                NSURLRequest *redirect = [[NSURLRequest alloc] initWithURL: url];
                [loadingRequest setRedirect: redirect];
                [loadingRequest setResponse: [[NSHTTPURLResponse alloc] initWithURL: [redirect URL] statusCode: 301 HTTPVersion: nil headerFields: nil]];
                [loadingRequest finishLoading];
            } else {
                [self finishLoadingError: loadingRequest];
            }
        });
        return true;
    }
    if ([url isEqualToString: m3u8_url_vir]) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSData *data = [self m3u8FileRequest: self->m3u8_url];
            if (data) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    NSString *m3u8String = [[NSString alloc] initWithData: data encoding: NSUTF8StringEncoding];
                    NSString *newM3u8String = [m3u8String stringByReplacingOccurrencesOfString: @"mayun" withString: @"0x65b9bb26c958f9dafb436f8908354bbb"];
                    NSData *data = [newM3u8String dataUsingEncoding: NSUTF8StringEncoding];
                    [[loadingRequest dataRequest] respondWithData: data];
                    [loadingRequest finishLoading];
                });
            } else {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self finishLoadingError: loadingRequest];
                });
            }
        });
        return true;
    }
    if (![url hasSuffix: @".ts"] && ![url isEqualToString: m3u8_url_vir]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            NSString *newUrl = [url stringByReplacingOccurrencesOfString: self->m3u8_url_vir withString: @"http://192.168.1.197:50009"];
            NSURL *url = [[NSURL alloc] initWithString: newUrl];
            if (url) {
                NSData *data = [[NSData alloc] initWithContentsOfURL: url];
                if (data) {
                    [[loadingRequest dataRequest] respondWithData: data];
                    [loadingRequest finishLoading];
                } else {
                    [self finishLoadingError: loadingRequest];
                }
            } else {
                [self finishLoadingError: loadingRequest];
            }
        });
        return true;
    }
    return false;
}

- (void)finishLoadingError: (AVAssetResourceLoadingRequest *)loadingRequest {
    [loadingRequest finishLoadingWithError: [[NSError alloc] initWithDomain: NSURLErrorDomain code: 400 userInfo: nil]];
}

- (NSData *)m3u8FileRequest: (NSString *)url {
    return [NSData dataWithContentsOfURL: [NSURL URLWithString:url]];
}

- (AVPlayerItem *)playItemWith: (NSString *)url {
    m3u8_url = url;
    AVURLAsset *urlAsset = [[AVURLAsset alloc] initWithURL: [[NSURL alloc] initWithString: m3u8_url_vir] options: nil];
    [[urlAsset resourceLoader] setDelegate: self queue: dispatch_get_main_queue()];
    AVPlayerItem *item = [[AVPlayerItem alloc] initWithAsset: urlAsset];
    [item setCanUseNetworkResourcesForLiveStreamingWhilePaused: YES];
    return item;
}

@end
