
import UIKit
import Photos
import PryntTrimmerView

/// 视频文件来源
///
/// - Source_Camare: 实时拍摄
/// - Source_Library: 相册选取
enum VideoSourceType: Int {
    case Source_Camare = 1
    case Source_Library
}

class VTViewController: UIViewController, TrimmerViewDelegate {
    
    @IBOutlet weak var videoPlayerView: VTVideoPlayerView!
    @IBOutlet weak var trimmerView: TrimmerView!
    
    @IBOutlet weak var playerButton: UIButton!
    @IBOutlet weak var trimmingButton: DefaultButton!
    
    @IBOutlet weak var timeLabel: UILabel!
    
    
    var camareVideoPath: URL?
    
    var asset: PHAsset?
    
    private var avAsset: AVAsset?
    
    var sourceType: VideoSourceType = .Source_Library
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initNav()
        self.initPlayer()
    }
    
    override func didMove(toParent parent: UIViewController?) {
        // parent = nil の時が navigationItem の戻るボタンで戻った時
        if parent == nil {
            videoPlayerView.finish()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    private func initNav() {
        self.title = "Video"
    }
    
    
    private func initPlayer() {
       
        // FIXME: 关键处理:
        // TODO: 这里的 self.avAsset 是由 相册中视频 asset 转换而来，如果是拍摄而来， 直接用本地视频路径创建self.avAsset， 如果是拍摄的视频， 隐藏滤镜选择按钮
        if sourceType == .Source_Library {
            self.asset?.toAVAsset { (asset: AVAsset?) in
                if let a: AVAsset = asset {
                    DispatchQueue.main.async {
                        self.fixAvAsset(a)
                        let url = (a as! AVURLAsset).url.absoluteString
                        print("Url === \(url)")
                    }
                }
            }
        } else {
            let a = AVAsset.init(url: camareVideoPath!)
          
            self.fixAvAsset(a)
        }
        
    }
    
    private func fixAvAsset(_ asset: AVAsset) {
        let maxDuration: CMTime = CMTimeMake(value: 240, timescale: 1)
        // CMTimeMake(<#T##value: Int64##Int64#>, <#T##timescale: Int32##Int32#>)
        timeLabel.text = ""
        trimmerView.minDuration = 13.0
        trimmerView.maxDuration = maxDuration.seconds
        trimmerView.delegate = self
        
        self.timeLabel.text = asset.duration.seconds.toFormatedString()
        self.avAsset = asset
        self.videoPlayerView.prepare(asset: asset)
        self.trimmerView.asset = asset
        self.timeLabel.text = (self.videoPlayerView.endTime.seconds < maxDuration.seconds) ? self.videoPlayerView.endTime.seconds.toFormatedString() : maxDuration.seconds.toFormatedString()
        self.videoPlayerView.endTime = (self.videoPlayerView.endTime.seconds < maxDuration.seconds) ? self.videoPlayerView.endTime : maxDuration
    }
    
    @IBAction func playAction(_ sender: UIButton) {
        if self.videoPlayerView.isPause {
            self.videoPlayerView.resume()
        } else {
            self.videoPlayerView.pause()
        }
    }
    
    @IBAction func doneAction(_ sender: UIButton) {
        if let asset: AVAsset = self.avAsset {
            print("start export")
            let exporter: VideoExporter = VideoExporter(to: FileManager.videoExportURL)
            exporter.startTime = self.videoPlayerView.startTime
            exporter.endTime = self.videoPlayerView.endTime
            exporter.export(asset: asset) { (error: Bool, message: String) in
                if error {
                    print(message)
                    return
                }
                DispatchQueue.main.async {
                    self.fileSizeWithPath(exporter.outputUrl)
                    self.fileSizeWithPath(FileManager.videoExportURL)
                    self.fileSizeWithPath(FileManager.videoUploadURL)
                    
                }
                
                //                    PHPhotoLibrary.shared().performChanges({
                //                        PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: exporter.outputUrl)
                //                    }, completionHandler: { (success: Bool, error: Error?) in
                //                        if success {
                //                            self.close()
                //                            return
                //                        }
                //                        var message: String = "failed: save to Library"
                //                        if let err: Error = error {
                //                            message = err.localizedDescription
                //                        }
                //                        print(message)
                //                    })
            }
        }
    }
    
    
    // 计算文件大小
    private func fileSizeWithPath(_ url: URL) {
        print("outputPath = \(url.absoluteString)")
        if let dataFile = try? Data(contentsOf: url)  {
            let size = Float(dataFile.count/1024/1024)
            print("fileSize = \(size)M")
        }
    }
    
    
    private func close() {
        self.dismiss(animated: true) {
            self.videoPlayerView.finish()
        }
    }
    
    
    // MARK: - TrimmerViewDelegate
    
    func didChangePositionBar(_ playerTime: CMTime) {
        videoPlayerView.pause()
        if let startTime: CMTime = trimmerView.startTime, let endTime: CMTime = trimmerView.endTime {
            let diff: Double = endTime.seconds - startTime.seconds
            timeLabel.text = diff.toFormatedString()
            videoPlayerView.seek(to: playerTime)
            videoPlayerView.startTime = startTime
            videoPlayerView.endTime = endTime
        }
    }
    
    
    func positionBarStoppedMoving(_ playerTime: CMTime) {
        if let startTime: CMTime = trimmerView.startTime, let endTime: CMTime = trimmerView.endTime {
            let diff: Double = endTime.seconds - startTime.seconds
            timeLabel.text = diff.toFormatedString()
            videoPlayerView.seek(to: playerTime)
            videoPlayerView.startTime = startTime
            videoPlayerView.endTime = endTime
        }
    }
    
}
