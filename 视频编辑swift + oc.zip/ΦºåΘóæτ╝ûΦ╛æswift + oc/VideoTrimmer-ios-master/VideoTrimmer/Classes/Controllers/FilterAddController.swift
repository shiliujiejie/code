//
//  FilterAddController.swift
//  VideoTrimmer
//
//  Created by mac on 2019/4/16.
//  Copyright © 2019年 伊井済史. All rights reserved.
//

import UIKit
import GPUImage

/// 这个页面弹出说明，滤镜已经选择好， 这个页面是直接合成视频的
class FilterAddController: UIViewController {
    
    //预览图层
    private lazy var preview : GPUImageView = {
        let view = GPUImageView(frame: CGRect(x: 0, y: 0, width:self.view.bounds.width , height: UIScreen.main.bounds.size.height))
        return view
    }()
    private var movieFile: GPUImageMovie?
    private var movieWriter: GPUImageMovieWriter?
    //初始化滤镜
    let bilateralFilter = GPUImageBilateralFilter()     //磨皮
    let exposureFilter = GPUImageExposureFilter()       //曝光
    let brightnessFilter = GPUImageBrightnessFilter()   //美白
    let satureationFilter = GPUImageSaturationFilter()  //饱和
    let sketchFilter = GPUImageSketchFilter()     //素描
    let sepiaFilter = GPUImageSepiaFilter()  //怀旧
    
    var videoPath: URL!
    
    var timer: Timer?

    override func viewDidLoad() {
        super.viewDidLoad()
        //添加预览图层
        view.insertSubview(preview, at: 0)
        movieFile = GPUImageMovie(url: videoPath)
        movieFile?.runBenchmark = true
        movieFile?.playAtActualSpeed = false
        let filterGroup = getGroupFilters()
        movieFile?.addTarget(filterGroup)
        filterGroup.addTarget(preview)
        
        let pathToMovie = FileManager.videoUploadPath
        let url = URL.init(fileURLWithPath: FileManager.videoUploadPath)
        
        movieWriter = GPUImageMovieWriter.init(movieURL: url, size: CGSize(width: 480, height: 640))
        filterGroup.addTarget(movieWriter)
        movieWriter?.shouldPassthroughAudio = true
        movieFile?.audioEncodingTarget = movieWriter
        movieFile?.enableSynchronizedEncoding(using: movieWriter)
        movieFile?.startProcessing()
        movieWriter?.startRecording()
        
        timer = Timer.new(every: 0.3.second, { [weak self] (timer) in
            self?.retrievingProgress()
        })
        
        movieWriter?.completionBlock = { [weak self] in
            guard let strongSelf = self else { return }
            filterGroup.removeTarget(strongSelf.movieWriter)
            strongSelf.movieWriter?.finishRecording()
            DispatchQueue.main.async {
                strongSelf.timer?.invalidate()
                strongSelf.fileSizeWithPath()
            }
        }
        
    }
    

    //创建滤镜组
    private func getGroupFilters() -> GPUImageFilterGroup {
        let filterGroup = GPUImageFilterGroup()
        
        //设置滤镜链接关系
        bilateralFilter.addTarget(brightnessFilter)
        brightnessFilter.addTarget(exposureFilter)
        exposureFilter.addTarget(satureationFilter)
        satureationFilter.addTarget(sepiaFilter)
        
        //设置group起始点 终点
        filterGroup.initialFilters = [bilateralFilter]
        
        filterGroup.terminalFilter = sepiaFilter
        
        return filterGroup
    }
    
    // 计算文件大小
    private func fileSizeWithPath() {
        if let dataFile = try? Data(contentsOf: FileManager.videoUploadURL)  {
            let size = Float(dataFile.count/1024/1024)
            print("fileSize = \(size)M")
        }
    }
    
    
    private func retrievingProgress() {
        let progress = String(format: "%d%", Int((movieFile?.progress ?? 0) * 100))
        print("progress = \(progress)")
    }
}

