
import UIKit

class UserRecScrollCell: UICollectionViewCell, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    static let cellId = "UserRecScrollCell"
    static let itemSize = CGSize(width: screenWidth, height: SearchUserCell.itemSize1.height)
    
    private let customLayout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 17.5
        layout.minimumInteritemSpacing = 0
        layout.sectionInset = UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 15)
        return layout
    }()
    private lazy var collView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect.zero, collectionViewLayout: customLayout)
        collection.backgroundColor = UIColor.clear
        collection.showsHorizontalScrollIndicator = false
        collection.delegate = self
        collection.dataSource = self
        collection.register(SearchUserCell.classForCoder(), forCellWithReuseIdentifier: SearchUserCell.cellId)
        return collection
    }()
    
    var itemClickHandler:((_ index: Int) -> Void)?
    var addFocusHandler:((_ index: Int) ->Void)?
    var userModels = [CLUserInfo]()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initialize()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func initialize() {
        addSubview(collView)
        layoutSubs()
    }
    
    func setUsers(_ models: [CLUserInfo]) {
        self.userModels = models
        collView.reloadData()
    }
    
    private func layoutSubs() {
        collView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.bottom.equalTo(0)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return userModels.count + 1
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return SearchUserCell.itemSize1
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SearchUserCell.cellId, for: indexPath) as! SearchUserCell
        cell.setStype(2)
        if indexPath.item > 0 {
            cell.focusButton.isHidden = false
            cell.setUserModel(userModels[indexPath.item - 1])
            cell.addFocusActionHandler = { [weak self] in
                self?.addFocusHandler?(indexPath.item-1)
            }
        } else {
            cell.headerImg.image = getImage("FocusAddItem")
            cell.nameLab.text = "更多"
            cell.focusButton.isHidden = true
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        itemClickHandler?(indexPath.item)
    }
}
