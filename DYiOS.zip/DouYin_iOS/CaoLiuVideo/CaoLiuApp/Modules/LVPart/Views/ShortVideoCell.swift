
import UIKit

public enum ShortVideoUIType {
    case itemSizeThird
    case itemSizeScroll
    case itemSizeDouble
}

class ShortVideoCell: UICollectionViewCell {
    
    static let cellId = "ShortVideoCell"
    
    static let itemSizeThird = CGSize(width: (screenWidth - 50)/3, height: (screenWidth - 50)/3*4/3 + 50)
    static let itemSizeScroll = CGSize(width: (screenWidth - 54)/3, height: (screenWidth - 54)/3.2*4/3 + 50)
    static let itemSizeDouble = CGSize(width: (screenWidth - 40)/2, height: (screenWidth - 40)/2*4/3 + 50)
    
    private let imgView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = 6
        imageView.layer.masksToBounds = true
        return imageView
    }()
    let coverLayer: CAGradientLayer = {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.clear.cgColor, UIColor(white: 0.0, alpha: 0.6).cgColor]
        gradientLayer.locations = [0.75, 1.0]
        return gradientLayer
    }()
    let titleLab: UILabel = {
        let titleLab = UILabel()
        titleLab.font = UIFont.boldSystemFont(ofSize: 14)
        titleLab.textAlignment = .left
        titleLab.numberOfLines = 1
        titleLab.textColor = .white
        return titleLab
    }()
    lazy var avatarImage: UIButton = {
        let avatarImage = UIButton(type: .custom)
        avatarImage.layer.cornerRadius = 8
        avatarImage.layer.masksToBounds = true
        avatarImage.layer.borderWidth = 1
        avatarImage.layer.borderColor = UIColor.white.cgColor
        avatarImage.addTarget(self, action: #selector(avartarClick), for: .touchUpInside)
        return avatarImage
    }()
   
    lazy var nickNameLab: UIButton = {
        let la = UIButton(type: .custom)
        la.setTitleColor(.lightGray, for: .normal)
        la.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        la.addTarget(self, action: #selector(avartarClick), for: .touchUpInside)
        return la
    }()
    let countsView: VideoCountDataView = {
        let v = VideoCountDataView(frame: .zero)
        return v
    }()
    let dimonLab: UILabel = {
        let la = UILabel()
        la.textColor = .white
        la.textAlignment = .center
        la.font = UIFont.boldSystemFont(ofSize: 11)
        return la
    }()
    let dimondTipView: UIView = {
        let v = UIView()
        v.backgroundColor = rgb(73, 66, 230)
        v.isHidden = true
        return v
    }()
   
    var avataClickHandler:(() ->Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(imgView)
        contentView.addSubview(dimondTipView)
        dimondTipView.addSubview(dimonLab)
        contentView.addSubview(titleLab)
        contentView.addSubview(avatarImage)
        contentView.addSubview(nickNameLab)
        contentView.addSubview(countsView)
        layoutPageViews()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func avartarClick() {
        avataClickHandler?()
    }
    
    func setModel(model: VideoNew, _ type: ShortVideoUIType? = .itemSizeThird) {
        imgView.kfSetVerticalImageWithUrl(model.cover)
        titleLab.text = model.title ?? ""
        avatarImage.kfsetHeader(model.user?.avatar)
        nickNameLab.setTitle(model.user?.nick, for: .normal)
        countsView.durationLab.text = PlayerView.formatTimDuration(duration: model.duration ?? 0)
        if type == ShortVideoUIType.itemSizeScroll {
            countsView.durationLab.isHidden = true
            imgView.bounds = CGRect(x: 0, y: 0, width: ShortVideoCell.itemSizeScroll.width, height: ShortVideoCell.itemSizeScroll.height - 50)
            imgView.snp.updateConstraints { (make) in
                make.height.equalTo(ShortVideoCell.itemSizeScroll.height - 50)
            }
        } else if type == .itemSizeThird {
            countsView.durationLab.isHidden = true
            imgView.bounds = CGRect(x: 0, y: 0, width: ShortVideoCell.itemSizeThird.width, height: ShortVideoCell.itemSizeThird.height - 50)
            imgView.snp.updateConstraints { (make) in
                make.height.equalTo(ShortVideoCell.itemSizeThird.height - 50)
            }
        } else if type == .itemSizeDouble {
            countsView.durationLab.isHidden = false
            imgView.bounds = CGRect(x: 0, y: 0, width: ShortVideoCell.itemSizeDouble.width, height: ShortVideoCell.itemSizeDouble.height - 50)
            imgView.snp.updateConstraints { (make) in
                make.height.equalTo(ShortVideoCell.itemSizeDouble.height - 50)
            }
        }
        coverLayer.frame = imgView.bounds
        imgView.layer.insertSublayer(coverLayer, at: 0)
        countsView.zanCountLab.text = getStringWithNumber(model.hot ?? 0)
        countsView.playCountLab.text = getStringWithNumber(model.play ?? 0)
        if model.is_free == 1 {
            dimondTipView.isHidden = false
            dimonLab.text = "免费"
            dimondTipView.backgroundColor = rgb(231, 25, 29)
        } else {
            dimondTipView.isHidden = (model.coins ?? 0) <= 0
            dimonLab.text = "\(model.coins ?? 0)钻石"
            dimondTipView.backgroundColor = rgb(73, 66, 230)
        }
        let size = dimonLab.textSize(text: dimonLab.text ?? "", font: dimonLab.font, maxSize: CGSize(width: 200, height: 24))
        dimondTipView.bounds = CGRect(x: 0, y: 0, width: size.width + 15, height: 24)
        dimondTipView.snp.updateConstraints { (make) in
            make.width.equalTo(size.width + 15)
        }
        dimondTipView.corner(byRoundingCorners: [.topRight, .bottomLeft], radii: 6)
    }
    
    
    
    func setAdModel(model: AdHome) {
        dimondTipView.isHidden = true
        avatarImage.isHidden = true
        countsView.zanCountLab.isHidden = true
        countsView.zanImgView.isHidden = true
       
        imgView.kfSetVerticalImageWithUrl(model.cover)
        titleLab.text = model.title ?? ""
        imgView.bounds = CGRect(x: 0, y: 0, width: (screenWidth - 38)/2, height: (screenWidth - 38)/2 * 4/3)
        coverLayer.frame = imgView.bounds
        imgView.layer.insertSublayer(coverLayer, at: 0)
    }
    
    func setPictureCoverModel(_ model: PictureModel, _ isDouble: Bool) {
        imgView.kfSetVerticalImageWithUrl(model.cover)
        titleLab.text = model.source_title ?? ""
        countsView.zanCountLab.text = getStringWithNumber(model.like_count ?? 0)
        if model.coins ?? 0 > 0 {
            dimondTipView.isHidden = false
            dimonLab.text = "\(model.coins ?? 0)"
        } else {
            dimondTipView.isHidden = true
        }
        if !isDouble {
            titleLab.numberOfLines = 0
            imgView.layer.cornerRadius = 10
            imgView.bounds = CGRect(x: 0, y: 0, width: screenWidth - 20, height: (screenWidth - 20) * 4/3)
            coverLayer.frame = imgView.bounds
            imgView.layer.insertSublayer(coverLayer, at: 0)
            countsView.zanImgView.snp.updateConstraints { (make) in
                make.bottom.equalTo(-12)
                make.leading.equalTo(12)
            }
        }
    }
    
}

//MARK: -Layout
private extension ShortVideoCell {
    
    func layoutPageViews() {
        layoutImageView()
    }
    
    func layoutImageView() {
        imgView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(ShortVideoCell.itemSizeScroll.height - 50)
        }
        titleLab.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(imgView.snp.bottom).offset(8)
        }
        avatarImage.snp.makeConstraints { (make) in
            make.leading.equalTo(2)
            make.top.equalTo(titleLab.snp.bottom).offset(6)
            make.height.width.equalTo(16)
        }
        nickNameLab.snp.makeConstraints { (make) in
            make.leading.equalTo(avatarImage.snp.trailing).offset(6)
            make.centerY.equalTo(avatarImage)
        }
        countsView.snp.makeConstraints { (make) in
            make.leading.bottom.trailing.equalTo(imgView)
            make.height.equalTo(20)
        }
        dimonLab.snp.makeConstraints { (make) in
            make.leading.equalTo(6)
            make.trailing.equalTo(-6)
            make.centerY.equalToSuperview()
        }
        dimondTipView.snp.makeConstraints { (make) in
            make.trailing.top.equalToSuperview()
            make.width.equalTo(45)
            make.height.equalTo(24)
        }
    }
    

}
