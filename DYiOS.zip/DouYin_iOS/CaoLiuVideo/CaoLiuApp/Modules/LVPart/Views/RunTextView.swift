
import UIKit

class RunTextView: UIView {
    let logoImg: UIImageView = {
        let image = UIImageView()
        image.image = getImage("noticeLogo")
        return image
    }()
    let noticeTip: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.backgroundColor = UIColor(r: 252, g: 44, b: 51)
        label.font = UIFont.systemFont(ofSize: 11)
        label.textAlignment = .center
        label.layer.cornerRadius = 3
        label.layer.masksToBounds = true
        label.text = "公告"
        return label
    }()
    lazy var runhouseView: UIRunHouseView = {
        let v = UIRunHouseView(frame: CGRect(x: 100, y: 0, width: screenWidth-115, height: 40))
        v.dataSourse = self
        v.backgroundColor = UIColor.clear
        v.registerClasse(classType: CustomRunHouseView.classForCoder(), reuseIdentifier: "CustomRunHouseView")
        return v
    }()
        
    var notice: String?
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(logoImg)
        addSubview(noticeTip)
        addSubview(runhouseView)
        layoutSubs()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func layoutSubs() {
        logoImg.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.centerY.equalToSuperview()
            make.height.equalTo(20)
            make.width.equalTo(40)
        }
        noticeTip.snp.makeConstraints { (make) in
            make.leading.equalTo(logoImg.snp.trailing).offset(5)
            make.centerY.equalToSuperview()
            make.width.equalTo(36)
            make.height.equalTo(20)
        }
        runhouseView.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.leading.equalTo(noticeTip.snp.trailing).offset(6)
            make.trailing.equalTo(-12)
            make.height.equalTo(40)
        }
    }
    func setNotice(_ noticeStr: String) {
        notice = noticeStr
        runhouseView.reloadData()
    }

}
extension RunTextView: UIRunHouseViewDatasourse {
    func numberOfItemsInRunHouseView(view: UIRunHouseView) -> Int {
        return 1
    }
    func runHouseView(runHouseView: UIRunHouseView, itemForIndex index: Int) -> UIView {
        var view = runHouseView.dequeneItemViewResueIdentity(resueIdentity: "CustomRunHouseView") as? CustomRunHouseView
        if view == nil {
            view = CustomRunHouseView()
        }
        view?.label.text = notice
        view?.label.textColor = .white
        return view!
    }
    func runHouseView(runHouseView: UIRunHouseView, widthForIndex index: Int) -> CGFloat {
        if let not = notice {
            let size = UILabel().textSize(text: not, font: UIFont.systemFont(ofSize: 12), maxSize: CGSize(width: 10000, height: 25))
            return size.width + 20
        }
       return screenWidth
    }

}


