
import UIKit
//MARK: - 滚动长v
class LongScrollCell: UICollectionViewCell, PlayerViewDelegate, UIScrollViewDelegate {
    static let cellId = "LongScrollCell"
    static let itemWidth: CGFloat = screenWidth*2/3
   
    lazy var collView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: (LongScrollCell.itemWidth)*9/16 + 50), collectionViewLayout: CustomFlowLayout())
        collection.delegate = self
        collection.dataSource = self
        collection.showsHorizontalScrollIndicator = false
        //collection.isPagingEnabled = true
        collection.backgroundColor = UIColor.clear
        collection.register(LongVideoCell.classForCoder(), forCellWithReuseIdentifier: LongVideoCell.cellId)
        return collection
    }()
    lazy var player: PlayerView = {
        let player = PlayerView(frame: CGRect(x: 0, y: 0, width: LongScrollCell.itemWidth, height: LongScrollCell.itemWidth*9/16))
        player.controlViewBottomInset = 0
        player.loadingBarColor = .clear
        player.loadingBarHeight = 1
        player.progressHeight = 0.5
        player.progressTintColor = .clear
        player.controlViewCoverLayer = false
        player.isPerView = true
        player.delegate = self
        return player
    }()
    var itemClickHandler:((_ video: VideoNew) -> Void)?
    var avatarClickHandler:((_ user: CLUserInfo?) ->Void)?
    var isFistInit = true
    
    var videos = [VideoNew]()
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = .clear
        backgroundColor = .clear
        contentView.addSubview(collView)
        collView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setModels(_ models: [VideoNew]?) {
        if let vs = models {
            videos = vs
            collView.reloadData()
        }
    }
    
    func playerPause() {
        player.pause()
    }
    
    func playerPlay() {
        player.play()
    }
    
    func playFirstVideo(_ cell: LongVideoCell) {
//        if videos.count > 0 {
//            if let url = URL(string: videos[0].smu ?? "") {
//                player.startPlay(url: url, in: cell.coverImg)
//                player.player?.volume = 0
//                player.playerIsUserInteractionEnabled(false)
//            }
//        }
    }
    @objc func stopPlaying() {
        player.stopPlaying()
    }
    @objc func scrollItemsPlay() {
        let indexPaths = collView.indexPathsForVisibleItems.sorted()
        if indexPaths.count > 0 && indexPaths.count <= 2 {
            var playIndex: IndexPath?
            let indexLast = indexPaths.last
            if let indexlast = indexPaths.last, indexLast?.item == videos.count - 1 { // 滑到最后
                playIndex = indexlast
            } else {
                playIndex = indexPaths[0]
            }
            if let cell = collView.cellForItem(at: playIndex!) as? LongVideoCell {
                // print("indexPath == \(indexPath)")
                if let url = URL(string: videos[indexPaths[0].item].smu ?? "") {
                    player.startPlay(url: url, in: cell.coverImg)
                    player.player?.volume = 0
                    player.playerIsUserInteractionEnabled(false)
                }
            }
        } else if indexPaths.count > 2 {
            if let cell = collView.cellForItem(at: indexPaths[1]) as? LongVideoCell {
                // print("indexPath == \(indexPath)")
                if let url = URL(string: videos[indexPaths[1].item].smu ?? "") {
                    player.startPlay(url: url, in: cell.coverImg)
                    player.player?.volume = 0
                    player.playerIsUserInteractionEnabled(false)
                }
            }
        }
        DLog("indexPaths == \(indexPaths), indexPathsCount = \(indexPaths.count)")
    }
    //MARK: - PlayerViewDelegate
    func currentUrlPlayToEnd(url: URL?, player: PlayerView) {
        player.replay()
    }
    func startPlay() {
        player.backgroundColor = UIColor(r: 0, g: 0, b: 0, a: 0.5)
    }
    //MARK: - UIScrollViewDelegate
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        //player.stopPlaying()
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
       // scrollItemsPlay()
    }
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if !decelerate {
            scrollItemsPlay()
        }
    }
}

extension LongScrollCell: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return videos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LongVideoCell.cellId, for: indexPath) as! LongVideoCell
        let model = videos[indexPath.item]
        cell.setModel(model)
        if indexPath.item == 0 && isFistInit {
            //playFirstVideo(cell)
            isFistInit = false
        }
        cell.avataClickHandler = { [weak self] in
            self?.avatarClickHandler?(model.user)
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        itemClickHandler?(videos[indexPath.item])
    }
}

//MARK: - 滚动短v
class ShortScrollCell: UICollectionViewCell {
    static let cellId = "ShortScrollCell"
    private let layout: UICollectionViewFlowLayout = {
        let l = UICollectionViewFlowLayout()
        l.scrollDirection = .horizontal
        l.itemSize = ShortVideoCell.itemSizeScroll
        l.minimumInteritemSpacing = 0
        l.minimumLineSpacing = 8
        l.sectionInset = UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 15)
        return l
    }()
    lazy var collView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect.zero, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.showsHorizontalScrollIndicator = false
        collection.backgroundColor = UIColor.clear
        collection.register(ShortVideoCell.classForCoder(), forCellWithReuseIdentifier: ShortVideoCell.cellId)
        return collection
    }()
    var itemClickHandler:((_ index: Int) -> Void)?
    var avatarClickHandler:((_ user: CLUserInfo?) ->Void)?
    var videos = [VideoNew]()
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(collView)
        collView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setModels(_ models: [VideoNew]?) {
        if let vs =  models {
            videos = vs
            collView.reloadData()
        }
    }
}

extension ShortScrollCell: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return videos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShortVideoCell.cellId, for: indexPath) as! ShortVideoCell
        let model = videos[indexPath.item]
        cell.setModel(model:model,.itemSizeScroll)
        cell.avataClickHandler = { [weak self] in
            self?.avatarClickHandler?(model.user)
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        itemClickHandler?(indexPath.item)
    }
}
