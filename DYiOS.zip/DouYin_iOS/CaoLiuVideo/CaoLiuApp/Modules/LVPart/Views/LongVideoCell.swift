
public enum LongVideoUIType {
    case itemSizeSingle
    case itemSizeScroll
    case itemSizeDouble
}
class LongVideoCell: UICollectionViewCell {
    
    static let cellId = "LongVideoCell"
    static let itemSizeSingle = CGSize(width: screenWidth-30, height: (screenWidth-30)*9/16 + 50)
    static let itemSizeScroll = CGSize(width: screenWidth*2/3, height: (screenWidth*2/3)*9/16 + 50)
    static let itemSizeDouble = CGSize(width: (screenWidth - 40)/2, height: (screenWidth - 40)/2*9/16 + 50)
   
    let shadowV: UIView = {
        let v = UIView()
        v.backgroundColor = .clear
        v.layer.cornerRadius = 8
        return v
    }()
    let coverImg: UIImageView = {
        let v = UIImageView()
        v.contentMode = .scaleAspectFill
        v.borderRadius = 8
        return v
    }()
    
    let dimonLab: UILabel = {
        let la = UILabel()
        la.textColor = .white
        la.textAlignment = .center
        la.font = UIFont.boldSystemFont(ofSize: 11)
        return la
    }()
    let dimondTipView: UIView = {
        let v = UIView()
        v.backgroundColor = rgb(73, 66, 230)
        v.isHidden = true
        return v
    }()
    lazy var avatarImage: UIButton = {
        let avatarImage = UIButton(type: .custom)
        avatarImage.layer.cornerRadius = 8
        avatarImage.layer.masksToBounds = true
        avatarImage.addTarget(self, action: #selector(avartarClick), for: .touchUpInside)
        return avatarImage
    }()
    let desLab: UILabel = {
        let la = UILabel()
        la.textColor = .white
        la.font = UIFont.boldSystemFont(ofSize: 14)
        return la
    }()
    lazy var nameLab: UIButton = {
        let la = UIButton(type: .custom)
        la.setTitleColor(.lightGray, for: .normal)
        la.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        la.addTarget(self, action: #selector(avartarClick), for: .touchUpInside)
        return la
    }()
    let countsView: VideoCountDataView = {
        let v = VideoCountDataView(frame: .zero)
        return v
    }()
    let coverLayer: CAGradientLayer = {
        let ly = CAGradientLayer()
        ly.colors = [UIColor.clear.cgColor, UIColor(white: 0.0, alpha: 0.6).cgColor]
        ly.locations = [0.75, 1.0]
        return ly
    }()
    var avataClickHandler:(() ->Void)?

    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = .clear
        backgroundColor = .clear
        contentView.addSubview(shadowV)
        shadowV.addSubview(coverImg)
        shadowV.addSubview(dimondTipView)
        dimondTipView.addSubview(dimonLab)
        shadowV.addSubview(desLab)
        shadowV.addSubview(avatarImage)
        shadowV.addSubview(nameLab)
        shadowV.addSubview(countsView)
        layoutSubs()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    @objc func avartarClick() {
        avataClickHandler?()
    }
    
    func setModel(_ model: VideoNew, _ type: LongVideoUIType? = .itemSizeScroll) {
        avatarImage.kfsetHeader(model.user?.avatar)
        coverImg.kfSetHorizontalImageWithUrl(model.cover)
        desLab.text = model.title ?? ""
        nameLab.setTitle(model.user?.nick, for: .normal) 
        countsView.zanCountLab.text = getStringWithNumber(model.hot ?? 0)
        countsView.playCountLab.text = getStringWithNumber(model.play ?? 0)
        countsView.durationLab.text = PlayerView.formatTimDuration(duration: model.duration ?? 0)
        if type == .itemSizeScroll {
            coverImg.bounds = CGRect(x: 0, y: 0, width: LongVideoCell.itemSizeScroll.width, height: LongVideoCell.itemSizeScroll.height - 50)
            coverImg.snp.updateConstraints { (make) in
                make.height.equalTo(LongVideoCell.itemSizeScroll.height - 50)
            }
        } else if type == .itemSizeSingle {
            coverImg.bounds = CGRect(x: 0, y: 0, width: LongVideoCell.itemSizeSingle.width, height: LongVideoCell.itemSizeSingle.height - 50)
            coverImg.snp.updateConstraints { (make) in
                make.height.equalTo(LongVideoCell.itemSizeSingle.height - 50)
            }
        } else if type == .itemSizeDouble {
            coverImg.bounds = CGRect(x: 0, y: 0, width: LongVideoCell.itemSizeDouble.width, height: LongVideoCell.itemSizeDouble.height - 50)
            coverImg.snp.updateConstraints { (make) in
                make.height.equalTo(LongVideoCell.itemSizeDouble.height - 50)
            }
        }
        coverLayer.frame = coverImg.bounds
        coverImg.layer.insertSublayer(coverLayer, at: 0)
        if model.is_free == 1 {
            dimondTipView.isHidden = false
            dimonLab.text = "免费"
            dimondTipView.backgroundColor = rgb(231, 25, 29)
        } else {
            dimondTipView.isHidden = (model.coins ?? 0) <= 0
            dimonLab.text = "\(model.coins ?? 0)钻石"
            dimondTipView.backgroundColor = rgb(73, 66, 230)
        }
        let size = dimonLab.textSize(text: dimonLab.text ?? "", font: dimonLab.font, maxSize: CGSize(width: 200, height: 24))
        dimondTipView.bounds = CGRect(x: 0, y: 0, width: size.width + 15, height: 24)
        dimondTipView.snp.updateConstraints { (make) in
            make.width.equalTo(size.width + 15)
        }
        dimondTipView.corner(byRoundingCorners: [.topRight, .bottomLeft], radii: 8)
    }
    func avatarHiden(_ hiden: Bool) {
        avatarImage.isHidden = hiden
        avatarImage.snp.updateConstraints { (make) in
            make.width.equalTo(hiden ? 0 : 16)
            make.leading.equalTo(hiden ? 0 : 2)
        }
    }
   
    private func layoutSubs() {
        shadowV.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        coverImg.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo((screenWidth*2/3)*9/16)
        }
    
        dimonLab.snp.makeConstraints { (make) in
            make.leading.equalTo(6)
            make.trailing.equalTo(-6)
            make.centerY.equalToSuperview()
        }
        dimondTipView.snp.makeConstraints { (make) in
            make.trailing.top.equalToSuperview()
            make.width.equalTo(45)
            make.height.equalTo(24)
        }
        
        desLab.snp.makeConstraints { (make) in
            make.leading.equalTo(2)
            make.trailing.equalTo(-2)
            make.top.equalTo(coverImg.snp.bottom).offset(8)
        }
        avatarImage.snp.makeConstraints { (make) in
            make.leading.equalTo(2)
            make.top.equalTo(desLab.snp.bottom).offset(6)
            make.height.width.equalTo(16)
        }
        nameLab.snp.makeConstraints { (make) in
            make.leading.equalTo(avatarImage.snp.trailing).offset(6)
            make.centerY.equalTo(avatarImage)
        }
        countsView.snp.makeConstraints { (make) in
            make.leading.bottom.trailing.equalTo(coverImg)
            make.height.equalTo(20)
        }
    }
    
}


class SearchLongVideoCell: UICollectionViewCell {
    
    static let cellId = "SearchLongVideoCell"
    static let itemSize = CGSize(width: screenWidth-20, height: (screenWidth/2 - 10)*9/16 + 10)
    let shadowV: UIView = {
        let v = UIView()
        v.backgroundColor = .clear
        return v
    }()
    let coverImg: UIImageView = {
        let v = UIImageView()
        v.contentMode = .scaleAspectFill
        v.bounds = CGRect(x: 0, y: 0, width: (screenWidth-20)/2, height: (screenWidth/2 - 10)*9/16)
        v.layer.cornerRadius = 5
        v.layer.masksToBounds = true
        return v
    }()
    let dimondmg: UIImageView = {
        let v = UIImageView()
        v.contentMode = .scaleAspectFill
        v.image = getImage("diamond")
        v.isHidden = true
        return v
    }()
    let dimonLab: UILabel = {
        let la = UILabel()
        la.textColor = ConstValue.kStypeColor
        la.font = UIFont.boldSystemFont(ofSize: 11)
        la.isHidden = true
        return la
    }()
    let dimondTipView: UIView = {
        let v = UIView()
        v.backgroundColor = .white
        v.layer.cornerRadius = 12.0
        v.layer.masksToBounds = true
        v.isHidden = true
        return v
    }()
    lazy var avatarImage: UIButton = {
        let avatarImage = UIButton(type: .custom)
        avatarImage.layer.cornerRadius = 12
        avatarImage.layer.masksToBounds = true
        avatarImage.addTarget(self, action: #selector(avartarClick), for: .touchUpInside)
        return avatarImage
    }()
    @objc func avartarClick() {
        avataClickHandler?()
    }
    var avataClickHandler:(() ->Void)?
    private let nickLab: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.systemFont(ofSize: 13)
        lab.textColor = .lightGray
        return lab
    }()
    let desLab: UILabel = {
        let la = UILabel()
        la.textColor = UIColor.white
        la.numberOfLines = 2
        la.font = UIFont.boldSystemFont(ofSize: 14)
        return la
    }()
    private let zanImgView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = getImage("icon_home_like_after")
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    private let zanCountLab: UILabel = {
        let titleLab = UILabel()
        titleLab.font = UIFont.systemFont(ofSize: 13)
        titleLab.textColor = .lightGray
        return titleLab
    }()
    let durationLab: UILabel = {
        let la = UILabel()
        la.textColor = .lightGray
        la.font = UIFont.systemFont(ofSize: 13)
        return la
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = ConstValue.kVcViewColor
        backgroundColor = .clear
        contentView.addSubview(shadowV)
        shadowV.addSubview(coverImg)
        shadowV.addSubview(dimondTipView)
        shadowV.addSubview(dimondmg)
        shadowV.addSubview(dimonLab)
        shadowV.addSubview(desLab)
        shadowV.addSubview(avatarImage)
        shadowV.addSubview(nickLab)
        shadowV.addSubview(zanImgView)
        shadowV.addSubview(zanCountLab)
        shadowV.addSubview(durationLab)
        layoutSubs()
       
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setModel(_ model: VideoNew) {
        avatarImage.kfsetHeader(model.user?.avatar)
        coverImg.kfSetHorizontalImageWithUrl(model.cover)
        nickLab.text = model.user?.nick ?? ""
        desLab.attributedText = TextSpaceManager.getAttributeStringWithString(model.title ?? "", lineSpace: 4)
        zanCountLab.text = getStringWithNumber(model.like ?? 0)
        durationLab.text = PlayerView.formatTimDuration(duration: model.duration ?? 0)
        dimondTipView.isHidden = (model.coins ?? 0) <= 0
        dimonLab.isHidden = (model.coins ?? 0) <= 0
        dimondmg.isHidden = (model.coins ?? 0) <= 0
        dimonLab.text = "\(model.coins ?? 0)"
    }
   
    private func layoutSubs() {
        shadowV.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(0)
            make.bottom.equalTo(0)
        }
        coverImg.snp.makeConstraints { (make) in
            make.leading.top.bottom.equalToSuperview()
            make.width.equalTo((screenWidth-20)/2)
        }
        dimondmg.snp.makeConstraints { (make) in
            make.top.equalTo(coverImg).offset(15)
            make.trailing.equalTo(coverImg).offset(-14)
            make.height.equalTo(10)
            make.width.equalTo(14)
        }
        dimonLab.snp.makeConstraints { (make) in
            make.trailing.equalTo(dimondmg.snp.leading).offset(-3)
            make.centerY.equalTo(dimondmg)
        }
        dimondTipView.snp.makeConstraints { (make) in
            make.leading.equalTo(dimonLab).offset(-8)
            make.trailing.equalTo(dimondmg).offset(8)
            make.centerY.equalTo(dimondmg)
            make.height.equalTo(24)
        }
        desLab.snp.makeConstraints { (make) in
            make.leading.equalTo(coverImg.snp.trailing).offset(10)
            make.trailing.equalTo(0)
            make.top.equalTo(5)
        }
        zanImgView.snp.makeConstraints { (make) in
            make.leading.equalTo(desLab)
            make.bottom.equalTo(0)
            make.height.width.equalTo(15)
        }
        zanCountLab.snp.makeConstraints { (make) in
            make.leading.equalTo(zanImgView.snp.trailing).offset(5)
            make.centerY.equalTo(zanImgView)
        }
        durationLab.snp.makeConstraints { (make) in
            make.trailing.equalTo(desLab)
            make.centerY.equalTo(zanCountLab)
        }
        avatarImage.snp.makeConstraints { (make) in
            make.leading.equalTo(desLab)
            make.bottom.equalTo(zanImgView.snp.top).offset(-8)
            make.height.width.equalTo(24)
        }
        nickLab.snp.makeConstraints { (make) in
            make.leading.equalTo(avatarImage.snp.trailing).offset(6)
            make.centerY.equalTo(avatarImage)
        }
    }
    
}
