
import UIKit
import MJRefresh
import NicooNetwork
import JXSegmentedView

extension LFShopListController: JXSegmentedListContainerViewListDelegate {
    func listView() -> UIView {
        return self.view
    }
}

class LFShopListController: UIViewController {
    private let layout = UICollectionViewFlowLayout()
    lazy var collView: UICollectionView = {
        layout.sectionHeadersPinToVisibleBounds = true
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.showsVerticalScrollIndicator = false
        collection.backgroundColor = UIColor.clear
        collection.register(BannerScrollCellNormal.classForCoder(), forCellWithReuseIdentifier: BannerScrollCellNormal.cellId)
        collection.register(LFShopListCell.classForCoder(), forCellWithReuseIdentifier: LFShopListCell.cellId)
        collection.register(CityChoseTipView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: CityChoseTipView.identifier)
        collection.mj_header = refreshView
        collection.mj_footer = loadMoreView
        return collection
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        let loadmore = MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
        loadmore?.setTitle("", for: .idle)
        loadmore?.setTitle("已經到底了", for: .noMoreData)
        loadmore?.stateLabel.font = ConstValue.kRefreshLableFont
        return loadmore!
    }()
    lazy private var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.loadFirstPage()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        mjRefreshHeader?.stateLabel.font = ConstValue.kRefreshLableFont
        mjRefreshHeader?.lastUpdatedTimeLabel.font = ConstValue.kRefreshLableFont
        return mjRefreshHeader!
    }()
    private lazy var lfMsgListApi: LFMsgListApi =  {
        let api = LFMsgListApi()
        api.isFavor = isFavor
        api.delegate = self
        api.paramSource = self
        return api
    }()
    var cityHeader: CityChoseTipView?

    let viewModel = VideoViewModel()
    
    
    var lfShops = [LFShopModel]()
    var ads = [AdHome]()
    
    var currentProvince: String?
    var currentCity: String?
    var userCode: String?
    
    var isShop: Bool = true
    
    var isFavor: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if #available(iOS 11.0, *) {
            collView.contentInsetAdjustmentBehavior = .never
        } else {
            self.automaticallyAdjustsScrollViewInsets = false
        }
        view.backgroundColor = ConstValue.kVcViewColor
        view.addSubview(collView)
        layoutPageSubviews()
        if !isFavor {
            loadData()
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if isFavor {
            loadData()
        }
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        collView.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight - safeAreaBottomHeight - 93 - statusBarHeight)
    }
    private func loadData() {
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: false)
        NicooErrorView.removeErrorMeesageFrom(view)
        let _ = lfMsgListApi.loadData()
    }
    private func loadFirstPage() {
        NicooErrorView.removeErrorMeesageFrom(view)
        let _ = lfMsgListApi.loadData()
    }
    private func loadNextPage() {
        NicooErrorView.removeErrorMeesageFrom(view)
        let _ = lfMsgListApi.loadNextPage()
    }
    private func endRefreshing() {
        refreshView.endRefreshing()
        loadMoreView.endRefreshing()
    }
   
}

extension LFShopListController {
    func goCitysChose() {
        let vc = CityChoseController()
        vc.isUserSearch = true
        vc.choseCityCallBack = { [weak self] (p, c) in
            self?.currentProvince = p
            self?.currentCity = c
            self?.loadData()
            vc.dismiss(animated: false, completion: nil)
        }
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: false, completion: nil)
    }
}

// MARK: - UICollectionViewDelegateFlowLayout
extension LFShopListController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if indexPath.section == 0 {
            return ads.count > 0 ? BannerScrollCellNormal.itemSize : .zero
        }
        return LFShopListCell.itemSize
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        if section == 1 {
            return UIEdgeInsets(top: 15, left: 15, bottom: 8, right: 15)
        }
        return .zero
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        if section == 1 {
            return isFavor ? .zero : CGSize(width: screenWidth, height: 36)
        }
        return .zero
    }
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: CityChoseTipView.identifier, for: indexPath) as! CityChoseTipView
        if currentProvince != nil {
            if currentCity != nil {
                header.setTitle("\(currentProvince!) · \(currentCity!)")
            } else {
                header.setTitle("\(currentProvince!)")
            }
        } else {
            if currentCity != nil {
               header.setTitle("\(currentCity!)")
            } else {
               header.setTitle("全部")
            }
        }
        header.cityItemTapHandler = { [weak self] in
            self?.goCitysChose()
        }
        cityHeader  = header
        return header
    }
}
// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension LFShopListController: UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0 {
            return ads.count > 0 ? 1 : 0
        } else if section == 1 {
            return lfShops.count
        }
        return 0
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.section == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: BannerScrollCellNormal.cellId, for: indexPath) as! BannerScrollCellNormal
            cell.setBanner(ads)
            cell.scrollItemClickHandler = { [weak self] index in
                guard let strongSelf = self else { return }
                if strongSelf.ads.count > index {
                    self?.goInnerLink(strongSelf.ads[index].link ?? "")
                }
            }
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LFShopListCell.cellId, for: indexPath) as! LFShopListCell
            cell.setShopModel(lfShops[indexPath.item])
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        if indexPath.section == 1 {
            let model = lfShops[indexPath.item]
            let vc = LFShopDetailController()
            vc.shopModel = model
            navigationController?.pushViewController(vc, animated: true)
        }
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension LFShopListController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        var params = [String : Any]()
        if isFavor {
            return nil
        }
        if currentProvince != nil && !currentProvince!.isEmpty {
            params[LFMsgListApi.kProvince] = currentProvince
        }
        if currentCity != nil && !currentCity!.isEmpty {
            params[LFMsgListApi.kCity] = currentCity
        }
        params[LFMsgListApi.kType] = isShop ? 1 : 2
        params[LFMsgListApi.kIsVip] = UserModel.share().user?.is_vip == "y" ? 1 : 0
        params[LFMsgListApi.kChannel] = UserModel.share().user?.channel
        return params
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        endRefreshing()
        if manager is LFMsgListApi {
            if isFavor {
                if let shops = manager.fetchJSONData(UserReformer()) as?  [LFShopModel] {
                    if lfMsgListApi.pageNumber == 1 {
                        ads = [AdHome]()
                        lfShops = shops
                        if lfShops.count == 0 {
                            NicooErrorView.showErrorMessage(.noData, on: view, topMargin: safeAreaTopHeight + 50) {
                                self.loadData()
                            }
                        }
                    } else {
                        lfShops.append(contentsOf: shops)
                    }
                    loadMoreView.isHidden = shops.count == 0
                    collView.reloadData()
                }
            } else {
                if let msgLs = manager.fetchJSONData(VideoReformer()) as?  LFShopListModel {
                    if let datas = msgLs.shop {
                        if lfMsgListApi.pageNumber == 1 {
                            lfShops = datas
                            if lfShops.count == 0 {
                                if let adModels = msgLs.ad, adModels.count > 0 {
                                    NicooErrorView.showErrorMessage(.noData, on: view, topMargin: safeAreaTopHeight + BannerScrollCellNormal.itemSize.height + 50) {
                                        self.loadData()
                                    }
                                } else {
                                    NicooErrorView.showErrorMessage(.noData, on: view, topMargin: safeAreaTopHeight + 50) {
                                        self.loadData()
                                    }
                                }
                            }
                        } else {
                            lfShops.append(contentsOf: datas)
                        }
                        loadMoreView.isHidden = datas.count == 0
                    }
                    if let adModels = msgLs.ad {
                        ads = adModels
                    }
                    collView.reloadData()
                }
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        endRefreshing()
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        NicooErrorView.showErrorMessage(.noNetwork, on: view, topMargin: safeAreaTopHeight + 50) {
            self.loadData()
        }
    }
}

// MARK: - Layout
private extension LFShopListController {
    
    func layoutPageSubviews() {
        layoutCollection()
    }
    func layoutCollection() {
        collView.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.leading.trailing.equalToSuperview()
            if userCode != nil {
                make.bottom.equalToSuperview().offset(0)
            } else {
                make.bottom.equalToSuperview().offset(-(safeAreaBottomHeight + 49))
            }
        }
    }
    
}
// MARK: - CLNavigationBarDelegate
extension LFShopListController:  CLNavigationBarDelegate  {
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}
