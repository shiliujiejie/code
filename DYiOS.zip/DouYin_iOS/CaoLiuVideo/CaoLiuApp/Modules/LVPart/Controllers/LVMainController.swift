
import UIKit
import JXPagingView

class LVMainController: BasePagerViewController {
    let barCoverLayer: CAGradientLayer = {
        let ly = CAGradientLayer()
        ly.colors = [UIColor.clear.cgColor,UIColor.clear.cgColor]
        ly.locations = [0.0,1.0]
        ly.frame = CGRect(x: 0, y: 0, width: screenWidth, height: statusBarHeight + 88)
        return ly
    }()
    let topBgImage: UIImageView = {
        let v = UIImageView()
        v.isUserInteractionEnabled = true
        v.backgroundColor = .clear
        return v
    }()
    let searchBar: SearchBarView = {
        let v = SearchBarView.init(frame: CGRect.zero)
        v.backgroundColor = .clear
        v.textLab.textColor = .white
        return v
    }()
    lazy var recordBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setImage(getImage("pushVideoIcon"), for: .normal)
        btn.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return btn
    }()
    lazy var historyBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setImage(getImage("historyWatch"), for: .normal)
        btn.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return btn
    }()
    
    let list1 = FocusVideoController()
    let list2 = LVModulesController()
    let lf = LVModulesController()
    let hot = LVModulesController()
    let pictures = LVModulesController()
    let ancchor = LVModulesController()
    
    var channels = [ChannelModel]()
    
    private let viewModel = VideoViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(topBarColorChange(_:)), name: Notification.Name.kMainTopBarColotNotification, object: nil)
        /// 请求分享数据
        let _ = viewModel.loadShareApi()
        loadChannels()
    }
    func loadChannels() {
        NicooErrorView.removeErrorMeesageFrom(view)
        viewModel.loadChannelListData([ChannelListApi.kPosition: 1]) { [weak self] (models) in
            self?.channels = models
            self?.setUpPage()
        } failHandler: { [weak self] (error) in
            guard let strongSelf = self else { return }
            NicooErrorView.showErrorMessage(.noNetwork, on: strongSelf.view) {
                strongSelf.loadChannels()
            }
        }
    }
    
    func setUpPage() {
        var titleHave = [String]()
        titleHave.append(contentsOf: ["关注"])
        if channels.count > 0 {
            let strs = channels.map { (model) -> String in
                return model.title ?? "未知"
            }
            titleHave.append(contentsOf: strs)
        }
        titles = titleHave
        dataSource.titleNormalFont = UIFont.boldSystemFont(ofSize: 16)
        dataSource.titleSelectedFont = UIFont.boldSystemFont(ofSize: 20)
        dataSource.titleNormalColor = UIColor(white: 1, alpha: 0.75)
        dataSource.titleSelectedColor = .white
       
        pagingView.defaultSelectedIndex = 1
        pagingView.backgroundColor = .clear
        pagingView.mainTableView.backgroundColor = UIColor.clear
        //导航栏隐藏就是设置pinSectionHeaderVerticalOffset属性即可，数值越大越往下沉
        pagingView.pinSectionHeaderVerticalOffset = Int(statusBarHeight + 44)
        
        dataSource.isItemSpacingAverageEnabled = false
        dataSource.itemSpacing = 20
        dataSource.titles = titles
        indicator.indicatorColor = .clear
        segmentedView.defaultSelectedIndex = 1
        segmentedView.backgroundColor = .clear
        segmentedView.reloadData()
        setUpUI()
        searchBar.barClickAction = { [weak self] (action)in
            if action == 1 {
                let v = SearchMainController()
                self?.navigationController?.pushViewController(v, animated: true)
            } else if action == 2 {
                let v = TypesCategrayController()
                self?.navigationController?.pushViewController(v, animated: true)
            }
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        pagingView.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight - safeAreaBottomHeight - 49)
    }
    override func pagingView(_ pagingView: JXPagingView, initListAtIndex index: Int) -> JXPagingViewListViewDelegate {
        if index == 0 {
            return list1
        } else {
            let channel = channels[index - 1]
            let type = channel.type ?? ModulePageType.Module
            let list2 = LVModulesController()
            list2.segIndex = index
            /// 只有在配置了顶部bar 颜色时调用
            list2.scrollOffSetYHandler = { [weak self] (offsetY, index) in
                guard let strongSelf = self else { return }
                DLog("scrollOffSetY == \(offsetY)")
                if offsetY >= BannerScrollCell.itemSizeBgImg.height {
                    self?.topBgImage.backgroundColor = .clear
                } else {
                    if let hexColor = strongSelf.channels[index - 1].background, !hexColor.isEmpty {
                        self?.fixBarColor(true, hexColor)
                    } else {
                        self?.fixBarColor(false)
                    }
                }
            }
            return list2
//            if type == .Module {
//
//               
//            } else if type == .H5 {
//                guard let urlStr = channel.url, !urlStr.isEmpty else {
//                    return AAViewController(url: URL(string: UserModel.share().authInfo?.config?.sys?.share_url ?? "")!)
//                }
//                if let urlstr = channel.url, !urlstr.isEmpty {
//                    let h5VC = AAViewController.init(url: <#T##URL#>)
//                }
//
//            } else {
//
//            }
        }
    }
    
    override func preferredPagingView() -> JXPagingView {
        return JXPagingListRefreshView(delegate: self)
    }
    override func tableHeaderViewHeight(in pagingView: JXPagingView) -> Int {
        return Int(statusBarHeight + 44.0)
    }
    override func tableHeaderView(in pagingView: JXPagingView) -> UIView {
        let headerView = UIView(frame: CGRect.zero)
        return headerView
    }
    override func heightForPinSectionHeader(in pagingView: JXPagingView) -> Int {
        return 44
    }
    
    @objc func buttonClick(_ sender: UIButton) {
        if sender == recordBtn {
            if UserModel.share().user?.isVip != "y" {
                showDialog(title: "温馨提示", message: "\n开通VIP才能发布视频作品哦～\n", okTitle: "充值VIP", cancelTitle: "取消", okHandler: {
                    let vip = VipCardsController()
                    self.navigationController?.pushViewController(vip, animated: true)
                }, cancelHandler: nil)
                return
            }
            choseVideoFromLibrary()
        }
        if sender == historyBtn {
            
        }
    }
    
    /// 从相册选择视频
    func choseVideoFromLibrary() {
        UserModel.share().isPushLF = false
        let storyboard: UIStoryboard = UIStoryboard(name: "Thumbnail", bundle: nil)
        let vc: ThumbnailViewController = storyboard.instantiateViewController(withIdentifier: "Thumbnail") as! ThumbnailViewController
        let nav = CLNavigationController.init(rootViewController: vc)
        nav.modalPresentationStyle = .fullScreen
        self.present(nav, animated: true, completion: nil)
    }
    
    @objc func topBarColorChange(_ notif: Notification) {
        guard let autoColor = notif.userInfo?["AutoTopBarBgColor"] as? Int else {
            topBgImage.backgroundColor = .clear
            return
        }
        if let index = notif.userInfo?["SegIndex"] as? Int,
           let offsetY = notif.userInfo?["OffSetY"] as? Int {
            if autoColor == 1 && offsetY < Int(BannerScrollCell.itemSizeBgImg.height) {
                if let hexColor = channels[index - 1].background, !hexColor.isEmpty {
                    fixBarColor(true, hexColor)
                } else {
                    fixBarColor(false)
                }
            } else {
                fixBarColor(false)
            }
        } else {
            fixBarColor(false)
        }
    }
    
    private func fixBarColor(_ autoChange: Bool, _ hexColor: String? = "") {
        if autoChange {
            topBgImage.backgroundColor = UIColor(hexadecimalString: hexColor ?? "")
            barCoverLayer.colors = [UIColor(white: 0.0, alpha: 0.1).cgColor, UIColor(white: 0.0, alpha: 0.1).cgColor]
        } else {
            topBgImage.backgroundColor = .clear
            barCoverLayer.colors = [UIColor.clear.cgColor, UIColor.clear.cgColor]
        }
    }
    
    private func setUpUI() {
        view.insertSubview(topBgImage, at: 0)
        topBgImage.layer.insertSublayer(barCoverLayer, at: 0)
        view.addSubview(recordBtn)
        view.addSubview(historyBtn)
        view.addSubview(searchBar)
        topBgImage.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(statusBarHeight + 88)
        }
        recordBtn.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(statusBarHeight + 10)
            make.height.width.equalTo(23)
        }
        historyBtn.snp.makeConstraints { (make) in
            make.leading.equalTo(recordBtn.snp.trailing).offset(15)
            make.top.equalTo(statusBarHeight + 10)
            make.height.width.equalTo(23)
        }
        searchBar.snp.makeConstraints { (make) in
            make.leading.equalTo(historyBtn.snp.trailing).offset(5)
            make.trailing.equalToSuperview()
            make.top.equalTo(statusBarHeight)
            make.height.equalTo(44)
        }
    }
}

