
import UIKit
import AVKit
import MJRefresh

class VideoDetailController: CLBaseViewController {
    private lazy var navBar: DetailNavBar = {
        let bar = DetailNavBar(frame: CGRect.zero)
        bar.navBackBlack = false
        bar.backgroundColor = ConstValue.kVcViewColor
        bar.delegate = self
        return bar
    }()
    let playerBgView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.black
        return view
    }()
    let playCover: UIImageView = {
        let v = UIImageView()
        v.isUserInteractionEnabled = true
        return v
    }()
    lazy var playerView: R_PlayerView = {
        let player = R_PlayerView.init(frame: CGRect(x: 0, y: 0, width: screenWidth, height: screenWidth*9/16), bothSidesTimelable: true)
        player.backgroundColor = .clear
        player.videoNameShowOnlyFullScreen = true
        player.delegate = self
        //player.customViewDelegate = self
        player.httpHeaderFieldsKey = ["AVURLAssetHTTPHeaderFieldsKey" : ["referer": UserModel.share().authInfo?.config?.sys?.request_referer ?? "http://www.qq.com"]]
        return player
    }()

    let vipTipsView: UserVipTipView = {
        let v = UserVipTipView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: screenWidth * 9/16))
        v.backgroundColor = UIColor(white: 0, alpha: 0.3)
        return v
    }()
    let layout = UICollectionViewFlowLayout()
    lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.showsVerticalScrollIndicator = false
        collection.backgroundColor = UIColor.clear
        collection.register(BannerScrollInsert.classForCoder(), forCellWithReuseIdentifier: BannerScrollInsert.cellId)
        collection.register(LongVideoCell.classForCoder(), forCellWithReuseIdentifier: LongVideoCell.cellId)
        collection.register(ShareOrFavorItemCell.classForCoder(), forCellWithReuseIdentifier: ShareOrFavorItemCell.cellId)
        collection.register(DetailInfoView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: DetailInfoView.reuseId)
        collection.register(DetailSegHeader.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: DetailSegHeader.reuseId)
        collection.register(DetailTimerView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: DetailTimerView.reuseId)
        return collection
    }()
    var backLaunchAdViewController:(() ->Void)?
    /// 文本高度
    var infoMsgHeight: CGFloat = 0

    var segView: DetailSegHeader?
    
    let viewModel = VideoViewModel()
    let userViewModel = UserInfoViewModel()
    var video = VideoNew()
    /// 当前视频播放进度
    var currentPlayTime: Int = 0
    /// 推荐用户
    var videoUserList = [VideoNew]()
    
    var videoRecList = [VideoNew]()
    
    /// 底部推荐 是不是 当前用户的视频 或者是。热门视频
    var isUserList = false
    
    /// 是否是从下级回来
    var isBack: Bool = false
    
    /// 是否历史观看
    var watchRecord: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let delegate = UIApplication.shared.delegate as? AppDelegate {
            delegate.location = .videoDetail
        }
        // APP被挂起通知监听
        NotificationCenter.default.addObserver(self, selector: #selector(applicationResignActivity(_:)), name: UIApplication.willResignActiveNotification, object: nil)
        view.addSubview(navBar)
        view.addSubview(playerBgView)
        playerBgView.addSubview(playCover)
        view.addSubview(collectionView)
        playCover.kfSetHeaderImageWithUrl(video.cover, placeHolder: nil)
        layoutPageSub()
        loadVideoInfo()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        /// 如果是从下级页面回来，播放新视频
        if isBack {
            loadVideoInfo()
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if backLaunchAdViewController != nil { // 从启动页进入
            self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false
        }
        if playerView.superview != nil {
            playerView.play()
        }
       
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        playerView.pause()
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        if let vcs = navigationController?.viewControllers, vcs.contains(self) {
            DLog("viewDidDisappear --- Push or Present")
        } else {
            DLog("viewDidDisappear --- Pop or Dimiss")
            backLaunchAdViewController?()
            videoProgressReport()
        }
    }
    /// 视频详情
    func loadVideoInfo() {
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: true)
        viewModel.loadVideoAuthData(params: [VideoAuthApi.kVideo_id: video.id ?? 0], succeedHandler: { [weak self] videoModel in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            strongSelf.resetVideoModel(videoModel)
            strongSelf.loadRecUserVideos()
        }) { [weak self] (errorMsg) in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            XSAlert.show(type: .error, text: "播放失败")
        }
    }
    /// 拉去当前用户的其他作品
    func loadRecUserVideos() {
        let param: [String : Any] = [UserWorkListApi.kIsLong: 1, UserWorkListApi.kUserCode: video.user?.code ?? ""]
        viewModel.loadUserVideosData(param, succeedHandler: { [weak self] (videos, page) in
            guard let strongSelf = self else { return }
            strongSelf.videoUserList = videos
            strongSelf.collectionView.reloadData()
        }) { (error) in
            XSAlert.show(type: .error, text: error)
        }
    }
    
    /// 热门视频
    func loadRecomentVideo() {
        let param: [String : Any] = [UserWorkListApi.kIsLong: 1]
        viewModel.loadRecVideoListApi(param, succeedHandler: { [weak self] (videoList) in
            self?.videoRecList = videoList
            self?.collectionView.reloadData()
        }) { (errorMsg) in
             XSAlert.show(type: .error, text: errorMsg)
        }
    }
    /// 视频进度上报参数
    func getProressReportParam() -> [String: Any] {
        var param = [String: Any]()
        param[VideoProgressReportApi.kVideo_id] = video.id
        param[VideoProgressReportApi.kIsLong] = video.is_long == 1 ? 1 : 0
        param[VideoProgressReportApi.kDuration] = currentPlayTime
        if let categorys = video.category, categorys.count > 0 {
            let attStr = NSMutableString()
            for i in 0 ..< categorys.count {
                let model = categorys[i]
                if i == categorys.count - 1{
                    attStr.append("\(model.id ?? model.type_id ?? 0)")
                } else {
                    attStr.append("\(model.id ?? model.type_id ?? 0),")
                }
            }
            param[VideoProgressReportApi.kType_Ids] = attStr as String
        }
        return param
    }
    /// 视频进度上传
    func videoProgressReport() {
        if let duration = video.duration, duration > 0 {
            if video.auth_error == nil && Float(currentPlayTime)/Float(duration) > 0.3 {
                AppInfo.videoProgressReport(getProressReportParam())
            }
        }
    }
    /// app进入后台
    @objc func applicationResignActivity(_ sender: NSNotification) {
        videoProgressReport()
    }
}

//MARK: - Video Set
extension VideoDetailController {
    
    private func resetVideoModel(_ videom: VideoNew) {
        video.user = videom.user
        video.mu = videom.mu
        video.smu = videom.smu
        video.is_attention = videom.is_attention
        video.is_like = videom.is_like
        video.is_free = videom.is_free
        video.like = videom.like
        video.coins = videom.coins
        video.vip_coins = videom.vip_coins
        video.hot = videom.hot
        video.play = videom.play
        video.user?.is_attention = videom.is_attention
        video.auth_error = videom.auth_error
        video.ad = videom.ad
        video.category = videom.category
        video.cover = videom.cover
        video.id = videom.id
        video.countdown = videom.countdown
        if !watchRecord { /// 历史记录
            video.lastWatchDurration = nil
        } else {
            watchRecord = false
        }
        playCover.kfSetHeaderImageWithUrl(video.cover, placeHolder: nil)
        if vipTipsView.superview != nil {
            vipTipsView.removeFromSuperview()
        }
        vipTipsView.clickAction = { [weak self] actionId in
            if actionId == 1 {
                self?.showBuyAlert(actionId)
            } else if actionId == 2 {
                let vip = VipCardsController()
                self?.navigationController?.pushViewController(vip, animated: true)
            } else if actionId == 3 {
                if self?.video.auth_error?.key == 1001 {
                    let vip = VipCardsController()
                    self?.navigationController?.pushViewController(vip, animated: true)
                } else {
                    self?.showBuyAlert(actionId)
                }
            }
        }
        /// 设置视频信息 （一定有的）
        setVideoInfo()
        if video.auth_error != nil && !playerBgView.subviews.contains(vipTipsView) {
            playerBgView.addSubview(vipTipsView)
            vipTipsView.setModel(video)
        }
        playVideo()
        collectionView.reloadData()
    }
    
    
    func setVideoInfo() {
        //MARK: - navBar
        navBar.avatarImg.kfsetHeader(video.user?.avatar)
        navBar.titleLabel.text = video.user?.nick
        if let follow = video.is_attention {
            navBar.rightButton.backgroundColor = follow == 1 ? ConstValue.kAppSepLineColor : ConstValue.kStypeColor
            navBar.rightButton.setTitle(follow == 1 ? "取消关注" : "关注", for: .normal)
        } else {
            navBar.rightButton.backgroundColor = ConstValue.kStypeColor
            navBar.rightButton.setTitle("关注", for: .normal)
        }
        navBar.rightActionHandler = { [weak self] actId in
            if actId == 1 {
                self?.goUserCenter(self?.video.user)
            } else if actId == 2 {
                self?.followOrNotAction()
            }
        }
    }
    func playVideo() {
        if video.auth_error != nil {
            if let url = URL(string: video.smu ?? "") {
                playerView.startPlay(url: url, in: playCover, title: video.title, uri: nil, cache: false)
                playerView.setPlayerControlView(operable: false)
                playerView.backgroundColor = .clear
            }
        } else {
            if let url = URL(string: video.mu ?? "") {
                if let sinceTime = video.lastWatchDurration {
                    playerView.replayVideo(url: url, in: playCover, lastPlayTime: Float(sinceTime), title: video.title, uri: nil, cache: false)
                } else {
                    playerView.startPlay(url: url, in: playCover, title: video.title, uri: nil, cache: false)
                }
                if vipTipsView.superview != nil {
                    vipTipsView.removeFromSuperview()
                }
                playerView.setPlayerControlView(operable: true)
                playerView.backgroundColor = .black
            }
        }
    }
    /// 金币购买视频
    func buyCoinsVideo() {
        XSProgressHUD.showCycleProgress(msg: "支付中...", onView: view, animated: false)
        userViewModel.coinsBuyVideo(params: [UseBuyVideoApi.kVideoId: video.id ?? 0] , succeedHandler: { [weak self] mu in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: true)
            XSAlert.show(type: .success, text: "恭喜您支付成功")
            if let userCoins = UserModel.share().user?.coins, let vCoins = strongSelf.video.coins, userCoins >= vCoins {
                 UserModel.share().user?.coins = userCoins - vCoins
                NotificationCenter.default.post(name: Notification.Name.kUserBasicalInformationChanged, object: nil)
            }
            strongSelf.video.auth_error = nil
            strongSelf.video.mu = mu
            strongSelf.setVideoInfo()
            //strongSelf.setTableHeaderView()
            strongSelf.playVideo()
        }) { [weak self] (failMsg) in
            guard let strongSelf = self else { return }
            strongSelf.showCoinBuyAlert(failMsg)
            XSProgressHUD.hide(for: strongSelf.view, animated: true)
        }
    }
    func showBuyAlert(_ actionId: Int) {
        let btnTitle: String = actionId == 1 ? "非VIP\(video.coins ?? 0)钻石购买" : "VIP优惠价:\(video.vip_coins ?? 0)钻石购买"
        let alert = CoinsBuyAlert.init(frame: view.bounds, buttonTitle: btnTitle, vipMsg: "VIP优惠价:\(video.vip_coins ?? 0)钻石", normalMsg: "非VIP价:\(video.coins ?? 0)钻石", tipsMsg: "支持原创,付费给\(video.user?.nick ?? "")", titleMsg: "本内容需购买观看")
        alert.backgroundColor = UIColor(white: 0, alpha: 0.6)
        alert.showInWindow()
        alert.itemButtonClick = { [weak self] in
            self?.buyCoinsVideo()
        }
    }
    /// 点赞
    func addFavorOrNot(_ isFavor: Bool) {
        let likeCount = video.like ?? 0
        var favorCount = 0
        if isFavor {
            favorCount = likeCount + 1
        } else { // 取消点赞
            favorCount = likeCount > 0 ? likeCount - 1 : 0
        }
        video.like = favorCount
        video.is_like = isFavor ? 1 : 0
        collectionView.reloadItems(at: [IndexPath.init(item: 0, section: 0)])
        userViewModel.addVideoFavor([UserFavorAddApi.kVideo_id: video.id ?? 0, UserFavorAddApi.kIslong: video.is_long ?? 1])
    }
    func showCoinBuyAlert(_ msg: String) {
        let failedModel = ConvertCardAlertModel(title: nil, msgInfo: msg, success: false)
        let controller = AlertManagerController(cardModel: failedModel)
        controller.modalPresentationStyle = .overCurrentContext
        controller.view.backgroundColor = UIColor(white: 0.0, alpha: 0.7)
        controller.touchDissMiss = true
        present(controller, animated: false, completion: nil)
        controller.commitActionHandler = {
            let vipVC = CoinsCardsController()
            vipVC.isCoins = true
            self.navigationController?.pushViewController(vipVC, animated: true)
        }
    }
    ///关注，取消关注的点击事件
    private func followOrNotAction() {
        if video.user?.code == UserModel.share().user?.code {    ///如果点击刚好点击的是自己
            XSAlert.show(type: .error, text: "不能关注自己")
            return
        } else {
            if userViewModel.followAddOrCancelSuccessHandler == nil {
                userViewModel.followAddOrCancelSuccessHandler = { [weak self] isAdd in
                    guard let strongSelf = self else { return }
                    XSProgressHUD.hide(for: strongSelf.view, animated: true)
                    if isAdd {
                        self?.navBar.rightButton.setTitle("取消关注", for: .normal)
                        self?.navBar.rightButton.backgroundColor = ConstValue.kAppSepLineColor
                        self?.video.user?.is_attention = 1
                        self?.video.is_attention = 1
                    } else {
                        self?.navBar.rightButton.setTitle("关注", for: .normal)
                        self?.navBar.rightButton.backgroundColor = ConstValue.kStypeColor
                        self?.video.user?.is_attention = 0
                        self?.video.is_attention = 0
                    }
                    NotificationCenter.default.post(name: NSNotification.Name.kHomeRefreshAttentionStateNotification, object: nil, userInfo: ["code": strongSelf.video.user?.code ?? "", "statu" : strongSelf.video.is_attention ?? 0])
                }
            }
            if userViewModel.followOrCancelFailureHandler == nil {
                userViewModel.followOrCancelFailureHandler = { (isAdd, msg) in
                    XSAlert.show(type: .error, text: msg)
                }
            }
            if let statu = video.user?.is_attention {
                if statu == 1 {  // 已关注，调用取消
                    userViewModel.loadCancleFollowApi([UserAddFollowApi.kUserId: video.user?.code ?? ""])
                } else  { // 未关注，调用关注
                    userViewModel.loadAddFollowApi([UserAddFollowApi.kUserId: video.user?.code ?? ""])
                }
            }
        }
    }
    /// 广告点击
    func goLink(_ herf: String) {
        if herf.contains("url://") {
            let urlStrs = herf.components(separatedBy: "url://")
            if urlStrs.count > 1 {
                if let url = URL(string: urlStrs[1]) {
                    if #available(iOS 10, *) {
                        UIApplication.shared.open(url, options: [:],
                                                  completionHandler: {
                                                    (success) in
                        })
                    } else {
                        UIApplication.shared.openURL(url)
                    }
                }
            }
        } else if herf.contains("tag://") {
            let urlStrs = herf.components(separatedBy: "://")
            if urlStrs.count > 1 {
                if let tag_id = Int(urlStrs[1]) {
                    var model = SearchHotTips()
                    model.id = tag_id
                    model.type_id = tag_id
                    if let vcs = navigationController?.viewControllers {
                        let allPlayVcs = vcs.filter { (vc) -> Bool in
                            return vc.isKind(of: TypeVideosController.self)
                        }
                        if allPlayVcs.count > 0 {
                            navigationController?.viewControllers.removeAll(where: { (vc) -> Bool in
                                return vc.isKind(of: TypeVideosController.self)
                            })
                        }
                        let detail = TypeVideosController()
                        detail.keyMode = model
                        navigationController?.pushViewController(detail, animated: true)
                    }
                }
            }
        } else if herf.contains("type://") {
            let urlStrs = herf.components(separatedBy: "://")
            if urlStrs.count > 1 {
                if let type_id = Int(urlStrs[1]) {
                    let model = ModuleDetailModel()
                    model.id = type_id
                    if let vcs = navigationController?.viewControllers {
                        let allPlayVcs = vcs.filter { (vc) -> Bool in
                            return vc.isKind(of: ModuleMoreController.self)
                        }
                        if allPlayVcs.count > 0 {
                            navigationController?.viewControllers.removeAll(where: { (vc) -> Bool in
                                return vc.isKind(of: ModuleMoreController.self)
                            })
                        }
                        let detail = ModuleMoreController()
                        detail.detailModel = model
                        navigationController?.pushViewController(detail, animated: true)
                    }
                }
            }
        } else if herf.contains("user://") {
            let urlStrs = herf.components(separatedBy: "://")
            if urlStrs.count > 1 {
                let userCode = urlStrs[1]
                if !userCode.isEmpty {
                    let v = CLUserInfo()
                    v.code = userCode
                    if let vcs = navigationController?.viewControllers {
                        let allPlayVcs = vcs.filter { (vc) -> Bool in
                            return vc.isKind(of: UserMCenterController.self)
                        }
                        if allPlayVcs.count > 0 {
                            navigationController?.viewControllers.removeAll(where: { (vc) -> Bool in
                                return vc.isKind(of: UserMCenterController.self)
                            })
                        }
                        let userPage = UserMCenterController()
                        userPage.userNew = v
                        userPage.userCode = userCode
                        navigationController?.pushViewController(userPage, animated: true)
                    }
                }
            }
        } else if herf.contains("video://") {
            let urlStrs = herf.components(separatedBy: "://")
            if urlStrs.count > 1 {
                if let videoId = Int(urlStrs[1]) {
                    viewModel.loadVideoAuthData(params: [VideoAuthApi.kVideo_id: videoId], succeedHandler: { [weak self] (video) in
                        self?.resetVideoModel(video)
                    }) { (error) in
                        XSAlert.show(type: .error, text: error)
                    }
                }
            }
        } else if herf.contains("buycoins://") {
            let vip = CoinsCardsController()
            vip.isCoins = true
            navigationController?.pushViewController(vip, animated: true)
        } else if herf.contains("buyvip://") {
            let vip = VipCardsController()
            navigationController?.pushViewController(vip, animated: true)
        } else if herf.contains("urlself://") {
            let urlStrs = herf.components(separatedBy: "urlself://")
            if urlStrs.count > 1 {
                innerLink(urlStrs[1])
            }
        }
    }
    func innerLink(_ url: String) {
        guard let adHref = URL(string: url) else { return }
        let aavc = AAViewController(url: adHref)
        navigationController?.pushViewController(aavc, animated: false)
    }
    func goUserCenter(_ user: CLUserInfo?) {
        if let vcs = navigationController?.viewControllers {
            let allVcs = vcs.filter { (vc) -> Bool in
                return vc.isKind(of: UserMCenterController.self)
            }
            if allVcs.count > 0 {
                navigationController?.viewControllers.removeAll(where: { (vc) -> Bool in
                    return vc.isKind(of: UserMCenterController.self)
                })
            }
            let userCenter = UserMCenterController()
            userCenter.userCode = user?.code
            userCenter.followOrCancelBackHandler = { [weak self] (focusStatu) in
                self?.reloadFocusStatu(focusStatu)
            }
            navigationController?.pushViewController(userCenter, animated: true)
        }
    }
    /// 标签分类页面
    func goTypeKeyController(_ videoKey: SearchHotTips) {
        if let vcs = navigationController?.viewControllers {
            let allVcs = vcs.filter { (vc) -> Bool in
                return vc.isKind(of: TypeVideosController.self)
            }
            if allVcs.count > 0 {
                navigationController?.viewControllers.removeAll(where: { (vc) -> Bool in
                    return vc.isKind(of: TypeVideosController.self)
                })
            }
            let keyVc = TypeVideosController()
            keyVc.keyMode.type_id = videoKey.type_id ?? videoKey.id
            keyVc.keyMode.title = videoKey.title
            navigationController?.pushViewController(keyVc, animated: true)
        }
    }
    func reloadFocusStatu(_ statu: Int) {
        video.user?.is_attention = statu
        video.is_attention = statu
        if let follow = video.is_attention {
            navBar.rightButton.backgroundColor = follow == 1 ? ConstValue.kAppSepLineColor : ConstValue.kStypeColor
            navBar.rightButton.setTitle(follow == 1 ? "取消关注" : "关注", for: .normal)
        } else {
            navBar.rightButton.backgroundColor = ConstValue.kStypeColor
            navBar.rightButton.setTitle("关注", for: .normal)
        }
    }
}
// MARK: - UICollectionViewDelegateFlowLayout
extension VideoDetailController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if indexPath.section == 0 {
            return ShareOrFavorItemCell.itemSize
        } else if indexPath.section == 1 {
            return BannerScrollInsert.itemSize
        } else if indexPath.section == 2 {
            return LongVideoCell.itemSizeDouble
        }
        return .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        if section == 0 || section == 2 {
            return 10
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        if section == 0 || section == 2  {
            return 10
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        if section == 1 {
            return UIEdgeInsets(top: 15, left: 0, bottom: 8, right: 0)
        } else if section == 2 || section == 0 {
            return UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 15)
        }
        return .zero
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        if section == 2 {
           return CGSize(width: screenWidth, height: 50)
        } else if section == 0 {
            let mstring = NSMutableString()
            if let allKeys = video.category, allKeys.count > 0 {
                for keyModel in allKeys {
                    mstring.append(" #\(keyModel.title ?? "")")
                }
            }
            let size = UILabel().textSize(text: video.title?.appending(mstring as String) ?? "", font: UIFont.boldSystemFont(ofSize: 14), maxSize: CGSize(width: screenWidth - 30, height: 200), 4)
            infoMsgHeight = 55 + size.height
            return CGSize(width: screenWidth, height: 55 + size.height)
        }
        return .zero
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        if section == 0 {
            if let time = video.countdown?.countdown_time, time > 0 {
                return CGSize(width: screenWidth, height: 60)
            }
        }
        return .zero
    }
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        var reusableView: UICollectionReusableView?
        if kind == UICollectionView.elementKindSectionHeader {
            if indexPath.section == 0 {
                let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: DetailInfoView.reuseId, for: indexPath) as! DetailInfoView
                header.setModel(video)
                header.tagClickAction = { [weak self] tagModel in
                    self?.goTypeKeyController(tagModel)
                }
                reusableView = header
            } else {
                let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: DetailSegHeader.reuseId, for: indexPath) as! DetailSegHeader
                header.backgroundColor = ConstValue.kVcViewColor
                reusableView = header
            }
        } else {
            let footer = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: DetailTimerView.reuseId, for: indexPath) as! DetailTimerView
            if let down = video.countdown {
                footer.setCountDown(down)
                footer.clickAction = { [weak self] in
                    if let link = self?.video.countdown?.countdown_link, !link.isEmpty {
                        self?.goInnerLink(link)
                    }
                }
            }
            reusableView = footer
        }
        return reusableView!
    }
   
    
}

extension VideoDetailController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offsetY = scrollView.contentOffset.y
        if offsetY > infoMsgHeight + ShareOrFavorItemCell.itemSize.height {
            layout.sectionHeadersPinToVisibleBounds = true
        } else {
            layout.sectionHeadersPinToVisibleBounds = false
        }
    }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension VideoDetailController: UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 3
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0 {
            return 2
        } else if section == 1 {
            if let ads = video.ad, ads.count > 0 {
                return 1
            }
        } else if section == 2 {
            return videoUserList.count
        }
        return 0
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.section == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShareOrFavorItemCell.cellId, for: indexPath) as! ShareOrFavorItemCell
            cell.iconImage.image = getImage([video.is_like == 1 ? "icon_home_like_after" : "favorItemIcon","earnMoneyShareIcon"][indexPath.item])
            cell.titleLable.text = [getStringWithNumber(video.like ?? 0), "赚钱"][indexPath.item]
            cell.tipsLable.text = ["喜欢就收藏一下","邀请好友.立即赚钱"][indexPath.item]
            return cell
        } else if indexPath.section == 1 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: BannerScrollInsert.cellId, for: indexPath) as! BannerScrollInsert
            if let ads = video.ad,ads.count > indexPath.item {
                cell.setBanner(ads)
                cell.scrollItemClickHandler = { [weak self] index in
                    self?.goLink(ads[index].link ?? "")
                }
            }
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LongVideoCell.cellId, for: indexPath) as! LongVideoCell
            cell.setModel(videoUserList[indexPath.item],.itemSizeDouble)
            cell.avataClickHandler = { [weak self] in
                guard let strongSelf = self else { return }
                self?.goUserCenter(strongSelf.videoUserList[indexPath.item].user)
            }
            return cell
        }
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        if indexPath.section == 2 {
            let model = videoUserList[indexPath.item]
            if model.id == self.video.id {
                XSAlert.show(type: .text, text: "当前正在播放此视频")
                return
            }
            /// 切换播放视频前，先上报进度
            videoProgressReport()
            self.video = model
            loadVideoInfo()
        } else if indexPath.section == 0 {
            if indexPath.item == 0 {
                addFavorOrNot(video.is_like == 0)
            } else if indexPath.item == 1 {
                let shareVc = ShareContentController()
                navigationController?.pushViewController(shareVc, animated: true)
            }
        }
    }
}
// MARK: - R_PlayerDelegate
extension VideoDetailController: R_PlayerDelegate {
    func customActionsBeforePlay() {
        print("customActionsBeforePlay")
    }
    func startPlay() {
        print("startPlay")
    }
    func retryToPlayVideo(url: URL?) {
        print("retryToPlayVideo = \(url?.absoluteString ?? "")")
    }
    func playVideoFailed(url: URL?, player: R_PlayerView) {
        //XSAlert.show(type: .error, text: "播放失败")
    }
    func playerProgress(progress: Float, currentPlayTime: Float) {
        if video.auth_error == nil {
            self.currentPlayTime = Int(currentPlayTime)
        }
    }
    func currentVideoPlayToEnd(url: URL?, isPlayingloaclFile: Bool) {
        print("currentVideoPlayToEnd = \(isPlayingloaclFile)")
        if video.auth_error != nil {
            playerView.replay()
        }
    }
}
// MARK: - CLNavigationBarDelegate
extension VideoDetailController: CLNavigationBarDelegate  {
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}

extension VideoDetailController {
    func layoutPageSub() {
        layoutToppart()
        layoutTable()
    }
    func layoutToppart() {
        navBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(safeAreaTopHeight)
        }
        playerBgView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(navBar.snp.bottom)
            make.height.equalTo(screenWidth*9/16)
        }
        playCover.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    func layoutTable() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(playerBgView.snp.bottom)
            make.bottom.equalToSuperview()
        }
    }
    
}
