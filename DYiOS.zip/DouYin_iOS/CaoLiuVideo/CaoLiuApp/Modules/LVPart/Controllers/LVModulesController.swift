
import UIKit
import MJRefresh
import NicooNetwork
import JXSegmentedView

extension LVModulesController: JXSegmentedListContainerViewListDelegate {
    func listView() -> UIView {
        return self.view
    }
}

class LVModulesController: UIViewController {
   
    lazy var collView: UICollectionView = {
        let layout = WaterfallMutiSectionFlowLayout()
        layout.delegate = self
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.showsVerticalScrollIndicator = false
        collection.backgroundColor = UIColor.clear
        collection.register(BannerScrollCellNormal.classForCoder(), forCellWithReuseIdentifier: BannerScrollCellNormal.cellId)
        collection.register(BannerScrollCellBgImg.classForCoder(), forCellWithReuseIdentifier: BannerScrollCellBgImg.cellId)
        collection.register(BannerScrollInsert.classForCoder(), forCellWithReuseIdentifier: BannerScrollInsert.cellId)
        collection.register(BannerScrollFullWidth.classForCoder(), forCellWithReuseIdentifier: BannerScrollFullWidth.cellId)
        collection.register(ADScrollCell.classForCoder(), forCellWithReuseIdentifier: ADScrollCell.cellId)
        
        collection.register(LongScrollCell.classForCoder(), forCellWithReuseIdentifier: LongScrollCell.cellId)
        collection.register(ShortScrollCell.classForCoder(), forCellWithReuseIdentifier: ShortScrollCell.cellId)
        
        collection.register(ShortVideoCell.classForCoder(), forCellWithReuseIdentifier: ShortVideoCell.cellId)
        collection.register(LongVideoCell.classForCoder(), forCellWithReuseIdentifier: LongVideoCell.cellId)
        collection.register(ADRandomCell.classForCoder(), forCellWithReuseIdentifier: ADRandomCell.cellId)
        collection.register(UINib(nibName: ModulesHeaderView.reuseId, bundle: Bundle.main), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: ModulesHeaderView.reuseId)
        collection.register(VideoHeaderView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: VideoHeaderView.reuseId)
        collection.register(VideoNoTitlHeaderView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: VideoNoTitlHeaderView.reuseId)
        collection.register(ModuleFootView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: ModuleFootView.reuseId)
        collection.register(VipCoinFootView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: VipCoinFootView.reuseId)
        collection.register(UICollectionReusableView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: "sepLineFooter")
        collection.mj_header = refreshView
        collection.mj_footer = loadMoreView
        return collection
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        let loadMore = MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
        loadMore?.stateLabel.font = ConstValue.kRefreshLableFont
        return loadMore!
    }()
    lazy private var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.loadFirstPage()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        mjRefreshHeader?.stateLabel.font = ConstValue.kRefreshLableFont
        mjRefreshHeader?.lastUpdatedTimeLabel.font = ConstValue.kRefreshLableFont
        return mjRefreshHeader!
    }()
    private lazy var moduleApi: VideoModuleApi =  {
        let api = VideoModuleApi()
        if position == .InVIPPart {
            api.inVIPPart = true
        } else {
            api.inVIPPart = false
        }
        api.delegate = self
        api.paramSource = self
        return api
    }()
    
    private lazy var waterFallMoreApi: VideoModuleMoreApi =  {
        let api = VideoModuleMoreApi()
        if position == .InVIPPart {
            api.inVIPPart = true
        } else {
            api.inVIPPart = false
        }
        api.kDefaultCount = 10
        api.delegate = self
        api.paramSource = self
        return api
    }()
    /// 是否弹起短视频播放页
    var isPresentPlay: Bool = false
    /// 加载更多是不是 loadWaterFall
    var loadWaterFall: Bool = false
    
    var position: VCPosition = .InModule
    var segIndex: Int = 0
    var channel = ChannelModel()
    
    var scrollOffSetYHandler:((CGFloat, Int) -> Void)?
    
    let viewModel = VideoViewModel()
    var modules = [ModulesModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if #available(iOS 11.0, *) {
            collView.contentInsetAdjustmentBehavior = .never
        } else {
            self.automaticallyAdjustsScrollViewInsets = false
        }
        collView.backgroundColor = .clear 
        view.addSubview(collView)
        layoutPageSubviews()
        loadData()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if position == .InVIPPart {
            NotificationCenter.default.post(name: Notification.Name.kVIPTopBarColotNotification, object: nil, userInfo: ["TopBarDarkColor": 0])
        } else if position == .InModule {
            NotificationCenter.default.post(name: Notification.Name.kMainTopBarColotNotification, object: nil, userInfo: ["AutoTopBarBgColor": 1, "SegIndex" :segIndex, "OffSetY" : Int(collView.contentOffset.y)])
        }
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if position == .InVIPPart {
            collView.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight - safeAreaBottomHeight - 49)
        } else if position == .InModule {
            collView.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight - safeAreaBottomHeight - 49 - statusBarHeight - 88)
        }
    }
    
    private func loadData() {
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: true)
        NicooErrorView.removeErrorMeesageFrom(view)
        let _ = moduleApi.loadData()
    }
    private func loadFirstPage() {
        NicooErrorView.removeErrorMeesageFrom(view)
        loadWaterFall = false
        loadMoreView.isHidden = false
        let _ = moduleApi.loadData()
    }
    private func loadNextPage() {
        NicooErrorView.removeErrorMeesageFrom(view)
        if loadWaterFall {
            _ = waterFallMoreApi.loadNextPage()
        } else {
            _ = moduleApi.loadNextPage()
        }
    }
    private func starLoadWaterFallData() {
        loadWaterFall = true
        waterFallMoreApi.pageNumber = 2
        _ = waterFallMoreApi.loadNextPage()
    }
}

extension LVModulesController {
    
    
    func goLongDetail(_ video: VideoNew) {
        let detail = VideoDetailController()
        detail.video = video
        navigationController?.pushViewController(detail, animated: true)
    }

    private func goUserCenter(_ user: CLUserInfo?) {
        let userCenter = UserMCenterController()
        userCenter.userCode = user?.code
        navigationController?.pushViewController(userCenter, animated: true)
    }
}

// MARK: - UICollectionViewDelegateFlowLayout
extension LVModulesController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        var reusableView: UICollectionReusableView?
        let mdModel = modules[indexPath.section]
        if kind == UICollectionView.elementKindSectionHeader {
            if mdModel.module == .longV_Five {
                var headerVideo: UICollectionReusableView!
                if let title = mdModel.title, !title.isEmpty {
                    let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: VideoHeaderView.reuseId, for: indexPath) as! VideoHeaderView
                    header.headerView.titleLab.text = mdModel.title
                    header.moreActionHandler = { [weak self] in
                        guard let strongSelf = self else { return }
                        DLog("moreActionHandler")
                        if let link = mdModel.more_link, !link.isEmpty {
                            strongSelf.goInnerLink(link)
                        }
                    }
                 
                    if let videoFives = mdModel.video_4_data, videoFives.count > 0 {
                        header.setModels(videoFives[0])
                        header.itemClickHandler = { [weak self] video in
                            self?.goLongDetail(video)
                        }
                        header.avatarClickHandler = { [weak self] user in
                            self?.goUserCenter(user)
                        }
                    }
                    headerVideo = header
                } else {
                    let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: VideoNoTitlHeaderView.reuseId, for: indexPath) as! VideoNoTitlHeaderView
                    if let videoFives = mdModel.video_4_data, videoFives.count > 0 {
                        header.setModels(videoFives[0])
                        header.itemClickHandler = { [weak self] video in
                            self?.goLongDetail(video)
                        }
                        header.avatarClickHandler = { [weak self] user in
                            self?.goUserCenter(user)
                        }
                    }
                    headerVideo = header
                }
                reusableView = headerVideo
            } else {
                let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: ModulesHeaderView.reuseId, for: indexPath) as! ModulesHeaderView
                if mdModel.module == Module.waterFall {
                    header.moreBtn.isHidden = true
                    header.moreLabel.isHidden = true
                    header.arrowRightimg.isHidden = true
                } else {
                    header.moreBtn.isHidden = false
                    header.moreLabel.isHidden = false
                    header.arrowRightimg.isHidden = false
                }
                header.titleLab.text = mdModel.title
                header.moreActionHandler = { [weak self] in
                    guard let strongSelf = self else { return }
                    DLog("moreActionHandler")
                    if let link = mdModel.more_link, !link.isEmpty {
                        strongSelf.goInnerLink(link)
                    }
                }
                reusableView = header
            }
        } else {
            if mdModel.module == .adFull && indexPath.section == 0 && position == .InVIPPart {
                let footer = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: VipCoinFootView.reuseId, for: indexPath) as! VipCoinFootView
                footer.contentv.backgroundColor = UIColor.colorGradientChangeWithSize(size: CGSize(width: screenWidth - 30, height: (UserModel.share().user?.countdown_time ?? 0) > 0 ? 130 : 60), direction: .vertical, startColor: ConstValue.kVcViewColor, endColor: ConstValue.kCoverBgColor)
                footer.setSegIndex(segIndex)
                footer.clickAction = { [weak self] id in
                    guard let strongSelf = self else { return }
                    if id == 1 {
                        if strongSelf.segIndex == 0 {
                            let vipvc = VipCardsController()
                            self?.navigationController?.pushViewController(vipvc, animated: true)
                        } else if strongSelf.segIndex == 1 {
                            let dim = CoinsCardsController()
                            self?.navigationController?.pushViewController(dim, animated: true)
                        }
                    } else if id == 2 {
                        if let link = UserModel.share().user?.countdown_link, !link.isEmpty {
                            self?.goInnerLink(link)
                        }
                    }
                }
                reusableView = footer
            } else {
                let footer = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: ModuleFootView.reuseId, for: indexPath) as! ModuleFootView
                footer.actionHandler = { [weak self] index in
                    guard let strongSelf = self else { return }
                    if index == 1 { // 更多
                        if let link = mdModel.more_link, !link.isEmpty {
                            strongSelf.goInnerLink(link)
                        }
                    } else if index == 2 { // 换一换
                        if mdModel.module == .longVdouble {
                            guard let page = mdModel.pageNum else { // pageNum不存在，说明第一页数据不够， 不能换
                                return
                            }
                            strongSelf.viewModel.loadModuleMoreListData(params:[VideoModuleMoreApi.kModuleId: mdModel.id ?? 0, VideoModuleMoreApi.kProtocol: mdModel.protocol ?? ""] , inVipPart: strongSelf.position == .InVIPPart, pageNumber: page, limit: mdModel.limit ?? 0) { (videos) in
                                if videos.count < (mdModel.limit ?? 0) {
                                    mdModel.pageNum = 1
                                    if videos.count == 0 {
                                        strongSelf.viewModel.loadModuleMoreListData(params: [VideoModuleMoreApi.kModuleId: mdModel.id ?? 0, VideoModuleMoreApi.kProtocol: mdModel.protocol ?? ""], inVipPart: strongSelf.position == .InVIPPart, pageNumber: 1, limit: mdModel.limit ?? 0) { (videoFirst) in
                                            mdModel.video_3_data = videoFirst
                                            mdModel.pageNum = 2
                                            strongSelf.collView.reloadData()
                                        } failHandler: { (error) in
                                            XSAlert.show(type: .error, text: error)
                                        }
                                    } else {
                                        mdModel.video_3_data = videos
                                        strongSelf.collView.reloadData()
                                    }
                                } else {
                                    mdModel.pageNum = page + 1
                                    mdModel.video_3_data = videos
                                    strongSelf.collView.reloadData()
                                }
                            } failHandler: { (error) in
                                XSAlert.show(type: .error, text: error)
                            }
                        } else if mdModel.module == .longV_Five {
                            guard let page = mdModel.pageNum else { // pageNum不存在，说明第一页数据不够， 不能换
                                return
                            }
                            strongSelf.viewModel.loadModuleMoreListData(params:[VideoModuleMoreApi.kModuleId: mdModel.id ?? 0, VideoModuleMoreApi.kProtocol: mdModel.protocol ?? ""] , inVipPart: strongSelf.position == .InVIPPart, pageNumber: page, limit: mdModel.limit ?? 0) { (videos) in
                                if videos.count < (mdModel.limit ?? 0) {
                                    mdModel.pageNum = 1
                                    if videos.count == 0 {
                                        strongSelf.viewModel.loadModuleMoreListData(params: [VideoModuleMoreApi.kModuleId: mdModel.id ?? 0, VideoModuleMoreApi.kProtocol: mdModel.protocol ?? ""], inVipPart: strongSelf.position == .InVIPPart, pageNumber: 1, limit: mdModel.limit ?? 0) { (videoFirst) in
                                            mdModel.video_4_data = videoFirst
                                            mdModel.pageNum = 2
                                            strongSelf.collView.reloadData()
                                        } failHandler: { (error) in
                                            XSAlert.show(type: .error, text: error)
                                        }
                                    } else {
                                        mdModel.video_4_data = videos
                                        strongSelf.collView.reloadData()
                                    }
                                } else {
                                    mdModel.pageNum = page + 1
                                    mdModel.video_4_data = videos
                                    strongSelf.collView.reloadData()
                                }
                            } failHandler: { (error) in
                                XSAlert.show(type: .error, text: error)
                            }
                        } else if mdModel.module == .shortV_Third {
                            guard let page = mdModel.pageNum else { // pageNum不存在，说明第一页数据不够， 不能换
                                return
                            }
                            strongSelf.viewModel.loadModuleMoreListData(params:[VideoModuleMoreApi.kModuleId: mdModel.id ?? 0, VideoModuleMoreApi.kProtocol: mdModel.protocol ?? ""] , inVipPart: strongSelf.position == .InVIPPart, pageNumber: page, limit: mdModel.limit ?? 0) { (videos) in
                                if videos.count < (mdModel.limit ?? 0) {
                                    mdModel.pageNum = 1
                                    if videos.count == 0 {
                                        strongSelf.viewModel.loadModuleMoreListData(params: [VideoModuleMoreApi.kModuleId: mdModel.id ?? 0, VideoModuleMoreApi.kProtocol: mdModel.protocol ?? ""], inVipPart: strongSelf.position == .InVIPPart, pageNumber: 1, limit: mdModel.limit ?? 0) { (videoFirst) in
                                            mdModel.video_5_data = videoFirst
                                            mdModel.pageNum = 2
                                            strongSelf.collView.reloadData()
                                        } failHandler: { (error) in
                                            XSAlert.show(type: .error, text: error)
                                        }
                                    } else {
                                        mdModel.video_5_data = videos
                                        strongSelf.collView.reloadData()
                                    }
                                } else {
                                    mdModel.pageNum = page + 1
                                    mdModel.video_5_data = videos
                                    strongSelf.collView.reloadData()
                                }
                            } failHandler: { (error) in
                                XSAlert.show(type: .error, text: error)
                            }
                        }
                    }
                }
                reusableView = footer
            }
        }
        return reusableView!
    }
}
// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension LVModulesController: UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return modules.count
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        let mdModel = modules[section]
        if mdModel.module == .ad {
            if let cover = channel.cover, !cover.isEmpty {  //有背景广告
                return 1
            } else {
                return mdModel.ad_1_data?.count == 0 ? 0 : 1
            }
        } else if mdModel.module == .adFull {
            return mdModel.ad_4_data?.count == 0 ? 0 : 1
        } else if mdModel.module == .adScroll {
            return mdModel.ad_2_data?.count == 0 ? 0 : 1
        } else if mdModel.module == .adImage {
            return mdModel.ad_3_data?.count == 0 ? 0 : 1
        } else if mdModel.module == .longVScroll {
            return mdModel.video_1_data?.count == 0 ? 0 : 1
        } else if mdModel.module == .shortVScroll  {
            return mdModel.video_2_data?.count == 0 ? 0 : 1
        } else if mdModel.module == .longVdouble {
            return mdModel.video_3_data?.count ?? 0
        } else if mdModel.module == .longV_Five {
            if let videos = mdModel.video_4_data, videos.count > 1 {
                return videos.count-1
            }
        } else if mdModel.module == .shortV_Third {
            return mdModel.video_5_data?.count ?? 0
        } else if mdModel.module == .waterFall {
            return mdModel.video_6_data?.count ?? 0
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let mdModel = modules[indexPath.section]
        if mdModel.module == .ad {
            if let cover = channel.cover, !cover.isEmpty {  //有背景广告
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: BannerScrollCellBgImg.cellId, for: indexPath) as! BannerScrollCellBgImg
                cell.setCoverImg(cover)
                cell.setBanner(mdModel.ad_1_data)
                cell.bgCoverClick = { [weak self] in
                    if let coverLink = self?.channel.cover_link, !coverLink.isEmpty {
                        self?.goInnerLink(coverLink)
                    }
                }
                cell.scrollItemClickHandler = { [weak self] index in
                    if let ads = mdModel.ad_1_data, ads.count > index {
                        self?.goInnerLink(ads[index].link ?? "")
                    }
                }
                return cell
            } else {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: BannerScrollCellNormal.cellId, for: indexPath) as! BannerScrollCellNormal
                cell.setBanner(mdModel.ad_1_data)
                cell.scrollItemClickHandler = { [weak self] index in
                    if let ads = mdModel.ad_1_data, ads.count > index {
                        self?.goInnerLink(ads[index].link ?? "")
                    }
                }
                return cell
            }
        } else if mdModel.module == .adImage {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: BannerScrollInsert.cellId, for: indexPath) as! BannerScrollInsert
            cell.setBanner(mdModel.ad_3_data)
            cell.scrollItemClickHandler = { [weak self] index in
                if let ads = mdModel.ad_3_data, ads.count > index {
                    self?.goInnerLink(ads[index].link ?? "")
                }
            }
            return cell
        } else if mdModel.module == .adFull {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: BannerScrollFullWidth.cellId, for: indexPath) as! BannerScrollFullWidth
            cell.setBanner(mdModel.ad_4_data)
            cell.scrollItemClickHandler = { [weak self] index in
                if let ads = mdModel.ad_4_data, ads.count > index {
                    self?.goInnerLink(ads[index].link ?? "")
                }
            }
            return cell
        }  else if mdModel.module == .adScroll {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ADScrollCell.cellId, for: indexPath) as! ADScrollCell
            cell.setModels(mdModel.ad_2_data)
            cell.itemClickHandler = { [weak self] index in
                if let ads = mdModel.ad_2_data, ads.count > index {
                    self?.goInnerLink(ads[index].link ?? "")
                }
            }
            return cell
        } else if mdModel.module == .longVScroll {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LongScrollCell.cellId, for: indexPath) as! LongScrollCell
            cell.setModels(mdModel.video_1_data)
            cell.itemClickHandler = { [weak self] video in
                self?.goLongDetail(video)
            }
            cell.avatarClickHandler = { [weak self] user in
                self?.goUserCenter(user)
            }
            return cell
        } else if mdModel.module == .shortVScroll {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShortScrollCell.cellId, for: indexPath) as! ShortScrollCell
            cell.setModels(mdModel.video_2_data)
            cell.itemClickHandler = { [weak self] index in
                if let shortVs = mdModel.video_2_data, shortVs.count > index {
                    self?.goShortVideoPlayerVC(shortVs[index])
                }
            }
            cell.avatarClickHandler = { [weak self] user in
                self?.goUserCenter(user)
            }
            return cell
        } else if mdModel.module == .longVdouble || mdModel.module == .longV_Five {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LongVideoCell.cellId, for: indexPath) as! LongVideoCell
            if mdModel.module == .longVdouble {
                if let videos = mdModel.video_3_data {
                    cell.setModel(videos[indexPath.item],.itemSizeDouble)
                    cell.avataClickHandler = { [weak self] in
                        self?.goUserCenter(videos[indexPath.item].user)
                    }
                }
            } else {
                if let videos = mdModel.video_4_data,videos.count > 0 {
                    cell.setModel(videos[indexPath.item + 1],.itemSizeDouble)
                    cell.avataClickHandler = { [weak self] in
                        self?.goUserCenter(videos[indexPath.item + 1].user)
                    }
                }
            }
            return cell
        } else if mdModel.module == .shortV_Third {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShortVideoCell.cellId, for: indexPath) as! ShortVideoCell
            if let videos = mdModel.video_5_data {
                cell.setModel(model: videos[indexPath.item],.itemSizeThird)
                cell.avataClickHandler = { [weak self] in
                    self?.goUserCenter(videos[indexPath.item].user)
                }
            }
            return cell
        } else if mdModel.module == .waterFall {
            guard let models = mdModel.video_6_data, models.count > 0 else {
                return UICollectionViewCell()
            }
            let model = models[indexPath.item]
            if model.recAd != nil {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ADRandomCell.cellId, for: indexPath) as! ADRandomCell
                if let ad = model.recAd {
                    cell.setAdModel(model: ad)
                }
                return cell
            }
            if model.is_long == 0 {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShortVideoCell.cellId, for: indexPath) as! ShortVideoCell
                cell.setModel(model: model,.itemSizeDouble)
                cell.avataClickHandler = { [weak self] in
                    self?.goUserCenter(model.user)
                }
                return cell
            } else {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LongVideoCell.cellId, for: indexPath) as! LongVideoCell
                cell.setModel(model,.itemSizeDouble)
                cell.avataClickHandler = { [weak self] in
                    self?.goUserCenter(model.user)
                }
                return cell
            }
        }
        return UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        let mdModel = modules[indexPath.section]
        if mdModel.module == .longVdouble {
            if let videos = mdModel.video_3_data, videos.count > indexPath.item {
                goLongDetail(videos[indexPath.item])
            }
        } else if mdModel.module == .longV_Five {
            if let videos = mdModel.video_4_data, videos.count > indexPath.item + 1 {
                goLongDetail(videos[indexPath.item + 1])
            }
        } else if mdModel.module == .waterFall {
            if let videos = mdModel.video_6_data, videos.count > indexPath.item {
                let video = videos[indexPath.item]
                if video.recAd != nil {
                    if let link = video.recAd?.link, !link.isEmpty {
                        goInnerLink(link)
                    }
                } else {
                    if video.is_long == 0 {
                        goShortVideoPlayerVC(video)
                    } else {
                        goLongDetail(video)
                    }
                }
            }
        } else if mdModel.module == .shortV_Third {
            if let videos = mdModel.video_5_data, videos.count > indexPath.item {
                let video = videos[indexPath.item]
                goShortVideoPlayerVC(video)
            }
        }
    }
    func collectionView(_ collectionView: UICollectionView, didEndDisplaying cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if modules.count > indexPath.section {
            let mdModel = modules[indexPath.section]
            if mdModel.module == .longVScroll {
                (cell as? LongScrollCell)?.playerPause()
            }
        }
        
    }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if modules.count > indexPath.section {
            let mdModel = modules[indexPath.section]
            if mdModel.module == .longVScroll {
                (cell as? LongScrollCell)?.playerPlay()
            }
        }
    }
}

// MARK: - WaterfallMutiSectionDelegate
extension LVModulesController: WaterfallMutiSectionDelegate {
    
    func heightForRowAtIndexPath(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, indexPath: IndexPath, itemWidth: CGFloat) -> CGFloat {
        let mdModel = modules[indexPath.section]
        if mdModel.module == .ad {
            if let cover = channel.cover, !cover.isEmpty {  //有背景广告
                return BannerScrollCellBgImg.itemSize.height
            } else {
                return mdModel.ad_1_data?.count == 0 ? .zero : BannerScrollCellNormal.itemSize.height
            }
        } else if mdModel.module == .adFull {
            return mdModel.ad_4_data?.count == 0 ? .zero : BannerScrollFullWidth.itemSize.height
        } else if mdModel.module == .adScroll {
            return mdModel.ad_2_data?.count == 0 ? .zero : ADModulItemCell.itemSizeScroll.height
        } else if mdModel.module == .adImage {
            return mdModel.ad_3_data?.count == 0 ? .zero : BannerScrollInsert.itemSize.height
        } else if mdModel.module == .longVScroll {
            return mdModel.video_1_data?.count == 0 ? .zero : LongVideoCell.itemSizeScroll.height
        } else if mdModel.module == .shortVScroll {
            return mdModel.video_2_data?.count == 0 ? .zero : ShortVideoCell.itemSizeScroll.height
        } else if mdModel.module == .longVdouble {
            return mdModel.video_3_data?.count == 0 ? .zero : LongVideoCell.itemSizeDouble.height
        } else if mdModel.module == .longV_Five {
            if let video4 = mdModel.video_4_data, video4.count > 1 {
                return  LongVideoCell.itemSizeDouble.height
            }
        } else if mdModel.module == .shortV_Third {
            return mdModel.video_5_data?.count == 0 ? .zero : ShortVideoCell.itemSizeThird.height
        } else if mdModel.module == .waterFall {
            if let models = mdModel.video_6_data, models.count > indexPath.item {
                let model = models[indexPath.item]
                if model.recAd != nil {
                    return ADRandomCell.itemSize.height
                } else {
                    if model.is_long == 1 {
                        return LongVideoCell.itemSizeDouble.height
                    } else {
                        return ShortVideoCell.itemSizeDouble.height
                    }
                }
            }
        }
        return .zero
    }
    func columnNumber(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> Int {
        let mdModel = modules[section]
        if mdModel.module == .longVdouble || mdModel.module == .longV_Five || mdModel.module == .waterFall {
            return 2
        } else if mdModel.module == .shortV_Third {
            return 3
        }
        return 1
    }
    func referenceSizeForHeader(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGSize {
        let mdModel = modules[section]
       
        if mdModel.module == .longVScroll {
            if mdModel.title == nil || mdModel.title!.isEmpty {
                return .zero
            }
            return mdModel.video_1_data?.count == 0 ? .zero : CGSize(width: screenWidth, height: 50)
        } else if mdModel.module == .shortVScroll  {
            if mdModel.title == nil || mdModel.title!.isEmpty {
                return .zero
            }
            return mdModel.video_2_data?.count == 0 ? .zero : CGSize(width: screenWidth, height: 50)
        } else if mdModel.module == .longVdouble {
            if mdModel.title == nil || mdModel.title!.isEmpty {
                return .zero
            }
            return mdModel.video_3_data?.count == 0 ? .zero : CGSize(width: screenWidth, height: 50)
        } else if mdModel.module == .longV_Five {
            if let models = mdModel.video_4_data, models.count > 0 {
                if let title = mdModel.title, !title.isEmpty {
                   return CGSize(width: screenWidth, height: 60 + LongVideoCell.itemSizeSingle.height)
                } else {
                   return CGSize(width: screenWidth, height: LongVideoCell.itemSizeSingle.height + 20)
                }
            }
            return .zero
        } else if mdModel.module == .shortV_Third {
            if mdModel.title == nil || mdModel.title!.isEmpty {
                return .zero
            }
            return mdModel.video_5_data?.count == 0 ? .zero : CGSize(width: screenWidth, height: 50)
        } else if mdModel.module == .waterFall {
            if mdModel.title == nil || mdModel.title!.isEmpty {
                return .zero
            }
            return mdModel.video_6_data?.count == 0 ? .zero : CGSize(width: screenWidth, height: 50)
        }
        return .zero
    }
    func referenceSizeForFooter(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGSize {
        let mdModel = modules[section]
        if mdModel.module == .longVdouble {
            return mdModel.video_3_data?.count == 0 ? .zero : CGSize(width: screenWidth, height: 50)
        } else if mdModel.module == .longV_Five {
            return mdModel.video_4_data?.count == 0 ? .zero : CGSize(width: screenWidth, height: 50)
        } else if mdModel.module == .shortV_Third {
            return mdModel.video_5_data?.count == 0 ? .zero : CGSize(width: screenWidth, height: 50)
        }
        if mdModel.module == .adFull && section == 0 && position == .InVIPPart {
            if let time = UserModel.share().user?.countdown_time, time > 0 {
                return CGSize(width: screenWidth, height: 130)
            } else {
                return CGSize(width: screenWidth, height: 60)
            }
        }
        return .zero
    }
    func insetForSection(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> UIEdgeInsets {
        let mdModel = modules[section]
        if mdModel.module == .ad {
            if let cover = channel.cover, !cover.isEmpty {  //有背景广告
                return mdModel.ad_1_data?.count == 0 ? .zero : UIEdgeInsets(top: 0, left: 0, bottom: 5, right: 0)
            } else {
                return mdModel.ad_1_data?.count == 0 ? .zero : UIEdgeInsets(top: 5, left: 0, bottom: 5, right: 0)
            }
        } else if mdModel.module == .adImage {
            return mdModel.ad_3_data?.count == 0 ? .zero : UIEdgeInsets(top: 15, left: 0, bottom: 8, right: 0)
        } else if mdModel.module == .adScroll {
            return mdModel.ad_2_data?.count == 0 ? .zero : UIEdgeInsets(top: 15, left: 0, bottom: 8, right: 0)
        } else if mdModel.module == .longVScroll {
            return mdModel.video_1_data?.count == 0 ? .zero : UIEdgeInsets(top: 0, left: 0, bottom: 8, right: 0)
        } else if mdModel.module == .shortVScroll {
            return mdModel.video_2_data?.count == 0 ? .zero : UIEdgeInsets(top: 0, left: 0, bottom: 8, right: 0)
        } else if mdModel.module == .longVdouble || mdModel.module == .longV_Five || mdModel.module == .waterFall || mdModel.module == .shortV_Third {
            return UIEdgeInsets(top: 0, left: 15, bottom: 8, right: 15)
        }
        return .zero
    }
    func lineSpacing(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGFloat {
        let mdModel = modules[section]
        if mdModel.module == Module.longVdouble || mdModel.module == .longV_Five || mdModel.module == .waterFall || mdModel.module == .shortV_Third {
           return 10
        }
        return 0
    }
    func interitemSpacing(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGFloat {
        let mdModel = modules[section]
        if mdModel.module == Module.longVdouble || mdModel.module == .longV_Five || mdModel.module == .waterFall || mdModel.module == .shortV_Third {
            return 10
        }
        return  0
    }
    func spacingWithLastSection(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGFloat {
        return 0
    }
}

// MARK: - UIScrollViewDelegate
extension LVModulesController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if position == .InModule {
            let offsetY = scrollView.contentOffset.y
            scrollOffSetYHandler?(offsetY, segIndex)
        }
    }
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        NotificationCenter.default.post(name: Notification.Name.init("stopPlay"), object: nil)
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension LVModulesController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is VideoModuleApi {
            if position == .InModule {
                return [VideoModuleApi.kKeyId: channel.id ?? 0,VideoModuleApi.kIsVip: UserModel.share().user?.is_vip == "y" ? 1 : 0, LFMsgListApi.kChannel: UserModel.share().user?.channel ?? ""]
            } else if position == .InVIPPart {
                if segIndex > 2 {
                    return [VideoModuleApi.kKeyId: channel.id ?? 0,VideoModuleApi.kIsVip: UserModel.share().user?.is_vip == "y" ? 1 : 0, LFMsgListApi.kChannel: UserModel.share().user?.channel ?? ""]
                } else {
                    return [VideoModuleApi.kKeyId: segIndex + 1,VideoModuleApi.kIsVip: UserModel.share().user?.is_vip == "y" ? 1 : 0, LFMsgListApi.kChannel: UserModel.share().user?.channel ?? ""]
                }
            }
        }
        if manager is VideoModuleMoreApi {
            if let lastId = modules.last?.id {
                return [VideoModuleMoreApi.kModuleId: lastId, VideoModuleMoreApi.kProtocol: modules.last?.protocol ?? ""]
            }
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        collView.mj_header.endRefreshing()
        collView.mj_footer.endRefreshing()
        if manager is VideoModuleApi {
            if var modulesList = manager.fetchJSONData(VideoReformer()) as? [ModulesModel] {
                modulesList = modulesList.map { (model) -> ModulesModel in
                    if model.module == .longVdouble {
                        if (model.video_3_data?.count ?? 0) >= (model.limit ?? 0) {
                            model.pageNum = 2
                        }
                    } else if model.module == .longV_Five {
                        if (model.video_4_data?.count ?? 0) >= (model.limit ?? 0) {
                            model.pageNum = 2
                        }
                    } else if model.module == .shortV_Third {
                        if (model.video_5_data?.count ?? 0) >= (model.limit ?? 0) {
                            model.pageNum = 2
                        }
                    }
                    return model
                }
                if moduleApi.pageNumber == 1 {
                    modules = modulesList
                    if modules.count == 0 {
                        loadMoreView.isHidden = true
                        NicooErrorView.showErrorMessage(.noData, "暂无数据", on: view, topMargin: position == .InVIPPart ? (statusBarHeight + 60) : statusBarHeight + 88) {
                            self.loadData()
                        }
                    } else {
                        if modules.count < VideoModuleApi.kDefaultCount && modules.last?.module != .waterFall {
                            loadMoreView.isHidden = true
                        } else {
                            loadMoreView.isHidden = false
                            if let waterFall = modules.last, waterFall.module == .waterFall {
                                let realDataCount = waterFall.video_6_data?.count ?? 0
                                if let skip = UserModel.share().authInfo?.config?.rule?.ad_skip?.int, skip > 0 {
                                    if let adList = UserModel.share().authInfo?.video_out, adList.count > 0 {
                                        let skipTimes = realDataCount/skip
                                        if skipTimes > 0 {
                                            for i in 1 ..< skipTimes + 1 {
                                                let arm = arc4random()%(UInt32(adList.count))
                                                let ad = adList[Int(arm)]
                                                let model = VideoNew()
                                                model.recAd = ad
                                                if realDataCount > skip {
                                                    waterFall.video_6_data?.insert(model, at: skip * i + i - 1)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    modules.append(contentsOf: modulesList)
                    if modulesList.count < VideoModuleApi.kDefaultCount {
                        if modules.last?.module == .waterFall {
                            /// 请求瀑布流接口第二页 (这里不用viewModel来做) （换一换 都要使用viewmodel）
                            starLoadWaterFallData()
                        } else {
                            loadMoreView.isHidden = true
                        }
                    }
                }
                collView.reloadData()
            }
        }
        if manager is VideoModuleMoreApi {
            if var waterFallList = manager.fetchJSONData(VideoReformer()) as? [VideoNew], waterFallList.count > 0 {
                waterFallMoreApi.pageNumber += 1
                let realDataCount = waterFallList.count
                if let skip = UserModel.share().authInfo?.config?.rule?.ad_skip?.int, skip > 0 {
                    if let adList = UserModel.share().authInfo?.video_out, adList.count > 0 {
                        let skipTimes = realDataCount/skip
                        if skipTimes > 0 {
                            for i in 1 ..< skipTimes + 1 {
                                let arm = arc4random()%(UInt32(adList.count))
                                let ad = adList[Int(arm)]
                                let model = VideoNew()
                                model.recAd = ad
                                if realDataCount > skip {
                                    waterFallList.insert(model, at: skip * i + i - 1)
                                }
                            }
                        }
                    }
                }
                modules.last?.video_6_data?.append(contentsOf: waterFallList)
                collView.reloadData()
            } else {
                loadMoreView.isHidden = true
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        collView.mj_header.endRefreshing()
        collView.mj_footer.endRefreshing()
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        NicooErrorView.showErrorMessage(.noNetwork, on: view, topMargin: position == .InVIPPart ? (statusBarHeight + 60) : statusBarHeight + 88) {
            self.loadData()
        }
    }
}

// MARK: - Layout
private extension LVModulesController {
    
    func layoutPageSubviews() {
        layoutCollection()
    }
    func layoutCollection() {
        collView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-44)
            } else {
                make.bottom.equalToSuperview().offset(-44)
            }
        }
    }

}



