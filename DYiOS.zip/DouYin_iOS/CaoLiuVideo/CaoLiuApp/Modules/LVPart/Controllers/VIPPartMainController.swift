
import UIKit
import JXSegmentedView


class VIPPartMainController: CLBaseViewController {
    
    let fakeStatuBar: UIView = {
        let v = UIView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: statusBarHeight + 44))
        v.backgroundColor = .clear
        return v
    }()
    let coverLayer: CAGradientLayer = {
        let ly = CAGradientLayer()
        ly.colors = [UIColor(white: 0.0, alpha: 0.65).cgColor, UIColor(white: 0.0, alpha: 0.0).cgColor]
        ly.locations = [0.75, 1.0]
        ly.frame = CGRect(x: 0, y: 0, width: screenWidth, height: statusBarHeight + 44)
        return ly
    }()
    
    var titles = [String]()
    let dataSource = JXSegmentedTitleDataSource()
    let segmentedView = JXSegmentedView()
    lazy var listContainerView: JXSegmentedListContainerView! = {
        return JXSegmentedListContainerView(dataSource: self)
    }()
    
    let vipvc = LVModulesController()
    let dimondvc = LVModulesController()
    let cateVideo = TypesCategrayController()
    
    var channels = [ChannelModel]()
    private let viewModel = VideoViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(topBarColorChange(_:)), name: Notification.Name.kVIPTopBarColotNotification, object: nil)
        titles = ["VIP会员","钻石","视频"]
        setUpUI()
        loadChannels()
    }
    func loadChannels() {
        NicooErrorView.removeErrorMeesageFrom(view)
        viewModel.loadChannelListData([ChannelListApi.kPosition: 1]) { [weak self] (models) in
            self?.channels = models
            self?.setUpPage()
        } failHandler: { [weak self] (error) in
            guard let strongSelf = self else { return }
            NicooErrorView.showErrorMessage(.noNetwork, on: strongSelf.view) {
                strongSelf.loadChannels()
            }
        }
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        listContainerView.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight)
        listContainerView.addSubview(fakeStatuBar)
        fakeStatuBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(statusBarHeight + 44)
        }
    }
    func setUpPage() {
        var titleHave = [String]()
        if channels.count > 0 {
            let strs = channels.map { (model) -> String in
                return model.title ?? "未知"
            }
            titleHave.append(contentsOf: strs)
        }
        titles.append(contentsOf: titleHave)
        dataSource.titles = titles
        dataSource.titleNormalFont = UIFont.boldSystemFont(ofSize: 16)
        dataSource.titleSelectedFont = UIFont.boldSystemFont(ofSize: 20)
        dataSource.titleNormalColor = .white
        dataSource.titleSelectedColor = rgb(226, 188, 137)
        dataSource.itemSpacing = 20
        dataSource.isItemSpacingAverageEnabled = false
    
        let indicator = JXSegmentedIndicatorLineView()
        indicator.indicatorWidth = 15
        indicator.indicatorCornerRadius = 1.5
        indicator.indicatorHeight = 3
        indicator.indicatorColor = UIColor.colorGradientChangeWithSize(size: CGSize(width: 12, height: 3), direction: .level, startColor: rgb(247, 219, 172), endColor: rgb(223, 180, 127))
        indicator.verticalOffset = 5
                
        segmentedView.frame = CGRect(x: 0, y: statusBarHeight - 5, width: screenWidth, height: 49)
        segmentedView.dataSource = dataSource
        segmentedView.indicators = [indicator]
        view.addSubview(listContainerView)
        view.addSubview(segmentedView)
        segmentedView.listContainer = listContainerView
    }
    private func setUpUI() {
        view.backgroundColor = ConstValue.kVcViewColor
        fakeStatuBar.layer.insertSublayer(coverLayer, at: 0)
    }
}
extension VIPPartMainController: JXSegmentedListContainerViewDataSource {
    func numberOfLists(in listContainerView: JXSegmentedListContainerView) -> Int {
        if let titleDataSource = segmentedView.dataSource as? JXSegmentedBaseDataSource {
            return titleDataSource.dataSource.count
        }
        return 0
    }

    func listContainerView(_ listContainerView: JXSegmentedListContainerView, initListAt index: Int) -> JXSegmentedListContainerViewListDelegate {
        if index == 0 {
            vipvc.position = .InVIPPart
            vipvc.segIndex = index
            if channels.count > index {
                vipvc.channel = channels[index]
            }
            return vipvc
        } else if index == 1 {
            dimondvc.position = .InVIPPart
            dimondvc.segIndex = index
            if channels.count > index {
                dimondvc.channel = channels[index]
            }
            return dimondvc
        } else if index == 2 {
            cateVideo.InVipPart = true
            return cateVideo
        } else {
            let channel = channels[index - 3]
            let type = channel.type ?? ModulePageType.Module
            if type == .Module {
               if let urlstr = channel.url, !urlstr.isEmpty, let url = URL(string: urlstr) {
                   let h5VC = AAViewController.init(url: url)
                   h5VC.position = .InVIPPart
                   h5VC.segIndex = index
                   return h5VC
               }
            } else if type == .H5 {
                let vc = GameListControlller()
                vc.position = .InVIPPart
                return vc
            }
        }
        let defaultVC = AAViewController(url: URL(string: UserModel.share().authInfo?.config?.sys?.share_url ?? "")!)
        defaultVC.position = .InVIPPart
        return defaultVC
    }
}

extension VIPPartMainController {
    @objc func topBarColorChange(_ notif: Notification) {
        if let colorType = notif.userInfo?["TopBarDarkColor"] as? Int {
            fakeStatuBar.backgroundColor = colorType == 1 ? ConstValue.kVcViewColor : .clear
        } else {
            fakeStatuBar.backgroundColor = .clear
        }
    }
}
