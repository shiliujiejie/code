
import UIKit
import SnapKit
import MJRefresh
import AVFoundation
import NicooNetwork
import AssetsLibrary
import Photos

class HomeViewController: UIViewController {
   
    var currentIndex:Int = 0
    var currentPlayIndex: Int = 0
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    private var topSegView: HomeTopSegView = {
        guard let view = Bundle.main.loadNibNamed("HomeTopSegView", owner: nil, options: nil)?[0] as? HomeTopSegView else { return HomeTopSegView() }
        return view
    }()
    private let adTimerlabel: UILabel = {
        let lab = UILabel()
        lab.text = "广告时间，3秒后可操作"
        lab.textColor = UIColor.white
        lab.font = UIFont.systemFont(ofSize: 15)
        lab.backgroundColor = UIColor(white: 0.1, alpha: 0.5)
        lab.layer.cornerRadius = 15
        lab.layer.masksToBounds = true
        lab.textAlignment = .center
        lab.isHidden = true
        return lab
    }()
    let flowLayout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        //每个Item之间最小的间距
        layout.minimumInteritemSpacing = 0
        //每行之间最小的间距
        layout.minimumLineSpacing = 0
        return layout
    }()
    lazy var mainCV: UICollectionView = {
        let collectionView = UICollectionView(frame: view.bounds, collectionViewLayout: flowLayout)
        collectionView.backgroundColor = UIColor.clear
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.scrollsToTop = false
        collectionView.isPagingEnabled = true
        collectionView.register(CLHomePlayCell.classForCoder(), forCellWithReuseIdentifier: CLHomePlayCell.cellId)
        return collectionView
    }()
    var player: PlayerView?
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        let loadmore = MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.viewModel.loadNextPage()
        })
        loadmore?.setTitle("", for: .idle)
        loadmore?.setTitle("", for: .pulling)
        loadmore?.setTitle("", for: .noMoreData)
        return loadmore!
    }()
    private let viewModel = VideoViewModel()
    private let userInfoViewModel = UserInfoViewModel()
    
    var vcIndex: Int = 0
    
    var videoCurrent: VideoNew?  //记录当前播放的视频模型
    
    var isRefreshOperation = false
    /// 推荐/ 免费
    var isRecoment = true
    /// 是否关注过别人
    var isAttentionPeople = true
    
    var isFirstIn = true
    var tipsTimer = TipTimerMg()
    var timer: Timer!
    var timer1: Timer?
    var adtime: Int = 3
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.darkText
        setUpUI()
        addViewModelCallBack()
        loadData(isRecomment: isRecoment)
        if isRecoment {
            loadAdInfoApi()
        }
        /// 延迟三秒弹起。版本更新框
        perform(#selector(showActivityAlert), with: nil, afterDelay: 2)
        NotificationCenter.default.addObserver(self, selector: #selector(didUserBeenKickedOut), name: Notification.Name.kUserBeenLogOutNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(refreshAttentionStatu), name: Notification.Name.kHomeRefreshAttentionStateNotification, object: nil)
        
        UIApplication.shared.isIdleTimerDisabled = true
    }
    
    public func playCurrent() {
        if viewModel.getHomeList().count == 0 { return }
        let homeModel = viewModel.getHomeList()[currentIndex]
        let index = IndexPath(item: currentIndex, section: 0)
        if let cell = mainCV.cellForItem(at: IndexPath(item: currentIndex, section: 0)) as? CLHomePlayCell {
            playVideo(homeModel: homeModel, cell: cell, indexPath: index)
        }
    }
    
    private func setUpUI() {
        //固定设置layut，或者通过UICollectionViewDelegateFlowLayout设置，这样可以动态调整
        if let layout = mainCV.collectionViewLayout as? UICollectionViewFlowLayout {
            //每个Item之间最小的间距
            layout.minimumInteritemSpacing = 0
            //每行之间最小的间距
            layout.minimumLineSpacing = 0
        }
        if #available(iOS 11.0, *) {
            mainCV.contentInsetAdjustmentBehavior = .never
        } else {
            self.automaticallyAdjustsScrollViewInsets = false
        }
        view.addSubview(mainCV)
        mainCV.scrollsToTop = false
        mainCV.isScrollEnabled = false
        mainCV.allowsSelection = true
        mainCV.mj_footer = loadMoreView
        view.addSubview(adTimerlabel)
        layoutPageSubviews()
    }
    // 账号失效/强制更新
    @objc private func didUserBeenKickedOut(_ notif: Notification) {
        if let code = notif.userInfo?["code"] as? Int, let delegate = UIApplication.shared.delegate as? AppDelegate {
            if code == 403 {
                delegate.window?.rootViewController?.showDialog(title: "账号切换提示", message: XSAlertMessages.kNotAvailTokenAlertMsg, okTitle: "退出重进", cancelTitle: nil, okHandler: {
                    exit(0)
                }, cancelHandler: nil)
            } else if code == 4999 {
                delegate.window?.rootViewController?.showDialog(title: "版本更新提示", message: XSAlertMessages.kUpdateAppAlertMsg, okTitle: "退出重进", cancelTitle: nil, okHandler: {
                    exit(0)
                }, cancelHandler: nil)
            }
        }
    }
    @objc private func refreshAttentionStatu(_ notif: Notification) {
        if let userInfo = notif.userInfo as? [String : Any] {
            if let code = userInfo["code"] as? String, let statu = userInfo["statu"] as? Int {
                _ = fixModelFollowStatu(statu, code: code, datas: viewModel.getHomeList())
            }
        }
    }
    /// 系統公告
    @objc func showSystemMsgAlert() {
        if let message = UserModel.share().authInfo?.config?.sys?.app_notice_ios, !message.isEmpty {
            let controller = AlertManagerController(system: message)
            controller.view.backgroundColor = UIColor(white: 0, alpha: 0.7)
            controller.modalPresentationStyle = .overCurrentContext
            self.modalPresentationStyle = .currentContext
            self.present(controller, animated: true, completion: nil)
        }
    }
    /// 活动弹框
    @objc func showActivityAlert() {
        if let cover = UserModel.share().authInfo?.skip?.cover, !cover.isEmpty {
            let controller = ActivityAlertController(activityIcon: cover)
            controller.modalPresentationStyle = .overCurrentContext
            self.modalPresentationStyle = .currentContext
            self.present(controller, animated: false, completion: nil)
            controller.actionClcick = { actionId in
                if actionId == 1 {
                    if let link = UserModel.share().authInfo?.skip?.link, !link.isEmpty {
                        self.goInnerLink(link)
                    }
                } else {
                    controller.dismiss(animated: false) {
                        self.showSystemMsgAlert()
                    }
                }
            }
        } else {
            showSystemMsgAlert()
        }
    }
}

//MARK: - cell Actions
private extension HomeViewController {
    
    func cellActions(actionId: Int) {
        switch actionId {
        case 1:
            p_showDetails()
            break
        case 2:
            userInfoViewModel.loadAddFollowApi([UserAddFollowApi.kUserId: videoCurrent?.user?.code ?? ""])
            break
        case 3:
            // 会员 完整版
            customActionForPalyer(actionKeyId: 2)
            break
        case 4:
            let homeModel = viewModel.getHomeList()[currentIndex]
            let isAd = (homeModel.type ?? .videoType) == .adType
            if isAd {
                if let link = homeModel.ad?.link, !link.isEmpty {
                    goInnerLink(link)
                }
            }
            break
        case 5:
            shareVideo()
            break
        case 6:
            /// 金币完整版
             customActionForPalyer(actionKeyId: 6)
            break
        case 7:
            /// 新用户优惠
            if videoCurrent?.coins ?? 0 > 0 {
                let vipVC = CoinsCardsController()
                vipVC.isCoins = true
                self.navigationController?.pushViewController(vipVC, animated: true)
            } else {
                customActionForPalyer(actionKeyId: 2)
            }
            break
        default:
            break
        }
    }
    /// user click
     func p_showDetails() {
        if viewModel.getHomeList().count == 0 { return }
        let currentModel = viewModel.homeModels[currentIndex]
        if (currentModel.type ?? .videoType) == .videoType {
            if (currentModel.type ?? .videoType) == .videoType {
                goUserCenter(videoCurrent?.user)
            }
        } else {
            /// 跳转到广告页面
            DLog("跳转到广告页面 === \(currentModel.ad?.link ?? "")")
            goAndUpdate(currentModel.ad?.link ?? "")
        }
    }
    /// 点赞
     func addFavorOrNot(_ isFavor: Bool) {
        let indexPath = IndexPath(row: self.currentIndex, section: 0)
        let likeCount = videoCurrent?.like ?? 0
        var favorCount = 0
        if isFavor {  // 不是点赞
            favorCount = likeCount + 1
        } else {
            favorCount = likeCount > 0 ? likeCount - 1 : 0
        }
        videoCurrent?.like = favorCount
        videoCurrent?.is_like = isFavor ? 1 : 0
        if let cell = self.mainCV.cellForItem(at: indexPath) as? CLHomePlayCell {
            cell.setVideoModel(videoCurrent)
        }
        userInfoViewModel.addVideoFavor([UserFavorAddApi.kVideo_id: videoCurrent?.id ?? 0, UserFavorAddApi.kIslong: videoCurrent?.is_long ?? 0])
    }
    func shareVideo() {
        let shareVc = ShareContentController()
        navigationController?.pushViewController(shareVc, animated: true)
    }
    func reloadCurrentIndexFocusStatu(_ statu: Int) {
        if let cell = mainCV.cellForItem(at: IndexPath.init(item: currentIndex, section: 0)) as? CLHomePlayCell {
            cell.focusButton.isHidden = statu == 1
            viewModel.homeModels[currentIndex].video!.user?.is_attention = statu
            viewModel.homeModels[currentIndex].video!.is_attention = statu
            _ = fixModelFollowStatu(statu, code: viewModel.homeModels[currentIndex].video!.user?.code ?? "", datas: viewModel.homeModels)
        }
    }
    func goUserCenter(_ user: CLUserInfo?) {
        let userCenter = UserMCenterController()
        userCenter.userCode = user?.code
        userCenter.followOrCancelBackHandler = { (focusStatu) in
            self.reloadCurrentIndexFocusStatu(focusStatu)
        }
        navigationController?.pushViewController(userCenter, animated: true)
    }
    func goAndUpdate(_ downLoadUrl: String?) {
        if let urlstring = downLoadUrl {
            let downUrl = String(format: "%@", urlstring)
            if let url = URL(string: downUrl) {
                DLog(downUrl)
                if #available(iOS 10, *) {
                    UIApplication.shared.open(url, options: [:],
                                              completionHandler: {
                                                (success) in
                    })
                } else {
                    UIApplication.shared.openURL(url)
                }
            }
        }
    }
}

 //MARK: - UICollectionViewDataSource
extension HomeViewController: UICollectionViewDelegateFlowLayout, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.getHomeList().count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell : CLHomePlayCell = collectionView.dequeueReusableCell(withReuseIdentifier: CLHomePlayCell.cellId, for: indexPath) as! CLHomePlayCell
        let homeModels = viewModel.getHomeList()
        let homeModel = homeModels[indexPath.row]
        let isVideo = (homeModel.type ?? .videoType) == .videoType
        if isVideo {  /// 视频类型
            let videoModel = homeModel.video
            cell.setVideoModel(videoModel)
        } else { /// 广告
            let adModel = homeModel.ad
            cell.setAdModel(adModel)
        }
        /// 第一次进入，播放第一条
        if indexPath.row == 0 && isFirstIn {
            self.playVideo(homeModel: homeModels[0], cell: cell, indexPath: indexPath)
            isFirstIn = false
            currentPlayIndex = currentIndex
        }
        cell.actionSingleHandler = { [weak self] actionId in
            self?.cellActions(actionId: actionId)
        }
        cell.videoFavorItemClick = { [weak self] (isFavor) in
            guard let strongSelf = self else { return  }
            strongSelf.addFavorOrNot(isFavor)
        }
        cell.clickTypeKeyCellHandler = { [weak self] videoKey in
            guard let strongSelf = self else { return }
            let keyMainVc = TypeVideosController()
            keyMainVc.keyMode.type_id = videoKey.type_id ?? videoKey.id
            keyMainVc.keyMode.title = videoKey.title
            strongSelf.navigationController?.pushViewController(keyMainVc, animated: true)
        }
        return cell
    }
    
    //MARK: - UICollectionViewDelegate
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return UIScreen.main.bounds.size
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
    }
}
// MARK: - LoadData
private extension HomeViewController {
    
    /// 请求视频列表
    func loadData(isRecomment: Bool) {
        NicooErrorView.removeErrorMeesageFrom(view)
        if !viewModel.isRefreshOperation {
            XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: true)
        } else {
            viewModel.isRefreshOperation = false
        }
        viewModel.loadHomeData(isRecomment)
    }
    
    /// 请求分享数据并下载开屏广告
    func loadAdInfoApi() {
        /// 处理广告
        if let adInfo = UserModel.share().authInfo?.startup {
            loadAdSplashInfoSuccess(adInfo)
        } else {
            removeLauchAd()
        }
    }
    
    /// 添加viewModel 数据请求回调
    func addViewModelCallBack() {
        viewModel.requestListSuccessHandle = { [weak self] in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: true)
            NicooErrorView.removeErrorMeesageFrom(strongSelf.view)
            if strongSelf.currentIndex != 0 {
                strongSelf.mainCV.scrollToItem(at: IndexPath.init(item: 0, section: 0), at: .top, animated: false)
            }
            strongSelf.isFirstIn = true
            strongSelf.currentIndex = 0
            strongSelf.currentPlayIndex = 0
            strongSelf.mainCV.mj_footer.endRefreshing()
            if strongSelf.viewModel.sourceCount > 0 {
                strongSelf.mainCV.isScrollEnabled = true
            }
            strongSelf.mainCV.reloadData()
        }
        viewModel.requestFailedHandle = { [weak self] (msg) in
            guard let strongSelf = self else { return }
            if let delegate = UIApplication.shared.delegate as? AppDelegate {
               XSProgressHUD.hide(for: delegate.window!, animated: true)
            }
            NicooErrorView.showErrorMessage(.noNetwork, on: strongSelf.view, topMargin: safeAreaTopHeight + 50) {
                strongSelf.loadData(isRecomment: strongSelf.isRecoment)
            }
        }
        userInfoViewModel.followAddOrCancelSuccessHandler = {[weak self]  isAdd in
             guard let strongSelf = self else { return }
            let homeModel = strongSelf.viewModel.homeModels[strongSelf.currentIndex]
            if homeModel.video != nil {
                homeModel.video!.user?.is_attention = isAdd ? 1 : 0
                homeModel.video!.is_attention = isAdd ? 1 : 0
                let _ = strongSelf.fixModelFollowStatu(isAdd ? 1 : 0, code: homeModel.video?.user?.code ?? "", datas: strongSelf.viewModel.homeModels)
            }
            if let cell = strongSelf.mainCV.cellForItem(at: IndexPath.init(item: strongSelf.currentIndex, section: 0)) as? CLHomePlayCell {
                cell.focusButton.setImage(LGConfig.getImage("followSuccess"), for: .normal)
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.8, execute: {
                    cell.focusButton.setImage(LGConfig.getImage("VideoSeriesAdd"), for: .normal)
                    cell.focusButton.isHidden = isAdd
                })
            }
        }
        userInfoViewModel.followOrCancelFailureHandler = { (isAdd, msg) in
            XSAlert.show(type: .error, text: msg)
        }
    }
    
    
    
}

// MARK: - play video
extension HomeViewController {
    
    private func playVideo(homeModel: VideoHomeNew, cell: CLHomePlayCell, indexPath: IndexPath) {
        if (homeModel.type ?? .videoType) == .videoType {   //视频
            guard let videoModel = homeModel.video else {
                videoTypeConfig(video: nil, cell: cell)
                return
            }
            //记录当前的视频模型
            self.videoCurrent = videoModel
             //先鉴权
            videoTypeConfig(video: videoModel, cell: cell)
        } else {    //广告
            let adModel = homeModel.ad
            if adModel?.type == 1 {
                player?.stopPlaying()
            } else {
                adTypeConfig(adModel: adModel, cell: cell)
            }
        }
    }
    private func resetVideoMode(_ video: VideoNew, _ cell: CLHomePlayCell) {
        videoCurrent?.mu = video.mu
        videoCurrent?.is_attention = video.is_attention
        videoCurrent?.is_like = video.is_like
        videoCurrent?.is_free = video.is_free
        videoCurrent?.like = video.like
        videoCurrent?.coins = video.coins
        videoCurrent?.user?.is_attention = video.is_attention
        videoCurrent?.auth_error = video.auth_error
        videoCurrent?.countdown = video.countdown
        cell.setVideoModel(videoCurrent)
    }
    //MARK: - 视频鉴权
    private func videoTypeConfig(video: VideoNew?, cell: CLHomePlayCell) {
        viewModel.loadVideoAuthData(params: [VideoAuthApi.kVideo_id: video?.id ?? 0], succeedHandler: { [weak self] videoModel in
            guard let strongSelf = self else { return }
            //鉴权通过，播放全影片
            strongSelf.resetVideoMode(videoModel,cell)
            if let _ = videoModel.auth_error { // 鉴权失败
                strongSelf.playShortVideo(video: video, cell: cell)
                return
            }
            strongSelf.playLongVideo(strongSelf.videoCurrent, cell)
            
        }) { [weak self] (errorMsg) in
            guard let strongSelf = self else { return }
            /// 接口失败，直接爆网络问题
            strongSelf.player?.stopPlaying()
           // XSAlert.show(type: .error, text: "播放失败1")
        }
    }
    private func playShortVideo(video: VideoNew?, cell: CLHomePlayCell) {
        if let urlshort = video?.smu, !urlshort.isEmpty {
            player?.startPlay(url: URL(string: urlshort), in: cell.bgImage)
        } else {
            player?.stopPlaying()
            XSAlert.show(type: .error, text: "播放失败")
        }
        coundownTips(cell)
    }
    private func playLongVideo(_ video: VideoNew?, _ cell: CLHomePlayCell) {
        if let urlStrM3u8 = video?.mu, !urlStrM3u8.isEmpty {
            player?.startPlay(url: URL(string: urlStrM3u8), in: cell.bgImage)
        } else {
            player?.stopPlaying()
            XSAlert.show(type: .error, text: "播放失败")
        }
        coundownTips(cell)
    }
    /// 新用户充值优惠提示
    private func coundownTips(_ cell: CLHomePlayCell) {
        tipsTimer.releaseTimer()
        guard let time = videoCurrent?.countdown?.countdown_time else { return }
        if time <= 1 { return }
        tipsTimer.timer = Timer.every(1.0.seconds) { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.videoCurrent?.countdown?.countdown_time = strongSelf.videoCurrent!.countdown!.countdown_time! - 1
            if let time = strongSelf.videoCurrent?.countdown?.countdown_time, time > 0 {
                cell.countDownlabel.attributedText = TextSpaceManager.getAttributeStringWithString("\(strongSelf.videoCurrent?.countdown?.countdown_intro ?? "") \(LGConfig.timeDuration(duration: time))", lineSpace: 5, .center)
            } else {
                cell.countDownlabel.isHidden = true
                cell.countDownlabel.tag = -1
            }
        }
        RunLoop.current.add(tipsTimer.timer!, forMode: .common)
    }
    private func adTypeConfig(adModel: AdHome?, cell: CLHomePlayCell) {
        
        mainCV.isScrollEnabled = false
        DLog("看广告了")
        adTimerlabel.isHidden = false
        timer = Timer.new(after: 3.seconds) { [weak self] in
            DLog("可以开始滑了")
            self?.mainCV.isScrollEnabled = true
            self?.timer1?.invalidate()
            self?.adTimerlabel.isHidden = true
            self?.adtime = 3
            self?.adTimerlabel.text = "广告时间，\(self?.adtime ?? 3 )秒后可操作"
        }
        timer1 = Timer.every(1.0.seconds) { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.adtime = strongSelf.adtime - 1
            self?.adTimerlabel.text = "广告时间，\(strongSelf.adtime)秒后可操作"
        }
        RunLoop.current.add(timer, forMode: .default)
        if let adUrl = adModel?.play, !adUrl.isEmpty {
            let url = URL(string: adUrl)
            player?.startPlay(url: url, in: cell.bgImage)
        } else {
            player?.stopPlaying()
        }
    }
    func customActionForPalyer(actionKeyId: Int) {
        if actionKeyId == 1 {
            let indexPath = IndexPath(row: currentIndex, section: 0)
            if let cell = self.mainCV.cellForItem(at: indexPath) as? CLHomePlayCell {
                player?.startPlay(url: player?.playUrl, in: cell.bgImage)
            }
        } else if actionKeyId == 2 {
            // 跳转到
            let vipVC = VipCardsController()
            navigationController?.pushViewController(vipVC, animated: true)
        } else if actionKeyId == 6 {  // 金币解锁
            XSProgressHUD.showCycleProgress(msg: "支付中...", onView: view, animated: false)
            userInfoViewModel.coinsBuyVideo(params: [UseBuyVideoApi.kVideoId: videoCurrent?.id ?? 0] , succeedHandler: { [weak self] mu in
                guard let strongSelf = self else { return }
                XSProgressHUD.hide(for: strongSelf.view, animated: true)
                XSAlert.show(type: .success, text: "恭喜您支付成功")
                if let userCoins = UserModel.share().user?.coins, let vCoins = strongSelf.videoCurrent?.coins, userCoins >= vCoins {
                    UserModel.share().user?.coins = userCoins - vCoins
                    NotificationCenter.default.post(name: Notification.Name.kUserBasicalInformationChanged, object: nil)
                }
                strongSelf.videoCurrent?.auth_error = nil
                strongSelf.videoCurrent?.mu = mu
                if let cell = strongSelf.mainCV.cellForItem(at: IndexPath(row: strongSelf.currentIndex, section: 0)) as? CLHomePlayCell {
                    cell.setVideoModel(strongSelf.videoCurrent)
                    strongSelf.playLongVideo(strongSelf.videoCurrent, cell)
                }
            }) { [weak self] (failMsg) in
                guard let strongSelf = self else { return }
                strongSelf.showCoinBuyAlert(failMsg)
                XSProgressHUD.hide(for: strongSelf.view, animated: true)
            }
        }
    }
    func showCoinBuyAlert(_ msg: String) {
       let failedModel = ConvertCardAlertModel(title: nil, msgInfo: msg, success: false)
       let controller = AlertManagerController(cardModel: failedModel)
       controller.modalPresentationStyle = .overCurrentContext
       controller.view.backgroundColor = UIColor(white: 0.0, alpha: 0.7)
       controller.touchDissMiss = true
       present(controller, animated: false, completion: nil)
       controller.commitActionHandler = {
           let vipVC = CoinsCardsController()
           vipVC.isCoins = true
           self.navigationController?.pushViewController(vipVC, animated: true)
       }
    }
}

// MARK: - UIGestureRecognizerDelegate
extension HomeViewController: UIGestureRecognizerDelegate {
    
    func showDetails(_ view: CLHomePlayCell) {
        /// 如果要让广告的滑动不起效， 可以在这里拦截掉， 不走 p_showDetails
        if viewModel.getHomeList().count > 0 {
             p_showDetails()
        }
    }
}

// MARK: - PlayerViewDelegate
extension HomeViewController: PlayerViewDelegate {
    
    func customActionsBeforePlay() {
    }
    func currentUrlPlayToEnd(url: URL?, player: PlayerView) {
        player.replay()
    }
    func playVideoFailed(url: URL?, player: PlayerView) {
        DLog("playVideoFailed")
        XSAlert.show(type: .error, text: "播放失败")
    }
    func doubleTapGestureAt(point: CGPoint) {
        DLog("doubleTapGestureAction")
        ZanAnimation.showAnimation(point: point, baseView: self.view,size: 30)
        ZanAnimation.showAnimation(point: CGPoint(x: point.x + 10, y: point.y - 70), baseView: self.view, size: 50)
        let homeModel = viewModel.getHomeList()[currentIndex]
        if homeModel.type == .adType { return }
        if let isFavor = videoCurrent?.is_like {
            if isFavor != 1 {  // 没有点赞
                let indexPath = IndexPath(row: self.currentIndex, section: 0)
                userInfoViewModel.addVideoFavor([UserFavorAddApi.kVideo_id: videoCurrent?.id ?? 0, UserFavorAddApi.kIslong: videoCurrent?.is_long ?? 0])
                let likeCount = videoCurrent?.like ?? 0
                let favorCount = likeCount + 1
                videoCurrent?.like = favorCount
                videoCurrent?.is_like = 1
                if let cell = self.mainCV.cellForItem(at: indexPath) as? CLHomePlayCell {
                    cell.setVideoModel(videoCurrent)
                }
            }
        }
    }
    func longpressGestureAt(point: CGPoint) {
        DLog("longpressGestureAt(point: CGPoint)")
//        if videoCurrent?.auth_error != nil { // 鉴权失败
//            return
//        }
//        if player?.player != nil {
//            let playerVc = FullScreenPlayController()
//            playerVc.player = player?.player!
//            playerVc.modalPresentationStyle = .fullScreen
//            present(playerVc, animated: false, completion: nil)
//        }
    }
    func dragingProgress(isDraging: Bool, to progress: Float?) {
        mainCV.panGestureRecognizer.isEnabled = !isDraging
        let indexPath = IndexPath(row: self.currentIndex, section: 0)
        if let cell = self.mainCV.cellForItem(at: indexPath) as? CLHomePlayCell {
            cell.setUIHidenOrNot(isDraging)
        }
    }
}


// MARK: - UIScrollViewDelegate
extension HomeViewController: UIScrollViewDelegate {
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        DispatchQueue.main.async {
            ///如果只有没有数据或者只有一条数据不让它滑动，解决角标越界，闪退
            if self.viewModel.getHomeList().count <= 1 {
                return
            }
            /// 禁用手势
            let translatedPoint = scrollView.panGestureRecognizer.translation(in: scrollView)
            scrollView.panGestureRecognizer.isEnabled = false
            
            if translatedPoint.y < -50 && self.currentIndex < (self.viewModel.getHomeList().count - 1) {
                /// 上滑
                self.currentIndex += 1
            }
            if translatedPoint.y > 50 && self.currentIndex > 0 {
                /// 下滑
                self.currentIndex -= 1
            }
            if self.currentIndex == self.viewModel.sourceCount - 1 && self.viewModel.getHomeList().count >  self.viewModel.sourceCount {
                self.mainCV.reloadData()
                self.viewModel.sourceCount = self.viewModel.getHomeList().count
            }
            let indexPath = IndexPath(row: self.currentIndex, section: 0)
            UIView.animate(withDuration: 0.15, delay: 0.0, options: .curveEaseOut, animations: {
                self.mainCV.scrollToItem(at: indexPath, at: .top, animated: false)
            }, completion: { finished in
                scrollView.panGestureRecognizer.isEnabled = true
                if let cell = self.mainCV.cellForItem(at: indexPath) as? CLHomePlayCell {
                    if self.currentPlayIndex != self.currentIndex { // 上下滑动
                        self.player?.removeFromSuperview()
                        self.playVideo(homeModel: self.viewModel.getHomeList()[indexPath.row], cell: cell, indexPath: indexPath)
                        self.currentPlayIndex = self.currentIndex
                    }
                }
                if self.currentIndex == self.viewModel.getHomeList().count - 3 {
                    DLog("给您补给数据。。， ")
                    self.viewModel.loadHomeDataNextPage()
                    // 这里先不刷新
                }
            })
        }
    }
}


// MARK: - Layout
private extension HomeViewController {
    
    func layoutPageSubviews() {
        layoutMainCV()
        layoutAdTimerLable()
    }
    func layoutMainCV() {
        mainCV.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    func layoutAdTimerLable() {
        adTimerlabel.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.top.equalTo(ConstValue.kStatusBarHeight + 50)
            make.height.equalTo(30)
            make.width.equalTo(180)
        }
    }
}

extension HomeViewController {
    
    func fixModelFollowStatu(_ statu: Int?, code: String, datas: [VideoHomeNew]) -> [VideoHomeNew] {
        for homeModel in datas {
            if homeModel.video?.user?.code == code {
                homeModel.video?.user?.is_attention = statu
                homeModel.video?.is_attention = statu
            }
        }
        return datas
    }
    func loadAdSplashInfoSuccess(_ adInfo: AdSplashModel) {
        guard let adPath = adInfo.cover, let adLink = adInfo.link else {
            removeLauchAd()
            return
        }
        if adPath.isEmpty || adLink.isEmpty {
            removeLauchAd()
            return
        }
        if let saveAdSplashUrl = UserDefaults.standard.string(forKey: UserDefaults.kAdDataUrl), let saveLink = UserDefaults.standard.string(forKey: UserDefaults.kAdLinkUrl) , saveAdSplashUrl == adPath, saveLink == adLink {
            DLog("此广告与上次打开时广告相同。")
            return
        }
        // 下载广告图片
        if let url = URL(string: adPath) {
            AdvertisementView.downLoadADDataWith(url)
        }
       
        /// 存储广告跳转链接
        if let href = adInfo.link, !href.isEmpty {
            UserDefaults.standard.set(href, forKey: UserDefaults.kAdLinkUrl)
        }
    }
   
    func removeLauchAd() {
        if UserDefaults.standard.value(forKey: UserDefaults.kAdDataUrl) != nil {
            UserDefaults.standard.removeObject(forKey: UserDefaults.kAdDataUrl)
        }
        if UserDefaults.standard.value(forKey: UserDefaults.kAdLinkUrl) != nil {
            UserDefaults.standard.removeObject(forKey: UserDefaults.kAdLinkUrl)
        }
    }
}

