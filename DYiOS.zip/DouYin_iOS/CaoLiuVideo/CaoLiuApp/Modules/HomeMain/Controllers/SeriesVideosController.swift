
import UIKit
import MJRefresh
import JXPagingView
import JXSegmentedView
enum VideoPageType {
    case hotTips
    case moduleMore
    case userPage
}

class SeriesVideosController: UIViewController {
    
    lazy var collectionView: UICollectionView = {
        let layout = WaterfallMutiSectionFlowLayout()
        layout.sectionHeadersPinToVisibleBounds = true
        layout.delegate = self
        
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.showsVerticalScrollIndicator = false
        collection.backgroundColor = UIColor.clear
        collection.register(ShortVideoCell.classForCoder(), forCellWithReuseIdentifier: ShortVideoCell.cellId)
        collection.register(LongVideoCell.classForCoder(), forCellWithReuseIdentifier: LongVideoCell.cellId)
        collection.register(ADRandomCell.classForCoder(), forCellWithReuseIdentifier: ADRandomCell.cellId)
        collection.mj_footer = loadMoreView
        collection.mj_header = refreshView
        return collection
    }()

    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        let loadmore = MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
        loadmore?.setTitle("", for: .idle)
        loadmore?.setTitle("已經到底了", for: .noMoreData)
        loadmore?.stateLabel.font = ConstValue.kRefreshLableFont
        return loadmore!
    }()
    lazy private var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.loadFirstPage()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        mjRefreshHeader?.stateLabel.font = ConstValue.kRefreshLableFont
        mjRefreshHeader?.lastUpdatedTimeLabel.font = ConstValue.kRefreshLableFont
        return mjRefreshHeader!
    }()
    

    var vcShowCallBack:(() ->Void)?
    var listViewDidScrollCallback: ((UIScrollView) -> ())?
    private let viewModel = VideoViewModel()
    
    
    var pageType: VideoPageType = .moduleMore
    
    /// Hot Tips
    var keyMode = SearchHotTips()
    /// 模块
    var moduleModel = ModuleDetailModel()
    /// 用于请求videoList
    var params = [String: Any]()
    /// 筛选条件
    var orderKey: String?
    
    ///
    var isLong: Bool = false
    /// segIndex
    var segmentIndex: Int = 0
    
    /// 模块ID
    var moduleID: Int?
    
    var videos = [VideoNew]()
    
    /// 用户id
    var userCode: String?
    
    /// 是否弹起短视频播放页
    var isPresentPlay: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        view.addSubview(collectionView)
        layoutPageSubviews()
        loadData()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        vcShowCallBack?()
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        collectionView.frame = view.bounds
    }
    func loadData() {
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: true)
        loadFirstPage()
    }
    private func loadFirstPage() {
        NicooErrorView.removeErrorMeesageFrom(view)
        params = [String: Any]()  // 这里重新开内存给参数
        if pageType == .hotTips {
            params[SearchVideoApi.kTag_id] = keyMode.type_id ?? keyMode.id
            if segmentIndex != 0 {
                params[SearchVideoApi.kIslong] = segmentIndex == 1 ? 1 : 0
            }
            if orderKey != nil {
                params[SearchVideoApi.kOrder_key] = orderKey
            }
            viewModel.loadSeriesVideoData(params, succeedHandler: { [weak self] (videos, page) in
                self?.dataSuccess(videos, page: page)
            }) { [weak self] (errorMsg) in
                guard let strongSelf = self else { return }
                strongSelf.endRefreshing()
                XSAlert.show(type: .error, text: errorMsg)
            }
        } else if pageType == .moduleMore {
            params[SearchVideoApi.kTypeId] = moduleModel.id
            if segmentIndex != 0 {
                params[SearchVideoApi.kIslong] = segmentIndex == 1 ? 1 : 0
            }
            if orderKey != nil {
                params[SearchVideoApi.kOrder_key] = orderKey
            }
            viewModel.loadSeriesVideoData(params, succeedHandler: { [weak self] (videos, page) in
                self?.dataSuccess(videos, page: page)
            }) { [weak self] (errorMsg) in
                guard let strongSelf = self else { return }
                strongSelf.endRefreshing()
                XSAlert.show(type: .error, text: errorMsg)
            }
        } else if pageType == .userPage {
            params[UserWorkListApi.kUserCode] = userCode
            if segmentIndex != 0 {
                params[UserWorkListApi.kIsLong] = segmentIndex == 1 ? 1 : 0
            }
            viewModel.loadUserVideosData(params) { [weak self] (videos, page) in
                self?.dataSuccess(videos, page: page)
            } failHandler: { [weak self] (errorMsg) in
                guard let strongSelf = self else { return }
                strongSelf.endRefreshing()
                XSAlert.show(type: .error, text: errorMsg)
            }
        }
    }
    
    private func loadNextPage() {
        if pageType == .hotTips || pageType == .moduleMore {
            viewModel.loadSeriesVideoNextPage()
        } else if pageType == .userPage {
            viewModel.loadUserVideosNextPage()
        }
    }
    
    private func endRefreshing() {
        collectionView.mj_header.endRefreshing()
        collectionView.mj_footer.endRefreshing()
        XSProgressHUD.hide(for: view, animated: false)
    }
    
    private func dataSuccess(_ datas: [VideoNew], page: Int) {
        var models = datas
        if segmentIndex == 0 {
            if pageType != .userPage {
                let realDataCount = models.count
                if let skip = UserModel.share().authInfo?.config?.rule?.ad_skip?.int, skip > 0 {
                    if let adList = UserModel.share().authInfo?.video_out, adList.count > 0 {
                        let skipTimes = realDataCount/skip
                        if skipTimes > 0 {
                            for i in 1 ..< skipTimes + 1 {
                                let arm = arc4random()%(UInt32(adList.count))
                                let ad = adList[Int(arm)]
                                let model = VideoNew()
                                model.recAd = ad
                                if realDataCount > skip {
                                    models.insert(model, at: skip * i + i - 1)
                                }
                            }
                        }
                    }
                }
            }
        }
        if page == 1 {
            videos = models
            if datas.count == 0 {
                NicooErrorView.showErrorMessage(.noData, "暂无数据", on: view, topMargin: 55) {
                    self.loadData()
                }
            }
        } else {
            videos.append(contentsOf: models)
        }
        loadMoreView.isHidden = datas.count == 0
        endRefreshing()
        collectionView.reloadData()
    }
    func goUserCenter(_ user: CLUserInfo?) {
        if let vcs = navigationController?.viewControllers {
            let allVcs = vcs.filter { (vc) -> Bool in
                return vc.isKind(of: UserMCenterController.self)
            }
            if allVcs.count > 0 {
                navigationController?.viewControllers.removeAll(where: { (vc) -> Bool in
                    return vc.isKind(of: UserMCenterController.self)
                })
            }
            let userCenter = UserMCenterController()
            userCenter.userCode = user?.code
            navigationController?.pushViewController(userCenter, animated: true)
        }
    }
}


extension SeriesVideosController: WaterfallMutiSectionDelegate {
    func heightForRowAtIndexPath(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, indexPath: IndexPath, itemWidth: CGFloat) -> CGFloat {
        if segmentIndex == 0 {
            let video = videos[indexPath.item]
            if video.recAd != nil {
                return ADRandomCell.itemSize.height
            } else {
                if video.is_long == 1 {
                    return LongVideoCell.itemSizeDouble.height
                } else {
                    return ShortVideoCell.itemSizeDouble.height
                }
            }
        } else if segmentIndex == 2 {
            return ShortVideoCell.itemSizeDouble.height
        } else if segmentIndex == 1 {
            return LongVideoCell.itemSizeDouble.height
        }
        return .zero
    }
    
    func columnNumber(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> Int {
        return 2
    }
    
  func referenceSizeForHeader(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGSize {
    return .zero
  }
  
  func referenceSizeForFooter(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGSize {
    return .zero
  }
  
  func insetForSection(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> UIEdgeInsets {
    return UIEdgeInsets(top: 5, left: 15, bottom: 5, right: 15)
  }
  
  
  func lineSpacing(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGFloat {
    return 10.0
  }
  
  func interitemSpacing(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGFloat {
    return 10.0
  }
  
  func spacingWithLastSection(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGFloat {
    return 0
  }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension SeriesVideosController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return videos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if segmentIndex == 0 {
            let video = videos[indexPath.item]
            if video.recAd != nil {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ADRandomCell.cellId, for: indexPath) as! ADRandomCell
                if let ad = video.recAd {
                    cell.setAdModel(model: ad)
                }
                return cell
            }
            if video.is_long == 0 {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShortVideoCell.cellId, for: indexPath) as! ShortVideoCell
                if videos.count > indexPath.item {
                    let model = videos[indexPath.item]
                    cell.setModel(model: model,.itemSizeDouble)
                    cell.avataClickHandler = { [weak self] in
                        self?.goUserCenter(model.user)
                    }
                }
                return cell
            } else {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LongVideoCell.cellId, for: indexPath) as! LongVideoCell
                let model = videos[indexPath.row]
                 cell.setModel(model,.itemSizeDouble)
                cell.avataClickHandler = { [weak self] in
                    self?.goUserCenter(model.user)
                }
                return cell
            }
           
        } else if segmentIndex == 2 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShortVideoCell.cellId, for: indexPath) as! ShortVideoCell
            if videos.count > indexPath.item {
                let model = videos[indexPath.item]
                cell.setModel(model: model,.itemSizeDouble)
                cell.avataClickHandler = { [weak self] in
                    self?.goUserCenter(model.user)
                }
            }
            return cell
        } else if segmentIndex == 1 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LongVideoCell.cellId, for: indexPath) as! LongVideoCell
            let model = videos[indexPath.row]
             cell.setModel(model,.itemSizeDouble)
            cell.avataClickHandler = { [weak self] in
                self?.goUserCenter(model.user)
            }
            return cell
        }
        return UICollectionViewCell()
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        let video = self.videos[indexPath.item]
        if segmentIndex == 0 {
            if video.recAd != nil {
                if let link = video.recAd?.link, !link.isEmpty {
                    goInnerLink(link)
                }
            } else {
                if video.is_long == 1 {
                    goLongVideoDetail(video)
                } else {
                    goShortVideoPlayerVC(video)
                }
            }
        } else if segmentIndex == 2 {
            goShortVideoPlayerVC(video)
        } else if segmentIndex == 1 {
            goLongVideoDetail(video)
        }
    }
}
extension SeriesVideosController: JXSegmentedListContainerViewListDelegate,JXPagingViewListViewDelegate {
    func listView() -> UIView {
        return self.view
    }
    func listScrollView() -> UIScrollView {
        return collectionView
    }

    func listViewDidScrollCallback(callback: @escaping (UIScrollView) -> ()) {
        listViewDidScrollCallback = callback
    }
}


// MARK: - UIScrollViewDelegate
extension SeriesVideosController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        listViewDidScrollCallback?(scrollView)
    }
}

// MARK: - Layout
private extension SeriesVideosController {
    
    func layoutPageSubviews() {
        
        layoutCollection()
    }
    func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(0)
            make.leading.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
    }
   
}
