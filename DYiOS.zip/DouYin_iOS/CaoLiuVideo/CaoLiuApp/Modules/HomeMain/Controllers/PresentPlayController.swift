
import UIKit
import AssetsLibrary
import Photos

/// 个人中心弹出播放页
class PresentPlayController: CLBaseViewController {
    
    var currentIndex:Int = 0
    var currentPlayIndex: Int = 0
    
    var urls = [String]()
    /// 是否可以点击跳转用户主页
    var canGoNext: Bool = true
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    lazy var player: PlayerView = {
        let player = PlayerView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight))
        player.controlViewBottomInset = safeAreaBottomHeight + 60
        player.progressHeight = 1.0
        player.progressTintColor = UIColor.white
        player.delegate = self
        return player
    }()
    private lazy var loadedFailedView: PlayerCoverTipsView = {
        let failedView = PlayerCoverTipsView(frame: self.view.bounds)
        failedView.backgroundColor = UIColor(white: 0.1, alpha: 0.5)
        return failedView
    }()
    lazy var leftBackButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "navBackWhite"), for: .normal)
        button.backgroundColor = UIColor(white: 0.9, alpha: 0.2)
        button.layer.cornerRadius = 15
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(backButtonClick), for: .touchUpInside)
        return button
    }()
    private lazy var searchBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(getImage("communitySeachIcon"), for: .normal)
        button.addTarget(self, action: #selector(searchBtnClick(_:)), for: .touchUpInside)
        return button
    }()
    let flowLayout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        //每个Item之间最小的间距
        layout.minimumInteritemSpacing = 0
        //每行之间最小的间距
        layout.minimumLineSpacing = 0
        return layout
    }()
    
    lazy var collection: UICollectionView = {
        let collectionView = UICollectionView(frame: view.bounds, collectionViewLayout: flowLayout)
        collectionView.backgroundColor = UIColor.clear
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.scrollsToTop = false
        collectionView.isPagingEnabled = true
        collectionView.register(CLHomePlayCell.classForCoder(), forCellWithReuseIdentifier: CLHomePlayCell.cellId)
        return collectionView
    }()
    
    private let userInfoViewModel = UserInfoViewModel()


    /// 上页 lists 视频个数
    var lastPageCount: Int = 0
    /// 上次刷新时,数据源个数
    var lastReloadVideoCount: Int = 0
    
    var videos = [VideoNew]()
    
    let videoViewModel = VideoViewModel()
    
    /// 返回启动广告页
    var backLaunchAdViewController:(() ->Void)?
    /// 上个页面加载更多
    var loadMoreDatasHandler:(() ->Void)?
    /// 出栈
    var popOrDissMissHandler:(() ->Void)?
    
    var videoCurrent: VideoNew?  //记录当前播放的视频模型
    var tipsTimer = TipTimerMg()
    /// 当前视频播放进度
    var currentPlayTime: Int = 0
    
    /// 步数
    var step: Int = 0
    
    var dataIsLoad: Bool = false
    /// 是否回来
    var isBack: Bool = false
    
    /// 历史观看
    var watchRecord: Bool = false
    
    deinit {
        DLog("release ---- PresentPlayVC")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // APP被挂起通知监听
        NotificationCenter.default.addObserver(self, selector: #selector(applicationResignActivity(_:)), name: UIApplication.willResignActiveNotification, object: nil)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        view.backgroundColor = UIColor(white: 0, alpha: 0.3)
        addUserInfoViewModelCallBack()
        setUpUI()
        loadFirstPage()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        player.pause()
        if let vcs = navigationController?.viewControllers, vcs.contains(self) {
            DLog("viewDidDisappear --- Push or Present")
        } else {
            DLog("viewDidDisappear --- Pop or Dimiss")
            backLaunchAdViewController?()
            videoProgressReport()
            popOrDissMissHandler?()
        }
    }
    func getParams() -> [String: Any]? {
        if videos.count == 0 {
            return nil
        }
        let video = videos[0]
        guard let keys = video.category, keys.count > 0 else {
            return nil
        }
        var param = [String: Any]()
        let allkeyIds = NSMutableString.init()
        for i in 0 ..< keys.count {
            let model = keys[i]
            if i == keys.count - 1 {
                allkeyIds.append("\(model.id ?? model.type_id ?? 0)")
            } else {
                allkeyIds.append("\(model.id ?? model.type_id ?? 0),")
            }
        }
        param[VideoShortListApi.kKeyIds] = allkeyIds as String
        param[VideoShortListApi.kVideoId] = video.id
        return param
    }
    func loadFirstPage() {
        videoViewModel.loadShortVideoData(getParams()) { [weak self] (models, page) in
            self?.loadDataSuccess(models, page)
        } failHandler: { [weak self]  (error, page) in
            if page == 1 {
                self?.step = 1
                self?.collection.reloadData()
            }
        }
    }
    func loadNextPage() {
        videoViewModel.loadShortVideoNextPage(getParams())
    }
    func loadDataSuccess(_ datas: [VideoNew], _ pageNum: Int) {
        lastPageCount = datas.count
        var models = datas
        let realDataCount = models.count
        if let skip = UserModel.share().authInfo?.config?.rule?.short_ad_skip?.int, skip > 0 {
            if let adList = UserModel.share().authInfo?.video_in, adList.count > 0 {
                let skipTimes = realDataCount/skip
                if skipTimes > 0 {
                    for i in 1 ..< skipTimes + 1 {
                        let arm = arc4random()%(UInt32(adList.count))
                        let ad = adList[Int(arm)]
                        let model = VideoNew()
                        model.recAd = ad
                        if realDataCount > skip {
                            models.insert(model, at: skip * i + i - 1)
                        }
                    }
                }
            }
        }
        videos.append(contentsOf: models)
        if pageNum == 1 {
            step = 1
            /// 赋初始值
            lastReloadVideoCount = videos.count
            collection.reloadData()
        }
    }
    
    private func setUpUI() {
        /// 赋初始值
        //self.lastReloadVideoCount = videos.count
        view.addSubview(collection)
        if #available(iOS 11.0, *) {
            collection.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        view.addSubview(leftBackButton)
        view.addSubview(searchBtn)
        layoutPageSubviews()
       // collection.scrollToItem(at: IndexPath.init(item: currentIndex, section: 0), at: .top, animated: false)
    }
    
    @objc func backButtonClick() {
        navigationController?.popViewController(animated: false)
    }
    /// app进入后台
    @objc func applicationResignActivity(_ sender: NSNotification) {
        videoProgressReport()
    }
    
    @objc func searchBtnClick(_ sender: UIButton) {
        if let vcs = navigationController?.viewControllers {
            let allPlayVcs = vcs.filter { (vc) -> Bool in
                return vc.isKind(of: SearchMainController.self)
            }
            if allPlayVcs.count > 0 {
                navigationController?.viewControllers.removeAll(where: { (vc) -> Bool in
                    return vc.isKind(of: SeriesVideosController.self)
                })
            }
            let vc = SearchMainController()
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    ///用户操作的回调
    func addUserInfoViewModelCallBack() {
        userInfoViewModel.followAddOrCancelSuccessHandler = { [weak self] isAdd  in
            guard let strongSelf = self else {return}
            if strongSelf.videos.count > 0 {
                for video in strongSelf.videos {
                    if isAdd {
                        video.user?.is_attention = 1
                    } else {
                        video.user?.is_attention = 0
                    }
                }
                if let cell = strongSelf.collection.cellForItem(at: IndexPath.init(item: strongSelf.currentIndex, section: 0)) as? CLHomePlayCell {
                    cell.focusButton.setTitle("已关注", for: .normal)
                    cell.focusButton.backgroundColor = UIColor.lightGray
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.8, execute: {
                        cell.focusButton.setTitle("关注", for: .normal)
                        cell.focusButton.backgroundColor = ConstValue.kStypeColor
                        cell.focusButton.isHidden = isAdd
                    })
                }
            }
        }
        
        userInfoViewModel.followOrCancelFailureHandler = { (isAdd, msg) in
            XSAlert.show(type: .error, text: msg)
        }
    }

    
}
extension PresentPlayController {
    func cellActions(actionId: Int) {
        switch actionId {
        case 1:
            p_showDetails()
            break
        case 2:
            userInfoViewModel.loadAddFollowApi([UserAddFollowApi.kUserId: videoCurrent?.user?.code ?? ""])
            break
        case 3:
            // 会员 完整版
            customActionForPalyer(actionKeyId: 2)
            break
        case 4:
            if let link = videoCurrent?.recAd?.link, !link.isEmpty {
                goInnerLink(link)
            }
            break
        case 5:
            shareVideo()
            break
        case 6:
            /// 金币完整版
             customActionForPalyer(actionKeyId: 6)
            break
        case 7:
            if let link = videoCurrent?.countdown?.countdown_link, !link.isEmpty {
                goInnerLink(link)
            }
            break
        default:
            break
        }
    }
    func showBuyAlert(_ actionId: Int) {
        let btnTitle: String = actionId == 1 ? "非VIP\(videoCurrent?.coins ?? 0)钻石购买" : "VIP优惠价:\(videoCurrent?.vip_coins ?? 0)钻石购买"
        let alert = CoinsBuyAlert.init(frame: view.bounds, buttonTitle: btnTitle, vipMsg: "VIP优惠价:\(videoCurrent?.vip_coins ?? 0)钻石", normalMsg: "非VIP价:\(videoCurrent?.coins ?? 0)钻石", tipsMsg: "支持原创,付费给\(videoCurrent?.user?.nick ?? "")", titleMsg: "本内容需购买观看")
        alert.backgroundColor = UIColor(white: 0, alpha: 0.6)
        alert.showInWindow()
        alert.itemButtonClick = { [weak self] in
            self?.customActionForPalyer(actionKeyId: 6)
        }
    }
    /// user click
     func p_showDetails() {
        if videos.count == 0 { return }
         goUserCenter(videoCurrent?.user)
    }
    /// 点赞
     func addFavorOrNot(_ isFavor: Bool) {
        let indexPath = IndexPath(row: self.currentIndex, section: 0)
        let likeCount = videoCurrent?.like ?? 0
        var favorCount = 0
        if isFavor {  // 不是点赞
            favorCount = likeCount + 1
        } else {
            favorCount = likeCount > 0 ? likeCount - 1 : 0
        }
        videoCurrent?.like = favorCount
        videoCurrent?.is_like = isFavor ? 1 : 0
        if let cell = collection.cellForItem(at: indexPath) as? CLHomePlayCell {
            cell.setVideoModel(videoCurrent)
        }
        userInfoViewModel.addVideoFavor([UserFavorAddApi.kVideo_id: videoCurrent?.id ?? 0, UserFavorAddApi.kIslong: videoCurrent?.is_long ?? 0])
    }
    func shareVideo() {
        let shareVc = ShareContentController()
        navigationController?.pushViewController(shareVc, animated: true)
    }
    func reloadCurrentIndexFocusStatu(_ statu: Int) {
        if let cell = collection.cellForItem(at: IndexPath.init(item: currentIndex, section: 0)) as? CLHomePlayCell {
            cell.focusButton.isHidden = statu == 1
            videoCurrent?.user?.is_attention = statu
            videoCurrent?.is_attention = statu
            fixModelFollowStatu(statu, code: videoCurrent?.user?.code ?? "", datas: videos)
        }
    }
    func fixModelFollowStatu(_ statu: Int?, code: String, datas: [VideoNew]) {
        for model in datas {
            if model.user?.code == code {
                model.user?.is_attention = statu
                model.is_attention = statu
            }
        }
    }
    /// 视频进度上报参数
    func getProressReportParam() -> [String: Any] {
        var param = [String: Any]()
        param[VideoProgressReportApi.kVideo_id] = videoCurrent?.id
        param[VideoProgressReportApi.kIsLong] = videoCurrent?.is_long == 1 ? 1 : 0
        param[VideoProgressReportApi.kDuration] = currentPlayTime
        if let categorys = videoCurrent?.category, categorys.count > 0 {
            let attStr = NSMutableString()
            for i in 0 ..< categorys.count {
                let model = categorys[i]
                if i == categorys.count - 1{
                    attStr.append("\(model.id ?? model.type_id ?? 0)")
                } else {
                    attStr.append("\(model.id ?? model.type_id ?? 0),")
                }
            }
            param[VideoProgressReportApi.kType_Ids] = attStr as String
        }
        return param
    }
    /// 视频进度上传
    func videoProgressReport() {
        if let duration = videoCurrent?.duration, duration > 0 {
            if videoCurrent?.auth_error == nil && Float(currentPlayTime)/Float(duration) > 0.3 {
                AppInfo.videoProgressReport(getProressReportParam())
            }
        }
    }
    func goUserCenter(_ user: CLUserInfo?) {
        if let vcs = navigationController?.viewControllers {
            let allVcs = vcs.filter { (vc) -> Bool in
                return vc.isKind(of: UserMCenterController.self)
            }
            if allVcs.count > 0 {
                navigationController?.viewControllers.removeAll(where: { (vc) -> Bool in
                    return vc.isKind(of: UserMCenterController.self)
                })
            }
            let userCenter = UserMCenterController()
            userCenter.userCode = user?.code
            userCenter.followOrCancelBackHandler = { (focusStatu) in
                self.reloadCurrentIndexFocusStatu(focusStatu)
            }
            navigationController?.pushViewController(userCenter, animated: true)
        }
    }
    func goTypeKeyController(_ videoKey: SearchHotTips) {
        if let vcs = navigationController?.viewControllers {
            let allVcs = vcs.filter { (vc) -> Bool in
                return vc.isKind(of: TypeVideosController.self)
            }
            if allVcs.count > 0 {
                navigationController?.viewControllers.removeAll(where: { (detailVc) -> Bool in
                    return detailVc.isKind(of: TypeVideosController.self)
                })
            }
            let detail = TypeVideosController()
            detail.keyMode = videoKey
            navigationController?.pushViewController(detail, animated: true)
        }
    }
}
// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension PresentPlayController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return videos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CLHomePlayCell.cellId, for: indexPath) as! CLHomePlayCell
        cell.backgroundColor = UIColor.darkText
        let videoModel = videos[indexPath.row]
        if videos.count > indexPath.row {
            if let recAd = videoModel.recAd {
                cell.setAdModel(recAd)
                if let adv = recAd.play, !adv.isEmpty, let url = URL(string: adv) {
                    player.startPlay(url: url, in: cell.bgImage)
                }
            } else {
                cell.setVideoModel(videoModel)
                if indexPath.row == currentIndex && step == 1 {
                    configVideo(videoModel, cell: cell, indexPath: indexPath)
                    step = 0
                }
            }
        }
        cell.actionSingleHandler = { [weak self] actionId in
            self?.cellActions(actionId: actionId)
        }
        cell.videoFavorItemClick = { [weak self] (isFavor) in
            guard let strongSelf = self else { return }
            strongSelf.addFavorOrNot(isFavor)
        }
        cell.clickTypeKeyCellHandler = { [weak self] videoKey in
            self?.goTypeKeyController(videoKey)
        }
        cell.actionVipViewHandler = { [weak self] id in
            if id == 1 {
                self?.showBuyAlert(id)
            } else if id == 2 {
                self?.cellActions(actionId: 3)
            } else if id == 3 {
                if self?.videoCurrent?.auth_error?.key == 1001 {
                    self?.cellActions(actionId: 3)
                } else {
                    self?.showBuyAlert(id)
                }
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
    }
}


// MARK: - UICollectionViewDelegateFlowLayout
extension PresentPlayController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return UIScreen.main.bounds.size;
    }
}

// MARK: - play video
extension PresentPlayController {
    private func configVideo(_ videoModel: VideoNew, cell: CLHomePlayCell, indexPath: IndexPath) {
        self.videoCurrent = videoModel
        //先鉴权
        playVideo(video: videoModel, cell: cell, indexPath: indexPath)
    }
    private func resetVideoMode(_ video: VideoNew, _ cell: CLHomePlayCell) {
        videoCurrent?.smu = video.smu
        videoCurrent?.mu = video.mu
        videoCurrent?.is_free = video.is_free
        videoCurrent?.category = video.category
        videoCurrent?.play = video.play
        videoCurrent?.hot = video.hot
        videoCurrent?.is_free = video.is_free
        videoCurrent?.user = video.user
        videoCurrent?.is_attention = video.is_attention
        videoCurrent?.is_like = video.is_like
        videoCurrent?.like = video.like
        videoCurrent?.coins = video.coins
        videoCurrent?.vip_coins = video.vip_coins
        videoCurrent?.auth_error = video.auth_error
        videoCurrent?.countdown = video.countdown
        if !watchRecord {
            videoCurrent?.lastWatchDurration = nil
        } else {
            watchRecord = false
        }
        cell.setVideoModel(videoCurrent!)
    }
    private func playVideo(video: VideoNew, cell: CLHomePlayCell, indexPath: IndexPath) {
        videoViewModel.loadVideoAuthData(params: [VideoAuthApi.kVideo_id: video.id ?? 0], succeedHandler: { [weak self]  videoModel in
            guard let strongSelf = self else { return }
            strongSelf.resetVideoMode(videoModel, cell)
            if let _ = videoModel.auth_error { // 鉴权失败
                strongSelf.videoCurrent?.isAuthAccross = false
                strongSelf.playShortVideo(video: video, cell: cell)
                return
            }
            strongSelf.videoCurrent?.isAuthAccross = true
            strongSelf.playWithVideo(strongSelf.videoCurrent, cell)
        }) { [weak self] (errorMsg) in
            guard let strongSelf = self else { return }
            /// 接口失败，直接爆网络问题
            strongSelf.player.stopPlaying()
            strongSelf.showFailedView(.Failed, nil)
        }
    }
    private func playShortVideo(video: VideoNew?, cell: CLHomePlayCell) {
        if let urlshort = video?.smu, !urlshort.isEmpty {
            player.startPlay(url: URL(string: urlshort), in: cell.bgImage)
        } else {
            XSAlert.show(type: .error, text: "播放失败")
            player.stopPlaying()
        }
        coundownTips(cell)
    }
    private func playWithVideo(_ video: VideoNew?, _ cell: CLHomePlayCell) {
        if let urlStrM3u8 = video?.mu, !urlStrM3u8.isEmpty {
            guard let url = URL(string: urlStrM3u8) else {
                return
            }
            if let sinceTime = video?.lastWatchDurration {
                player.startPlay(url: url, in: cell.bgImage, since: Float(sinceTime))
            } else {
                player.startPlay(url: url, in: cell.bgImage)
            }
        }
        coundownTips(cell)
    }
    /// 新用户充值优惠提示
    private func coundownTips(_ cell: CLHomePlayCell) {
        tipsTimer.releaseTimer()
        guard let time = videoCurrent?.countdown?.countdown_time else { return }
        if time < 1 {
            cell.countDownlabel.attributedText = TextSpaceManager.getAttributeStringWithString("\(videoCurrent?.countdown?.countdown_intro ?? "")", lineSpace: 3, .center)
            return
        }
        guard let timeDisplay = videoCurrent?.countdown?.countdown_display, timeDisplay == 1 else {
            cell.countDownlabel.attributedText = TextSpaceManager.getAttributeStringWithString("\(videoCurrent?.countdown?.countdown_intro ?? "")", lineSpace: 3, .center)
            return
        }
        cell.countDownlabel.attributedText = TextSpaceManager.getAttributeStringWithString("\(videoCurrent?.countdown?.countdown_intro ?? "") \(LGConfig.timeDuration(duration: time))", lineSpace: 3, .center)
        tipsTimer.timer = Timer.every(1.0.seconds) { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.videoCurrent?.countdown?.countdown_time = strongSelf.videoCurrent!.countdown!.countdown_time! - 1
            if let time = strongSelf.videoCurrent?.countdown?.countdown_time, time > 0 {
                cell.countDownlabel.attributedText = TextSpaceManager.getAttributeStringWithString("\(strongSelf.videoCurrent?.countdown?.countdown_intro ?? "") \(LGConfig.timeDuration(duration: time))", lineSpace: 3, .center)
            } else {
                strongSelf.tipsTimer.releaseTimer()
                cell.countDownlabel.isHidden = true
                cell.countDownlabel.tag = -1
            }
        }
        RunLoop.current.add(tipsTimer.timer!, forMode: .common)
    }
    func customActionForPalyer(actionKeyId: Int) {
        if actionKeyId == 1 {
           let indexPath = IndexPath(row: currentIndex, section: 0)
            if let cell = collection.cellForItem(at: indexPath) as? CLHomePlayCell {
                player.startPlay(url: player.playUrl, in: cell.bgImage)
            }
        } else if actionKeyId == 2 {
            // 跳转到
            let vipVC = VipCardsController()
            navigationController?.pushViewController(vipVC, animated: true)
        } else if actionKeyId == 6 { //  金币购买
            XSProgressHUD.showCycleProgress(msg: "支付中...", onView: view, animated: false)
            let videoModel = videos[currentIndex]
            userInfoViewModel.coinsBuyVideo(params: [UseBuyVideoApi.kVideoId: videoModel.id ?? 0] , succeedHandler: { [weak self] mu in
                guard let strongSelf = self else { return }
                XSProgressHUD.hide(for: strongSelf.view, animated: true)
                XSAlert.show(type: .success, text: "恭喜您支付成功")
                if let userCoins = UserModel.share().user?.coins, let vCoins = strongSelf.videoCurrent?.coins, userCoins >= vCoins {
                    UserModel.share().user?.coins = userCoins - vCoins
                    NotificationCenter.default.post(name: Notification.Name.kUserBasicalInformationChanged, object: nil)
                }
                strongSelf.videoCurrent?.auth_error = nil
                strongSelf.videoCurrent?.mu = mu
                if let cell = strongSelf.collection.cellForItem(at: IndexPath(row: strongSelf.currentIndex, section: 0)) as? CLHomePlayCell {
                    cell.setVideoModel(strongSelf.videoCurrent)
                    strongSelf.playWithVideo(strongSelf.videoCurrent, cell)
                }
            }) { [weak self] (failMsg) in
                guard let strongSelf = self else { return }
                strongSelf.showCoinBuyAlert(failMsg)
                XSProgressHUD.hide(for: strongSelf.view, animated: true)
            }
        }
    }
    func showCoinBuyAlert(_ msg: String) {
        let failedModel = ConvertCardAlertModel(title: nil, msgInfo: msg, success: false)
        let controller = AlertManagerController(cardModel: failedModel)
        controller.modalPresentationStyle = .overCurrentContext
        controller.view.backgroundColor = UIColor(white: 0.0, alpha: 0.7)
        controller.touchDissMiss = true
        present(controller, animated: false, completion: nil)
        controller.commitActionHandler = {
            let vipVC = CoinsCardsController()
            vipVC.isCoins = true
            self.navigationController?.pushViewController(vipVC, animated: true)
        }
    }
}

// MARK: - UIScrollViewDelegate
extension PresentPlayController: UIScrollViewDelegate {
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        DispatchQueue.main.async {
            /// 禁用手势
            let translatedPoint = scrollView.panGestureRecognizer.translation(in: scrollView)
            scrollView.panGestureRecognizer.isEnabled = false
            
            if translatedPoint.y < -50 && self.currentIndex < (self.videos.count - 1) {
                /// 上滑
                self.currentIndex += 1
            }
            if translatedPoint.y > 50 && self.currentIndex > 0 {
                /// 下滑
                self.currentIndex -= 1
            }
            
            if self.currentIndex == self.lastReloadVideoCount - 1 && self.videos.count > self.lastReloadVideoCount {
                self.collection.reloadData()
                self.lastReloadVideoCount = self.videos.count
                DLog("倒数第一条数据时 -- 刷新 ")
            }
            let indexPath = IndexPath(row: self.currentIndex, section: 0)
            UIView.animate(withDuration: 0.15, delay: 0.0, options: .curveEaseOut, animations: {
                if self.videos.count > indexPath.row {
                    self.collection.scrollToItem(at: indexPath, at: .top, animated: false)
                } 
            }, completion: { finished in
                scrollView.panGestureRecognizer.isEnabled = true
                self.videoProgressReport()
                if let cell = self.collection.cellForItem(at: indexPath) as? CLHomePlayCell {
                    if self.currentPlayIndex != self.currentIndex { // 上下滑动
                        self.player.removeFromSuperview()
                        if let ad = self.videos[self.currentIndex].recAd {
                            self.videoCurrent = self.videos[self.currentIndex]
                            if let adv = ad.play, !adv.isEmpty, let url = URL(string: adv) {
                                self.player.startPlay(url: url, in: cell.bgImage)
                            }
                        } else {
                            self.configVideo(self.videos[indexPath.row], cell: cell, indexPath: indexPath)
                        }
                        self.currentPlayIndex = self.currentIndex
                    }
                    if self.lastPageCount > 0 {
                        if self.currentIndex >= self.videos.count - 3 {
                            DLog("给您补给数据。。， ")
                            self.loadNextPage()
                            // 这里先不刷新
                        }
                    }
                }
            })
        }
    }
}

// MARK: - PlayerViewDelegate
extension PresentPlayController: PlayerViewDelegate {
    func playerProgress(progress: Float, currentPlayTime: Float) {
        if videoCurrent?.auth_error == nil {
            self.currentPlayTime = Int(currentPlayTime)
        }
    }
    func customActionsBeforePlay() {
        loadedFailedView.removeFromSuperview()
    }
    func currentUrlPlayToEnd(url: URL?, player: PlayerView) {
        player.replay()
    }
    func playVideoFailed(url: URL?, player: PlayerView) {
        print("playVideoFailed")
        if videoCurrent?.recAd == nil {
            showFailedView(.Failed, nil)
        }
    }
    func doubleTapGestureAt(point: CGPoint) {
        print("doubleTapGestureAction")
        let indexPath = IndexPath(row: self.currentIndex, section: 0)
        if let cell = self.collection.cellForItem(at: indexPath) as? CLHomePlayCell {
            if cell.infoView.isHidden {
                cell.setUIHidenOrNot(false)
            } else {
                cell.setUIHidenOrNot(true)
            }
        }
//        ZanAnimation.showAnimation(point: point, baseView: self.view,size: 30)
//        ZanAnimation.showAnimation(point: CGPoint(x: point.x + 10, y: point.y - 70), baseView: self.view, size: 50)
//        let isFavor = videoCurrent?.is_like == 1
//        if !isFavor {  // 没有点赞
//            let indexPath = IndexPath(row: self.currentIndex, section: 0)
//            userInfoViewModel.addVideoFavor([UserFavorAddApi.kVideo_id: videoCurrent?.id ?? 0, UserFavorAddApi.kIslong: videoCurrent?.is_long ?? 0])
//            let appraiseCount = videoCurrent?.is_like ?? 0
//            let favorCount = appraiseCount + 1
//            videoCurrent?.like = favorCount
//            videoCurrent?.is_like = 1
//            if let cell = self.collection.cellForItem(at: indexPath) as? CLHomePlayCell {
//                cell.setVideoModel(videoCurrent!)
//            }
//        }
    }
    func longpressGestureAt(point: CGPoint) {
        DLog("longpressGestureAt(point: CGPoint)")
        if videoCurrent?.auth_error != nil { // 鉴权失败
            return
        }
        if player.player != nil {
            let playerVc = FullScreenPlayController()
            playerVc.player = player.player!
            playerVc.modalPresentationStyle = .fullScreen
            present(playerVc, animated: false, completion: nil)
        }
    }
    func dragingProgress(isDraging: Bool, to progress: Float?) {
        collection.panGestureRecognizer.isEnabled = !isDraging
        let indexPath = IndexPath(row: self.currentIndex, section: 0)
        if let cell = self.collection.cellForItem(at: indexPath) as? CLHomePlayCell {
            cell.setUIHidenOrNot(isDraging)
        }
    }
    
}
// MARK: - 播放器权限提示显示
extension PresentPlayController {
    
    func showFailedView(_ showType: LoadFailedViewStyle, _ errorDes: String?) {
        if !player.subviews.contains(loadedFailedView) {
            player.addSubview(loadedFailedView)
        }
        /// 重新连接
        loadedFailedView.retryButtonClickBlock = { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.customActionForPalyer(actionKeyId: 1)
        }
        ///  去买会员
        loadedFailedView.goChrageButtonClickBlock = { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.customActionForPalyer(actionKeyId: 2)
        }
        /// 去分享
        loadedFailedView.goShareButtonClickBlock = { [weak self]  in
            guard let strongSelf = self else { return }
            strongSelf.customActionForPalyer(actionKeyId: 3)
        }
        /// 购买视频或者充值金币
        loadedFailedView.goPayButtonClickBlock = { [weak self]  (canPay) in
            guard let strongSelf = self else { return }
            strongSelf.customActionForPalyer(actionKeyId: 4)
        }
        if showType == .NoPermission {
            loadedFailedView.setType(.NoPermission, errorDes)
        } else {
            loadedFailedView.setType(showType)
        }
    }
}

// MARK: - Layout
private extension PresentPlayController {
    
    func layoutPageSubviews() {
        layoutLeftBackButton()
        layoutCollection()
    }
    
    func layoutCollection() {
        collection.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.bottom.equalToSuperview()
        }
    }
    func layoutLeftBackButton() {
        leftBackButton.snp.makeConstraints { (make) in
            make.leading.equalTo(13)
            make.top.equalTo(ConstValue.kStatusBarHeight + 10)
            make.width.height.equalTo(30)
        }
        searchBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.centerY.equalTo(leftBackButton)
            make.width.height.equalTo(18)
        }
    }
}

