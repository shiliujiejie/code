import JXPagingView
import JXSegmentedView
import NicooNetwork

class ModuleMoreController: BasePagerViewController {
    
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.titleLabel.text = nil
        bar.backgroundColor = .clear
        bar.backButton.isHidden = false
        bar.titleLabel.isHidden = false
        bar.lineView.isHidden = true
        bar.navBackBlack = false
        bar.delegate = self
        return bar
    }()
    private lazy var searchBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(getImage("communitySeachIcon"), for: .normal)
        button.addTarget(self, action: #selector(searchBtnClick(_:)), for: .touchUpInside)
        return button
    }()
    private lazy var seletedBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(getImage("selectedvideo"), for: .normal)
        button.addTarget(self, action: #selector(searchBtnClick(_:)), for: .touchUpInside)
        return button
    }()
    lazy var topView: ModuleMoreTopView = {
        let v = ModuleMoreTopView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: screenWidth * 130/375 + 77))
        v.backgroundColor = .clear
        return v
    }()
    let selectedLabel:UILabel = {
        let lab = UILabel()
        lab.text = "综合"
        lab.textColor = .white
        lab.textAlignment = .right
        lab.font = UIFont.systemFont(ofSize: 14)
        return lab
    }()
    let arrow: UIImageView = {
        let ar = UIImageView(image: getImage("downArrow"))
        ar.isUserInteractionEnabled = true
        return ar
    }()
    let selectedView: UIView = {
        let v = UIView()
        return v
    }()
    lazy var cateButton: UIButton = {
        let v = UIButton(type: .custom)
        v.addTarget(self, action: #selector(selectedAction(_:)), for: .touchUpInside)
        return v
    }()
    var popover: Popover = {
        let popoverOptions: [PopoverOption] = [
            .type(.auto),
            .blackOverlayColor(UIColor(white: 0.0, alpha: 0.6))
        ]
        let p = Popover(options: popoverOptions)
        return p
    }()
    private lazy var infoApi: TipsTypesDetailApi =  {
        let api = TipsTypesDetailApi()
        api.isModule = true
        api.delegate = self
        api.paramSource = self
        return api
    }()
    let list1 = SeriesVideosController()
    let list2 = SeriesVideosController()
    let list3 = SeriesVideosController()
    
    var isBack: Bool = false
    /// 文字高度
    var topDesHeight: CGFloat = 0
    ///
    var currentSegIndex: Int?
    
    var detailModel = ModuleDetailModel()
    let selectedTexts = ["综合","播放最多","收藏最多","最新视频"]
    var selectedIndex: Int = 0
    
    
    var backLaunchAdViewController:(() ->Void)?
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        pagingView.mainTableView.backgroundColor = UIColor.clear
        //导航栏隐藏就是设置pinSectionHeaderVerticalOffset属性即可，数值越大越往下沉
        pagingView.pinSectionHeaderVerticalOffset = Int(safeAreaTopHeight)

        loadData()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if isBack {
            navBar.titleLabel.text = detailModel.title ?? ""
            navBar.backgroundColor = ConstValue.kVcViewColor
            pagingView.reloadData()
        }
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        if let vcs = navigationController?.viewControllers, vcs.contains(self) {
            DLog("viewDidDisappear --- Push or Present")
        } else {
            DLog("viewDidDisappear --- Pop or Dimiss")
            backLaunchAdViewController?()
        }
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        pagingView.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight)
    }
    override func pagingView(_ pagingView: JXPagingView, initListAtIndex index: Int) -> JXPagingViewListViewDelegate {
        if index == 0 {
            list1.isLong = false
            list1.segmentIndex = 0
            list1.moduleModel = self.detailModel
            list1.pageType = .moduleMore
            list1.vcShowCallBack = { [weak self] in
                self?.currentSegIndex = 0
            }
            return list1
        } else if index == 1 {
            list2.isLong = true
            list2.segmentIndex = 1
            list2.moduleModel = self.detailModel
            list2.pageType = .moduleMore
            list2.vcShowCallBack = { [weak self] in
                self?.currentSegIndex = 1
            }
            return list2
        } else{
            list3.isLong = false
            list3.segmentIndex = 2
            list3.moduleModel = self.detailModel
            list3.pageType = .moduleMore
            list3.vcShowCallBack = { [weak self] in
                self?.currentSegIndex = 2
            }
            return list3
        }
    }
    override func preferredPagingView() -> JXPagingView {
        return JXPagingListRefreshView(delegate: self)
    }
    override func tableHeaderViewHeight(in pagingView: JXPagingView) -> Int {
        return Int(screenWidth * 130/375) + 20 +  Int(topDesHeight)
    }
    override func tableHeaderView(in pagingView: JXPagingView) -> UIView {
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: screenWidth * 130/375 + 20))
        headerView.addSubview(topView)
        layoutTopTipView()
        return headerView
    }
    func mainTableViewDidScroll(_ scrollView: UIScrollView) {
        let offsetY = scrollView.contentOffset.y
        if offsetY >= 60 {
            navBar.titleLabel.isHidden = false
            navBar.titleLabel.text = "\(detailModel.title ?? "")"
            navBar.backgroundColor = ConstValue.kVcViewColor
        } else {
            navBar.titleLabel.isHidden = true
            navBar.backgroundColor = UIColor.clear
            navBar.titleLabel.text = nil
        }
    }
    
    func loadData() {
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: false)
        _ = infoApi.loadData()
    }
    func setUpInfo() {
        let size = topView.desLab.textSize(text: (detailModel.intro != nil && !detailModel.intro!.isEmpty) ? detailModel.intro! : "暂未添加详细介绍～", font: UIFont.systemFont(ofSize: 13), maxSize: CGSize(width: screenWidth-30, height: 500), 6)
        topDesHeight = size.height
        topView.desLab.attributedText = TextSpaceManager.getAttributeStringWithString((detailModel.intro != nil && !detailModel.intro!.isEmpty) ? detailModel.intro! : "暂未添加详细介绍～", lineSpace: 6)
        topView.titleLab.text = detailModel.title
        topView.bgImg.kfSetHorizontalImageWithUrl(detailModel.cover)
        
        titles = ["全部", "只看长视频","只看短视频"]
        dataSource.isItemSpacingAverageEnabled = false
        dataSource.titleNormalFont = UIFont.systemFont(ofSize: 14)
        dataSource.titleSelectedZoomScale = 1.1
        dataSource.titles = titles
        dataSource.itemSpacing = 25
        let indicator = JXSegmentedIndicatorBackgroundView()
        indicator.indicatorColor = ConstValue.kStypeColor
        indicator.isIndicatorConvertToItemFrameEnabled = true
        indicator.indicatorCornerRadius = 4
        indicator.indicatorHeight = 28
        segmentedView.indicators = [indicator]
        
        segmentedView.reloadData()
        pagingView.reloadData()
        selectedView.addSubview(arrow)
        selectedView.addSubview(selectedLabel)
        segmentedView.addSubview(selectedView)
        arrow.snp.makeConstraints { (make) in
            make.trailing.equalTo(-5)
            make.centerY.equalToSuperview()
            make.height.width.equalTo(5)
        }
        selectedLabel.snp.makeConstraints { (make) in
            make.trailing.equalTo(arrow.snp.leading).offset(-3)
            make.centerY.equalToSuperview()
        }
        selectedView.snp.makeConstraints { (make) in
            make.trailing.equalTo(-10)
            make.centerY.equalToSuperview()
            make.width.equalTo(50)
            make.height.equalTo(40)
        }
        selectedView.addSubview(cateButton)
        cateButton.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        navBar.navBarView.addSubview(seletedBtn)
        navBar.navBarView.addSubview(searchBtn)
        view.addSubview(navBar)
        layoutNavBar()
    }
    @objc func searchBtnClick(_ sender: UIButton) {
        if sender == searchBtn {
            if let vcs = navigationController?.viewControllers {
                let allPlayVcs = vcs.filter { (vc) -> Bool in
                    return vc.isKind(of: SearchMainController.self)
                }
                if allPlayVcs.count > 0 {
                    navigationController?.viewControllers.removeAll(where: { (vc) -> Bool in
                        return vc.isKind(of: SearchMainController.self)
                    })
                }
                let vc = SearchMainController()
                navigationController?.pushViewController(vc, animated: true)
            }
        } else if sender == seletedBtn {
            if let vcs = navigationController?.viewControllers {
                let allPlayVcs = vcs.filter { (vc) -> Bool in
                    return vc.isKind(of: TypesCategrayController.self)
                }
                if allPlayVcs.count > 0 {
                    navigationController?.viewControllers.removeAll(where: { (vc) -> Bool in
                        return vc.isKind(of: TypesCategrayController.self)
                    })
                }
                let vc = TypesCategrayController()
                navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
    @objc func selectedAction(_ sender: UIButton) {
        let tableView = UITableView(frame: CGRect(x: 0, y: 10, width: 120, height: 160))
        tableView.delegate = self
        tableView.dataSource = self
        tableView.isScrollEnabled = false
        popover.show(tableView, fromView: cateButton)
    }
}


extension ModuleMoreController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.popover.dismiss()
        selectedIndex = indexPath.row
        selectedLabel.text = selectedTexts[selectedIndex]
        if selectedIndex == 0 {
            list1.orderKey = nil
            list2.orderKey = nil
            list3.orderKey = nil
        } else if selectedIndex == 1 {
            list1.orderKey = SearchVideoApi.kPlayCount
            list2.orderKey = SearchVideoApi.kPlayCount
            list3.orderKey = SearchVideoApi.kPlayCount
        } else if selectedIndex == 2 {
            list1.orderKey = SearchVideoApi.kOrder_keyLike
            list2.orderKey = SearchVideoApi.kOrder_keyLike
            list3.orderKey = SearchVideoApi.kOrder_keyLike
        } else if selectedIndex == 3 {
            list1.orderKey = SearchVideoApi.kOrder_keyOnline_at
            list2.orderKey = SearchVideoApi.kOrder_keyOnline_at
            list3.orderKey = SearchVideoApi.kOrder_keyOnline_at
        }
        switch currentSegIndex {
        case 0:
            list1.loadData()
            break
        case 1:
            list2.loadData()
            break
        case 2:
            list3.loadData()
            break
        default:
            break
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return selectedTexts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.textLabel?.text = self.selectedTexts[indexPath.row]
        cell.textLabel?.textAlignment = .center
        cell.textLabel?.font = UIFont.boldSystemFont(ofSize: 12)
        if selectedIndex == indexPath.row {
            cell.textLabel?.textColor = ConstValue.kStypeColor
        } else {
            cell.textLabel?.textColor = .darkText
        }
        return cell
    }
}

// MARK: - CLNavigationBarDelegate
extension ModuleMoreController:  CLNavigationBarDelegate  {
    
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}

extension ModuleMoreController {
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalToSuperview()
            make.height.equalTo(safeAreaTopHeight)
        }
        seletedBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-18)
            make.centerY.equalToSuperview()
            make.width.equalTo(18)
            make.height.equalTo(18)
        }
        searchBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(seletedBtn.snp.leading).offset(-15)
            make.centerY.equalToSuperview()
            make.width.equalTo(18)
            make.height.equalTo(18)
        }
    }
    func layoutTopTipView() {
        topView.snp.makeConstraints { (make) in
            make.top.equalTo(0)
            make.leading.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension ModuleMoreController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is TipsTypesDetailApi {
            return [TipsTypesDetailApi.kTypeId: detailModel.id ?? 0]
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is TipsTypesDetailApi {
            if let detailModel = manager.fetchJSONData(SearchReformer()) as? ModuleDetailModel {
                self.detailModel = detailModel
                setUpInfo()
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        if manager is TipsTypesDetailApi {
            XSAlert.show(type: .text, text: manager.errorMessage)
        }
    }
}
