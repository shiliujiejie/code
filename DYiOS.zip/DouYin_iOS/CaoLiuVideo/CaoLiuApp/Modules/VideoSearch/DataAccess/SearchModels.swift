
import Foundation

struct SearchLikeKey: Codable {
    var id: Int?
    var title: String?
}

///搜索用户列表
struct SearchUserListModel: Codable {
    var current_page: Int?
    var data: [CLUserInfo]?
    var total: Int?
}

//struct SearchUserModel: Codable {
//    var id: Int?
//    var name: String?
//    var nikename: String?
//    var mobile: String?
//    var cover_path: String?
//    var created_at: String?
//    var _realation: FollowOrCancelModel?
//}
struct SearchHotTipListModel: Codable {
    var current_page: Int?
    var data: [SearchHotTips]?
    var total: Int?
}
struct SearchHotTips: Codable {
    var id: Int? // id 和 type_id 是一样的， 自己这里叫ID， 别人那里叫 type_id
    var intro: String?
    var cover: [String]?
    var join: Int?  // 上传 被 添加数
    var play: Int?  // 视频备播放量
    var is_like: Int?
    /// 视频标签
    var title: String?
    var type_id: Int?
    var video_count: Int?
    
    /// 搜索关键词
    var keyword: String?
    var mcount: Int?
    var selected: Bool? = false
}

class ModuleDetailModel: Codable {
    var id: Int?
    var title: String?
    var intro: String?
    var cover: String?
}

class AchorModel: Codable {
    var id: Int?
    var title: String?
    var member: [CLUserInfo]?
}


class SearchMainModel: Codable {
    var keyword: [SearchHotTips]?
    var hot: [VideoNew]?
    var tag: [SearchChannel]?
}

class SearchChannel: Codable {
    var id: Int?
    var title: String?
    var more_link: String?
    var video_list: [VideoNew]?
}
