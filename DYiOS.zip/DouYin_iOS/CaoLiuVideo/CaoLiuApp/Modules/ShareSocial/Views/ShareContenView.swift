
import UIKit

class ShareContenView: UIView {

    let textView: InviteTexts = {
        let v = InviteTexts.init(frame: CGRect.zero)
        return v
    }()
    private let customLayout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = ShareContentItemCell.itemSize
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 10
        layout.sectionInset = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        return layout
    }()
    private lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect.zero, collectionViewLayout: customLayout)
        collection.backgroundColor = UIColor.clear
        collection.showsHorizontalScrollIndicator = false
        collection.delegate = self
        collection.dataSource = self
        collection.register(ShareContentItemCell.classForCoder(), forCellWithReuseIdentifier: ShareContentItemCell.cellId)
        collection.register(UINib(nibName: ShareImageItemCell.cellId, bundle: Bundle.main), forCellWithReuseIdentifier: ShareImageItemCell.cellId)
        return collection
    }()
    private lazy var copyButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("復制鏈接", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        button.backgroundColor =  UIColor(r: 0, g: 123, b: 255)
        button.layer.cornerRadius = 20
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return button
    }()
    private lazy var saveButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("保存圖片", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        button.backgroundColor =  UIColor(r: 0, g: 123, b: 255)
        button.layer.cornerRadius = 20
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return button
    }()
    var itemClickHandler:((_ index: Int)->Void)?
    var closebtnClickHadnler:(()->Void)?
    
    var shareModels = [ShareTypeItemModel]()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.white
        addSubview(copyButton)
        addSubview(saveButton)
        addSubview(collectionView)
        addSubview(textView)
     
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    @objc private func buttonClick(_ sender: UIButton) {
       if sender == copyButton {
            UIPasteboard.general.string = String(format: "%@", ShareContentItemCell.getDownLoadUrl())
            XSAlert.show(type: .success, text: "复制成功！")
        } else if sender == saveButton {
            itemClickHandler?(1)
        }
    }
    
    func setShareModels(_ models: [ShareTypeItemModel]) {
        shareModels = models
        collectionView.reloadData()
    }
    
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension ShareContenView: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return shareModels.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
         let model = shareModels[indexPath.item]
        if model.type == .picture {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShareImageItemCell.cellId, for: indexPath) as! ShareImageItemCell
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShareContentItemCell.cellId, for: indexPath) as! ShareContentItemCell
            cell.setShareTypeModel(model)
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        itemClickHandler?(indexPath.item)
    }
    
}

// MARK: - Layout
private extension ShareContenView {
    func layoutPageSubviews() {
        layoutCopyButton()
        layoutSaveButton()
        layoutCollection()
    }
    func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.bottom.equalTo(copyButton.snp.top).offset(-22)
            make.height.equalTo((screenWidth-30)*2/3 + 20)
        }
        textView.snp.makeConstraints { (make) in
            make.bottom.equalTo(collectionView.snp.top).offset(-10)
            make.top.leading.trailing.equalToSuperview()
        }
    }
    func layoutCopyButton() {
        copyButton.snp.makeConstraints { (make) in
            make.bottom.equalTo(UIDevice.current.isiPhoneXSeriesDevices() ? -54 : -20)
            make.leading.equalTo(20)
            make.trailing.equalTo(self.snp.centerX).offset(-12)
            make.height.equalTo(40)
        }
    }
    func layoutSaveButton() {
        saveButton.snp.makeConstraints { (make) in
            make.trailing.equalTo(-20)
            make.leading.equalTo(self.snp.centerX).offset(12)
            make.centerY.equalTo(copyButton)
            make.height.equalTo(40)
        }
    }
    
}

class InviteTexts: UIView {
    
    let shareInview: ShareInView = {
        let v = ShareInView(frame: .zero)
        return v
    }()
    let iLabel: UILabel = {
        let l = UILabel()
        l.font = UIFont.boldSystemFont(ofSize: 21)
        l.textColor = .white
        return l
    }()
    let tLabel: UILabel = {
        let l = UILabel()
        l.font = UIFont.boldSystemFont(ofSize: 13)
        l.textColor = .white
        l.numberOfLines = 0
        return l
    }()
    let sLabel: UILabel = {
        let l = UILabel()
        l.font = UIFont.boldSystemFont(ofSize: 21)
        l.textColor = ConstValue.kStypeColor
        return l
    }()
    let cLabel: UILabel = {
        let l = UILabel()
        l.font = UIFont.boldSystemFont(ofSize: 21)
        l.textColor = .white
        return l
    }()
    let dLabel: UILabel = {
        let l = UILabel()
        l.font = UIFont.boldSystemFont(ofSize: 21)
        l.textColor = .white
        return l
    }()
    let pLabel: UILabel = {
        let l = UILabel()
        l.font = UIFont.boldSystemFont(ofSize: 21)
        l.textColor = .white
        return l
    }()
    let eLabel: UILabel = {
        let l = UILabel()
        l.font = UIFont.boldSystemFont(ofSize: 21)
        l.textColor = .white
        return l
    }()
    let vLabel: UILabel = {
        let l = UILabel()
        l.font = UIFont.boldSystemFont(ofSize: 21)
        l.textColor = .white
        return l
    }()
    lazy var setInviteCode: UIButton = {
        let btn = UIButton(type: .custom)
        btn.addTarget(self, action: #selector(invviteBtnClick), for: .touchUpInside)
        return btn
    }()
    var inviteAction:(() -> Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(pLabel)
        addSubview(dLabel)
        addSubview(sLabel)
        addSubview(cLabel)
        addSubview(tLabel)
        addSubview(iLabel)
        addSubview(eLabel)
        addSubview(vLabel)
        addSubview(shareInview)
        addSubview(setInviteCode)
        layoutSub()
        setUpUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setUpUI() {
        print("AppInfo.share().shareInfo?.ini_people = \((AppInfo.share().shareInfo?.ini_people ?? "").count)")
        pLabel.attributedText = TextSpaceManager.configColorString(allString: "", attribStr: "", ConstValue.kStypeColor, UIFont.boldSystemFont(ofSize: 21), 3)
        eLabel.attributedText = TextSpaceManager.configColorString(allString: "最高可获得\(AppInfo.share().shareInfo?.ini_cash_back ?? "")收益", attribStr: "\(AppInfo.share().shareInfo?.ini_cash_back ?? "")", ConstValue.kStypeColor, UIFont.boldSystemFont(ofSize: 21), 3)
        sLabel.text = nil
        tLabel.text = nil
        vLabel.text = UserModel.share().user?.is_vip == "y" ? "\(UserModel.share().user?.play_num_notice ?? "")" : "您还不是vip会员"
        cLabel.attributedText = TextSpaceManager.configColorString(allString: "邀请好友注册,TA充值,你赚钱", attribStr: "你赚钱", ConstValue.kStypeColor, UIFont.boldSystemFont(ofSize: 21), 3)
        let code = UserModel.share().user?.code
        iLabel.attributedText = TextSpaceManager.configColorString(allString: "我的邀请码: \(code ?? "")", attribStr: "\(code ?? "")", ConstValue.kStypeColor, UIFont.boldSystemFont(ofSize: 21), 3)
        shareInview.recPLabel.text = "推广业绩:\(UserModel.share().user?.bill ?? "0")"
        shareInview.recMLabel.text = "收益余额:\(UserModel.share().user?.balance ?? "0")"
        shareInview.shareWebinHandler = { [weak self] in
            self?.inviteAction?()
        }
    }
    @objc func invviteBtnClick() {
        inviteAction?()
    }
    
    func layoutSub() {
        let size = pLabel.textSize(text: "", font: UIFont.boldSystemFont(ofSize: 21), maxSize: CGSize(width: screenWidth-150, height: 60))
        let size1 = pLabel.textSize(text: "", font: UIFont.boldSystemFont(ofSize: 21), maxSize: CGSize(width: screenWidth-150, height: 60))
        let topMargin: CGFloat = UIDevice.current.isiPhoneXSeriesDevices() ? 15 : 5
        pLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(10)
            make.width.equalTo(size.width)
        }
        dLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(pLabel.snp.trailing)
            make.centerY.equalTo(pLabel)
            make.width.equalTo(size1.width)
        }
        sLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(dLabel.snp.trailing)
            make.centerY.equalTo(pLabel)
            make.trailing.equalTo(-10)
        }
        cLabel.snp.makeConstraints { make in
            make.leading.equalTo(pLabel)
            make.trailing.equalTo(-15)
            make.top.equalTo(pLabel.snp.bottom).offset(topMargin)
        }
        eLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(pLabel)
            make.top.equalTo(cLabel.snp.bottom).offset(topMargin)
            make.trailing.equalTo(-10)
        }
        vLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(pLabel)
            make.top.equalTo(eLabel.snp.bottom).offset(topMargin)
            make.trailing.equalTo(-10)
        }
        iLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(vLabel.snp.bottom).offset(topMargin)
        }
        shareInview.snp.makeConstraints { (make) in
            make.top.equalTo(iLabel.snp.bottom).offset(topMargin)
            make.height.equalTo(62)
            make.leading.equalTo(pLabel)
            make.trailing.equalTo(-15)
        }
        tLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-10)
            make.top.equalTo(shareInview.snp.bottom).offset(5)
        }
        setInviteCode.snp.makeConstraints { (make) in
            make.edges.equalTo(shareInview)
        }
    }
}
