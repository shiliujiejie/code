

import Foundation

struct SystemAlertModel: Codable {
    var title: String?
    var englishTitle: String?
    var msgInfo: String?
    var tipsMsg: String?
    var commitTitle: String?
    var isLinkType: Bool?  = false
}

struct ConvertCardAlertModel: Codable {
    var title: String?
    var msgInfo: String?
    var commitTitle: String?
    var success: Bool = false
}
