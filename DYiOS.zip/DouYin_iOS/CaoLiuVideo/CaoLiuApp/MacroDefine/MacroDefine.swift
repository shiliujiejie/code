
import Foundation
import UIKit

// MARK: - AppKey
public enum APPKeys {
    /// WeChat APPid
    public static let kWeChatAppId = ""
    /// 支付寶appid
    public static let kAlipayAppId = ""
    /// QQ appid
    public static let kQQAppId = ""
    /// 高的地图appid
    public static let kAMAppKey = ""
    /// 友盟
    public static let kUMengAppKey = ""
    public static let kUMengChannelId = ""
    /// sina
    public static let kSinaAppkey = ""
    public static let kSinaAppSecurity = ""
}

let screenWidth = UIScreen.main.bounds.size.width
let screenHeight = UIScreen.main.bounds.size.height
var statusBarHeight = UIApplication.shared.statusBarFrame.height
let screenFrame: CGRect = UIScreen.main.bounds
let safeAreaTopHeight: CGFloat = (screenHeight >= 812.0 && UIDevice.current.model == "iPhone" ? 88 : 64)
let safeAreaBottomHeight: CGFloat = (screenHeight >= 812.0 && UIDevice.current.model == "iPhone"  ? 34 : 0)

// MARK: - 全局静态常量
public struct ConstValue {
    
    /// 本appurlscheme
    public static let kAppScheme = "DYGame"
    
    // MARK: ------  屏幕各个模块的 宽高
    public static let kScreenHeight = UIScreen.main.bounds.size.height
    public static let kScreenWdith = UIScreen.main.bounds.size.width
    public static let kStatusBarHeight = UIApplication.shared.statusBarFrame.size.height
    public static let kNavigationBarHeight = CGFloat(44.0)
    
    // MARK: ------  App 主体颜色
    public static let kAppDefaultColor = UIColor(red: 73/255.0, green: 114/255.0, blue: 255/255.0, alpha: 1)
    public static let kAppDefaultTitleColor = UIColor(red: 21/255.0, green: 168/255.0, blue: 255/255.0, alpha: 1)
    public static let kAppSepLineColor = UIColor(red: 247/255.0, green: 246/255.0, blue: 248/255.0, alpha: 0.12)
    public static let kStypeColor = UIColor(red: 23/255.0, green:73/255.0, blue: 255/255.0, alpha: 1.0)
    /// vc 背景 23 73 255
    public static let kVcViewColor = UIColor(r: 15, g: 15, b: 29)
    
    public static let kVBgColor = UIColor(red: 25/255.0, green: 19/255.0, blue: 39/255.0, alpha: 1.0)
    
    /// 灰色， 分割线 bar
    public static let kViewLightColor = UIColor(red: 23/255.0, green: 23/255.0, blue: 38/255.0, alpha: 1.0)
    public static let kIconBgColor = UIColor(red: 60/255.0 , green: 60/255.0 , blue: 72/255.0, alpha: 0.90)
    public static let kCoverBgColor = UIColor(red: 30/255.0, green: 31/255.0, blue: 49/255.0, alpha: 1.0)
    
    ///TF时间提示
    public static let tfEndTime: String = "2021-07-20"
    
    /// 用户钥匙串唯一标识 key
    public static let kUserKeychainKey: String = {
        let filePath = Bundle.main.path(forResource: "Info", ofType: "plist")
        let dictionary = NSDictionary(contentsOfFile: filePath!)
        return dictionary!["CustomKeychainKey"] as! String
    }()
    static let appServerPath: String = {
        let filePath = Bundle.main.path(forResource: "Info", ofType: "plist")
        let dictionary = NSDictionary(contentsOfFile: filePath!)
        return dictionary!["CustomServerPath"] as! String
    }()
    public static let kAllEncryptKeys: NSDictionary = {
        let filePath = Bundle.main.path(forResource: "Info", ofType: "plist")
        let dictionary = NSDictionary(contentsOfFile: filePath!)
        return dictionary!["HandShakes"] as! NSDictionary
    }()
    public static let kCustomCodes: String = {
        let filePath = Bundle.main.path(forResource: "Info", ofType: "plist")
        let dictionary = NSDictionary(contentsOfFile: filePath!)
        return dictionary!["CustomCodePath"] as! String
    }()
    // MARK: ------ 接口数据加密开关 + 密钥
    /// 图片解密key
    public static let kImageDataDecryptKey: String = {
        let filePath = Bundle.main.path(forResource: "Info", ofType: "plist")
        let dictionary = NSDictionary(contentsOfFile: filePath!)
        return dictionary!["CustomImageDataDecryptKey"] as! String
    }()
    /// 接口数据加密解密Key
    // Ju7WDrEW7FDnggPU - v0-dev  // pq9YCg1#HdlYrGnm - v0 - Inhouse
    // TbYOSw9svntPMjYu - v1- dev   // RlxQyqdL61u3ltYp - v1 -InHouse
    public static let kApiEncryptKey: String = {
        let filePath = Bundle.main.path(forResource: "Info", ofType: "plist")
        let dictionary = NSDictionary(contentsOfFile: filePath!)
        return dictionary!["CustomApiEncryptKey"] as! String
    }()
    /// 是否是Dev 环境。
    public static let kIsDevServer: Bool = {
        let filePath = Bundle.main.path(forResource: "Info", ofType: "plist")
        let dictionary = NSDictionary(contentsOfFile: filePath!)
        let number = Int(dictionary!["CustomServerPathIsDev"] as! String)!
        return number == 1
    }()
    /// 是否是线上正式 环境。
    public static let kIsDebugOrReleaseServer: Bool = {
        let filePath = Bundle.main.path(forResource: "Info", ofType: "plist")
        let dictionary = NSDictionary(contentsOfFile: filePath!)
        let number = Int(dictionary!["CustomServerIsDebugOrRelease"] as! String)!
        return number == 1
    }()
    
    /// 是否对接口加密的  开关 （如果Dev需要加密，直接 return true）
    public static let kIsEncryptoApi: Bool = {
        return !ConstValue.kIsDevServer
    }()
    
    /// 版本控制
    public static let kApiVersion = "api/v3"
    /// 版本号
    public static let kAppVersion = "4.0.0"
    
    /// app 网页下载地址
    public static let kAppDownLoadLoadUrl = ""
  
    // MARK: ------  ServiceIdentifier （服务Key）
    /// app 数据接口服务名 （正式服）
    public static let kXSVideoService = "XSVideoService"
    
    // MARK: ------ 本地数据库名： db name
     /// 本地数据库名称
    public static let kXSVideoLocalDBName = "XSVideoLocal.db"
    
    // MARK: ------ 占位图片
    /// 竖屏展位图
    public static let kVerticalPHImage = LGConfig.getImage("placeholdV")
    /// 横屏展位图
    public static let kHorizontalPHImage = LGConfig.getImage("placeholdH")
    /// 默认头像
    public static let kDefaultHeader = LGConfig.getImage("defaultHeader")
    /// 圆形展位图
    public static let kTopicTypeHolder = UIImage(named: "starHeaderPh")
    
    // MARK: ------ Refresh Image + FontSize  Loading Image
    public static let kRefreshLableFont = UIFont.systemFont(ofSize: 12.0)
    public static let loadingImageNames =  ["loading1","loading2","loading3","loading4","loading5","loading6","loading7","loading8","loading9","loading10","loading11"]
    public static let refreshImageNames = ["refreshing_1","refreshing_2","refreshing_3","refreshing_4","refreshing_5","refreshing_6","refreshing_7","refreshing_8"]
    
}

// MARK: - Notificaiton name
public extension Notification.Name {
    /// 登錄成功的通知
    static let kUserLoginSuccessfully = Notification.Name("kUserLoginSuccessfully")
    /// 在切换定位信息后，需要某些地方收到通知，并重新获取数据
    static let kLocationHaveSwitchedNotification = Notification.Name("locationHaveSwitchedNotification")
    /// 账户信息变动的通知
    static let kUserBasicalInformationChanged = Notification.Name("kUserBasicalInformationChanged")
    /// 用户别踢下线或者token失效的回调
    static let kUserBeenLogOutNotification = Notification.Name("kUserBeenLogOutNotification")
    /// 分享信息更新
    static let kShareInfoUpdateNotification = Notification.Name("kShareInfoUpdateNotification")
    /// 上传本地视频狀態切换通知
    static let kUploadVideoStatuCallBackNotification = Notification.Name("kUploadVideoStatuCallBack")
    ///关注,和取消关注的通知
    static let kAttentionVideoUploaderNotification = Notification.Name("kAttentionVideoUploaderNotification")
    ///通知主页刷新关注狀態的通知
    static let kHomeRefreshAttentionStateNotification = Notification.Name("kHomeRefreshAttentionStateNotification")
    /// 分享控件消失
    static let kShareActivityDownNotification = Notification.Name("kShareActivityDownNotification")
    /// VIP模块TopBar颜色
    static let kVIPTopBarColotNotification = Notification.Name("VipTopBarColotNotification")
    /// main模块TopBar颜色
    static let kMainTopBarColotNotification = Notification.Name("MainTopBarColotNotification")
    ///是否查看对应消息
    static let kLookMessageNotification = Notification.Name("kShareActivityDownNotification")
    ///社区消息红点
    static let kMessageDotNotification = Notification.Name("kMessageDotNotification")
    ///余额发生改变
    static let kBalanceHasChangeNotification = Notification.Name("kBalanceHasChangeNotification")
    ///充值成功
    static let kHasInvestSuccessNotification = Notification.Name("kHasInvestSuccessNotification")
    ///游戏终止
    static let kGameTrankNotification = Notification.Name("kGameTrankNotification")
    /// 任务上传成功
    static let kUploadSuccessNotification = Notification.Name("UploadSuccessNotification")
}

// MARK: - UserDefaults Key
public extension UserDefaults {
    /// 本地存储vip类型key
    static let kVipCardLevel = "saveVipLevel"
    /// 手势密码是否开启
    static let kGestureLock = "GestureLock"
    /// 是否是首次进入APP
    static let kIsNotFirstIn = "IsFirstIn"
    ///  当日是否已经领过观影獎勵 bool 类型
    static let kSatisfyKey = "Satisfy"
    ///  当日累加观影时长 Int
    static let kWatchedTime = "TimeLogin"
    ///  最后一次观影的日期 String
    static let kLastTimeDay = "LastTimeDay"
    ///  [String: Any]类型  存放单日观影时长， 当日时间，
    static let kSatisfyInfo = "SatisfyInfo"
    ///  上一个用户的用户名
    static let kUserAcountPhone = "AcountPhone"
    /// 上一个 登錄的用户token
    static let kUserToken = "UserLastToken"
    ///  上一个登錄用户的邀請碼
    static let kUserInviteCode = "UserInviteCode"
    /// 搜索历史 (数组，长度为9)
    static let kSearchHistory = "SearchHistoryList"
    /// 是否保存idCard
    static let kSaveIDCard = "idCarSave"
    
    /// APP安装包地址
    static let kAppDownLoadUrl = "AppDownLoadUrl"
    /// App分享地址（）
    static let kAppShareUrl = "AppShareUrl"
    /// 是否提示过新用户獎勵
    static let knewUserSatisfiedShow = "IsSatisfyAlertShow"
    /// 广告数据是否有
    static let kAdDataUrl = "AdDataUrl"
    /// 广告跳转是否有
    static let kAdLinkUrl = "AdLinkUrl"
    /// 本地图片key
    static let kLocalImgsPath = "LocalImgsPath"
    /// 本地图片对应的版本号
    static let kAppVersion = "AppVersion"
    /// 本地上传任务
    static let kVideoTaskParams = "VideoPushTasksParams"
    ///崩溃日志
    static let kCrashLog = "CrashLog"
    /// 楼风本地草稿
    static let kLocalLFInfoParams = "LocalLFInfoParams"
    static let kLocalLFImageDatas = "LocalLFImageDatas"
}


// log
public func DLog(_ item: Any, _ file: String = #file,  _ line: Int = #line, _ function: String = #function) {
    #if DEBUG
    print(file + ":\(line):" + function, item)
    #endif
}


/// 全局错误提示
public struct XSAlertMessages {
    // MARK: - 全局
    public static let kConvertTasksOrNot = "是否兌換當前權益?"
    public static let kNetworkErrorMessage = "網絡開小差啦!"

    public static let kNotAvailTokenAlertMsg = "您的账号信息已更新，请重新打开app,登陆账号"
    public static let kUpdateAppAlertMsg = "軟件已更新了新版本，請您重新打開App"
    public static let kVideoPlayNetworkMessage = "當前為非wifi環境，播放將產生流量費用，是否繼續?"
    
}
