import UIKit
import CoreMotion
import AVFoundation
import SnapKit

class AppMainViewController: UIViewController {
    
  
    lazy var resetBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitle("Start", for: .normal)
        btn.setTitleColor(UIColor.white, for: .normal)
        btn.layer.cornerRadius = 2
        btn.layer.masksToBounds = true
        btn.backgroundColor = UIColor.colorGradientChangeWithSize(size: CGSize(width: screenWidth/10, height: screenWidth/10), direction: .upwardDiagonalLine, startColor: .blue, endColor: .black)
        btn.addTarget(self, action: #selector(reset), for: .touchUpInside)
        return btn
    }()
    var timeLabel: UILabel = {
        let lab = UILabel()
        lab.textAlignment = .center
        lab.text = "300"
        lab.font = UIFont.init(name: "DBLCDTempBlack", size: 120)
        lab.textColor = UIColor.colorGradientChangeWithSize(size: CGSize(width: screenWidth/10, height: screenWidth/10), direction: .upwardDiagonalLine, startColor: .blue, endColor: .black)
        return lab
    }()
    var tipLabel: UILabel = {
        let lab = UILabel()
        lab.textAlignment  = .center
        lab.numberOfLines = 0
        lab.textColor = UIColor.blue
        lab.font = UIFont.systemFont(ofSize: 15)
        return lab
    }()
    
    var isFocus = false
    
    var ticker: Ticker!
    
    var manager = CMMotionManager()
    
    var focusTime = 300 {
        didSet {
            timeLabel.text = "\(focusTime)"
        }
    }
    
    override func viewDidLoad() {
        view.backgroundColor = UIColor.colorGradientChangeWithSize(size: CGSize(width: 3, height: 3), direction: .upwardDiagonalLine, startColor: .white, endColor: .black)
        view.addSubview(timeLabel)
        view.addSubview(tipLabel)
        view.addSubview(resetBtn)
        
        timeLabel.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(view.snp.centerY).offset(-80)
        }
       
        tipLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(30)
            make.trailing.equalTo(-30)
            make.top.equalTo(timeLabel.snp.bottom).offset(30)
        }
        tipLabel.attributedText = TextSpaceManager.getAttributeStringWithString("Turn the phone screen down, and start", lineSpace: 5, .center)
        resetBtn.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(tipLabel.snp.bottom).offset(70)
            make.height.equalTo(55)
            make.width.equalTo(screenWidth - 150)
        }
        
        ticker = Ticker(action: self.tickerAction, interval: 1)
        manager.deviceMotionUpdateInterval = 1
    }
    @objc func reset() {
        focusTime = 300
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override func viewDidAppear(_ animated: Bool) {
        UIApplication.shared.isIdleTimerDisabled = true
        manager.startDeviceMotionUpdates()
        ticker.start()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        UIApplication.shared.isIdleTimerDisabled = false
        manager.stopDeviceMotionUpdates()
        ticker.stop()
    }
    
    func tickerAction() {
        if manager.deviceMotion?.gravity.z ?? 0 > 0.98 {
            UIDevice.current.isProximityMonitoringEnabled = true
            focusTime -= 1
            doHeartBeat()
            tipLabel.isHidden = true
            resetBtn.isHidden = true
            if focusTime == 0 {
                timeLabel.text = "End"
            }
        } else {
            UIDevice.current.isProximityMonitoringEnabled = false
            tipLabel.isHidden = false
            resetBtn.isHidden = false
        }
    }
    
    func doHeartBeat() {
        Thread {
            if self.focusTime % 60 == 0 {
                AudioServicesPlaySystemSound(1521)
            } else {
                AudioServicesPlaySystemSound(1519)
            }
        }.start()
    }
}

