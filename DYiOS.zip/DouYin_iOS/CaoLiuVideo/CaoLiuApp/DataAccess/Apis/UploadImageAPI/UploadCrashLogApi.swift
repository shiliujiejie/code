

import UIKit
import NicooNetwork
class UploadCrashLogApi: XSVideoBaseAPI  {
    static let kUa = "ua"
    static let kError_message = "message"
    static let kDevice_code = "device_no"
    static let kVersion = "version"
    static let kPlatform = "device_type"
    static let kCode  = "user_id"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/crash/log"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String : Any]?) -> [String : Any]? {
        return super.reform(params)
    }
}


