//
//  AppVersionInfo.swift
//  XSVideo
//
//  Created by pro5 on 2019/1/5.
//  Copyright © 2019年 pro5. All rights reserved.
//

import Foundation


/// 是否强制更新
enum ForceUpdate: Int, Codable {
    case normalUpdate = 0
    case forceUpdate = 1
    
    var isForce: Bool {
        switch self {
        case .forceUpdate:
            return true
        case .normalUpdate:
            return false
        }
    }
}
/// 设备检测model

struct DeviceCheckModel: Codable {
    var isOpen: Int?
    var probability: Int?
    var isChannelOpen: Int?
    var channelProbability: Int?
    var dyCodes: [DevideCodeModel]?
}

struct DevideCodeModel: Codable {
    var id: String?
    var code: String?
}

/// APP检查更新
struct AppVersionInfo: Codable {
    var id: Int?
    var title: String?
    var remark: String?
    var platform: String?
    var force: ForceUpdate?
    var version_code: String?
    var package_path: String?
    var share_url: String?
    var extend: String?
    var created_at: String?
    var updated_at: String?
    var share_text: String?
    var potato_invite_link: String?
    var app_url: String?
    var static_url: String?
    var file_upload_url: String?
    var help_url: String?
    var wallet_url: String?
}

/// App闪屏广告
struct AdSplashModel: Codable {
    var id: Int?
    var video_id: Int?
    var title: String?
    var ad_path: String?
    var cover: String?
    var link: String?
    var status: Int?
    var type: Int?
    var play: String?
    var href: String?
    var created_at: String?
    var position: String?
}

/// 验证码对象
struct CodeModel: Codable {
    var verification_key: String?
    var expiredAt: String?
    var verification_code: String?
}

/** ***********************----  设备号注册 + app 公共信息 ----***************************/
struct DeviceAuthModel: Codable {
    var auth: AuthTokenModel?
    var notice: String?
    var startup: AdSplashModel?
    var skip: AdHome?
    var config: ConfigModel?
    var video_out: [AdHome]?
    var video_in: [AdHome]?
    var handshake: String?
}

struct AuthTokenModel: Codable {
    var token: String?
    var expired_at: String?  // token 过期时间
}

struct ConfigModel: Codable {
    var rule: RuleModel?
    var sys: SystemConfig?
}

struct RuleModel: Codable {
    var min_coins: String?
    var max_coins: String?
    var feedback_type: String?
    var coins_intro: String?
    var vip_intro: String?
    var video_all: String?
    var withdraw_fee: String?
    var withdraw_money: String?
    var service_change: String?
    var jsg_url: String?
    var new_user_vip_text: String?
    var new_user_coins_text: String?
    var service_return_rate: String?
    var floor_upload_limit: String?
    var shop_tips: String?
    
    /// 广告插入规则
    var short_ad_skip: StrInt?
    var ad_skip: StrInt?
    
    var create_h5: String? // 创作中心H5
    var yuepa_h5: String? // yuepa 中心H5
    var coins_withdraw_h5: String? // 钻石提现
    var cheat_h5: String?  // 防骗指南
    var game_withdraw_h5: String? // 游戏提现
    var is_open_game: StrInt? //是否开启游戏模块:0-关闭 1-打开
    
}

struct SystemConfig: Codable {
    var app_notice: String?
    var app_notice_ios: String?
    var notice: String?
    var upload_url: String?
    var share_text: String?
    var share_url: String?
    var ios_img_url: String?
    var invite_h5: String?
    var request_referer: String?
}
