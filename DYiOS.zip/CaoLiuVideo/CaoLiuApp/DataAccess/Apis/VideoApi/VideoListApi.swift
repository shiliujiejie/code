//
//  VideoListApi.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/12.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

//MARK: - 视频分类筛选中的  视频列表
class VideoListApi: XSVideoBaseAPI {
    // 分页参数
    static let kPageNumber = "page"
    static let kPageCount = "limit"
    static let kDefaultCount = 12
    
 
    static let key_id = "key_id" // 视频关键字Id
    static let kVideo_title = "video_title"  // 视频名称
    static let kUpdateded_at  = "updateded_at"  // 默认值 desc
    static let kPlay_count = "play_count" // 默认值 desc
    static let kKeyword = "keywords"   // 按关键词查询
    
    static let kDefaultCreat_at = "desc" // created_at 默认值
    static let kDefaultPlay_count = "desc" // 播放数： 默认值
    
    var pageNumber: Int = 1
    
    // MARK: - Public method
    
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "video/lists"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
      
        var newParams: [String: Any] = [VideoListApi.kPageNumber: pageNumber,
                                        VideoListApi.kPageCount: VideoListApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
       
        return super.reform(newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
       
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
         self.pageNumber += 1
    }
   
}

//MARK:  - 视频首页  视频列表
class VideoHomeListApi: XSVideoBaseAPI {
    // 分页参数
    static let kDefaultCount = 20
    static let kIsFree = "is_free"
    var pageNumber: Int = 1
    
    // MARK: - Public method
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/video/home"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        self.pageNumber += 1
    }
}

//MARK:  - 短视频 视频列表
class VideoShortListApi: XSVideoBaseAPI {
    // 分页参数
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kDefaultCount = 10
    
    static let kKeyIds = "type_ids"
    static let kVideoId = "video_id"
    var pageNumber: Int = 1
   
    // MARK: - Public method
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/video/short"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
      
        var newParams: [String: Any] = [VideoShortListApi.kPageNumber: pageNumber,
                                        VideoShortListApi.kPageCount: VideoShortListApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
       
        return super.reform(newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        self.pageNumber += 1
    }
}

//MARK: - 关注 首页关注 视频列表
class VideoAttentionListApi: XSVideoBaseAPI {
    // 分页参数
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kDefaultCount = 20
    
    static let kIslong = "is_long"
    
    var pageNumber: Int = 1
    
    // MARK: - Public method
    
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/video/attention"
    }
    override func shouldCache() -> Bool {
        return false
    }
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
      
        var newParams: [String: Any] = [VideoAttentionListApi.kPageNumber: pageNumber,
                                        VideoAttentionListApi.kPageCount: VideoAttentionListApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
         self.pageNumber += 1
    }
}

// MARK: - 首页频道列表Api
class ChannelListApi: XSVideoBaseAPI {
    
    static let kPosition = "position" //0首页 1会员 2约炮
    
    var position: Int = 0
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        if position == 0 {
            return "app/api/tab/list"
        } else {
            return "app/api/tab/h5/list"
        }
    }
    override func shouldCache() -> Bool {
        return true
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

// MARK: - 影片 模块化
class VideoModuleApi: XSVideoBaseAPI {
    // 分页参数
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kDefaultCount = 5
    
    /// 外部参数
    static let kKeyId = "tab_id" //1会员 2钻石
    
    static let kIsVip = "is_vip"
    
    static let kIslong = "is_long"
    
    var pageNumber: Int = 1
    
    /// 是否为vip模块
    var inVIPPart: Bool = false
    
    // MARK: - Public method
    
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return inVIPPart ? "app/api/tab/vip/module" : "app/api/tab/module"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        /// 分页参数
        var newParams: [String: Any] = [VideoModuleApi.kPageNumber: pageNumber, VideoModuleApi.kPageCount: VideoModuleApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        pageNumber += 1
    }
}

// MARK: - 影片 模块化 下一页
class VideoModuleMoreApi: XSVideoBaseAPI {
    // 分页参数
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    
    /// 外部参数
    static let kModuleId = "module_id" //模块id
    static let kProtocol = "protocol"
    
    var kDefaultCount: Int = 5
    
    var pageNumber: Int = 1
    
    /// 是否为vip模块
    var inVIPPart: Bool = false
    
    // MARK: - Public method
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return  inVIPPart ? "app/api/tab/vip/change" : "app/api/tab/change"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        /// 分页参数
        var newParams: [String: Any] = [VideoModuleMoreApi.kPageNumber: pageNumber, VideoModuleMoreApi.kPageCount: kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
       // pageNumber += 1
    }
}

// MARK: - 视频观看进度上报Api
class VideoProgressReportApi: XSVideoBaseAPI {
    
    static let kVideo_id = "video_id"
    static let kDuration = "duration"
    static let kIsLong = "is_long"
    static let kType_Ids = "type_ids"
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/video/play"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

// MARK: - 视频观看h鉴权Api
class VideoAuthApi: XSVideoBaseAPI {
    
    static let kVideo_id = "video_id"
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/video/info"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

//MARK:模块下视频列表
class VideoMoreListApi: XSVideoBaseAPI {
    // 分页参数
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kDefaultCount = 20
    
    /// 外部参数
    static let kModule = "module_id"
    static let kIslong = "is_long"

    var pageNumber: Int = 1

    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/video/module/list"
    }
    override func shouldCache() -> Bool {
        return false
    }
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        /// 分页参数
        var newParams: [String: Any] = [VideoMoreListApi.kPageNumber: pageNumber, VideoMoreListApi.kPageCount: VideoMoreListApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        pageNumber += 1
    }
}

//MARK: - 图片分类标签列表
class SexPictureTypesApi: XSVideoBaseAPI {
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/photos/search_type"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}
//MARK: - 视频标签详情 + 模块更多详情
class TipsTypesDetailApi: XSVideoBaseAPI {
    static let kTypeId = "type_id"
    var isModule: Bool = false
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return isModule ? "app/api/search/type/info" : "app/api/search/tag/info"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}
class TipsTypesFavorApi: XSVideoBaseAPI {
    static let kTypeId = "type_id"
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/video/like/type"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

/// 小视频头部标签
class TipsTypesRecomentApi: XSVideoBaseAPI {
    var isPushVideo: Bool = false
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return isPushVideo ? "app/api/search/upload/tag" : "app/api/search/recommend/tag"
    }
    override func shouldCache() -> Bool {
        return true
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

//MARK: - 图片列表
class PictureListApi: XSVideoBaseAPI {
    // 分页参数
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kDefaultCount = 20
    /// 外部参数
    static let kTypeKey = "images_type"
    
    var pageNumber: Int = 1

    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/photos/list"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        /// 分页参数
        var newParams: [String: Any] = [PictureListApi.kPageNumber: pageNumber, PictureListApi.kPageCount: PictureListApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        pageNumber += 1
    }
}

//MARK: - 图片详情
class PictureDetailApi: XSVideoBaseAPI {
     
    static let kPicId = "id"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/photos/info"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

//MARK: -楼风地区列表
class LFLocalListApi: XSVideoBaseAPI {
    
    var isUserSearch: Bool = false
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return isUserSearch ? "app/api/yuepa/city" : "app/api/yuepa/shop/mm/city"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

//MARK: - 楼风信息列表
class LFMsgListApi: XSVideoBaseAPI {
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kDefaultCount = 20
    static let kUserCode = "code"
    static let kProvince = "province"
    static let kCity = "city"
    static let kType = "type"  //1-经纪人 2-认证女神
    static let kIsVip = "is_vip"
    static let kChannel = "channel"
    
    var isFavor: Bool = false
    var pageNumber: Int = 1

    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return isFavor ? "app/api/yuepa/list/like" : "app/api/yuepa/shop/list"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var newParams: [String: Any] = [LFMsgListApi.kPageNumber: pageNumber, LFMsgListApi.kPageCount: LFMsgListApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        pageNumber += 1
    }
}

//MARK: - 楼风妹妹列表
class LFMMListApi: XSVideoBaseAPI {
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kDefaultCount = 10
    static let kShopCode = "shop_code"
    static let kProvince = "province"
    static let kCity = "city"
    var pageNumber: Int = 1

    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/yuepa/shop/mm/list"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var newParams: [String: Any] = [LFMMListApi.kPageNumber: pageNumber, LFMMListApi.kPageCount: LFMMListApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        pageNumber += 1
    }
}



//MARK: - 我的楼风信息列表
class MyLFMsgListApi: XSVideoBaseAPI {
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kDefaultCount = 20
    var pageNumber: Int = 1

    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/floor/list/my"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var newParams: [String: Any] = [MyLFMsgListApi.kPageNumber: pageNumber, MyLFMsgListApi.kPageCount: MyLFMsgListApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        pageNumber += 1
    }
}

//MARK: - 楼风信息订单列表
class LFMsgOrderListApi: XSVideoBaseAPI {
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kDefaultCount = 20
    static let kType = "type" // 1发起(即用户购买的） 2收到（即商家销售的)
    var pageNumber: Int = 1

    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/floor/order/list"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var newParams: [String: Any] = [LFMsgOrderListApi.kPageNumber: pageNumber, LFMsgOrderListApi.kPageCount: LFMsgOrderListApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        pageNumber += 1
    }
}

//MARK: - 楼凤商家详情
class LFShopDetailApi: XSVideoBaseAPI {
     
    static let kShop_code = "shop_code"
    
    var isSelfSearch: Bool = false
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return isSelfSearch ? "app/api/yuepa/shop/my/info" : "app/api/yuepa/shop/info"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

//MARK: - 楼凤详情
class LFMsgDetailApi: XSVideoBaseAPI {
     
    static let klFId = "id"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/floor/info"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}


//MARK: - 楼风体验信息列表
class LFCommentListApi: XSVideoBaseAPI {
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kLFInfoId = "floor_post_id"
    static let kDefaultCount = 20
    var pageNumber: Int = 1

    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/floor/feel/list"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var newParams: [String: Any] = [LFCommentListApi.kPageNumber: pageNumber, LFCommentListApi.kPageCount: LFCommentListApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        pageNumber += 1
    }
}
//MARK: - 楼风信息发布
class LFInfoPushApi: XSVideoBaseAPI {
    static let kTitle = "title"
    static let kIs_top = "is_top"  // 是否设为推荐 0 ： 1
    static let kProvince = "province" // 省
    static let kCity = "city"  // 城市
    static let kImages = "images"  // 逗号隔开
    static let kVideo = "video"   // 视频地址
    static let kCover = "cover"  // 封面
    static let kFloor_id = "id" // id
    static let kCreate_at = "create_at" //
    
    var isEdit: Bool = false
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return isEdit ? "app/api/yuepa/shop/mm/update" : "app/api/yuepa/shop/mm/add"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

//MARK: - 楼凤认证权益
class LFMsgAuthApi: XSVideoBaseAPI {
     
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/floor/authority"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}
//MARK: - 楼凤删除
class LFMsgDeleteApi: XSVideoBaseAPI {
     static let kfloor_id = "id"
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/yuepa/shop/mm/del"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}
//MARK: - 楼凤上下架
class LFMsgUpOrDownApi: XSVideoBaseAPI {
    static let kfloor_id = "floor_id"
    static let kStatu = "status"
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/floor/set_status"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

//MARK: - 楼凤体验发布
class LFCommentPushApi: XSVideoBaseAPI {
     static let kLFid = "floor_post_id"
    static let kComment_msg = "comment_msg"
    static let kComment_image = "comment_image"
    static let kOrder_sn = "order_sn"
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/floor/feel/create"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

//MARK: - 楼凤预约
class LFMsgOrderApi: XSVideoBaseAPI {
     static let kFloor_post_id = "floor_post_id"
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/floor/order/add"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}
