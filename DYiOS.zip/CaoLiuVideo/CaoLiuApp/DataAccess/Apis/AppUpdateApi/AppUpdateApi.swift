

import Foundation
import NicooNetwork

/// 版本更新信息Api
class AppUpdateApi: XSVideoBaseAPI {
    
    static let kParamData = "data"
    static let kPlatform = "device_type"   // A [A:安卓版 I:IOS版]
    static let kDomain = "domain"
    static let kDefaultPlatform = "I"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return  "app/api/version"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    override func requestType() -> NicooAPIManagerRequestType {
        return .post
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        guard let allParams = params else { return nil }
        if allParams.count == 0 { return nil }
        return super.reform(params)
    }
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
//        if (response.content as? [String: Any]) != nil {
//            let content = response.content as! [String: Any]
//            if let handshake = content["handshake"] as? String, !handshake.isEmpty { // 密码表返回
//                AppInfo.share().handShake = handshake
//            }
//        }
        
        return true
    }
}


//MARK: - 分享内容
class AppShareContentApi: XSVideoBaseAPI {
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/share/index"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}
