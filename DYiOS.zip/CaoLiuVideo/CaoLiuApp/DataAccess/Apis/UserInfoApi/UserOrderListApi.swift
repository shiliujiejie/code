
import Foundation
import NicooNetwork

//MARK: -VIP卡 列表
class VipCardsApi: XSVideoBaseAPI {
    
    static let kOrderType = "order_type"
    static let kIsvip = "is_vip"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/vip/lists"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

//MARK: 查询用户历史订单列表Api
class UserOrderListApi: XSVideoBaseAPI {
    
    // 分页参数
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kDefaultCount = 15
    
    var pageNumber: Int = 1
    var isGame: Bool = false
    
    // MARK: - Public method

    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return isGame ? "app/api/game/order" : "app/api/log/viporder"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
       
        var newParams: [String: Any] = [UserOrderListApi.kPageNumber: pageNumber,
                                        UserOrderListApi.kPageCount: UserOrderListApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        self.pageNumber += 1
    }
    
}


//MARK: - 订单生成
class UserOrderAddApi: XSVideoBaseAPI {
    
    static let kVc_id = "vip_id"   // vipCard id
    static let kPay_id = "payment_id"    // 支付方式
    static let kOrderType = "order_type"
    static let kAmount = "amount"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/vip/buyvip"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

//MARK: - 业务充值
class CoinChargeApi: XSVideoBaseAPI {
    
    static let kAmount = "amount"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/vip/recharge"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}
//MARK: - 上传支付凭证
class OrderProofApi: XSVideoBaseAPI {
    
    static let kOrderSn = "order_sn"   // vipCard id
    static let kFile_path = "file_path"    // 支付方式
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/orders/proof"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

// MARK: - 金币明细
class UserCoinsDetailApi: XSVideoBaseAPI {

    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kDefaultCount = 20
    
    var pageNumber: Int = 1
    
    /// 0 钻石 1: 上传收益钻石  2 游戏
    var type: Int = 0
    
    // MARK: - Public method
    
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        if type == 0 {
            return "app/api/log/coins"
        } else if type == 1 {
            return "app/api/user/upload/detail"
        } else if type == 2 {
            return "app/api/game/detail"
        }
        return "app/api/log/coins"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
      
        var newParams: [String: Any] = [UserCoinsDetailApi.kPageNumber: pageNumber,
                                        UserCoinsDetailApi.kPageCount: UserCoinsDetailApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
         self.pageNumber += 1
    }
}




