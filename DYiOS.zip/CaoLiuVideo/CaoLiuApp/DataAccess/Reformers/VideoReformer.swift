

import Foundation
import NicooNetwork

/// 数据解析器
class VideoReformer: NSObject {
    /// 系列分类 列表
    private func reformChannelsDatas(_ data: Data?) -> Any? {
        if let models = try? decode(response: data, of: ObjectResponse<[ChannelModel]>.self)?.data {
            return models
        }
        return nil
    }
    
    /// 系列分类 列表
    private func reformVideoModulesDatas(_ data: Data?) -> Any? {
        if let videoModules = try? decode(response: data, of: ObjectResponse<CateTypeListModel>.self)?.data {
            return videoModules
        }
        return nil
    }
    ///
    private func reformTypeTipsDatas(_ data: Data?) -> Any? {
        if let lists = try? decode(response: data, of: ObjectResponse<SearchHotTipListModel>.self)?.data {
            return lists
        }
        return nil
    }
    private func reformTypeTipsDetailDatas(_ data: Data?) -> Any? {
        if let model = try? decode(response: data, of: ObjectResponse<SearchHotTips>.self)?.data {
            return model
        }
        return nil
    }
    private func reformTypeTipsRecommentlDatas(_ data: Data?) -> Any? {
        if let model = try? decode(response: data, of: ObjectResponse<[SearchHotTips]>.self)?.data {
            return model
        }
        return nil
    }
    
    /// 首页带广告列表
    private func reformHomeListDatas(_ data: Data?) -> Any? {
        if let videoModules = try? decode(response: data, of: ObjectResponse<[VideoHomeNew]>.self)?.data {
            return videoModules
        }
        return nil
    }
    /// 影片模块
    private func reformVideoModuleModels(_ data: Data?) -> Any? {
        if let modules = try? decode(response: data, of: ObjectResponse<[ModulesModel]>.self)?.data {
            return modules
        }
        return nil
    }
    ///视频鉴权
    private func reformVideoAuthDatas(_ data: Data?) -> Any? {
        if let videoModel = try? decode(response: data, of: ObjectResponse<VideoNew>.self)?.data {
            return videoModel
        }
        return nil
    }
    /// 分类页面视频列表
    private func reformVideoListDatas(_ data: Data?) -> Any? {
        if let videoList = try? decode(response: data, of: ObjectResponse<[VideoNew]>.self)?.data {
            return videoList
        }
        return nil
    }
    /// 喜歡视频列表
    private func reformVideoFavorListDatas(_ data: Data?) -> Any? {
        if let videoList = try? decode(response: data, of: ObjectResponse<[VideoNew]>.self)?.data {
            return videoList
        }
        return nil
    }
    /// 观看历史
    private func reformWatchRecordListDatas(_ data: Data?) -> Any? {
        if let videoList = try? decode(response: data, of: ObjectResponse<[WatchRecord]>.self)?.data {
            return videoList
        }
        return nil
    }
    /// 作品视频列表
    private func reformVideoWorkListDatas(_ data: Data?) -> Any? {
        if let videoList = try? decode(response: data, of: ObjectResponse<WorksLisModel>.self)?.data {
            return videoList
        }
        return nil
    }
    /// 视频评论列表
    private func reformVideoCommentListDatas(_ data: Data?) -> Any? {
        if let commentList = try? decode(response: data, of: ObjectResponse<VideoCommentListModel>.self)?.data {
            return commentList
        }
        return nil
    }
    
    ///视频子评论列表
    private func reformVideoCommentSonListDatas(_ data: Data?) -> Any? {
        if let commentList = try? decode(response: data, of: ObjectResponse<CommentAnswerListModel>.self)?.data {
            return commentList
        }
        return nil
    }
    
    ///视频评论点赞
    private func reformVideoCommentLikeDatas(_ data: Data?) -> Any? {
        if let commentLikeModel = try? decode(response: data, of: ObjectResponse<VideoCommentLikeModel>.self)?.data {
            return commentLikeModel
        }
        return nil
    }
    
    ///视频详情
    private func reformVideoInfoData(_ data: Data?) ->Any? {
        if let videoModel = try? decode(response: data, of: ObjectResponse<VideoListModel>.self)?.data {
            return videoModel
        }
        return nil
    }
    /// 游戏入口
    private func reformGameEnterData(_ data: Data?) -> Any? {
        if let game = try? decode(response: data, of: ObjectResponse<GameEnterData>.self)?.data {
            return game
        }
        return nil
    }
    /// 游戏页面链接
    private func reformGameUrlData(_ data: Data?) -> Any? {
        if let game = try? decode(response: data, of: ObjectResponse<GameUrlData>.self)?.data {
            return game
        }
        return nil
    }
    ///活动视频列表
    private func reformActivityVideoListData(_ data: Data?) ->Any? {
        if let videoListModel = try? decode(response: data, of: ObjectResponse<VideoListModel>.self)?.data {
            return videoListModel
        }
        return nil
    }
    /// 分享内容
    private func reformShareContentData(_ data: Data?) -> Any? {
        if let game = try? decode(response: data, of: ObjectResponse<ShareContentModel>.self)?.data {
            return game
        }
        return nil
    }
    /// 图片分类
    private func reformPictureKeyTypesData(_ data: Data?) -> Any?  {
        if let types = try? decode(response: data, of: ObjectResponse<[PictureKey]>.self)?.data {
            return types
        }
        return nil
    }
    /// 图片封面列表
    private func reformPictureListData(_ data: Data?) -> Any?  {
        if let pictures = try? decode(response: data, of: ObjectResponse<PictureLsModel>.self)?.data {
            return pictures
        }
        return nil
    }
    /// 图片详情
    private func reformPictureInfoData(_ data: Data?) -> Any?  {
        if let pictures = try? decode(response: data, of: ObjectResponse<PictureModel>.self)?.data {
            return pictures
        }
        return nil
    }
    /// 楼凤地区
    private func reformLFCityModuleData(_ data: Data?) -> Any?  {
        if let pictures = try? decode(response: data, of: ObjectResponse<[LFLocalModel]>.self)?.data {
            return pictures
        }
        return nil
    }
    /// 楼风商家列表
    private func reformLFShopListData(_ data: Data?) -> Any?  {
        if let shops = try? decode(response: data, of: ObjectResponse<LFShopListModel>.self)?.data {
            return shops
        }
        return nil
    }
    /// 楼风商家详情
    private func reformLFShopDetailData(_ data: Data?) -> Any?  {
        if let shop = try? decode(response: data, of: ObjectResponse<LFShopDetail>.self)?.data {
            return shop
        }
        return nil
    }
    /// 楼风列表
    private func reformLFMsgListData(_ data: Data?) -> Any?  {
        if let pictures = try? decode(response: data, of: ObjectResponse<LFMsgLsModel>.self)?.data {
            return pictures
        }
        return nil
    }
    /// 楼风MM列表
    private func reformLFMMListData(_ data: Data?) -> Any?  {
        if let pictures = try? decode(response: data, of: ObjectResponse<[LFMsgModel]>.self)?.data {
            return pictures
        }
        return nil
    }
    
    /// 楼风详情
    private func reformLFMsgModelData(_ data: Data?) -> Any?  {
        if let lfModel = try? decode(response: data, of: ObjectResponse<LFMsgModel>.self)?.data {
            return lfModel
        }
        return nil
    }
    /// 楼风体验列表
    private func reformLFCommentsData(_ data: Data?) -> Any?  {
        if let lfModels = try? decode(response: data, of: ObjectResponse<[LFCommentModel]>.self)?.data {
            return lfModels
        }
        return nil
    }
    /// 楼风认证权益列表
    private func reformLFAuthData(_ data: Data?) -> Any?  {
        if let lfModels = try? decode(response: data, of: ObjectResponse<[LFMsgAuthModel]>.self)?.data {
            return lfModels
        }
        return nil
    }
    /// 楼风订单列表
    private func reformLFOrdersData(_ data: Data?) -> Any?  {
        if let lfModels = try? decode(response: data, of: ObjectResponse<[LFOrderModel]>.self)?.data {
            return lfModels
        }
        return nil
    }
}

extension VideoReformer: NicooAPIManagerDataReformProtocol {
    
    func manager(_ manager: NicooBaseAPIManager, reformData jsonData: Data?) -> Any? {
        if manager is ChannelListApi {
            return reformChannelsDatas(jsonData)
        }
        if manager is VideoAuthApi {
           return reformVideoAuthDatas(jsonData)
        }
        if manager is VideoListApi || manager is SearchVideoApi || manager is VideoModuleMoreApi ||  manager is UserWorkListApi || manager is VideoShortListApi {
            return reformVideoListDatas(jsonData)
        }
        if manager is UserWatchReccordListApi {
            return reformWatchRecordListDatas(jsonData)
        }
        if manager is UserFavorListApi || manager is UserBuyListApi || manager is VideoAttentionListApi || manager is VideoMoreListApi {
            return reformVideoFavorListDatas(jsonData)
        }
        if manager is VideoHomeListApi || manager is VideoAttentionListApi || manager is RecommentVideoApi {
            return reformHomeListDatas(jsonData)
        }
        if manager is VideoModuleApi {
            return reformVideoModuleModels(jsonData)
        }
        if manager is AppShareContentApi {
            return reformShareContentData(jsonData)
        }
        if manager is SexPictureTypesApi {
            return reformPictureKeyTypesData(jsonData)
        }
        
        if manager is PictureDetailApi {
            return reformPictureInfoData(jsonData)
        }
        if manager is LFLocalListApi {
            return reformLFCityModuleData(jsonData)
        }
        if manager is UserFavorLFMsgApi || manager is UserBuyFLMsgsApi  || manager is MyLFMsgListApi {
            return reformLFMsgListData(jsonData)
        }
        if manager is LFMsgListApi {
            return reformLFShopListData(jsonData)
        }
        if manager is LFMMListApi {
            return reformLFMMListData(jsonData)
        }
        if manager is LFShopDetailApi {
            return reformLFShopDetailData(jsonData)
        }
        if manager is LFMsgDetailApi || manager is LFInfoPushApi {
            return reformLFMsgModelData(jsonData)
        }
        if manager is LFCommentListApi {
            return reformLFCommentsData(jsonData)
        }
        if manager is LFMsgAuthApi {
            return reformLFAuthData(jsonData)
        }
        if manager is LFMsgOrderListApi {
            return reformLFOrdersData(jsonData)
        }
        if manager is UserFavorTipTypeApi {
            return reformTypeTipsDatas(jsonData)
        }
        if manager is TipsTypesDetailApi {
            return reformTypeTipsDetailDatas(jsonData)
        }
        if manager is TipsTypesRecomentApi {
            return reformTypeTipsRecommentlDatas(jsonData)
        }
        if manager is UserUploadListApi {
            return reformVideoListDatas(jsonData)
        }
        return nil
    }
}
