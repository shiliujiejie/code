

import Foundation
import NicooNetwork

/// 用户信息数据解析器
class UserReformer: NSObject {
    
    // MARK: - 用户订单列表
    private func reformOrderListDatas(_ data: Data?) -> Any? {
        if let loginInfo = try? decode(response: data, of: ObjectResponse<OrderListModel>.self)?.data {
            return loginInfo
        }
        return nil
    }
    // MARK: - 用户信息
    private func reformUserInfoDatas(_ data: Data?) -> Any? {
        if let videoList = try? decode(response: data, of: ObjectResponse<CLUserInfo>.self)?.data {
            return videoList
        }
        return nil
    }
    // MARK: - 卡片列表
    private func reformVipCardsDatas(_ data: Data?) -> Any? {
        if let videoList = try? decode(response: data, of: ObjectResponse<VipCardListModel>.self)?.data {
            return videoList
        }
        return nil
    }
    // MARK: - 游戏充值卡列表
    private func reformGameCardsDatas(_ data: Data?) -> Any? {
        if let videoList = try? decode(response: data, of: ObjectResponse<[VipCardModel]>.self)?.data {
            return videoList
        }
        return nil
    }
    
    // MARK: - 邀請记录
    private func reformInvitedListDatas(_ data: Data?) -> Any? {
        if let invitedList = try? decode(response: data, of: ObjectResponse<InviteListModel>.self)?.data {
            return invitedList
        }
        return nil
    }
    // MARK: - 点击付款 ，订单生成
    private func reformOrderAddDatas(_ data: Data?) -> Any? {
        if let invitedList = try? decode(response: data, of: ObjectResponse<OrderAddModel>.self)?.data {
            return invitedList
        }
        return nil
    }
    // MARK: - 获取支付通道列表
    private func reformPayTypeListDatas(_ data: Data?) -> Any? {
        if let invitedList = try? decode(response: data, of: ObjectResponse<[PayTypeModel]>.self)?.data {
            return invitedList
        }
        return nil
    }
    /// 会话列表
    private func msgSessionlistDatas(_ data: Data?) -> Any? {
        if let list = try? decode(response: data, of: ObjectResponse<MsgSessionModel>.self)?.data {
            return list
        }
        return nil
    }
    /// 反馈消息列表
    private func msglistRecordDatas(_ data: Data?) -> Any? {
        if let list = try? decode(response: data, of: ObjectResponse<MsgLsModel>.self)?.data {
            return list
        }
        return nil
    }
    /// 反馈消息回复
    private func feedReplyDatas(_ data: Data?) -> Any? {
        if let list = try? decode(response: data, of: ObjectResponse<MsgModel>.self)?.data {
            return list
        }
        return nil
    }
    /// 私聊消息列表
    private func chatMsglistDatas(_ data: Data?) -> Any? {
        if let list = try? decode(response: data, of: ObjectResponse<[MsgModel]>.self)?.data {
            return list
        }
        return nil
    }
   ///加群交流
     private func addGroupLinkData(_ data: Data?) -> Any? {
         if let groupLink = try? decode(response: data, of: ObjectResponse<[AddGroupLinkModel]>.self)?.data {
             return groupLink
         }
         return nil
     }
    // MARK: - 用户关注列表 和用户粉絲列表
    private func reformUserFollowOrFansList(_ data: Data?) -> Any? {
        if let oldUser = try? decode(response: data, of: ObjectResponse<FollowListModel>.self)?.data {
            return oldUser
        }
        return nil
    }
    // 用户关注狀態
    private func reforUserFollowStatuDatas(_ data: Data?) -> Any? {
        if let oldUser = try? decode(response: data, of: ObjectResponse<FollowStatu>.self)?.data {
            return oldUser
        }
        return nil
    }
    ///关注 | 取消关注
    private func  reformUserFollowOrCancelFollowDatas(_ data: Data?) -> Any? {
        if let followOrCancel = try? decode(response: data, of: ObjectResponse<FollowOrCancelModel>.self)?.data {
            return followOrCancel
        }
        return nil
    }
    /// 兌換Vip
    private func vipCardConvertData(_ data: Data?) -> Any? {
        if let taskList = try? decode(response: data, of: ObjectResponse<ExCoinsInfo>.self)?.data {
            return taskList
        }
        return nil
    }
    /// 金币套餐
    private func reformCoinListData(_ data: Data?) -> Any? {
        if let coinList = try? decode(response: data, of: ObjectResponse<[CoinModel]>.self)?.data {
            return coinList
        }
        return nil
    }
    ///金币明细
    private func reformCoinDetailListData(_ data: Data?) -> Any? {
        if let coinDetailList = try? decode(response: data, of: ObjectResponse<CoinDetailListModel>.self)?.data {
            return coinDetailList
        }
        return nil
    }
    /// 用户签到
    private func reformSignData(_ data: Data?) -> Any? {
        if let sign = try? decode(response: data, of: ObjectResponse<SignInfo>.self)?.data {
            return sign
        }
        return nil
    }
    private func reformBuyVideoData(_ data: Data?) -> Any? {
        if let mumodel = try? decode(response: data, of: ObjectResponse<VideoMU>.self)?.data {
            return mumodel
        }
        return nil
    }
    private func reformBuyMsgData(_ data: Data?) -> Any? {
        if let model = try? decode(response: data, of: ObjectResponse<LFMsgModel>.self)?.data {
            return model
        }
        return nil
    }
    private func reformLFCommetLsData(_ data: Data?) -> Any? {
        if let model = try? decode(response: data, of: ObjectResponse<[LFCommentModel]>.self)?.data {
            return model
        }
        return nil
    }
    private func reformShopInfoData(_ data: Data?) -> Any? {
        if let model = try? decode(response: data, of: ObjectResponse<LFShopModel>.self)?.data {
            return model
        }
        return nil
    }
    private func reformUploadInfoData(_ data: Data?) -> Any? {
        if let model = try? decode(response: data, of: ObjectResponse<CreatorInfoPage>.self)?.data {
            return model
        }
        return nil
    }
    /// 点赞的楼风商家列表
    private func reformLFShopListData(_ data: Data?) -> Any?  {
        if let shops = try? decode(response: data, of: ObjectResponse<[LFShopModel]>.self)?.data {
            return shops
        }
        return nil
    }
    
    private func reformGamepageData(_ data: Data?) -> Any?  {
        if let game = try? decode(response: data, of: ObjectResponse<GamePageModel>.self)?.data {
            return game
        }
        return nil
    }
    private func reformQAMsgData(_ data: Data?) -> Any?  {
        if let game = try? decode(response: data, of: ObjectResponse<[Q_AItemModel]>.self)?.data {
            return game
        }
        return nil
    }
    private func reformGameDetailData(_ data: Data?) -> Any?  {
        if let game = try? decode(response: data, of: ObjectResponse<GameListModel>.self)?.data {
            return game
        }
        return nil
    }
}

extension UserReformer: NicooAPIManagerDataReformProtocol {
    
    func manager(_ manager: NicooBaseAPIManager, reformData jsonData: Data?) -> Any? {
        if manager is UserInfoApi || manager is UserInfoOtherApi {
            return reformUserInfoDatas(jsonData)
        }
        if manager is UserOrderListApi {
            return reformOrderListDatas(jsonData)
        }
        if manager is LFMsgListApi {
            return reformLFShopListData(jsonData)
        }
        if manager is VipCardsApi {
            return reformVipCardsDatas(jsonData)
        }
        if manager is UserInvitedListApi {
            return reformInvitedListDatas(jsonData)
        }
        if manager is UserOrderAddApi {
            return reformOrderAddDatas(jsonData)
        }
        if manager is UserMsgLsApi {
            return msglistRecordDatas(jsonData)
        }
        if manager is ChatMsgApi || manager is NoticeMsgListApi {
            return chatMsglistDatas(jsonData)
        }
        if manager is ChatListApi {
            if (manager as! ChatListApi).pageNumber == 1 {
                return msgSessionlistDatas(jsonData)
            } else {
                return chatMsglistDatas(jsonData)
            }
        }
        if manager is FeedReplyApi {
            return feedReplyDatas(jsonData)
        }
        if manager is UserFollowListApi || manager is UserFansListApi {
            return reformUserFollowOrFansList(jsonData)
        }
        if manager is UserAddFollowApi || manager is UserCancleFollowApi {
            return reformUserFollowOrCancelFollowDatas(jsonData)
        }
        if manager is VipCardExChangeApi || manager is VipConvertInfoApi {
            return vipCardConvertData(jsonData)
        }
        if manager is CoinListApi {
            return reformCoinListData(jsonData)
        }
        if manager is UserInviteLinkApi {
            return addGroupLinkData(jsonData)
        }
        if manager is UserCoinsDetailApi {
            return reformCoinDetailListData(jsonData)
        }
        if manager is UserSignApi {
            return reformSignData(jsonData)
        }
        if manager is UseBuyVideoApi {
            return reformBuyVideoData(jsonData)
        }
        if manager is UseBuyMsgApi {
            return reformBuyMsgData(jsonData)
        }
        if manager is CoinChargeApi {
            return reformPayTypeListDatas(jsonData)
        }
        if manager is LfCommentLsApi {
            return reformLFCommetLsData(jsonData)
        }
        if manager is LFShopDetailApi {
            return reformShopInfoData(jsonData)
        }
        if manager is UserUploadInfoApi {
            return reformUploadInfoData(jsonData)
        }
        if manager is GameListApi {
            return reformGamepageData(jsonData)
        }
        if manager is GameCardsApi {
            return reformGameCardsDatas(jsonData)
        }
        if manager is UserFeedQ_AApi {
            return reformQAMsgData(jsonData)
        }
        if manager is GameDetailApi {
            return reformGameDetailData(jsonData)
        }
        return nil
    }
}


