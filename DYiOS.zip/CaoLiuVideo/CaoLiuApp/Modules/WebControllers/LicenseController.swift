
import UIKit
import WebKit

/// 上传须知
class LicenseController: CLBaseViewController {
    
    static let kListener = "JSListener"
    static let kListenerFenxiao = "JSListenerFX"
    
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.titleLabel.text = nil
        bar.navBackBlack = false
        bar.delegate = self
        return bar
    }()
    private lazy var wkConfig: WKWebViewConfiguration = {
        let config = WKWebViewConfiguration()
        //声明一个WKUserScript对象
        let params = ["" : ""]
        let script = WKUserScript.init(source: "function callJavaScript() {nativeToJavaScript('\(params)');}", injectionTime: .atDocumentEnd, forMainFrameOnly: true)
        config.userContentController.addUserScript(script)
        return config
    }()
    
    lazy var webView: WKWebView = {
        let webView = WKWebView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: ConstValue.kScreenHeight), configuration: wkConfig)
        webView.navigationDelegate = self
        webView.isOpaque = false
        webView.scrollView.showsHorizontalScrollIndicator = false
        webView.scrollView.backgroundColor = UIColor.darkText
        // 用WeakScriptMessageDelegate(self) 代替self,解决内存泄漏的问题
        webView.configuration.userContentController.add(WeakScriptDelegate(self), name: LicenseController.kListener)
        webView.configuration.userContentController.add(WeakScriptDelegate(self), name: LicenseController.kListenerFenxiao)
        return webView
    }()
    var urlString: String?
    var navTitle: String?
        
    deinit {
        webView.configuration.userContentController.removeScriptMessageHandler(forName: LicenseController.kListener)
        webView.configuration.userContentController.removeScriptMessageHandler(forName: LicenseController.kListenerFenxiao)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        view.addSubview(navBar)
        view.addSubview(webView)
        layoutSubs()
        navBar.titleLabel.text = navTitle
        if let urlstr = urlString {
            if let url = URL(string: urlstr) {
                webView.load(URLRequest(url: url))
            }
        }
    }
    private func layoutSubs() {
        navBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(safeAreaTopHeight)
        }
        webView.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview()
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(navBar.snp.bottom)
        }
    }

    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        DLog("webView.url?.absoluteString == \(webView.url?.absoluteString ?? "")")
    }
    
}

//MARK: - js交互  js调用原生  获取到JS传来的参数

extension LicenseController: WKScriptMessageHandler {
    /// 交互， 监听JS的事件返回
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == LicenseController.kListener {
            
        }
    }
}

extension LicenseController: WKNavigationDelegate {
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        decisionHandler(.allow)
    }
    
    // 开始接收响应
    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        decisionHandler(.allow)
    }
    
    //用于授权验证的API，与AFN、UIWebView的授权验证API是一样的
    func webView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        completionHandler(.performDefaultHandling ,nil)
    }
    
    // 开始加载数据
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
    }
    func webView(_ webView: WKWebView, didReceiveServerRedirectForProvisionalNavigation navigation: WKNavigation!) {
    }
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        XSProgressHUD.hide(for: view, animated: false)
    }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        XSProgressHUD.hide(for: view, animated: false)
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        XSProgressHUD.hide(for: view, animated: false)
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        XSProgressHUD.hide(for: view, animated: false)
    }
}

// MARK: - CLNavigationBarDelegate
extension LicenseController:  CLNavigationBarDelegate  {
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}
