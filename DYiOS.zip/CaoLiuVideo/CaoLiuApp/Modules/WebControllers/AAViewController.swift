
import UIKit
import WebKit
import JXSegmentedView
import JXPagingView

public let kScreenHeight = UIScreen.main.bounds.size.height
public let kScreenWdith = UIScreen.main.bounds.size.width

enum JSFuctionEnum: String {
    case finishActivity = "finishActivity"
    case uploadVideo = "uploadVideo"
    case showPersonPage = "showPersonPage"
    case showVideo = "showVideo"
}

enum VCPosition {
    case OnePage
    case InModule
    case InVIPPart
    case InYuePa
    case InTabar
}

extension AAViewController: JXSegmentedListContainerViewListDelegate {
    func listView() -> UIView {
        return self.view
    }
}
class AAViewController: UIViewController {
    
    static let kListener = "JSListener"
    private let estimatedProgressKeyPath = "estimatedProgress"
    private lazy var closeBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.frame = CGRect(x: screenWidth - 40, y: statusBarHeight + 7, width: 30, height: 30)
        button.setTitle("X", for: .normal)
        button.layer.cornerRadius = 15
        button.layer.masksToBounds = true
        button.backgroundColor = UIColor(white: 0, alpha: 0.3)
        button.addTarget(self, action: #selector(closeBtnClick), for: .touchUpInside)
        return button
    }()
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .default
    }
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    private lazy var wkConfig: WKWebViewConfiguration = {
        let config = WKWebViewConfiguration()
        let source: String = "var meta = document.createElement('meta');" +
            "meta.name = 'viewport';" +
            "meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';" +
            "var head = document.getElementsByTagName('head')[0];" +
            "head.appendChild(meta);"
        //声明一个WKUserScript对象
        let script: WKUserScript = WKUserScript(source: source, injectionTime: .atDocumentEnd, forMainFrameOnly: true)
        let userContentController: WKUserContentController = WKUserContentController()
        let conf = WKWebViewConfiguration()
        conf.userContentController = userContentController
        userContentController.addUserScript(script)
        return config
    }()
    private lazy var webView: WKWebView = {
        let webView = WKWebView(frame: CGRect(x: 0, y: 0, width: kScreenWdith, height: kScreenHeight), configuration: wkConfig)
        webView.navigationDelegate = self
        webView.scrollView.showsHorizontalScrollIndicator = false
        webView.scrollView.backgroundColor = UIColor.white
        webView.scrollView.showsVerticalScrollIndicator = false
        webView.allowsBackForwardNavigationGestures = true
        webView.scrollView.isMultipleTouchEnabled = false
        webView.allowsLinkPreview = true
        webView.uiDelegate = self
        // 用WeakScriptMessageDelegate(self) 代替self,解决内存泄漏的问题
        webView.configuration.userContentController.add(WeakScriptDelegate(self), name: AAViewController.kListener)
        webView.addObserver(self, forKeyPath: estimatedProgressKeyPath, options: .new, context: nil)
        return webView
    }()
    private lazy final var progressView: UIProgressView = {
        let progressView = UIProgressView(frame: CGRect(x: 0, y: safeAreaTopHeight, width: screenWidth, height: 0.5))
        progressView.progressViewStyle = .bar
        progressView.tintColor = UIColor.red
        progressView.trackTintColor = UIColor.clear
        progressView.borderRadius = 0.5
        return progressView
    }()
    var segIndex: Int = 0
    
    /// 网页所在位置，默认为独立页面
    var position: VCPosition = .OnePage
    
    private var openUrl: URL?
    
    let viewModel: VideoViewModel = VideoViewModel()
    var backLaunchAdViewController:(() ->Void)?
    var scrollOffSetYHandler:((CGFloat, Int) -> Void)?
    deinit {
        DLog("vc is deinit")    // 出站的时候，这里没走，说明当前控制器没有被释放调，存在内存泄漏
        webView.configuration.userContentController.removeScriptMessageHandler(forName: AAViewController.kListener)
        webView.removeObserver(self, forKeyPath: estimatedProgressKeyPath, context: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        view.backgroundColor = ConstValue.kVcViewColor
        view.addSubview(webView)
        if #available(iOS 11.0, *) {
            webView.scrollView.contentInsetAdjustmentBehavior = .never
        } else {
            self.automaticallyAdjustsScrollViewInsets = false
        }
        self.webView.scrollView.contentInset = UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
        view.addSubview(progressView)
        if position == .InVIPPart {
            progressView.frame = CGRect(x: 0, y: statusBarHeight + 44, width: screenWidth, height: 0.5)
        } else if position == .InModule {
            progressView.frame = CGRect(x: 0, y: 0, width: screenWidth, height: 0.5)
            webView.scrollView.delegate = self
        } else if position == .InYuePa {
            progressView.frame = CGRect(x: 0, y: 0, width: screenWidth, height: 0.5)
        } else if position == .OnePage {
            view.addSubview(closeBtn)
        }
        webView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        loadWebUrl()
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        backLaunchAdViewController?()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if position == .InVIPPart {
            NotificationCenter.default.post(name: Notification.Name.kVIPTopBarColotNotification, object: nil, userInfo: ["TopBarDarkColor": 0])
        } else if position == .InModule {
            NotificationCenter.default.post(name: Notification.Name.kMainTopBarColotNotification, object: nil, userInfo: ["AutoTopBarBgColor": 1, "SegIndex" :segIndex, "OffSetY" : Int(webView.scrollView.contentOffset.y)])
        }
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if position == .InVIPPart {
            webView.frame = CGRect(x: 0, y: statusBarHeight + 44, width: screenWidth, height: screenHeight - statusBarHeight - 94 - safeAreaBottomHeight)
        } else if position == .InModule {
            webView.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight - safeAreaBottomHeight - 137 - statusBarHeight)
        } else if position == .InYuePa {
            webView.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight - 93 - statusBarHeight - safeAreaBottomHeight)
        } else {
            webView.frame = view.bounds
        }
    }
    
    /// 加载网页
    private func loadWebUrl() {
        if openUrl != nil {
            webView.load(URLRequest(url: openUrl!))
        }
    }
    
    init(url: URL) {
        openUrl = url
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func backAction() {
        if webView.canGoBack {
            webView.goBack()
        } else {
            navigationController?.popViewController(animated: true)
        }
    }
    @objc func closeBtnClick() {
        navigationController?.popViewController(animated: false)
    }
}

extension AAViewController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
//        if position == .InModule {
//            let offsetY = scrollView.contentOffset.y
//            scrollOffSetYHandler?(offsetY, segIndex)
//        }
    }
}

//MARK: -KVO
extension AAViewController {
    open override func observeValue(forKeyPath keyPath: String?,
                                    of object: Any?,
                                    change: [NSKeyValueChangeKey : Any]?,
                                    context: UnsafeMutableRawPointer?) {
        guard let theKeyPath = keyPath , object as? WKWebView == webView else {
            super.observeValue(forKeyPath: keyPath, of: object, change: change, context: context)
            return
        }
        if theKeyPath == estimatedProgressKeyPath {
            updateProgress()
        }
    }
    
    // MARK: Private
    private final func updateProgress() {
        let completed = webView.estimatedProgress == 1.0
        progressView.setProgress(completed ? 0.0 : Float(webView.estimatedProgress), animated: !completed)
        UIApplication.shared.isNetworkActivityIndicatorVisible = !completed
    }
}

//MARK: - js交互 - 原生调用Js
extension AAViewController {
    
    /// WKUserScript对象 调用JS      也可以直接调用 jsString = "nativeToJavaScript('\(params)')"
    @objc func rightBarButtonClick() {
        let jsString = "callJavaScript()"
        webView.evaluateJavaScript(jsString) { (response, error) in
            if (error != nil) {
                DLog("getINFOfROM = \(String(describing: response))")
            }
        }
    }
    
    /// 直接调用JS,传递参数
    @objc func leftBarButtonClick() {
        let params = ["firstObjc", "secondObjc"]
        let jsString = "changeHead('\(params)')"
        webView.evaluateJavaScript(jsString) { (response, error) in
            if (error != nil) {
                DLog("getINFOfROM = \(response ?? "")")
            }
        }
    }
}

//MARK: - js交互  js调用原生  获取到JS传来的参数
extension AAViewController: WKScriptMessageHandler {
    /// 交互， 监听JS的事件返回
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == AAViewController.kListener {
            DLog("Js回调的数据为:---\n\(message.body),")
            if let msg = message.body as? String {
                DispatchQueue.main.async {
                    if msg == "b" || msg == "back" {
                        self.backAction()
                    } else if msg == "s" || msg == "share" {
                        self.goShare()
                    } else if msg == "chargeVip" {
                        self.goCharge(false)
                    } else if msg == "chargeDiamonds" {
                        self.goCharge(true)
                    } else if msg == "bandPhone" {
                        self.bandPhone()
                    } else if msg == "sign" {
                        self.signDetail()
                    } else if msg == "service" {
                        self.chartvc()
                    } else if msg == "myfans" {
                        self.fansOrFocus(true)
                    } else if msg == "myfocus" {
                        self.fansOrFocus(false)
                    } else if msg == "myinvite" {
                        self.inviteRecord()
                    }
                }
            }
        }
        if let info = message.body as? [String: String] {
            DispatchQueue.main.async {
                if let uid = info["uid"], !uid.isEmpty {
                    let user = CLUserInfo()
                    user.code = uid
                    self.goUserCenter(user)
                }
                if let videoId = info["videoId"], !videoId.isEmpty {
                    self.viewModel.loadVideoAuthData(params: [VideoAuthApi.kVideo_id: videoId], succeedHandler: { [weak self] (video) in
                        if video.is_long == 1 {
                            self?.goVideoDetail(video)
                        } else {
                            self?.goVideoPlayVc([video])
                        }
                    }) { (error) in
                        XSAlert.show(type: .error, text: error)
                    }
                }
                if let loufengId = info["loufengId"], !loufengId.isEmpty {
                    let lfModel = LFShopModel()
                    lfModel.code = loufengId
                    self.lfdetail(lfModel)
                }
                if let photoId = info["photoId"], !photoId.isEmpty {
                    let photoModel = PictureModel()
                    photoModel.id = Int(photoId) ?? 0
                    self.photoDetail(photoModel)
                }
                if let adlink = info["ad"], !adlink.isEmpty {
                    self.goInnerLink(adlink,"web")
                }
                if let labelDetail = info["labelDetail"], !labelDetail.isEmpty {
                    let strs = labelDetail.components(separatedBy: "#")
                    if strs.count == 2 {
                        self.typeVc(Int(strs[0]) ?? 0, strs[1])
                    }
                }
                if let moduleDetail = info["moduleDetail"], !moduleDetail.isEmpty {
                    let strs = moduleDetail.components(separatedBy: "#")
                    if strs.count == 2 {
                        self.moduleMoreVc(Int(strs[0]) ?? 0, strs[1])
                    }
                }
            }
        }
    }
}
// MARK: - WKUIDelegate
extension AAViewController: WKUIDelegate {
    
    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        print("prompt = \(prompt)")
        if prompt.contains("UserCode") {
            completionHandler(UserModel.share().user?.code)
        }
        if prompt.contains("BarHeight") {
            completionHandler("\(position == .OnePage ? statusBarHeight : 0)")
        }
    }
}
//MARK: -WKWebView的代理
extension AAViewController: WKNavigationDelegate {
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        decisionHandler(.allow)
    }
    // 开始接收响应
    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        decisionHandler(.allow)
    }
    //用于授权验证的API，与AFN、UIWebView的授权验证API是一样的
    func webView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        completionHandler(.performDefaultHandling ,nil)
    }
    // 开始加载数据
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        webView.isHidden = false
        // self.indicatorView.startAnimating()
    }
    // 当main frame接收到服务重定向时调用
    func webView(_ webView: WKWebView, didReceiveServerRedirectForProvisionalNavigation navigation: WKNavigation!) {
        // 接收到服务器跳转请求之后调用
    }
    // 当内容开始返回时调用
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        webView.evaluateJavaScript("document.body.offsetHeight") { [weak self] (result, error) in
            if self != nil {
                if let webheight = result as? CGFloat {
                    DLog("网页高度= \(webheight)")
                }
            }
        }
    }
    //当main frame导航完成时，会回调
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        
  
        webView.evaluateJavaScript("document.body.offsetHeight") { [weak self] (result, error) in
            if self != nil {
                if let webheight = result as? CGFloat {
                    DLog("网页高度= \(webheight)")
                }
            }
        }
    }
    // 当web content处理完成时，会回调
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        webView.evaluateJavaScript("document.body.offsetHeight") { [weak self] (result, error) in
            if self != nil {
                if let webheight = result as? CGFloat {
                    DLog("网页高度= \(webheight)")
                }
            }
        }
    }
    
    // 当main frame开始加载数据失败时，会回调
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        
    }
    // 当main frame最后下载数据失败时，会回调
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        
    }
}


/// Action Jumps
private extension AAViewController {
    /// 用户中心
    func goUserCenter(_ user: CLUserInfo?) {
        if let vcs = navigationController?.viewControllers {
            let allVcs = vcs.filter { (vc) -> Bool in
                return vc.isKind(of: UserMCenterController.self)
            }
            if allVcs.count > 0 {
                navigationController?.viewControllers.removeAll(where: { (vc) -> Bool in
                    return vc.isKind(of: UserMCenterController.self)
                })
            }
            let userCenter = UserMCenterController()
            userCenter.userCode = user?.code
            navigationController?.pushViewController(userCenter, animated: true)
        }
    }
    /// 视频详情
    func goVideoDetail(_ model: VideoNew) {
        let detail = VideoDetailController()
        detail.video = model
        navigationController?.pushViewController(detail, animated: true)
    }
    ///小视频播放
    func goVideoPlayVc(_ models: [VideoNew]) {
        let controller = PresentPlayController()
        controller.videos = models
        controller.currentIndex = 0
        controller.currentPlayIndex = 0
        navigationController?.pushViewController(controller, animated: false)
    }
    /// 内链
    func innerLink(_ url: String) {
        guard let adHref = URL(string: url) else { return }
        let aavc = AAViewController(url: adHref)
        navigationController?.pushViewController(aavc, animated: false)
    }
    /// 充值
    func goCharge(_ isCoin: Bool) {
        if isCoin {
            let vipvc = CoinsCardsController()
            vipvc.isCoins = true
            navigationController?.pushViewController(vipvc, animated: true)
        } else {
            let vip = VipCardsController()
            navigationController?.pushViewController(vip, animated: true)
        }
    }
    /// 分享
    func goShare() {
        if let vcs = navigationController?.viewControllers {
            let allVcs = vcs.filter { (vc) -> Bool in
                return vc.isKind(of: ShareContentController.self)
            }
            if allVcs.count > 0 {
                navigationController?.viewControllers.removeAll(where: { (vc) -> Bool in
                    return vc.isKind(of: ShareContentController.self)
                })
            }
            let shareVc = ShareContentController()
            navigationController?.pushViewController(shareVc, animated: true)
        }
    }
    /// 帮手机
    func bandPhone() {
        let bind = VerbPhoneController()
        bind.isLogin = true
        navigationController?.pushViewController(bind, animated: true)
    }
    /// 粉丝关注
    func fansOrFocus(_ isFanns: Bool) {
        if isFanns {
            let vc = FansListController()
            vc.fansCount = UserModel.share().user?.fans ?? 0
            navigationController?.pushViewController(vc, animated: true)
        } else {
            let vc = AttentionController()
            vc.attentionCount = UserModel.share().user?.flow ?? 0
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    /// 邀请记录
    func inviteRecord() {
        let recordVC = InviteRecordController()
        navigationController?.pushViewController(recordVC, animated: true)
    }
    //签到记录
    func signDetail() {
        let vc = DailyInController()
        if UserModel.share().signInfo != nil {
            vc.signModel = UserModel.share().signInfo!
        }
        navigationController?.pushViewController(vc, animated: true)
    }
    /// 客服
    func chartvc() {
        let feedBack = ChartController()
        navigationController?.pushViewController(feedBack, animated: true)
    }
    /// tag主页
    func typeVc(_ id: Int, _ title: String) {
        let keyVc = TypeVideosController()
        keyVc.keyMode.type_id = id
        keyVc.keyMode.title = title
        navigationController?.pushViewController(keyVc, animated: true)
    }
    /// 类型主页
    func moduleMoreVc(_ id: Int, _ title: String) {
        let keyVc = ModuleMoreController()
        keyVc.detailModel.id = id
        keyVc.detailModel.title = title
        navigationController?.pushViewController(keyVc, animated: true)
    }
    /// 漏风详情
    func lfdetail(_ model: LFShopModel) {
        let vc = LFShopDetailController()
        vc.shopModel = model
        navigationController?.pushViewController(vc, animated: true)
    }
    /// 私照详情
    func photoDetail(_ picture: PictureModel) {
        let pictvc = PictureDetailController()
        pictvc.picture = picture
        navigationController?.pushViewController(pictvc, animated: true)
    }
}
