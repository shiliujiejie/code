
import UIKit

/// 更新弹框
class UpdateAlert: UIView {

    @IBOutlet weak var alertContainView: UIView!
    @IBOutlet weak var titleLable: UILabel!
    @IBOutlet weak var closeBtn: UIButton!
    @IBOutlet weak var updateBtn: UIButton!
    
    @IBOutlet weak var versionCodeLab: UILabel!
    @IBOutlet weak var updateTipBtn: UIButton!
    @IBOutlet weak var updateInfoTextView: UITextView!
    
    @IBOutlet weak var nextTimeBtnWidth: NSLayoutConstraint!
    @IBOutlet weak var UpdateBtnWidth: NSLayoutConstraint!
    var updateActionHandler:(() ->Void)?
    var versionInfoHandler:(() ->Void)?
    var closeActionHandler:(() ->Void)?
    var webUpdateActonhandler:(() -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = UIColor.clear
        alertContainView.layer.cornerRadius = 10
        alertContainView.layer.masksToBounds = true
        versionCodeLab.text = "V\(AppInfo.share().appInfo?.version_code ?? "")"
    }
    
    @IBAction func updateAction(_ sender: UIButton) {
        updateActionHandler?()
    }
    
    @IBAction func closeAction(_ sender: Any) {
        closeActionHandler?()
    }
    
    @IBAction func versionInfo(_ sender: UIButton) {
        closeActionHandler?()
    }
    
}

extension SystemAlert: UITextViewDelegate {
    func textView(_ textView: UITextView, shouldInteractWith URL: URL, in characterRange: NSRange) -> Bool {
        return true
    }
}
