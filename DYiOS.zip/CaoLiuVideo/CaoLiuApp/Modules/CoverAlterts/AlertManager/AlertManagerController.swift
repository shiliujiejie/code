
import UIKit
public enum DouYinAlertType: Int {
    case updateInfo = 1
    case newUserReward
    case addPhoneWarning
    case systemAlert
    case systemMessage
    case coinNotEnoughAlert
    case coinBuyPictureAlert
    case findAcountAlert
}

/// 弹框 管理控制器，所有弹框 都被他持有，选择调用
class AlertManagerController: UIViewController {
    
    static let kWelfCardString = "WelfCardInfo"
    static let kWelfCardTiem = "WelfCardTime"
    
    static let kConvertTitle = "ConvertTitle"
    static let kConvertMsg = "ConvertMsg"
    
    var alertType: DouYinAlertType = .updateInfo
    
    private(set) var newUserCardInfo: [String : String]?
    private(set) var addPhoneDays: Int = 3
    private(set) var vipCardModel: VipCardModel?
    private(set) var systemModel: String?
    private(set) var convertCardInfo: ConvertCardAlertModel?
    private(set) var systemMessages: String?

    /// 弹框点击确认按钮操作
    var commitActionHandler:(() -> Void)?
    
    var closeActionHandler: (() -> Void)?
    var customActionHandler:((_ id: Int) -> Void)?
    
    /// 弹框绘制完成回调
    var alertLoadFinishHandler:(() -> Void)?
    
    var cancleActionHandler:(() -> Void)?
    
    /// 触摸屏幕消失
    var touchDissMiss: Bool = false
    
    /// 钻石不足 弹框
    ///
    /// - Parameter altertType: 弹框类型
    convenience init(cardModel: ConvertCardAlertModel) {
        self.init()
        self.alertType = .coinNotEnoughAlert
        convertCardInfo = cardModel
    }
    /// 钻石买图集 弹框
    ///
    /// - Parameter altertType: 弹框类型
    convenience init(alertModel: ConvertCardAlertModel) {
        self.init()
        self.alertType = .coinBuyPictureAlert
        convertCardInfo = alertModel
    }
    
    /// 找回原账号提示
    ///
    /// - Parameter cardModel: 弹框需要的信息
    convenience init(alertInfoModel: ConvertCardAlertModel) {
        self.init()
        self.alertType = .findAcountAlert
        convertCardInfo = alertInfoModel
    }
    
    /// 系统提示弹框
    ///
    /// - Parameter model: 系统model
    convenience init(systemAlert model: String) {
        self.init()
        alertType = .systemAlert
        systemModel = model
    }
    
    /// 系統公告
    ///
    /// - Parameter messages:  消息公告
    convenience init(system messages: String) {
        self.init()
        alertType = .systemMessage
        systemMessages = messages
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if alertType == .updateInfo {
            getUpdateAlter()
        } else if alertType == .systemAlert {
            getSystemAlter(systemModel!)
        } else if alertType == .systemMessage {
            getSystemMessagesAlter(systemMessages!)
        } else if alertType == .coinNotEnoughAlert {
            coinsNotEnoughAlter(model: convertCardInfo!)
        } else if alertType == .findAcountAlert {
            getAcountBackConvertAlter(model: convertCardInfo!)
        } else if alertType == .coinBuyPictureAlert {
            coinsBuyPictureAlter(model: convertCardInfo!)
        }
       
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
       
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if touchDissMiss {
            self.dissMiss()
        }
    }
    /// 版本更新弹框
    func getUpdateAlter() {
        guard let updateView = Bundle.main.loadNibNamed("UpdateAlert", owner: nil, options: nil)?[0] as? UpdateAlert else { return }
        view.addSubview(updateView)
        layoutAlertView(updateView)
        updateView.updateInfoTextView.attributedText = TextSpaceManager.configColorString(allString: AppInfo.share().appInfo?.remark ?? "", attribStr: AppInfo.share().appInfo?.remark ?? "", .darkGray, UIFont.systemFont(ofSize: 14), 5)
        
        if (AppInfo.share().appInfo?.force?.isForce ?? false) {
            updateView.nextTimeBtnWidth.constant = 0
            updateView.UpdateBtnWidth.constant = 290
        } else {
            updateView.nextTimeBtnWidth.constant = 144.5
            updateView.UpdateBtnWidth.constant = 144.5
        }
        
        updateView.closeActionHandler = {
            self.closeActionHandler?()
            self.dissMiss()
        }
        updateView.updateActionHandler = {
            self.commitActionHandler?()
            if !(AppInfo.share().appInfo?.force?.isForce ?? false) {
                self.dissMiss()
            }
        }
        updateView.versionInfoHandler = {
             self.closeActionHandler?()
             self.dissMiss()
        }
    }
    
    /// 转世不足提示
    func coinsNotEnoughAlter(model: ConvertCardAlertModel) {
        let alert = CoinNotEnoughAlert(frame: view.bounds)
        alert.msgLabel.text = model.msgInfo
        view.addSubview(alert)
        alert.commitActionHandler = {
            self.commitActionHandler?()
            self.dissMiss()
        }
    }
    
    /// 钻石买图集提示
    func coinsBuyPictureAlter(model: ConvertCardAlertModel) {
        guard let coinAlter = Bundle.main.loadNibNamed("LuckCardSucceedAlert", owner: nil, options: nil)?[0] as? LuckCardSucceedAlert else { return }
        view.addSubview(coinAlter)
        layoutAlertView(coinAlter)
        coinAlter.titLabel.text = nil
        coinAlter.statuImage.layer.cornerRadius = 40
        coinAlter.statuImage.addShadow(radius: 10, opacity: 0.7)
        coinAlter.mesgLabel.text = model.msgInfo
        coinAlter.mesgLabel.font = UIFont.boldSystemFont(ofSize: 16)
        coinAlter.mesgLabel.textColor = UIColor.darkText
        coinAlter.commitBtn.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        coinAlter.commitBtn.setTitle(model.commitTitle, for: .normal)
        coinAlter.commitBtn.setTitleColor(.white, for: .normal)
        coinAlter.commitW.constant = 200
        coinAlter.contentVH.constant = 250
        coinAlter.commitBtn.backgroundColor = UIColor(r: 26, g: 168, b: 254, a: 0.9)
        coinAlter.statuImage.image = model.success ? getImage("pictureVip") : getImage("diamond")
        coinAlter.commitActionhandler = {
            self.commitActionHandler?()
            self.dissMiss()
        }
    }
    
    /// 提交找回原账号提示
    func getAcountBackConvertAlter(model: ConvertCardAlertModel) {
        guard let CardConvertAlter = Bundle.main.loadNibNamed("LuckCardSucceedAlert", owner: nil, options: nil)?[0] as? LuckCardSucceedAlert else { return }
        view.addSubview(CardConvertAlter)
        layoutAlertView(CardConvertAlter)
        CardConvertAlter.contenView.backgroundColor = UIColor(white: 0.96, alpha: 1)
        CardConvertAlter.titLabel.textColor = UIColor.darkText
        CardConvertAlter.mesgLabel.textColor = UIColor.gray
        CardConvertAlter.commitBtn.layer.borderColor = UIColor.clear.cgColor
        CardConvertAlter.commitBtn.layer.borderWidth = 0.0
        CardConvertAlter.commitBtn.setTitleColor(UIColor.white, for: .normal)
        CardConvertAlter.titLabel.text = model.title ?? ""
        CardConvertAlter.mesgLabel.text = model.msgInfo ?? ""
        CardConvertAlter.statuImage.image =  model.success ? getImage("cardConvertSucceed") : getImage("cardConvertFailed")
        CardConvertAlter.commitBtn.backgroundColor = ConstValue.kStypeColor
        CardConvertAlter.commitBtn.setTitle(model.success ? "知道了" : "重新找回", for: .normal)
        CardConvertAlter.commitBtn.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        CardConvertAlter.commitActionhandler = {
            self.commitActionHandler?()
            self.dissMiss()
        }
    }
    
   /// 系统提示框
    func getSystemAlter(_ systemModel: String) {
        guard let systemAlert = Bundle.main.loadNibNamed("SystemAlert", owner: nil, options: nil)?[0] as? SystemAlert else { return }
        view.addSubview(systemAlert)
        layoutAlertView(systemAlert)
        systemAlert.titleLable.text = systemModel
        systemAlert.commitBtn.setTitle("知道了", for: .normal)
        systemAlert.closeActionHandler = {
            self.dissMiss()
        }
    }
    
    /// 系統公告
    func getSystemMessagesAlter(_ message: String) {
        guard let systemAlert = Bundle.main.loadNibNamed("SystemAlert", owner: nil, options: nil)?[0] as? SystemAlert else { return }
        view.addSubview(systemAlert)
        layoutAlertView(systemAlert)
        systemAlert.commitBtn.setTitle("知道了", for: .normal)
        systemAlert.setMessages(message)
      
        systemAlert.closeActionHandler = {
            self.closeActionHandler?()
            self.dissMiss()
        }
    }
    
    /// 弹框消失
    func dissMiss() {
        self.dismiss(animated: false, completion: nil)
    }
    
    func exitApp() {
        exit(0)
    }

}


// MARK: - Layout
private extension AlertManagerController {
    
    func layoutAlertView(_ view: UIView) {
        view.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
}
