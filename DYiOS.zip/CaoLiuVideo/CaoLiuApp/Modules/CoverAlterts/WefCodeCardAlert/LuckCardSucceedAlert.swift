
import UIKit

class LuckCardSucceedAlert: UIView {

    @IBOutlet weak var contenView: UIView!
    @IBOutlet weak var commitBtn: UIButton!
    @IBOutlet weak var titLabel: UILabel!
    @IBOutlet weak var mesgLabel: UILabel!
    @IBOutlet weak var statuImage: UIImageView!
    @IBOutlet weak var commitW: NSLayoutConstraint!
    @IBOutlet weak var contentVH: NSLayoutConstraint!
    var commitActionhandler:(() ->())?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        commitBtn.layer.cornerRadius = 17.5
        commitBtn.layer.masksToBounds = true
        contenView.layer.cornerRadius = 8
        contenView.layer.masksToBounds = true
    }
    
    @IBAction func commitAction(_ sender: UIButton) {
        commitActionhandler?()
    }
    
}


class CoinNotEnoughAlert: UIView {
    let contentView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white
        view.layer.cornerRadius = 10
        view.layer.masksToBounds = true
        return view
    }()
    let msgLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 17)
        label.textColor = .darkText
        label.numberOfLines = 2
        return label
    }()
    let cosLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 18)
        label.textColor = .lightGray
        label.text = "x"
        return label
    }()
    lazy var okButton: UIButton = {
        let btn = UIButton(type: .custom)
        btn.backgroundColor = UIColor(r: 26, g: 168, b: 254)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        btn.layer.cornerRadius = 20
        btn.addShadow(radius: 5, opacity: 0.5)
        btn.setTitle("充值鉆石", for: .normal)
        btn.addTarget(self, action: #selector(okClick), for: .touchUpInside)
        return btn
    }()
    var commitActionHandler:(() ->Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(contentView)
        contentView.addSubview(msgLabel)
        contentView.addSubview(okButton)
        contentView.addSubview(cosLabel)
        layoutPageSub()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    @objc func okClick() {
        commitActionHandler?()
    }
    
    func layoutPageSub() {
        contentView.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.height.equalTo(170)
            make.width.equalTo(250)
        }
        cosLabel.snp.makeConstraints { (make) in
            make.top.equalTo(5)
            make.trailing.equalTo(-10)
        }
        msgLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(10)
            make.trailing.equalTo(-10)
            make.bottom.equalTo(contentView.snp.centerY).offset(-10)
        }
        okButton.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(-20)
            make.height.equalTo(40)
            make.width.equalTo(130)
        }
    }
}
