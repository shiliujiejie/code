
import UIKit

class ShareContenView: UIView {

    let textView: InviteTexts = {
        let v = InviteTexts.init(frame: CGRect.zero)
        return v
    }()
    private let customLayout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = ShareContentItemCell.itemSize
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 10
        layout.sectionInset = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        return layout
    }()
    private lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect.zero, collectionViewLayout: customLayout)
        collection.backgroundColor = UIColor.clear
        collection.showsHorizontalScrollIndicator = false
        collection.delegate = self
        collection.dataSource = self
        collection.register(ShareContentItemCell.classForCoder(), forCellWithReuseIdentifier: ShareContentItemCell.cellId)
        collection.register(UINib(nibName: ShareImageItemCell.cellId, bundle: Bundle.main), forCellWithReuseIdentifier: ShareImageItemCell.cellId)
        return collection
    }()
    private lazy var copyButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("復制鏈接", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        button.backgroundColor =  UIColor(r: 0, g: 123, b: 255)
        button.layer.cornerRadius = 20
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return button
    }()
    private lazy var saveButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("保存圖片", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        button.backgroundColor =  UIColor(r: 0, g: 123, b: 255)
        button.layer.cornerRadius = 20
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return button
    }()
    var itemClickHandler:((_ index: Int)->Void)?
    var closebtnClickHadnler:(()->Void)?
    
    var shareModels = [ShareTypeItemModel]()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.white
        addSubview(copyButton)
        addSubview(saveButton)
        addSubview(collectionView)
        addSubview(textView)
     
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    @objc private func buttonClick(_ sender: UIButton) {
       if sender == copyButton {
            AppInfo.share().uploadUserAction([UploadActionsLogApi.kEvent: UploadActionsLogApi.kShare])
            UIPasteboard.general.string = String(format: "%@", ShareContentItemCell.getDownLoadUrl())
            XSAlert.show(type: .success, text: "复制成功！")
        } else if sender == saveButton {
            itemClickHandler?(1)
        }
    }
    
    func setShareModels(_ models: [ShareTypeItemModel]) {
        shareModels = models
        collectionView.reloadData()
    }
    
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension ShareContenView: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return shareModels.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
         let model = shareModels[indexPath.item]
        if model.type == .picture {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShareImageItemCell.cellId, for: indexPath) as! ShareImageItemCell
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShareContentItemCell.cellId, for: indexPath) as! ShareContentItemCell
            cell.setShareTypeModel(model)
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        itemClickHandler?(indexPath.item)
    }
    
}

// MARK: - Layout
private extension ShareContenView {
    func layoutPageSubviews() {
        layoutCopyButton()
        layoutSaveButton()
        layoutCollection()
    }
    func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.bottom.equalTo(copyButton.snp.top).offset(-22)
            make.height.equalTo((screenWidth-30)*2/3 + 20)
        }
        textView.snp.makeConstraints { (make) in
            make.bottom.equalTo(collectionView.snp.top).offset(-10)
            make.top.leading.trailing.equalToSuperview()
        }
    }
    func layoutCopyButton() {
        copyButton.snp.makeConstraints { (make) in
            make.bottom.equalTo(UIDevice.current.isiPhoneXSeriesDevices() ? -54 : -20)
            make.leading.equalTo(20)
            make.trailing.equalTo(self.snp.centerX).offset(-12)
            make.height.equalTo(40)
        }
    }
    func layoutSaveButton() {
        saveButton.snp.makeConstraints { (make) in
            make.trailing.equalTo(-20)
            make.leading.equalTo(self.snp.centerX).offset(12)
            make.centerY.equalTo(copyButton)
            make.height.equalTo(40)
        }
    }
    
}

class InviteTexts: UIView {
    
    let shareInview: ShareInView = {
        let v = ShareInView(frame: .zero)
        v.isHidden = true
        return v
    }()

    let pLabel: ActiveLabel = {
        let l = ActiveLabel()
        l.font = UIFont.boldSystemFont(ofSize: 21)
        l.numberOfLines = 0
        l.textColor = .white
        return l
    }()

    lazy var setInviteCode: UIButton = {
        let btn = UIButton(type: .custom)
        btn.addTarget(self, action: #selector(invviteBtnClick), for: .touchUpInside)
        return btn
    }()
    var inviteAction:(() -> Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(pLabel)
        addSubview(shareInview)
        addSubview(setInviteCode)
        layoutSub()
        setUpUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setUpUI() {
        let code = UserModel.share().user?.code ?? ""
        let p = "\(AppInfo.share().shareInfo?.ini_people ?? "")"
        let c = AppInfo.share().shareInfo?.ini_content ?? "10万部"
        let s = "\(AppInfo.share().shareInfo?.ini ?? "")"
        let vip = UserModel.share().user?.is_vip == "y" ? "\(UserModel.share().user?.vip_expired_text ?? "")" : "您还不是vip会员"
        let all = "每邀请 \(AppInfo.share().shareInfo?.ini_people ?? "") 送 \(AppInfo.share().shareInfo?.ini ?? "") 会员\n\(c) 视频无限观看\n\(vip)\n我的邀请码: \(code)"
        let customType = ActiveType.custom(pattern: "\\s\(p)\\b")
        let customType2 = ActiveType.custom(pattern: "\\s\(s)\\b")
        let customType3 = ActiveType.custom(pattern: "\\s\(code)\\b")
        let customType4 = ActiveType.custom(pattern: "\\s\(c)\\b")
        pLabel.enabledTypes.append(customType)
        pLabel.enabledTypes.append(customType2)
        pLabel.enabledTypes.append(customType3)
        pLabel.enabledTypes.append(customType4)
        pLabel.attributedText = TextSpaceManager.getAttributeStringWithString(all, lineSpace: 4)
        pLabel.customize { label in
            
            label.numberOfLines = 0
            label.lineSpacing = 4
            
            label.customColor[customType] = ConstValue.kStypeColor
            label.customSelectedColor[customType] = ConstValue.kStypeColor
            label.customColor[customType2] = ConstValue.kStypeColor
            label.customSelectedColor[customType2] = ConstValue.kStypeColor
            label.customColor[customType3] = ConstValue.kStypeColor
            label.customSelectedColor[customType3] = ConstValue.kStypeColor
            label.customColor[customType4] = ConstValue.kStypeColor
            label.customSelectedColor[customType4] = ConstValue.kStypeColor
        }
        pLabel.frame = CGRect(x: 15, y: safeAreaTopHeight + 15, width: screenWidth - 30, height: 200)
        shareInview.recPLabel.text = "推广业绩:\(UserModel.share().user?.bill ?? "0")"
        shareInview.recMLabel.text = "收益余额:\(UserModel.share().user?.balance ?? "0")"
        shareInview.shareWebinHandler = { [weak self] in
            self?.inviteAction?()
        }
    }
    @objc func invviteBtnClick() {
        inviteAction?()
    }
    
    func layoutSub() {
        let topMargin: CGFloat = UIDevice.current.isiPhoneXSeriesDevices() ? 15 : 5
        pLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(10)
            make.width.equalTo(screenWidth - 30)
        }
       
        shareInview.snp.makeConstraints { (make) in
            make.top.equalTo(pLabel.snp.bottom).offset(topMargin)
            make.height.equalTo(62)
            make.leading.equalTo(pLabel)
            make.trailing.equalTo(-15)
        }
        setInviteCode.snp.makeConstraints { (make) in
            make.edges.equalTo(shareInview)
        }
    }
}
