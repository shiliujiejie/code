
import UIKit
import DouYinScan

class ShareImageItemCell: UICollectionViewCell {
    
    static let cellId = "ShareImageItemCell"
    
    @IBOutlet weak var shareImage: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        contentView.backgroundColor = UIColor(white: 0.95, alpha: 1)
        contentView.layer.cornerRadius = 9
        contentView.layer.masksToBounds = true
        if let imagerl = AppInfo.share().shareInfo?.cover, !imagerl.isEmpty {
            shareImage.kfSetVerticalImageWithUrl(imagerl)
        } else {
            let image = getImage("defaultShare3")
            shareImage.image = image
        }
    }

}
