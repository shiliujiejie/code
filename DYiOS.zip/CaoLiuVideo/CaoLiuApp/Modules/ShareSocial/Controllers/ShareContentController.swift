
import UIKit
import NicooNetwork

/// 分享弹出页面
class ShareContentController: CLBaseViewController, CLNavigationBarDelegate {
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.titleLabel.text = "邀请赢福利"
        bar.navBackBlack = false
        bar.delegate = self
        return bar
    }()
    private let shareView: ShareContenView = {
        let view = ShareContenView(frame: CGRect.zero)
        view.backgroundColor = ConstValue.kVcViewColor
        return view
    }()
    private lazy var clearTapView: UIButton = {
        let view = UIButton(type: .custom)
        view.backgroundColor = UIColor.clear
        view.addTarget(self, action: #selector(shareComtentViewDissMiss), for: .touchUpInside)
        return view
    }()
    
    private lazy var imageVc: ShareImageController = {
        let bigVc = ShareImageController()
       return bigVc
    }()
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(navBar)
        view.addSubview(shareView)
        layoutoPageSubviews()
        shareView.setShareModels(getShareTypeModels())
        shareView.closebtnClickHadnler = { [weak self] in
            UserModel.share().shareText  = nil
            UserModel.share().shareImageLink = nil
            self?.dismiss(animated: false, completion: nil)
        }
        shareView.itemClickHandler = { [weak self] (index) in
            guard let strongSelf = self else { return }
            if index == 0 {
                AppInfo.share().uploadUserAction([UploadActionsLogApi.kEvent: UploadActionsLogApi.kShare])
                self?.shareText(ShareContentItemCell.getDefaultContentString())
            } else if index == 1 {
                strongSelf.imageVc.model = self?.getShareTypeModels()[index]
                strongSelf.imageVc.modalPresentationStyle = .fullScreen
                strongSelf.present(strongSelf.imageVc, animated: true, completion: nil)
            } else {
                AppInfo.share().uploadUserAction([UploadActionsLogApi.kEvent: UploadActionsLogApi.kShare])
                self?.share()
            }
        }
        shareView.textView.inviteAction = { [weak self] in
            if let urlw = URL(string: "\(UserModel.share().authInfo?.config?.sys?.invite_h5 ?? "")?height=\(statusBarHeight)") {
                let aa = AAViewController(url: urlw)
                self?.navigationController?.pushViewController(aa, animated: true)
            }
        }
    }
    
    @objc private func shareComtentViewDissMiss() {
        UserModel.share().shareText  = nil
        UserModel.share().shareImageLink = nil
        backAction()
    }
    func backAction() {
        navigationController?.popViewController(animated: true)
    }

}

// MARK: - funcs
private extension ShareContentController {
    func getShareTypeModels() -> [ShareTypeItemModel] {
        let shareImageLink = UserModel.share().shareImageLink
        let shareText = UserModel.share().shareText
        let textModel = ShareTypeItemModel.init(title: "分享鏈接", content:  shareText, imageUrl: nil, type: .text)
        let imageModel = ShareTypeItemModel.init(title: "分享圖片", content: shareText, imageUrl: shareImageLink, type: .picture)
      //  let linkModel = ShareTypeItemModel.init(title: "分享链接", content: shareText, imageUrl: nil, type: .textLink)
        return [textModel, imageModel]
    }
}


// MARK: - Layout
private extension ShareContentController {
    func layoutoPageSubviews() {
        layoutNavbar()
        layoutShareView()
    }
    func layoutNavbar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(safeAreaTopHeight)
        }
    }
    func layoutShareView() {
        shareView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
            make.top.equalTo(navBar.snp.bottom)
        }
    }
    func layoutClearView() {
        clearTapView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.bottom.equalTo(shareView.snp.top)
        }
    }
}
