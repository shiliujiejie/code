//
//  SearchRefromer.swift
//  CaoLiuApp
//
//  Created by mac on 2019/10/10.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import Foundation
import NicooNetwork

class SearchReformer: NSObject {
    
    //MARK: - 搜索主页接口
    private func searchMainDataListDatas(_ data: Data?) -> Any? {
        if let model = try? decode(response: data, of: ObjectResponse<SearchMainModel>.self)?.data {
            return model
        }
        return nil
    }
    //MARK: - 搜索 频道 视频列表
    private func searchChannelListDatas(_ data: Data?) -> Any? {
        if let model = try? decode(response: data, of: ObjectResponse<SearchChannel>.self)?.data {
            return model
        }
        return nil
    }
    //MARK: - 模块详情
    private func moduleDetailDatas(_ data: Data?) -> Any? {
        if let model = try? decode(response: data, of: ObjectResponse<ModuleDetailModel>.self)?.data {
            return model
        }
        return nil
    }
    //MARK: - 搜索推荐关键字
    private func searchKeyRecommendListDatas(_ data: Data?) -> Any? {
        if let keyList = try? decode(response: data, of: ObjectResponse<[SearchHotTips]>.self)?.data {
            return keyList
        }
        return nil
    }
    //MARK: - 搜索视频
    private func searchVideoListDatas(_ data: Data?) -> Any? {
        if let videoList = try? decode(response: data, of: ObjectResponse<[VideoNew]>.self)?.data {
            return videoList
        }
        return nil
    }
    /// 热门视频
    private func searchVideoHotDatas(_ data: Data?) -> Any? {
        if let videoList = try? decode(response: data, of: ObjectResponse<[VideoNew]>.self)?.data {
            return videoList
        }
        return nil
    }
    //MARK: -搜索用户
    private func searchUserListDatas(_ data: Data?) -> Any? {
        if let userList = try? decode(response: data, of: ObjectResponse<[CLUserInfo]>.self)?.data {
            return userList
        }
        return nil
    }
    //MARK: -推荐用户
    private func recommandUserListDatas(_ data: Data?) -> Any? {
        if let userList = try? decode(response: data, of: ObjectResponse<[CLUserInfo]>.self)?.data {
            return userList
        }
        return nil
    }
    //MARK: -用户分组
     private func userListDatas(_ data: Data?) -> Any? {
         if let userList = try? decode(response: data, of: ObjectResponse<[UserGroupModel]>.self)?.data {
             return userList
         }
         return nil
     }
}
// MARK: - NicooAPIManagerDataReformProtocol
extension SearchReformer: NicooAPIManagerDataReformProtocol {
    func manager(_ manager: NicooBaseAPIManager, reformData jsonData: Data?) -> Any? {
        if manager is SearchMainDataApi {
            return searchMainDataListDatas(jsonData)
        }
        if manager is SearchModuleApi {
            return searchChannelListDatas(jsonData)
        }
        if manager is SearchRecomApi || manager is SearchModuleApi || manager is SearchHotTextApi {
            return searchKeyRecommendListDatas(jsonData)
        }
        if manager is SearchVideoApi {
            return searchVideoListDatas(jsonData)
        }
        if manager is SearchRecActorApi || manager is RelationActorApi{
            return recommandUserListDatas(jsonData)
        }
        if manager is SearchUserApi {
            return searchUserListDatas(jsonData)
        }
        if manager is SearchHotVideoApi  {
            return searchVideoHotDatas(jsonData)
        }
        if manager is UserListApi {
            return userListDatas(jsonData)
        }
        if manager is TipsTypesDetailApi {
            return moduleDetailDatas(jsonData)
        }
        return nil
    }
}
