//
//  SearchApis.swift
//  CaoLiuApp
//
//  Created by mac on 2019/10/10.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import Foundation
import NicooNetwork

// 搜索热门视频Api
class SearchHotVideoApi: XSVideoBaseAPI {

    static let kIslong = "is_long"
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/search/list/hot"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
    
}
/// 搜多推荐关键字
class SearchRecomApi: XSVideoBaseAPI {
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/search/tag/hot"
    }
    override func shouldCache() -> Bool {
        return true
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}
/// 搜索推荐主播
class SearchRecActorApi: XSVideoBaseAPI {
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/search/anchor/hot"
    }
    override func shouldCache() -> Bool {
        return true
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

/// 推荐关联主播
class RelationActorApi: XSVideoBaseAPI {
    static let kIslong = "is_long"
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/relation/anchor"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}


/// 用户搜索主页
class SearchMainDataApi: XSVideoBaseAPI {
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/search/index"
    }
    
    override func shouldCache() -> Bool {
        return true
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}
// 用户热搜
class SearchHotTextApi: XSVideoBaseAPI {
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/video/keyword/random/list"
    }
    
    override func shouldCache() -> Bool {
        return true
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

/// 搜索内模块id 搜索
class SearchModuleApi: XSVideoBaseAPI {
    static let kChannelId = "id"
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/search/index/tag/video"
    }
    
    override func shouldCache() -> Bool {
        return true
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

/// 搜索视频
class SearchVideoApi: XSVideoBaseAPI {
    // 分页参数
    static let kTitle = "title"
    static let kKeywords = "keywords"
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kIslong = "is_long"
    /// 用于模块详情
    static let kTypeId = "type_id"
    /// 用于标签详情
    static let kTag_id = "tag_id"
    /// 外部参数
    static let kOrder_key = "order_key"
    /// 最新
    static let kOrder_keyOnline_at = "online_at"
    /// 点赞最多
    static let kOrder_keyLike = "like"
    /// 播放最多
    static let kPlayCount = "play"
    static let kPaytype = "paytype"        ///付费类型：1-vip  2-钻石 3-免费
    static let kUserCode = "code"
    static let kDefaultCount = 10
    
    var isHot: Bool = false
    
    var pageNumber: Int = 1
    
    // MARK: - Public method
    
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return isHot ? "app/api/search/user/list" : "app/api/search/list"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var newParams: [String: Any] = [SearchVideoApi.kPageNumber: pageNumber,
                                        SearchVideoApi.kPageCount: SearchVideoApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        self.pageNumber += 1
    }
}

///搜索用户
class SearchUserApi: XSVideoBaseAPI {
    static let kKeywords = "keywords"
    static let kGroup_id = "group_id"
    // 分页参数
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kDefaultCount = 10
    
    var pageNumber: Int = 1
    
    var isSearch: Bool = false
    
    // MARK: - Public method
    
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return isSearch ? "app/api/search/anchor" : "app/api/search/anchor/more"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var newParams: [String: Any] = [SearchUserApi.kPageNumber: pageNumber,
                                        SearchUserApi.kPageCount: SearchUserApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        self.pageNumber += 1
    }
}

/// 推荐主播分组列表
class UserListApi: XSVideoBaseAPI {
    // 分页参数
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kDefaultCount = 5
    
    var pageNumber: Int = 1
    
    // MARK: - Public method
    
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/search/anchor/group"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var newParams: [String: Any] = [UserListApi.kPageNumber: pageNumber,
                                        UserListApi.kPageCount: UserListApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        self.pageNumber += 1
    }
}



/// 推荐视频
class RecommentVideoApi: XSVideoBaseAPI {
    // 分页参数
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kDefaultCount = 20
    
    var pageNumber: Int = 1
    
    // MARK: - Public method
    
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/video/attention"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var newParams: [String: Any] = [RecommentVideoApi.kPageNumber: pageNumber,
                                        RecommentVideoApi.kPageCount: RecommentVideoApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        self.pageNumber += 1
    }
}
