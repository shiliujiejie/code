
import UIKit
import MJRefresh
import NicooNetwork

class MdMoreListController: CLBaseViewController {
    
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.navBackBlack = false
        bar.backgroundColor = ConstValue.kVcViewColor
        bar.delegate = self
        return bar
    }()
    private let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
    lazy var collectionView: CustomcollectionView = {
        let collection = CustomcollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.clear
        collection.register(ShortVideoCell.classForCoder(), forCellWithReuseIdentifier: ShortVideoCell.cellId)
        collection.register(SearchLongVideoCell.classForCoder(), forCellWithReuseIdentifier: SearchLongVideoCell.cellId)
        collection.mj_footer = loadMoreView
        collection.mj_header = refreshView
        return collection
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        let loadmore = MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
        loadmore?.setTitle("", for: .idle)
        loadmore?.setTitle("已經到底了", for: .noMoreData)
        loadmore?.stateLabel.font = ConstValue.kRefreshLableFont
        return loadmore!
    }()
    
    lazy private var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.loadFirstPage()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        mjRefreshHeader?.stateLabel.font = ConstValue.kRefreshLableFont
        mjRefreshHeader?.lastUpdatedTimeLabel.font = ConstValue.kRefreshLableFont
        return mjRefreshHeader!
    }()
    
    private lazy var videoMoreApi: VideoMoreListApi =  {
        let api = VideoMoreListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    
    var listViewDidScrollCallback: ((UIScrollView) -> ())?
    /// 选中index
    var selectIndex:Int = 0
    var cateModels = [VideoNew]()
    /// 模块ID
    var moduleID: Int?
    var moduleName: String?
    var islong: Bool = false
    
    // MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpNavBar()
        view.addSubview(collectionView)
        layoutPageSubviews()
        loadData()
    }
    
    
    func setUpNavBar() {
        view.addSubview(navBar)
        navBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(safeAreaTopHeight)
        }
        navBar.titleLabel.text = moduleName
        navBar.addShadow(opacity: 0.5, position: 3, pathWidth: 1, UIColor(white: 0.96, alpha: 1))
    }
    private func goUserCenter(_ user: CLUserInfo?) {
        let userCenter = UserMCenterController()
        userCenter.userCode = user?.code
        navigationController?.pushViewController(userCenter, animated: true)
    }
    
}

// MARK: - Private - Funcs
private extension MdMoreListController {
    
    func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: true)
        let _ = videoMoreApi.loadData()
        
        
    }
    func loadFirstPage() {
        NicooErrorView.removeErrorMeesageFrom(view)
        let _ = videoMoreApi.loadData()
        
    }
    func loadNextPage() {
        
        let _ = videoMoreApi.loadNextPage()
    }
    func endRefreshing() {
        collectionView.mj_footer.endRefreshing()
        collectionView.mj_header.endRefreshing()
    }
    
    func succeedRequest(_ models: [VideoNew]) {
        if videoMoreApi.pageNumber == 1 {
            cateModels = models
            if cateModels.count == 0 {
                NicooErrorView.showErrorMessage(.noData, "暂无更多数据", on: view, topMargin: safeAreaTopHeight) {
                    self.loadData()
                }
            }
        } else {
            cateModels.append(contentsOf: models)
        }
        loadMoreView.isHidden = models.count == 0
        endRefreshing()
        collectionView.reloadData()
    }
    
    func failedRequest(_ manager: NicooBaseAPIManager) {
        endRefreshing()
        NicooErrorView.showErrorMessage(.noNetwork, on: view, topMargin: 0, clickHandler: {
            self.loadData()
        })
    }
}

// MARK: - UICollectionViewDelegateFlowLayout
extension MdMoreListController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return islong ? SearchLongVideoCell.itemSize : ShortVideoCell.itemSizeThird
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return islong ? 10 : 5.0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return islong ? 0 : 5.0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return islong ? UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5) : UIEdgeInsets(top: 5, left: 10, bottom: 5, right: 10)
    }
    
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension MdMoreListController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return cateModels.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if islong {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SearchLongVideoCell.cellId, for: indexPath) as! SearchLongVideoCell
            let model = cateModels[indexPath.row]
            cell.setModel(model)
            cell.avataClickHandler = { [weak self] in
                self?.goUserCenter(model.user)
            }
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShortVideoCell.cellId, for: indexPath) as! ShortVideoCell
            let model = cateModels[indexPath.row]
            cell.setModel(model: model)
            cell.avataClickHandler = { [weak self] in
                self?.goUserCenter(model.user)
            }
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        if islong {
            goLongVideoDetail(cateModels[indexPath.item])
        } else {
            goShortVideoPlayerVC(cateModels[indexPath.item])
        }
    }
}



// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension MdMoreListController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        return [VideoMoreListApi.kModule: moduleID ?? 0, VideoMoreListApi.kIslong: islong]
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is VideoMoreListApi {
            if let videoList = manager.fetchJSONData(VideoReformer()) as? [VideoNew] {
                succeedRequest(videoList)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        failedRequest(manager)
    }
}

extension MdMoreListController: CLNavigationBarDelegate {
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}

// MARK: - Layout
private extension MdMoreListController {
    
    func layoutPageSubviews() {
        layoutCollection()
    }
    
    func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(navBar.snp.bottom)
            make.leading.bottom.trailing.equalToSuperview()
        }
    }
}
