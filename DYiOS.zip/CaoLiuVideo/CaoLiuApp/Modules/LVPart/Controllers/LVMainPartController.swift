

import UIKit
import JXSegmentedView
import NicooNetwork

class LVMainPartController: CLBaseViewController {
    let barCoverLayer: CAGradientLayer = {
        let ly = CAGradientLayer()
        ly.colors = [UIColor.clear.cgColor,UIColor.clear.cgColor]
        ly.locations = [0.0,1.0]
        ly.frame = CGRect(x: 0, y: 0, width: screenWidth, height: statusBarHeight + 88)
        return ly
    }()
    let topBgImage: UIImageView = {
        let v = UIImageView()
        v.isUserInteractionEnabled = true
        v.backgroundColor = .clear
        return v
    }()
    let searchBar: SearchBarView = {
        let v = SearchBarView.init(frame: CGRect.zero)
        v.backgroundColor = .clear
        v.textLab.textColor = .white
        return v
    }()
    lazy var recordBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setImage(getImage("pushVideoIcon"), for: .normal)
        btn.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return btn
    }()
    lazy var historyBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setImage(getImage("historyWatch"), for: .normal)
        btn.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return btn
    }()
    
    var titles = [String]()
    let dataSource = JXSegmentedTitleDataSource()
    let segmentedView = JXSegmentedView()
    lazy var listContainerView: JXSegmentedListContainerView! = {
        return JXSegmentedListContainerView(dataSource: self)
    }()
    var showTFtimeTips: Bool = false
    
    var channels = [ChannelModel]()
    private let viewModel = VideoViewModel()
    let userViewModel = UserInfoViewModel()
    
    let list1 = FocusVideoController()

    override func viewDidLoad() {
        super.viewDidLoad()
        uploadExceptionLogWithData()
        view.backgroundColor = .clear
        NotificationCenter.default.addObserver(self, selector: #selector(didUserBeenKickedOut), name: Notification.Name.kUserBeenLogOutNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(topBarColorChange(_:)), name: Notification.Name.kMainTopBarColotNotification, object: nil)
        loadShareApi()
        loadAdInfoApi()
        setUpUI()
        loadChannels()
        /// 延迟三秒弹起。版本更新框
        perform(#selector(showActivityAlert), with: nil, afterDelay: 2)
    }
    func loadChannels() {
        NicooErrorView.removeErrorMeesageFrom(view)
        viewModel.loadChannelListData(nil) { [weak self] (models) in
            self?.channels = models
            self?.setUpPage()
        } failHandler: { [weak self] (error) in
            guard let strongSelf = self else { return }
            NicooErrorView.showErrorMessage(.noNetwork, on: strongSelf.view,topMargin: safeAreaTopHeight + 30) {
                strongSelf.loadChannels()
            }
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if !showTFtimeTips {
            /// tf到期时间提示
            showTFtimeTips()
            showTFtimeTips = true
        }
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        listContainerView.frame = CGRect(x: 0, y: statusBarHeight + 88, width: view.bounds.size.width, height: view.bounds.size.height - statusBarHeight - 88)
    }
    
    func setUpPage() {
        var titleHave = [String]()
        titleHave.append(contentsOf: ["关注"])
        if channels.count > 0 {
            let strs = channels.map { (model) -> String in
                return model.title ?? "未知"
            }
            titleHave.append(contentsOf: strs)
        }
        titles = titleHave
        dataSource.titles = titles
        dataSource.titleNormalFont = UIFont.boldSystemFont(ofSize: 16)
        dataSource.titleSelectedFont = UIFont.boldSystemFont(ofSize: 20)
        dataSource.titleNormalColor = UIColor(white: 1, alpha: 0.75)
        dataSource.titleSelectedColor = .white
        dataSource.itemSpacing = 20
        dataSource.isItemSpacingAverageEnabled = false
    
        let indicator = JXSegmentedIndicatorBackgroundView()
        indicator.indicatorColor = ConstValue.kStypeColor
        indicator.isIndicatorConvertToItemFrameEnabled = true
        indicator.indicatorCornerRadius = 4
        indicator.indicatorHeight = 28
        segmentedView.frame = CGRect(x: 0, y: statusBarHeight + 44, width: screenWidth, height: 44)
        segmentedView.dataSource = dataSource
        segmentedView.defaultSelectedIndex = 1
        //segmentedView.indicators = [indicator]
        
        view.addSubview(segmentedView)
        segmentedView.listContainer = listContainerView
        view.addSubview(listContainerView)
    }
    private func setUpUI() {
        view.insertSubview(topBgImage, at: 0)
        topBgImage.layer.insertSublayer(barCoverLayer, at: 0)
        view.addSubview(recordBtn)
        view.addSubview(historyBtn)
        view.addSubview(searchBar)
        searchBar.barClickAction = { [weak self] (action)in
            if action == 1 {
                let v = SearchMainController()
                self?.navigationController?.pushViewController(v, animated: true)
            } else if action == 2 {
                let v = TypesCategrayController()
                self?.navigationController?.pushViewController(v, animated: true)
            }
        }
        topBgImage.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(statusBarHeight + 88)
        }
        recordBtn.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(statusBarHeight + 10)
            make.height.width.equalTo(23)
        }
        historyBtn.snp.makeConstraints { (make) in
            make.leading.equalTo(recordBtn.snp.trailing).offset(15)
            make.top.equalTo(statusBarHeight + 10)
            make.height.width.equalTo(23)
        }
        searchBar.snp.makeConstraints { (make) in
            make.leading.equalTo(historyBtn.snp.trailing).offset(5)
            make.trailing.equalToSuperview()
            make.top.equalTo(statusBarHeight)
            make.height.equalTo(44)
        }
    }
    @objc func buttonClick(_ sender: UIButton) {
        if sender == recordBtn {
            if let canUpload = UserModel.share().user?.upload_auth, !canUpload.isEmpty {
                let vc = CreateCenterController()
                navigationController?.pushViewController(vc, animated: true)
            } else {
                if let h5 = UserModel.share().authInfo?.config?.rule?.create_h5, !h5.isEmpty {
                    self.goInnerLink("urlself://\(h5)")
                }
            }
        }
        if sender == historyBtn {
            let vc = WatchRecordMainCcontroller()
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @objc func topBarColorChange(_ notif: Notification) {
        guard let autoColor = notif.userInfo?["AutoTopBarBgColor"] as? Int else {
            topBgImage.backgroundColor = .clear
            return
        }
        if let index = notif.userInfo?["SegIndex"] as? Int {
            let channel = channels[index - 1]
            if channel.type == .Module {
                if let offsetY = notif.userInfo?["OffSetY"] as? Int {
                    if autoColor == 1 && offsetY < Int(BannerScrollCellBgImg.itemSize.height) {
                        if let hexColor = channel.background, !hexColor.isEmpty {
                            fixBarColor(true, hexColor)
                        } else {
                            fixBarColor(false)
                        }
                    } else {
                        fixBarColor(false)
                    }
                }
            } else {
                if let hexColor = channel.background, !hexColor.isEmpty, autoColor == 1 {
                    fixBarColor(true, hexColor)
                } else {
                    fixBarColor(false)
                }
            }
        } else {
            fixBarColor(false)
        }
    }
    
    private func fixBarColor(_ autoChange: Bool, _ hexColor: String? = "") {
        if autoChange {
            topBgImage.backgroundColor = UIColor(hexadecimalString: hexColor ?? "")
            barCoverLayer.colors = [UIColor(white: 0.0, alpha: 0.1).cgColor, UIColor(white: 0.0, alpha: 0.1).cgColor]
        } else {
            topBgImage.backgroundColor = .clear
            barCoverLayer.colors = [UIColor.clear.cgColor, UIColor.clear.cgColor]
        }
    }
}

extension LVMainPartController {
    // 账号失效/强制更新
    @objc private func didUserBeenKickedOut(_ notif: Notification) {
        if let code = notif.userInfo?["code"] as? Int, let delegate = UIApplication.shared.delegate as? AppDelegate {
            if code == 403 {
                delegate.window?.rootViewController?.showDialog(title: "账号切换提示", message: XSAlertMessages.kNotAvailTokenAlertMsg, okTitle: "退出重进", cancelTitle: nil, okHandler: {
                    exit(0)
                }, cancelHandler: nil)
            } else if code == 4999 {
                delegate.window?.rootViewController?.showDialog(title: "版本更新提示", message: XSAlertMessages.kUpdateAppAlertMsg, okTitle: "退出重进", cancelTitle: nil, okHandler: {
                    exit(0)
                }, cancelHandler: nil)
            }
        }
    }
}

extension LVMainPartController {
    /// 系統公告
    @objc func showSystemMsgAlert() {
        if let message = UserModel.share().authInfo?.config?.sys?.app_notice_ios, !message.isEmpty {
            let controller = AlertManagerController(system: message)
            controller.view.backgroundColor = UIColor(white: 0, alpha: 0.7)
            controller.modalPresentationStyle = .overCurrentContext
            self.modalPresentationStyle = .currentContext
            self.present(controller, animated: true, completion: nil)
        }
    }
    /// 活动弹框
    @objc func showActivityAlert() {
        if let cover = UserModel.share().authInfo?.skip?.cover, !cover.isEmpty {
            let controller = ActivityAlertController(activityIcon: cover)
            controller.modalPresentationStyle = .overCurrentContext
            self.modalPresentationStyle = .currentContext
            self.present(controller, animated: false, completion: nil)
            controller.actionClcick = { actionId in
                if actionId == 1 {
                    if let link = UserModel.share().authInfo?.skip?.link, !link.isEmpty {
                        self.goInnerLink(link,"skip")
                    }
                } else {
                    controller.dismiss(animated: false) {
                        self.showSystemMsgAlert()
                    }
                }
            }
        } else {
            showSystemMsgAlert()
        }
    }
}

extension LVMainPartController: JXSegmentedListContainerViewListDelegate {
    func listView() -> UIView {
        return view
    }
}

extension LVMainPartController: JXSegmentedListContainerViewDataSource {
    func numberOfLists(in listContainerView: JXSegmentedListContainerView) -> Int {
        if let titleDataSource = segmentedView.dataSource as? JXSegmentedBaseDataSource {
            return titleDataSource.dataSource.count
        }
        return 0
    }

    func listContainerView(_ listContainerView: JXSegmentedListContainerView, initListAt index: Int) -> JXSegmentedListContainerViewListDelegate {
        if index == 0 {
            return list1
        } else {
            let channel = channels[index - 1]
            let type = channel.type ?? ModulePageType.Module
            let list2 = LVModulesController()
            if type == .Module {
                list2.segIndex = index
                list2.channel = channel
                /// 只有在配置了顶部bar 颜色时调用
                list2.scrollOffSetYHandler = { [weak self] (offsetY, index) in
                    guard let strongSelf = self else { return }
                    if offsetY >= BannerScrollCellBgImg.itemSize.height {
                        self?.topBgImage.backgroundColor = .clear
                    } else {
                        if let hexColor = strongSelf.channels[index - 1].background, !hexColor.isEmpty {
                            self?.fixBarColor(true, hexColor)
                        } else {
                            self?.fixBarColor(false)
                        }
                    }
                }
                return list2

            } else if type == .H5 {
                if let urlstr = channel.url, !urlstr.isEmpty, let url = URL(string: urlstr) {
                    let h5VC = AAViewController.init(url: url)
                    h5VC.position = .InModule
                    h5VC.segIndex = index
                    h5VC.scrollOffSetYHandler = { [weak self] (offsetY, index) in
                        guard let strongSelf = self else { return }
                        if offsetY >= BannerScrollCellBgImg.itemSize.height {
                            self?.topBgImage.backgroundColor = .clear
                        } else {
                            if let hexColor = strongSelf.channels[index - 1].background, !hexColor.isEmpty {
                                self?.fixBarColor(true, hexColor)
                            } else {
                                self?.fixBarColor(false)
                            }
                        }
                    }
                    return h5VC
                }
            } else if type == .Game {
                let vc = GameListControlller()
                vc.position = .InModule
                vc.segIndex = index
                return vc
            }
        }
        let defaultVC = AAViewController(url: URL(string: UserModel.share().authInfo?.config?.sys?.share_url ?? "")!)
        return defaultVC
    }
}


extension LVMainPartController {
    
    func loadShareApi() {
        /// 请求分享数据
        let _ = viewModel.loadShareApi()
    }
    
    /// 请求分享数据并下载开屏广告
    func loadAdInfoApi() {
        /// 处理广告
        if let adInfo = UserModel.share().authInfo?.startup {
            loadAdSplashInfoSuccess(adInfo)
        } else {
            removeLauchAd()
        }
    }
    
    func loadAdSplashInfoSuccess(_ adInfo: AdSplashModel) {
        guard let adPath = adInfo.cover, let adLink = adInfo.link else {
            removeLauchAd()
            return
        }
        if adPath.isEmpty || adLink.isEmpty {
            removeLauchAd()
            return
        }
        if let saveAdSplashUrl = UserDefaults.standard.string(forKey: UserDefaults.kAdDataUrl), let saveLink = UserDefaults.standard.string(forKey: UserDefaults.kAdLinkUrl) , saveAdSplashUrl == adPath, saveLink == adLink {
            DLog("此广告与上次打开时广告相同。")
            return
        }
        // 下载广告图片
        if let url = URL(string: adPath) {
            AdvertisementView.downLoadADDataWith(url)
        }
       
        /// 存储广告跳转链接
        if let href = adInfo.link, !href.isEmpty {
            UserDefaults.standard.set(href, forKey: UserDefaults.kAdLinkUrl)
        }
    }
   
    func removeLauchAd() {
        if UserDefaults.standard.value(forKey: UserDefaults.kAdDataUrl) != nil {
            UserDefaults.standard.removeObject(forKey: UserDefaults.kAdDataUrl)
        }
        if UserDefaults.standard.value(forKey: UserDefaults.kAdLinkUrl) != nil {
            UserDefaults.standard.removeObject(forKey: UserDefaults.kAdLinkUrl)
        }
    }
}

extension LVMainPartController {
    
    private func uploadExceptionLogWithData() {
        let path = TBUncaughtExceptionHandler.shared.getdataPath()
        let data = NSData(contentsOfFile: path)
        if data != nil {
            if let crushStr = String(data: data! as Data, encoding: String.Encoding.utf8), !crushStr.isEmpty {
                let params : [String : Any] = [UploadCrashLogApi.kError_message: crushStr,
                UploadCrashLogApi.kDevice_code: UIDevice.current.getIdfv(),
                UploadCrashLogApi.kPlatform: "I",
                UploadCrashLogApi.kVersion: XSVideoService.appVersion,
                UploadCrashLogApi.kUa: UIDevice.current.iosType(),UploadCrashLogApi.kCode: "0"]
                userViewModel.uploadCrashLog(params)
            }
        }
    }

}
