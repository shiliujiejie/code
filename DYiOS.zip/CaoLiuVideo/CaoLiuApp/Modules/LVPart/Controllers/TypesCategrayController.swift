
import UIKit
import MJRefresh
import NicooNetwork
import JXSegmentedView

extension TypesCategrayController: JXSegmentedListContainerViewListDelegate {
    func listView() -> UIView {
        return self.view
    }
}
class TypesCategrayController: UIViewController {
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.backgroundColor = ConstValue.kVcViewColor
        bar.navBackBlack = false
        bar.delegate = self
        return bar
    }()
    private lazy var searchBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(getImage("communitySeachIcon"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        button.setTitleColor(ConstValue.kStypeColor, for: .normal)
        button.addTarget(self, action: #selector(searchBtnClick), for: .touchUpInside)
        return button
    }()
    lazy var collectionView: UICollectionView = {
        let layout = WaterfallMutiSectionFlowLayout()
        layout.sectionHeadersPinToVisibleBounds = true
        layout.delegate = self
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.showsVerticalScrollIndicator = false
        collection.backgroundColor = UIColor.clear
        collection.register(ShortVideoCell.classForCoder(), forCellWithReuseIdentifier: ShortVideoCell.cellId)
        collection.register(LongVideoCell.classForCoder(), forCellWithReuseIdentifier: LongVideoCell.cellId)
        collection.register(ADRandomCell.classForCoder(), forCellWithReuseIdentifier: ADRandomCell.cellId)
        collection.register(SegmentItemView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: SegmentItemView.identifier)
        collection.register(SegItemDoubleView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: SegItemDoubleView.identifier)
        collection.mj_footer = loadMoreView
        return collection
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        let loadmore = MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
        loadmore?.setTitle("", for: .idle)
        loadmore?.setTitle("已經到底了", for: .noMoreData)
        loadmore?.stateLabel.font = ConstValue.kRefreshLableFont
        return loadmore!
    }()
    
    lazy private var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.loadData()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        mjRefreshHeader?.stateLabel.font = ConstValue.kRefreshLableFont
        mjRefreshHeader?.lastUpdatedTimeLabel.font = ConstValue.kRefreshLableFont
        return mjRefreshHeader!
    }()
    lazy var topItemBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.backgroundColor = rgb(30, 31, 49)
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 14)
        btn.setTitleColor(rgb(255, 239, 195), for: .normal)
        btn.addTarget(self, action: #selector(topItemClick), for: .touchUpInside)
        btn.isHidden = true
        return btn
    }()
    private lazy var searchHotTipsApi: SearchRecomApi = {
        let api = SearchRecomApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var searchVideoApi: SearchVideoApi = {
        let api = SearchVideoApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    let coverBgView: UIView = {
        let bgv = UIView()
        bgv.backgroundColor = UIColor(white: 0, alpha: 0.5)
        return bgv
    }()
    let sourceSeg0 = ["综合排序","播放最多","收藏最多","最新上架"]
    let sourceSeg2 = ["长短视频","长视频", "短视频"]
    let sourceSeg3 =  ["付费类型","VIP","钻石","免费"]
    
    var videos = [VideoNew]()
    var keyModels = [SearchHotTips]()
    var allTypes = [String]()
    /// 用户id
    var userId: Int?
    /// 热度分类
    var segmentIndex0: Int = 0
    /// 标签分类
    var segmentIndex1: Int = 0
    /// 视频类型分类
    var segmentIndex2: Int = 0
    /// 付费类型分类
    var segmentIndex3: Int = 0
    
    var segDoubleView: SegItemDoubleView?
    
    /// 是否在VIP模块
    var InVipPart: Bool = false
    
    var islong = true
    let viewModel = VideoViewModel()
    
    /// 是否弹起短视频播放页
    var isPresentPlay: Bool = false
    
    // MARK: - Life Cycly
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        setUpUI()
        loadTypes()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if InVipPart {
            NotificationCenter.default.post(name: Notification.Name.kVIPTopBarColotNotification, object: nil, userInfo: ["TopBarDarkColor": 1])
        }
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if InVipPart {
            navBar.isHidden = true
            collectionView.frame = CGRect(x: 0, y: statusBarHeight + 44, width: screenWidth, height: screenHeight - statusBarHeight - 94 - safeAreaBottomHeight)
        } 
    }
    func setUpUI() {
        navBar.navBarView.addSubview(searchBtn)
        view.addSubview(navBar)
        view.addSubview(collectionView)
        view.addSubview(topItemBtn)
        searchBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.centerY.equalToSuperview()
            make.width.equalTo(18)
            make.height.equalTo(18)
        }
        navBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(safeAreaTopHeight)
        }
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            if InVipPart {
                make.top.equalTo(statusBarHeight + 44)
            } else {
                make.top.equalTo(navBar.snp.bottom)
            }
            if InVipPart {
                if #available(iOS 11.0, *) {
                    make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-49)
                } else {
                    make.bottom.equalToSuperview().offset(-49)
                }
            } else {
                make.bottom.equalToSuperview()
            }
        }
        topItemBtn.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalTo(collectionView)
            make.height.equalTo(32)
        }
        navBar.titleLabel.text = "所有分类"
    }
    
    func segSetTitle() {
        var allTitles = keyModels.map { (model) -> String in
            return model.title ?? ""
        }
        allTitles.insert("全部标签", at: 0)
        allTypes = allTitles
        segDoubleView?.setFirstTitles(sourceSeg0)
        segDoubleView?.setSecondTitles(allTitles)
        topItemBtn.setTitle("\(sourceSeg0[segmentIndex0]) · \(allTitles[segmentIndex1]) · \(sourceSeg2[segmentIndex2]) · \(sourceSeg3[segmentIndex3])", for: .normal)
    }
    private func goUserCenter(_ user: CLUserInfo?) {
        let userCenter = UserMCenterController()
        userCenter.userCode = user?.code
        navigationController?.pushViewController(userCenter, animated: true)
    }
    @objc func topItemClick() {
        collectionView.scrollToItem(at: IndexPath.init(item: 0, section: 0), at: .top, animated: false)
    }
    @objc func tapCover() {
        coverBgView.removeFromSuperview()
    }
    @objc func searchBtnClick() {
        if let vcs = navigationController?.viewControllers {
            let allPlayVcs = vcs.filter { (vc) -> Bool in
                return vc.isKind(of: SearchMainController.self)
            }
            if allPlayVcs.count > 0 {
                navigationController?.viewControllers.removeAll(where: { (vc) -> Bool in
                    return vc.isKind(of: SearchMainController.self)
                })
            }
            let vc = SearchMainController()
            navigationController?.pushViewController(vc, animated: true)
        }
    }
}

// MARK: - Private - Funcs
private extension TypesCategrayController {
    
    func loadTypes() {
        NicooErrorView.removeErrorMeesageFrom(view)
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: false)
        _ = searchHotTipsApi.loadData()
    }
    func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: false)
        let _ = searchVideoApi.loadData()
    }
    
    func loadNextPage() {
        let _ = searchVideoApi.loadNextPage()
    }
    func endRefreshing() {
        collectionView.mj_footer.endRefreshing()
        //collectionView.mj_header.endRefreshing()
    }
    
    func succeedRequest(_ models: [VideoNew]) {
        var vrmodels = models
        if segmentIndex2 == 0 {
            let realDataCount = vrmodels.count
            if let skip = UserModel.share().authInfo?.config?.rule?.ad_skip?.int, skip > 0 {
                if let adList = UserModel.share().authInfo?.video_out, adList.count > 0 {
                    let skipTimes = realDataCount/skip
                    if skipTimes > 0 {
                        for i in 1 ..< skipTimes + 1 {
                            let arm = arc4random()%(UInt32(adList.count))
                            let ad = adList[Int(arm)]
                            let model = VideoNew()
                            model.recAd = ad
                            if realDataCount > skip {
                                vrmodels.insert(model, at: skip * i + i - 1)
                            }
                        }
                    }
                }
            }
        }
        if searchVideoApi.pageNumber == 1 {
            videos = vrmodels
            if videos.count == 0 {
                NicooErrorView.showErrorMessage(.noData, "暂无数据", on: view, topMargin: safeAreaTopHeight + 190) {
                    self.loadData()
                }
            }
        } else {
            videos.append(contentsOf: vrmodels)
        }
        loadMoreView.isHidden = models.count == 0
        collectionView.reloadData()
        segSetTitle()
    }
    
    func failedRequest(_ manager: NicooBaseAPIManager) {
        endRefreshing()
        NicooErrorView.showErrorMessage(.noNetwork, on: view, topMargin: safeAreaTopHeight + 190, clickHandler: {
            self.loadData()
        })
    }
}

// MARK: - UIScrollViewDelegate
extension TypesCategrayController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offSetY = scrollView.contentOffset.y
        if offSetY >= 150.0 {
            topItemBtn.isHidden = false
        } else {
            topItemBtn.isHidden = true
        }
    }
}
// MARK: - UICollectionViewDelegateFlowLayout
extension TypesCategrayController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: SegItemDoubleView.identifier, for: indexPath) as! SegItemDoubleView
        header.backgroundColor = ConstValue.kVcViewColor
        header.firstItemTapHandler = { [weak self] index in
            guard let strongSelf = self else { return }
            strongSelf.segmentIndex0 = index
            strongSelf.loadData()
        }
        header.secondItemTapHandler = { [weak self] index in
            guard let strongSelf = self else { return }
            strongSelf.segmentIndex1 = index
            strongSelf.loadData()
        }
        header.thirdItemTapHandler = { [weak self] index in
            guard let strongSelf = self else { return }
            strongSelf.segmentIndex2 = index
            strongSelf.loadData()
        }
        header.fourthItemTapHandler = { [weak self] index in
            guard let strongSelf = self else { return }
            strongSelf.segmentIndex3 = index
            strongSelf.loadData()
        }
        header.setFirstTitles(sourceSeg0)
        header.setSecondTitles(allTypes)
        header.setThirdTitles(sourceSeg2)
        header.setFourthTitles(sourceSeg3)
        header.setIndexs(segmentIndex0,segmentIndex1,segmentIndex2, segmentIndex3)
        segDoubleView = header
        return header
    }
}
extension TypesCategrayController: WaterfallMutiSectionDelegate {
    func heightForRowAtIndexPath(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, indexPath: IndexPath, itemWidth: CGFloat) -> CGFloat {
        if segmentIndex2 == 0 {
            let video = videos[indexPath.item]
            if video.recAd != nil {
                 return ADRandomCell.itemSize.height
            } else {
                if video.is_long == 1 {
                    return LongVideoCell.itemSizeDouble.height
                } else {
                    return ShortVideoCell.itemSizeDouble.height
                }
            }
        } else if segmentIndex2 == 1 {
            return LongVideoCell.itemSizeDouble.height
        } else if segmentIndex2 == 2 {
            return ShortVideoCell.itemSizeDouble.height
        }
        return .zero
    }
    func columnNumber(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> Int {
        return 2
    }
    func referenceSizeForHeader(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGSize {
        if section == 0 {
            return SegItemDoubleView.headerSizeDb
        }
        return .zero
    }
    func referenceSizeForFooter(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGSize {
        return .zero
    }
    func insetForSection(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    func lineSpacing(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGFloat {
        return 8
    }
    func interitemSpacing(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGFloat {
        return 4
    }
    func spacingWithLastSection(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGFloat {
        return 0
    }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension TypesCategrayController: UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0 { return 0 }
        return videos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if segmentIndex2 == 0 {
            let model = videos[indexPath.item]
            if model.recAd != nil {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ADRandomCell.cellId, for: indexPath) as! ADRandomCell
                if let ad = model.recAd {
                    cell.setAdModel(model: ad)
                }
                return cell
            }
            if model.is_long == 0 {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShortVideoCell.cellId, for: indexPath) as! ShortVideoCell
                cell.avatarImage.isHidden = false
                let model = videos[indexPath.item]
                cell.setModel(model: model,.itemSizeDouble)
                cell.avataClickHandler = { [weak self] in
                    self?.goUserCenter(model.user)
                }
                return cell
            } else {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LongVideoCell.cellId, for: indexPath) as! LongVideoCell
                let model = videos[indexPath.row]
                cell.setModel(model,.itemSizeDouble)
                cell.avataClickHandler = { [weak self] in
                    self?.goUserCenter(model.user)
                }
                return cell
            }
        } else if segmentIndex2 == 1 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LongVideoCell.cellId, for: indexPath) as! LongVideoCell
            let model = videos[indexPath.row]
            cell.setModel(model,.itemSizeDouble)
            cell.avataClickHandler = { [weak self] in
                self?.goUserCenter(model.user)
            }
            return cell
            
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShortVideoCell.cellId, for: indexPath) as! ShortVideoCell
            cell.avatarImage.isHidden = false
            let model = videos[indexPath.item]
            cell.setModel(model: model,.itemSizeDouble)
            cell.avataClickHandler = { [weak self] in
                self?.goUserCenter(model.user)
            }
            return cell
        }
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        if indexPath.section == 0 {
            return
        }
        let video = self.videos[indexPath.item]
        if video.recAd != nil {
            if let link = video.recAd?.link, !link.isEmpty {
                goInnerLink(link,video.recAd?.position)
            }
        } else {
            if video.is_long == 1 {
                goLongVideoDetail(video)
            } else {
                goShortVideoPlayerVC(video)
            }
        }
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension TypesCategrayController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is SearchVideoApi {
            var params = [String : Any]()
            if segmentIndex2 == 1 {
                params[SearchVideoApi.kIslong] = 1
            } else if segmentIndex2 == 2 {
                params[SearchVideoApi.kIslong] = 0
            }
            if segmentIndex1 != 0 && allTypes.count > segmentIndex1 {
                params[SearchVideoApi.kTag_id] = keyModels[segmentIndex1 - 1].id ?? keyModels[segmentIndex1 - 1].type_id ?? 0
            }
            if segmentIndex3 > 0 {
                params[SearchVideoApi.kPaytype] = segmentIndex3
            }
            if segmentIndex0 > 0 {
                params[SearchVideoApi.kOrder_key] = [SearchVideoApi.kPlayCount, SearchVideoApi.kOrder_keyLike, SearchVideoApi.kOrder_keyOnline_at][segmentIndex0 - 1]
            }
            return params
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        endRefreshing()
        if manager is SearchVideoApi {
            if view.subviews.contains(coverBgView) {
                coverBgView.removeFromSuperview()
            }
            if let list = manager.fetchJSONData(SearchReformer()) as? [VideoNew] {
                succeedRequest(list)
            }
        }
        if  manager is SearchRecomApi {
            if let modules = manager.fetchJSONData(SearchReformer()) as? [SearchHotTips] {
                keyModels = modules
                segSetTitle()
                collectionView.reloadData()
                loadData()
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if view.subviews.contains(coverBgView) {
            coverBgView.removeFromSuperview()
        }
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        failedRequest(manager)
    }
}


extension TypesCategrayController: CLNavigationBarDelegate {
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}
