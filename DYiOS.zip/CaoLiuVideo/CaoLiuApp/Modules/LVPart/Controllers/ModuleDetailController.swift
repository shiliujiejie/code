import UIKit
import JXPagingView
import JXSegmentedView
import NicooNetwork

class ModuleDetailController: BasePagerViewController {
    
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.titleLabel.text = nil
        bar.backButton.isHidden = false
        bar.titleLabel.isHidden = false
        bar.lineView.isHidden = true
        bar.navBackBlack = false
        bar.delegate = self
        return bar
    }()
    lazy var topTipView: TypeTipsView = {
        let v = TypeTipsView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: safeAreaTopHeight + 77))
        v.backgroundColor = .clear
        return v
    }()
    private lazy var infoApi: TipsTypesDetailApi =  {
        let api = TipsTypesDetailApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var favorApi: TipsTypesFavorApi =  {
        let api = TipsTypesFavorApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    let list1 = SeriesVideosController()
    let list2 = SeriesVideosController()
    let list3 = SeriesVideosController()
    
    var isBack: Bool = false
    /// 文字高度
    var topDesHeight: CGFloat = 0
    
    /// 模块ID
    var moduleID: Int?
    var moduleDetail = ModuleDetailModel()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        pagingView.mainTableView.backgroundColor = UIColor.clear
        //导航栏隐藏就是设置pinSectionHeaderVerticalOffset属性即可，数值越大越往下沉
        pagingView.pinSectionHeaderVerticalOffset = Int(safeAreaTopHeight)
        
        view.addSubview(navBar)
        layoutNavBar()
        
        navBar.titleLabel.text = nil
        navBar.backgroundColor = .clear
        
        loadData()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if isBack {
            navBar.titleLabel.text = nil
            navBar.backgroundColor = .clear
            pagingView.reloadData()
        }
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        pagingView.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight)
    }
    override func pagingView(_ pagingView: JXPagingView, initListAtIndex index: Int) -> JXPagingViewListViewDelegate {
        if index == 0 {
            list1.isLong = false
            list1.segmentIndex = 0
            list1.pageType = .moduleMore
            list1.moduleID = moduleID
            return list1
        } else if index == 1 {
            list2.isLong = true
            list2.segmentIndex = 1
            list2.pageType = .moduleMore
            list2.moduleID = moduleID
            return list2
        } else{
            list3.isLong = false
            list3.segmentIndex = 2
            list3.moduleID = moduleID
            list3.pageType = .moduleMore
            return list3
        }
    }
    override func preferredPagingView() -> JXPagingView {
        return JXPagingListRefreshView(delegate: self)
    }
    override func tableHeaderViewHeight(in pagingView: JXPagingView) -> Int {
        return Int(safeAreaTopHeight) + 77 +  Int(topDesHeight)
    }
    override func tableHeaderView(in pagingView: JXPagingView) -> UIView {
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: safeAreaTopHeight + 77))
        headerView.addSubview(topTipView)
        layoutTopTipView()
        return headerView
    }
    
    func loadData() {
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: false)
        _ = infoApi.loadData()
    }
    func addFavor() {
        _ = favorApi.loadData()
    }
    func setUpInfo() {
        let size = topTipView.desLab.textSize(text: (moduleDetail.intro != nil && !moduleDetail.intro!.isEmpty) ? moduleDetail.intro! : "该标签暂未添加详细介绍～", font: UIFont.systemFont(ofSize: 13), maxSize: CGSize(width: screenWidth-30, height: 500), 6)
        topDesHeight = size.height
        
        topTipView.desLab.attributedText = TextSpaceManager.getAttributeStringWithString((moduleDetail.intro != nil && !moduleDetail.intro!.isEmpty) ? moduleDetail.intro! : "该标签暂未添加详细介绍～", lineSpace: 6)
        
        topTipView.titleLab.text = moduleDetail.title
        
        titles = ["全部", "只看长视频","只看短视频"]
        dataSource.titleNormalFont = UIFont.systemFont(ofSize: 14)
        dataSource.isItemSpacingAverageEnabled = false
        dataSource.titleSelectedZoomScale = 1.1
        dataSource.titles = titles
        dataSource.itemSpacing = 25
        let indicator = JXSegmentedIndicatorBackgroundView()
        indicator.indicatorColor = ConstValue.kStypeColor
        indicator.isIndicatorConvertToItemFrameEnabled = true
        indicator.indicatorCornerRadius = 4
        indicator.indicatorHeight = 28
        segmentedView.indicators = [indicator]
        
        segmentedView.reloadData()
        pagingView.reloadData()
    }
    
}

// MARK: - CLNavigationBarDelegate
extension ModuleDetailController:  CLNavigationBarDelegate  {
    
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}

extension ModuleDetailController {
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalToSuperview()
            make.height.equalTo(safeAreaTopHeight)
        }
    }
    func layoutTopTipView() {
        topTipView.snp.makeConstraints { (make) in
            make.top.equalTo(ConstValue.kStatusBarHeight + 44)
            make.leading.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension ModuleDetailController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is TipsTypesDetailApi {
            return [TipsTypesDetailApi.kTypeId: moduleDetail.id ?? 0]
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is TipsTypesDetailApi {
            if let tipsModel = manager.fetchJSONData(SearchReformer()) as? ModuleDetailModel {
                moduleDetail = tipsModel
                setUpInfo()
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        if manager is TipsTypesDetailApi {
            XSAlert.show(type: .text, text: manager.errorMessage)
        }
        if manager is TipsTypesFavorApi {
            XSAlert.show(type: .text, text: manager.errorMessage)
        }
    }
}
