
import UIKit
import NicooNetwork
import MJRefresh
import AVKit

class LFMsgDetailController: CLBaseViewController {
    let titleS = ["MM人数: ", "MM年龄: ", "MM地址: ","服务项目: ","服务价格: ", "联系方式: ", "详细地址: ","详情介绍: "]
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.backgroundColor = .clear
        bar.navBackBlack = false
        bar.lineView.isHidden = true
        bar.backButton.layer.cornerRadius = 17
        bar.backButton.backgroundColor = UIColor(white: 0, alpha: 0.2)
        bar.layer.masksToBounds = true
        bar.delegate = self
        return bar
    }()
   
    lazy var tableView: UITableView = {
        let table = UITableView.init(frame: CGRect.zero, style: .plain)
        table.showsVerticalScrollIndicator = false
        table.backgroundColor = UIColor.clear
        table.separatorStyle = .none
        table.allowsSelection = false
        table.bounces = false
        table.delegate = self
        table.dataSource = self
        table.register(LfInfoTextCell.classForCoder(), forCellReuseIdentifier: LfInfoTextCell.cellId)
        table.register(LfCommentCell.classForCoder(), forCellReuseIdentifier: LfCommentCell.cellId)
        table.register(LFPusherCell.classForCoder(), forCellReuseIdentifier: LFPusherCell.cellId)
        table.register(CommunityTextCell.classForCoder(), forCellReuseIdentifier: CommunityTextCell.cellId)
        table.register(CommunitySinglePictureCell.classForCoder(), forCellReuseIdentifier: CommunitySinglePictureCell.cellId)
        table.register(CommunityImagesCell.classForCoder(), forCellReuseIdentifier: CommunityImagesCell.cellId)
        table.mj_footer = loadMoreView
        return table
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        let loadMore = MJRefreshAutoNormalFooter(refreshingBlock: {
            //weakSelf?.loadNextPage()
        })
        loadMore?.isHidden = true
        loadMore?.stateLabel.font = ConstValue.kRefreshLableFont
        return loadMore!
    }()
    lazy var tableHeader: LFDetailHeaderView = {
        let v = LFDetailHeaderView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: screenWidth * 4/3 + 110))
        v.backgroundColor = ConstValue.kVcViewColor
        return v
    }()
    lazy var orderView: LFOrderView = {
        let v = LFOrderView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 75))
        v.layer.borderColor = ConstValue.kAppSepLineColor.cgColor
        v.backgroundColor = ConstValue.kAppSepLineColor
        v.layer.borderWidth = 0.6
        return v
    }()
    private lazy var lfInfoApi: LFMsgDetailApi =  {
        let api = LFMsgDetailApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var lfCommentsApi: LFCommentListApi =  {
        let api = LFCommentListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var orderApi: LFMsgOrderApi =  {
        let api = LFMsgOrderApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    
    var serverInfos = [String]()
    var lfModel = LFMsgModel()
    let userViewModel = UserInfoViewModel()
    
    /// 约啪体验
    var lfFeels = [LFCommentModel]()
    /// 讨论区
    var lfComments = [LFCommentModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if #available(iOS 11.0, *) {
            tableView.contentInsetAdjustmentBehavior = .never
        } else {
            self.automaticallyAdjustsScrollViewInsets = false
        }
        view.addSubview(tableView)
        view.addSubview(navBar)
        view.addSubview(orderView)
        layoutPageSub()
        loadLFInfo()
        loadFeelsFirstPage()
        tableView.tableHeaderView = tableHeader
    }
    private func loadLFInfo() {
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: false)
        let _ = lfInfoApi.loadData()
    }
    func loadFeelsFirstPage() {
        NicooErrorView.removeErrorMeesageFrom(view)
        _ = lfCommentsApi.loadData()
    }
    func loadNextPage() {
        NicooErrorView.removeErrorMeesageFrom(view)
        _ = lfCommentsApi.loadNextPage()
    }
    func orderLf() {
       
        if UserModel.share().user?.coins == 0 {
            showCoinsAlert()
            return
        }
        if (lfModel.decide_coins ?? 0) > (UserModel.share().user?.coins ?? 0) {
            showCoinsAlert()
            return
        }
        let vc = LFOrderAlertController()
        vc.lfModel = lfModel
        vc.modalPresentationStyle = .overCurrentContext
        self.present(vc, animated: true, completion: nil)
        vc.commitHandler = { [weak self] in
            self?.orderLfMsg()
            vc.dismiss(animated: true, completion: nil)
        }

    }
    func orderLfMsg() {
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: false)
        _ = orderApi.loadData()
    }
    func showCoinsAlert() {
        showDialog(title: "温馨提示", message: "\n你的钻石不足，请前去充值", okTitle: "立即充值", cancelTitle: "取消", okHandler: {
            let vc = CoinsCardsController()
            vc.isCoins = true
            self.navigationController?.pushViewController(vc, animated: true)
        }, cancelHandler: nil)
    }
    func setLfModelInfo() {
        //tableHeader.setLfInfo(lfModel)
        orderView.setModel(lfModel)
        if lfModel.is_attest == 0 || lfModel.decide_coins == 0 {  // 非认证 或者 预约金为0
            orderView.isHidden = true
            orderView.snp.updateConstraints { (make) in
                make.height.equalTo(0)
            }
        } else {
            orderView.snp.updateConstraints { (make) in
                make.height.equalTo(75)
            }
            orderView.isHidden = false
        }
        let size = tableHeader.titleLab.textSize(text: lfModel.title ?? "", font: UIFont.boldSystemFont(ofSize: 14), maxSize: CGSize(width: screenWidth - 20, height: 200), 5)
        print("size.height = \(size.height)")
        tableHeader.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenWidth * 4/3 + size.height + 88)
//        tableHeader.favorItem.itemClickHandle = { [weak self] _ in
//            guard let strSelf = self else { return }
//            self?.addFavorOrNot(!strSelf.tableHeader.favorItem.iconButton.isSelected)
//        }
        tableHeader.pictureTapHandler = { [weak self] index in
            self?.showPictureBower(index,self?.lfModel.images)
        }
        tableHeader.videoTapHandler = { [weak self] _ in
            self?.playVideo()
        }
        tableHeader.actionHandler = { [weak self] actionId in
            if actionId == 1 {
                let vipVC = VipCardsController()
                self?.navigationController?.pushViewController(vipVC, animated: true)
            } else if actionId == 2 {
                self?.buyCoinsLFMsg()
            }
        }
        orderView.orderAction = { [weak self] in
            self?.orderLf()
        }
    }
    func fixLfModelSource() {
        serverInfos.append(lfModel.people ?? "")
        serverInfos.append(lfModel.age ?? "")
        if let p = lfModel.province, !p.isEmpty {
            serverInfos.append("\(p)·\(lfModel.city ?? "")")
        } else {
            serverInfos.append("\(lfModel.city ?? "")")
        }
        let server = NSMutableString.init()
        if let servers = lfModel.serving {
            for i in 0 ..< servers.count {
                if i == servers.count - 1 {
                    server.append("\(servers[i])")
                } else {
                    server.append("\(servers[i]),")
                }
            }
        }
        serverInfos.append(server as String)
        let price = NSMutableString.init()
        if let prices = lfModel.serving_money {
            for i in 0 ..< prices.count {
                if i == prices.count - 1 {
                    price.append("\(prices[i])")
                } else {
                    price.append("\(prices[i]),")
                }
            }
        }
        serverInfos.append(price as String)
        serverInfos.append(lfModel.contact ?? "")
        serverInfos.append(lfModel.milieu ?? "")
        serverInfos.append(lfModel.serving_intro ?? "")
    }
    /// 点赞
    func addFavorOrNot(_ isFavor: Bool) {
        let likeCount = lfModel.like_count ?? 0
        var favorCount = 0
        if isFavor {  // 不是点赞
            favorCount = likeCount + 1
        } else {
            favorCount = likeCount > 0 ? likeCount - 1 : 0
        }
        lfModel.like_count = favorCount
        lfModel.is_like = isFavor ? 1 : 0
        //tableHeader.favorItem.iconButton.isSelected = isFavor
//        tableHeader.favorItem.iconImage = isFavor ? "icon_home_like_after" : "lvFavor"
//        tableHeader.favorItem.title = getStringWithNumber(favorCount)
        userViewModel.addMsgFavor([UserFavorAddApi.kMsg_Id: lfModel.id ?? 0])
    }
    func playVideo() {
        if let Url = URL(string: lfModel.video ?? "") {
            let playerVc = AVPlayerViewController()
            playerVc.player = AVPlayer(url: Url)
            playerVc.player?.play()
            playerVc.modalPresentationStyle = .fullScreen
            self.present(playerVc, animated: false, completion: nil)
        } else {
            XSAlert.show(type: .text, text: "视频地址不正确")
        }
        
    }
    /// 金币购买楼风信息
    func buyCoinsLFMsg() {
        XSProgressHUD.showCycleProgress(msg: "支付中...", onView: view, animated: false)
        userViewModel.coinsBuyMsg(params: [UseBuyMsgApi.kMsgId: lfModel.id ?? 0] , succeedHandler: { [weak self] model in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: true)
            XSAlert.show(type: .success, text: "恭喜您支付成功")
            if let userCoins = UserModel.share().user?.coins, let vCoins = strongSelf.lfModel.coins, userCoins >= vCoins {
                UserModel.share().user?.coins = userCoins - vCoins
                NotificationCenter.default.post(name: Notification.Name.kUserBasicalInformationChanged, object: nil)
            }
            strongSelf.lfModel.contact = model.contact
            strongSelf.lfModel.milieu = model.milieu
            strongSelf.lfModel.coins = 0
            strongSelf.lfModel.paytype = 3
            strongSelf.lfModel.is_look_contact = 1
            //strongSelf.tableHeader.setLfInfo(strongSelf.lfModel)
            strongSelf.tableView.reloadData()
        }) { [weak self] (failMsg) in
            guard let strongSelf = self else { return }
            strongSelf.showCoinBuyAlert(failMsg)
            XSProgressHUD.hide(for: strongSelf.view, animated: true)
        }
    }
    func showCoinBuyAlert(_ msg: String) {
        showDialog(title: "温馨提示", message: "\n\(msg)", okTitle: "立即充值", cancelTitle: "取消", okHandler: {
            let vc = CoinsCardsController()
            vc.isCoins = true
            self.navigationController?.pushViewController(vc, animated: true)
        }, cancelHandler: nil)
    }
    func showPictureBower(_ index: Int,_ images: [String]?) {
        guard let pictures = images else { return }
        if pictures.count <= index { return }
        let loader = JXKingfisherLoader()
        // 数据源
        let source = JXNetworkingDataSource(photoLoader: loader, numberOfItems: { () -> Int in
            return pictures.count
        }, placeholder: { index -> UIImage? in
            return LGConfig.getImage("playCellBg")
        }) { index -> String? in
            return pictures[index]
        }
        let delegate = JXNumberPageControlDelegate()
        let trans = JXPhotoBrowserZoomTransitioning { (browser, index, view) -> UIView? in
            return nil
        }
        JXPhotoBrowser(dataSource: source, delegate: delegate, transDelegate: trans)
            .show(pageIndex: index)
    }
    func goUserCenter(_ user: CLUserInfo?) {
        if let vcs = navigationController?.viewControllers {
            let allVcs = vcs.filter { (vc) -> Bool in
                return vc.isKind(of: UserMCenterController.self)
            }
            if allVcs.count > 0 {
                let userVc = allVcs[0] as! UserMCenterController
                userVc.userCode = user?.code
                navigationController?.popToViewController(userVc, animated: true)
            } else {
                let userCenter = UserMCenterController()
                userCenter.userCode = user?.code
                navigationController?.pushViewController(userCenter, animated: true)
            }
        }
    }
    func goChatWith() {
        if lfModel.user_info?.code == nil {
            XSAlert.show(type: .error, text: "用户code为空")
            return
        }
        if lfModel.user_info?.code == UserModel.share().user?.code {
            XSAlert.show(type: .error, text: "不能私信自己。")
            return
        }
        let chat = ChatUser2UserController()
        chat.toUser = lfModel.user_info
        navigationController?.pushViewController(chat, animated: true)
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension LFMsgDetailController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 60.0
        return tableView.rowHeight
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return serverInfos.count
        } else if section == 1 {
            return 1
        } else if section == 2 {
            return lfComments.count == 0 ? 1 : lfComments.count
        } else if section == 3 {
            return lfFeels.count == 0 ? 1 : lfFeels.count
        }
        return 0
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            return 5
        }
        return 45
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let v = UIView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 5))
        v.backgroundColor = ConstValue.kAppSepLineColor
        if section == 0 {
            return v
        } else {
            guard let header = Bundle.main.loadNibNamed("ModulesHeaderView", owner: nil, options: nil)?[0] as? ModulesHeaderView else {
                return v
            }
            header.backgroundColor = ConstValue.kVcViewColor
            header.titleLab.font = UIFont.boldSystemFont(ofSize: 15)
            header.tipsView.isHidden = true
            header.lfcostant.constant = -7
            header.titleLab.text = ["发布者","评论区 (\(lfModel.comment_count ?? 0))","约啪体验 (\(lfModel.feel_count ?? 0))"][section - 1]
            if section ==  2 {
                header.moreBtn.isHidden = false
                header.arrowRightimg.isHidden = false
                header.moreLabel.isHidden = false
                header.moreLabel.text = "参与讨论"
                header.moreActionHandler = { [weak self] in
                    let vc = LFCommentsController()
                    vc.lfModelId = self?.lfModel.id
                    self?.navigationController?.pushViewController(vc, animated: true)
                }
            } else {
                header.moreBtn.isHidden = true
                header.arrowRightimg.isHidden = true
                header.moreLabel.isHidden = true
                header.moreLabel.text = nil
            }
            header.frame = CGRect(x: 0, y: 5, width: screenWidth, height: 40)
            let conV = UIView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 45))
            conV.addSubview(v)
            conV.addSubview(header)
            return conV
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: LfInfoTextCell.cellId, for: indexPath) as! LfInfoTextCell
            if indexPath.row == 5 || indexPath.row == 6 {
                cell.textLab.textColor = .red
                if lfModel.is_look_contact == 1 { // 已免费
                    cell.fakeButton.isHidden = true
                } else {
                    cell.fakeButton.isHidden = false
                    cell.textClickAction = { [weak self] in
                        guard let strongSelf = self else { return }
                        if strongSelf.lfModel.paytype == 1 {
                            let vip = VipCardsController()
                            strongSelf.navigationController?.pushViewController(vip, animated: true)
                        } else if strongSelf.lfModel.paytype == 2 {
                            strongSelf.buyCoinsLFMsg()
                        }
                    }
                }
            } else {
                cell.textLab.textColor = .lightGray
                cell.fakeButton.isHidden = true
            }
            cell.textLab.attributedText = TextSpaceManager.configColorString(allString: "\(titleS[indexPath.row])  \(serverInfos[indexPath.row])", attribStr: "\(titleS[indexPath.row])", UIColor.white, UIFont.boldSystemFont(ofSize: 14), 5)
            return cell
        } else if indexPath.section == 1 {
            let cell = tableView.dequeueReusableCell(withIdentifier: LFPusherCell.cellId, for: indexPath) as! LFPusherCell
            cell.setModel(lfModel.user_info)
            cell.actionHandler = { [weak self] tag in
                if tag == 1 {
                    if UserModel.share().user?.is_vip == "y" {
                        self?.goChatWith()
                    } else {
                        self?.showDialog(title: nil, message: "\n购买高级会员后才可发私信\n\n", okTitle: "开通VIP", cancelTitle: "取消", okHandler: {
                            let vc = VipCardsController()
                            self?.navigationController?.pushViewController(vc, animated: true)
                        }, cancelHandler: nil)
                    }
                } else if tag == 2 {
                    self?.goUserCenter(self?.lfModel.user_info)
                } else if tag == 3 {
                    self?.goUserCenter(self?.lfModel.user_info)
                }
            }
            return cell
        } else if indexPath.section == 2 {
            if lfComments.count == 0 {
                let cell = tableView.dequeueReusableCell(withIdentifier: LfInfoTextCell.cellId, for: indexPath) as! LfInfoTextCell
                cell.textLab.text = "暂无评论"
                cell.textLab.textAlignment = .center
                return cell
            } else {
                let cell = tableView.dequeueReusableCell(withIdentifier: LfCommentCell.cellId, for: indexPath) as! LfCommentCell
                let model = lfComments[indexPath.row]
                cell.setModel(model, true)
                return cell
            }
        } else if indexPath.section == 3 {
            if lfFeels.count == 0 {
                let cell = tableView.dequeueReusableCell(withIdentifier: LfInfoTextCell.cellId, for: indexPath) as! LfInfoTextCell
                cell.textLab.text = "暂无约啪体验"
                cell.textLab.textAlignment = .center
                return cell
            } else {
                let model = lfFeels[indexPath.row]
                if let imageResource = model.comment_image {
                    if imageResource.count == 0 {
                        let cell = tableView.dequeueReusableCell(withIdentifier: CommunityTextCell.cellId, for: indexPath) as! CommunityTextCell
                        cell.setModel(model,true)
                        cell.userViewActionHandler = { [weak self] actionId in
                            //self?.goUserCenter(model.user_info)
                        }
                        return cell
                    } else if imageResource.count == 1 {
                        let cell = tableView.dequeueReusableCell(withIdentifier: CommunitySinglePictureCell.cellId, for: indexPath) as! CommunitySinglePictureCell
                        cell.setModel(model, true)
                        cell.imageClickHandler = { [weak self] in
                            self?.showPictureBower(0, model.comment_image)
                        }
                        cell.userViewActionHandler = { [weak self] actionId in
                           // self?.goUserCenter(model.user_info)
                        }
                        return cell
                    } else {
                        let cell = tableView.dequeueReusableCell(withIdentifier: CommunityImagesCell.cellId, for: indexPath) as! CommunityImagesCell
                        cell.setModel(model,true)
                        cell.imagesClickHandler = { [weak self] (index) in
                            self?.showPictureBower(index, model.comment_image)
                        }
                        cell.userViewActionHandler = { [weak self] actionId in
                            //self?.goUserCenter(model.user_info)
                        }
                        return cell
                    }
                }
//                let cell = tableView.dequeueReusableCell(withIdentifier: CommunityTextCell.cellId, for: indexPath) as! CommunityTextCell
//                cell.setModel(model,true)
//                cell.userViewActionHandler = { [weak self] actionId in
//                    self?.goUserCenter(model.user_info)
//                }
//                return cell
            }
        
        }
        return UITableViewCell()
    }
}
extension LFMsgDetailController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offsetY = scrollView.contentOffset.y
        let thresholdDistance: CGFloat = screenWidth * 4/3 - safeAreaTopHeight
        var percent = offsetY/thresholdDistance
        percent = max(0, min(1, percent))
        navBar.backgroundColor = UIColor(red: 27/255.0, green: 27/255.0, blue: 40/255.0, alpha: percent)
        if offsetY > (screenWidth * 4/3 - safeAreaTopHeight) {
            navBar.titleLabel.text = "约啪详情"
            navBar.backgroundColor = ConstValue.kAppSepLineColor
            navBar.navBackBlack = false
            navBar.backButton.backgroundColor = .clear
        } else {
            navBar.titleLabel.text = ""
            navBar.backgroundColor = .clear
            navBar.navBackBlack = false
            navBar.backButton.backgroundColor = UIColor(white: 0, alpha: 0.2)
        }
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension LFMsgDetailController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is LFMsgDetailApi {
            return [LFMsgDetailApi.klFId : lfModel.id ?? 0]
        }
        if manager is LFCommentListApi {
            return [LFCommentListApi.kLFInfoId : lfModel.id ?? 0]
        }
        if manager is LFMsgOrderApi {
            return [LFMsgOrderApi.kFloor_post_id: lfModel.id ?? 0]
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is LFMsgDetailApi {
            if let lfInfo = manager.fetchJSONData(VideoReformer()) as? LFMsgModel {
                lfModel = lfInfo
                fixLfModelSource()
                if let comments = lfModel.comments_data, comments.count > 0 {
                    lfComments = comments
                }
                setLfModelInfo()
                tableView.reloadData()
            } else {
                XSAlert.show(type: .text, text: "数据错误")
            }
        }
        
        if manager is LFCommentListApi {
            if let list = manager.fetchJSONData(VideoReformer()) as? [LFCommentModel] {
                if lfCommentsApi.pageNumber == 1 {
                    lfFeels = list
                } else {
                    lfFeels.append(contentsOf: list)
                }
                loadMoreView.isHidden = list.count == 0
                tableView.reloadData()
            }
        }
        if manager is LFMsgOrderApi {
            let vc = OrderSuccessController()
            vc.infoModel = lfModel
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        if manager is LFMsgOrderApi {
            XSAlert.show(type: .error, text: manager.errorMessage)
        }
    }
}

extension LFMsgDetailController {
    func layoutPageSub() {
        layoutToppart()
        layoutOrderView()
        layoutTable()
    }
    func layoutToppart() {
        navBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(safeAreaTopHeight)
        }
    }
    func layoutTable() {
        tableView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.bottom.equalTo(orderView.snp.top)
        }
    }
    func layoutOrderView() {
        orderView.snp.makeConstraints { (make) in
            make.leading.trailing.bottom.equalToSuperview()
            make.height.equalTo(75)
        }
    }
    
}
// MARK: - CLNavigationBarDelegate
extension LFMsgDetailController: CLNavigationBarDelegate  {
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}
