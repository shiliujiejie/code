import UIKit
import NicooNetwork
import MJRefresh
import IQKeyboardManagerSwift

class LFCommentsController: CLBaseViewController {
    
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.navBackBlack = false
        bar.delegate = self
        return bar
    }()
    private lazy var tableView: UITableView = {
        let table = UITableView()
        table.backgroundColor = UIColor.clear
        table.showsVerticalScrollIndicator = false
        table.allowsSelection = false
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .none
        table.register(LfCommentCell.classForCoder(), forCellReuseIdentifier: LfCommentCell.cellId)
        table.mj_header = refreshView
        table.mj_footer = loadMoreView
        return table
    }()
    private var bottomView: ChartBottomView = {
        guard let view = Bundle.main.loadNibNamed("ChartBottomView", owner: nil, options: nil)?[0] as? ChartBottomView else { return ChartBottomView() }
        view.backgroundColor = ConstValue.kVcViewColor
        view.textFliedBgView.backgroundColor = ConstValue.kAppSepLineColor
        view.pictureChoseWidth.constant = 0
        view.pictureBtn.isHidden = true
        view.frame = CGRect(x: 0, y: screenHeight-59, width: view.bounds.width, height: 59)
        return view
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        let loadmore = MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
        loadmore?.setTitle("", for: .idle)
        loadmore?.setTitle("已經到底了", for: .noMoreData)
        loadmore?.stateLabel.font = ConstValue.kRefreshLableFont
        return loadmore!
    }()
    
    lazy private var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.loadFirstPage()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        mjRefreshHeader?.stateLabel.font = ConstValue.kRefreshLableFont
        mjRefreshHeader?.lastUpdatedTimeLabel.font = ConstValue.kRefreshLableFont
        return mjRefreshHeader!
    }()
    private lazy var commentsApi: LfCommentLsApi = {
        let api = LfCommentLsApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var commentAddApi: LFCommentAddApi = {
           let api = LFCommentAddApi()
           api.delegate = self
           api.paramSource = self
           return api
       }()
    
    var lfModelId: Int?
    var comments = [LFCommentModel]()
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        addKeyboardObserver()
        navBar.titleLabel.text = "参与讨论"
        view.addSubview(navBar)
        view.addSubview(tableView)
        view.addSubview(bottomView)
        bottomView.contentTf.delegate = self
        layoutPageSubviews()
        loadData()
        bottomView.actionHandler = { [weak self] (actionId) in
            self?.commentAdd(self?.bottomView.contentTf.text)
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        IQKeyboardManager.shared.enable = false
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillAppear(animated)
        IQKeyboardManager.shared.enable = true
    }
    func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
       XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: false)
        _ = commentsApi.loadData()
    }
    func loadFirstPage() {
        NicooErrorView.removeErrorMeesageFrom(view)
         let _  = commentsApi.loadData()
    }
    func loadNextPage() {
        NicooErrorView.removeErrorMeesageFrom(view)
         let _  = commentsApi.loadNextPage()
    }
    func commentAdd(_ text: String?) {
        if text == nil || text!.isEmpty {
            XSAlert.show(type: .text, text: "请输入讨论内容")
            return
        }
        _ = commentAddApi.loadData()
    }
    private func endRefreshing() {
        tableView.mj_header.endRefreshing()
        tableView.mj_footer.endRefreshing()
    }
}
extension LFCommentsController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        commentAdd(textField.text)
        return true
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension LFCommentsController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 60.0
        return tableView.rowHeight
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let v = UIView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 40))
        let l = UILabel(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 30))
        l.backgroundColor = ConstValue.kAppSepLineColor
        l.textColor = ConstValue.kStypeColor
        l.font = UIFont.systemFont(ofSize: 13)
        l.text = "\(comments.count)条讨论"
        l.textAlignment = .center
        v.addSubview(l)
        return v
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return comments.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: LfCommentCell.cellId, for: indexPath) as! LfCommentCell
        let model = comments[indexPath.row]
        cell.setModel(model, false)
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
       
    }
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension LFCommentsController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is LfCommentLsApi {
            return [LfCommentLsApi.kLfId : lfModelId ?? 0]
        }
        if manager is LFCommentAddApi {
            return [LFCommentAddApi.kContent_id : lfModelId ?? 0, LFCommentAddApi.kContent: bottomView.contentTf.text ?? ""]
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is LfCommentLsApi {
            if let models = manager.fetchJSONData(UserReformer()) as? [LFCommentModel] {
               endRefreshing()
                if commentsApi.pageNumber == 1 {
                    comments = models
                    tableView.reloadData()
                } else {
                    comments.append(contentsOf: comments)
                }
                loadMoreView.isHidden = comments.count == 0
                tableView.reloadData()
            }
        }
        if manager is LFCommentAddApi {
            self.loadData()
            bottomView.contentTf.text = nil
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        if manager is LfCommentLsApi {
            NicooErrorView.showErrorMessage(.noNetwork, "数据走丢了，请检查网络", on: view, topMargin: safeAreaTopHeight + 50) {
                self.loadData()
            }
        }
        if manager is LFCommentAddApi {
            bottomView.contentTf.endEditing(true)
            XSAlert.show(type: .text, text: manager.errorMessage)
        }
    }
}

// MARK: - Description
private extension LFCommentsController {
    func layoutPageSubviews() {
        layoutToppart()
        layoutTableView()
        layoutBottomView()
    }
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(navBar.snp.bottom)
            make.bottom.equalTo(-59)
        }
    }
    func layoutToppart() {
        navBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(safeAreaTopHeight)
        }
    }
    func layoutBottomView() {
        bottomView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.bottom.equalTo(0)
            make.height.equalTo(59)
        }
    }
}
extension LFCommentsController: CLNavigationBarDelegate {
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}

extension LFCommentsController {
    func addKeyboardObserver() {
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(keyboardFrameWillChange(notification:)),
                                               name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
    }
    
    @objc func keyboardFrameWillChange(notification: NSNotification) {
        guard let userInfo = notification.userInfo,
            let endKeyboardFrameValue = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue,
            let durationValue = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey] as? NSNumber else {
                return
        }
        
        let endKeyboardFrame = endKeyboardFrameValue.cgRectValue
        let duration = durationValue.doubleValue
        
        let isShowing: Bool = endKeyboardFrame.maxY > UIScreen.main.bounds.height ? false : true
        
        UIView.animate(withDuration: duration) { [weak self] in
            guard let strongSelf = self else {
                return
            }
            
            if isShowing {
                let offsetY = strongSelf.bottomView.frame.maxY - endKeyboardFrame.minY
                guard offsetY > 0 else {
                    return
                }
                strongSelf.bottomView.snp.updateConstraints({ (make) in
                    make.bottom.equalTo(-offsetY)
                })
            } else {
                strongSelf.bottomView.snp.updateConstraints({ (make) in
                    make.bottom.equalTo(0)
                })
                //strongSelf.commentTagsView.isHidden = true
            }
            strongSelf.view.layoutIfNeeded()
        }
    }
}
