
import UIKit
import MJRefresh
import NicooNetwork
import JXPagingView

class LFCommunityController: UIViewController {
    
    lazy var tableView: CommunityTableView = {
        let tableView = CommunityTableView(frame: view.bounds, style: .plain)
        tableView.backgroundColor = UIColor.clear
        tableView.separatorStyle = .none
        tableView.allowsSelection = false
        tableView.dataSource = self
        tableView.delegate = self
        tableView.showsVerticalScrollIndicator = false
        tableView.register(CommunityTextCell.classForCoder(), forCellReuseIdentifier: CommunityTextCell.cellId)
        tableView.register(CommunitySinglePictureCell.classForCoder(), forCellReuseIdentifier: CommunitySinglePictureCell.cellId)
        tableView.register(CommunityImagesCell.classForCoder(), forCellReuseIdentifier: CommunityImagesCell.cellId)
        tableView.mj_header = refreshView
        tableView.mj_footer = loadMoreView
        return tableView
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        let loadMore = MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
        loadMore?.isHidden = true
        loadMore?.stateLabel.font = ConstValue.kRefreshLableFont
        return loadMore!
    }()
    lazy private var refreshView: MJRefreshGifHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshGifHeader(refreshingBlock: {
            weakSelf?.loadFirstPage()
        })
        var gifImages = [UIImage]()
        for string in ConstValue.refreshImageNames {
            gifImages.append(UIImage(named: string)!)
        }
        mjRefreshHeader?.setImages(gifImages, for: .refreshing)
        mjRefreshHeader?.setImages(gifImages, for: .idle)
        mjRefreshHeader?.stateLabel.font = ConstValue.kRefreshLableFont
        mjRefreshHeader?.lastUpdatedTimeLabel.font = ConstValue.kRefreshLableFont
        return mjRefreshHeader!
    }()
    
    private lazy var lfCommentsApi: LFCommentListApi =  {
        let api = LFCommentListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    
    var listViewDidScrollCallback: ((UIScrollView) -> ())?
    
    var dataSource = [LFCommentModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        view.addSubview(tableView)
        layoutSubs()
        loadData()
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        tableView.frame = view.bounds
    }
    func loadData() {
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: false)
        NicooErrorView.removeErrorMeesageFrom(view)
        _ = lfCommentsApi.loadData()
    }
    func loadFirstPage() {
        NicooErrorView.removeErrorMeesageFrom(view)
        _ = lfCommentsApi.loadData()
    }
    func loadNextPage() {
        NicooErrorView.removeErrorMeesageFrom(view)
        _ = lfCommentsApi.loadNextPage()
    }
    func endRefreshing() {
        tableView.mj_header.endRefreshing()
        tableView.mj_footer.endRefreshing()
    }
    
}
extension LFCommunityController {
    /// 看大图
    func showImages(_ imageSource: [String]?, _ index: Int) {
        guard let images = imageSource else { return }
        // 网图加载器
        let loader = JXKingfisherLoader()
        // 数据源
        let source = JXNetworkingDataSource(photoLoader: loader, numberOfItems: { () -> Int in
            return images.count
        }, placeholder: { index -> UIImage? in
            return LGConfig.getImage("playCellBg")
        }) { index -> String? in
            return images[index]
        }
        // 视图代理，实现了光点型页码指示器
        let delegate = JXDefaultPageControlDelegate() // 视图代理，实现了光点型页码指示器
        // 转场动画
        let trans = JXPhotoBrowserZoomTransitioning { (browser, index, view) -> UIView? in
            return nil
        }
        // 打开浏览器
        JXPhotoBrowser(dataSource: source, delegate: delegate, transDelegate: trans)
            .show(pageIndex: index)
        
    }
    private func goUserCenter(_ user: CLUserInfo?) {
        let userCenter = UserMCenterController()
        userCenter.userNew = user
        navigationController?.pushViewController(userCenter, animated: true)
    }
    private func goLFDetail(_ lfModel: LFMsgModel?) {
        let vc = LFMsgDetailController()
        if lfModel != nil {
           vc.lfModel = lfModel!
        }
        navigationController?.pushViewController(vc, animated: true)
    }
}
// MARK: - UITableViewDataSource, UITableViewDelegate
extension LFCommunityController: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return dataSource.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 100.0
        return tableView.rowHeight
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let model = dataSource[indexPath.section]
        if let imageResource = model.comment_image {
            if imageResource.count == 0 {
                let cell = tableView.dequeueReusableCell(withIdentifier: CommunityTextCell.cellId, for: indexPath) as! CommunityTextCell
                cell.setModel(model)
                cell.userViewActionHandler = { [weak self] actionId in
                    //self?.goUserCenter(model.user_info)
                }
                cell.bottomActionHandler = { [weak self] actionId in
                    self?.goLFDetail(model.floor_info)
                }
                return cell
            } else if imageResource.count == 1 {
                let cell = tableView.dequeueReusableCell(withIdentifier: CommunitySinglePictureCell.cellId, for: indexPath) as! CommunitySinglePictureCell
                cell.setModel(model)
                cell.imageClickHandler = { [weak self] in
                    self?.showImages(model.comment_image, 0)
                }
                cell.userViewActionHandler = { [weak self] actionId in
                    //self?.goUserCenter(model.user_info)
                }
                cell.bottomActionHandler = { [weak self] actionId in
                    self?.goLFDetail(model.floor_info)
                }
                return cell
            } else {
                let cell = tableView.dequeueReusableCell(withIdentifier: CommunityImagesCell.cellId, for: indexPath) as! CommunityImagesCell
                cell.setModel(model)
                cell.imagesClickHandler = { [weak self] (index) in
                    self?.showImages(model.comment_image, index)
                }
                cell.userViewActionHandler = { [weak self] actionId in
                    //self?.goUserCenter(model.user_info)
                }
                cell.bottomActionHandler = { [weak self] actionId in
                    self?.goLFDetail(model.floor_info)
                }
                return cell
            }
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: CommunityTextCell.cellId, for: indexPath) as! CommunityTextCell
        cell.setModel(model)
        cell.userViewActionHandler = { [weak self] actionId in
            self?.goUserCenter(model.user_info)
        }
        cell.bottomActionHandler = { [weak self] actionId in
            self?.goLFDetail(model.floor_info)
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 3.0
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let v = UIView()
        v.backgroundColor = ConstValue.kAppSepLineColor
        return v
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
    }
}

// MARK: - UIScrollViewDelegate
extension LFCommunityController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        listViewDidScrollCallback?(scrollView)
    }
}

extension LFCommunityController: JXPagingViewListViewDelegate {
    func listView() -> UIView {
        return self.view
    }
    
    func listScrollView() -> UIScrollView {
        return tableView
    }
    
    func listViewDidScrollCallback(callback: @escaping (UIScrollView) -> ()) {
        listViewDidScrollCallback = callback
    }
}
// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension LFCommunityController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        endRefreshing()
        if manager is LFCommentListApi {
            if let list = manager.fetchJSONData(VideoReformer()) as? [LFCommentModel] {
                if lfCommentsApi.pageNumber == 1 {
                    dataSource = list
                    if dataSource.count == 0 {
                        NicooErrorView.showErrorMessage(.noData, on: view, topMargin: 60) {
                            self.loadData()
                        }
                    }
                } else {
                    dataSource.append(contentsOf: list)
                }
                loadMoreView.isHidden = list.count == 0
                tableView.reloadData()
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        endRefreshing()
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        NicooErrorView.showErrorMessage(.noNetwork, on: view) {
            self.loadData()
        }
    }
}

extension LFCommunityController {
    func layoutSubs() {
        tableView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-44)
            } else {
                make.bottom.equalToSuperview().offset(-44)
            }
        }
    }
}
