
import UIKit
import MJRefresh
import AVKit
class LFMMShowCcontroller: CLBaseViewController {
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.backgroundColor = .clear
        bar.navBackBlack = false
        bar.lineView.isHidden = true
        bar.backButton.layer.cornerRadius = 17
        bar.backButton.backgroundColor = UIColor(white: 0, alpha: 0.2)
        bar.layer.masksToBounds = true
        bar.delegate = self
        return bar
    }()
    private let layout: UICollectionViewFlowLayout = {
        let l = UICollectionViewFlowLayout()
        l.scrollDirection = .horizontal
        l.itemSize = CGSize(width: screenWidth, height: screenWidth * 4/3)
        l.minimumInteritemSpacing = 0
        l.minimumLineSpacing = 0
        l.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        return l
    }()
    lazy var collView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect.zero, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.showsHorizontalScrollIndicator = false
        collection.isPagingEnabled = true
        collection.bounces = false
        collection.backgroundColor = .darkText
        collection.register(PictureDetailCell.classForCoder(), forCellWithReuseIdentifier: PictureDetailCell.cellId)
        return collection
    }()
    let indexNumber: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.textAlignment = .center
        label.backgroundColor = UIColor(white: 0, alpha: 0.5)
        label.layer.cornerRadius = 10
        label.layer.masksToBounds = true
        label.font = UIFont.systemFont(ofSize: 12)
        return label
    }()
   
    let titleLab: UILabel = {
        let v = UILabel()
        v.textColor = UIColor.white
        v.numberOfLines = 0
        v.font = UIFont.boldSystemFont(ofSize: 14)
        return v
    }()

    var lfmodel = LFMsgModel()
    var pictures = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let pics = lfmodel.images {
            indexNumber.isHidden = pics.count == 0
            if pics.count > 0 {
                if let video = lfmodel.video, !video.isEmpty {
                    indexNumber.text = "1/\(pics.count + 1)"
                } else {
                    indexNumber.text = "1/\(pics.count)"
                }
            }
            pictures = pics
        } else {
            indexNumber.isHidden = true
        }
        titleLab.text = "\(lfmodel.title ?? "")"
    
        view.addSubview(navBar)
        view.addSubview(collView)
        view.addSubview(indexNumber)
        view.addSubview(titleLab)
        layoutPage()
    }
    
    func playVideo() {
        if let Url = URL(string: lfmodel.video ?? "") {
            let playerVc = AVPlayerViewController()
            playerVc.player = AVPlayer(url: Url)
            playerVc.player?.play()
            playerVc.modalPresentationStyle = .fullScreen
            self.present(playerVc, animated: false, completion: nil)
        } else {
            XSAlert.show(type: .text, text: "视频地址不正确")
        }
    }
    func showPictureBower(_ index: Int,_ images: [String]?) {
        guard let pictures = images else { return }
        if pictures.count <= index { return }
        let loader = JXKingfisherLoader()
        // 数据源
        let source = JXNetworkingDataSource(photoLoader: loader, numberOfItems: { () -> Int in
            return pictures.count
        }, placeholder: { index -> UIImage? in
            return LGConfig.getImage("playCellBg")
        }) { index -> String? in
            return pictures[index]
        }
        let delegate = JXNumberPageControlDelegate()
        let trans = JXPhotoBrowserZoomTransitioning { (browser, index, view) -> UIView? in
            return nil
        }
        JXPhotoBrowser(dataSource: source, delegate: delegate, transDelegate: trans)
            .show(pageIndex: index)
    }
}
// MARK: - UICollectionViewDelegate
extension LFMMShowCcontroller: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if let video = lfmodel.video, !video.isEmpty {
            return pictures.count + 1
        }
        return pictures.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PictureDetailCell.cellId, for: indexPath) as! PictureDetailCell
        cell.imgV.contentMode = .scaleAspectFill
        cell.showCover()
        if let video = lfmodel.video, !video.isEmpty {
            if indexPath.item == 0 {
                cell.imgV.kfSetVerticalImageWithUrl(pictures[indexPath.item])
                cell.playIcon.isHidden = false
            } else {
                cell.playIcon.isHidden = true
                cell.imgV.kfSetVerticalImageWithUrl(pictures[indexPath.item - 1])
            }
        } else {
            cell.playIcon.isHidden = true
            cell.imgV.kfSetVerticalImageWithUrl(pictures[indexPath.item])
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        if let video = lfmodel.video, !video.isEmpty {
            if indexPath.item == 0 {
                playVideo()
            } else {
                showPictureBower(indexPath.item - 1, pictures)
            }
        } else {
            showPictureBower(indexPath.item, pictures)
        }
    }
}

// MARK: UIScrollViewDelegate
extension LFMMShowCcontroller: UIScrollViewDelegate {
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
         let offsetX = scrollView.contentOffset.x
        if let video = lfmodel.video, !video.isEmpty {
            indexNumber.text = "\(Int(offsetX/screenWidth) + 1)/\(pictures.count + 1)"
        } else {
            indexNumber.text = "\(Int(offsetX/screenWidth) + 1)/\(pictures.count)"
        }
         
    }
}

// MARK: Layout
extension LFMMShowCcontroller {
    func layoutPage() {
        navBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(safeAreaTopHeight)
        }
        collView.snp.makeConstraints { (make) in
            make.top.equalTo(navBar.snp.bottom)
            make.leading.trailing.equalToSuperview()
            make.bottom.equalTo(-safeAreaBottomHeight - 100)
        }
        indexNumber.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.bottom.equalTo(-safeAreaBottomHeight - 20)
            make.height.equalTo(20)
            make.width.equalTo(40)
        }
        titleLab.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(indexNumber.snp.leading).offset(-10)
            make.bottom.equalTo(-safeAreaBottomHeight - 20)
        }
    }
}

// MARK: - CLNavigationBarDelegate
extension LFMMShowCcontroller: CLNavigationBarDelegate  {
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}
