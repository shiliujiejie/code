
import UIKit

class LongVideoTableCell: UITableViewCell {

    static let cellId = "LongVideoTableCell"
     static let rowHeight = (screenWidth/2 - 10)*9/16 + 15
     let shadowV: UIView = {
         let v = UIView()
        v.backgroundColor = ConstValue.kVBgColor
         v.layer.cornerRadius = 5
         v.bounds = CGRect(x: 0, y: 0, width: screenWidth-20, height:  (screenWidth/2 - 10)*9/16)
         return v
     }()
     let coverImg: UIImageView = {
         let v = UIImageView()
         v.contentMode = .scaleAspectFill
         v.bounds = CGRect(x: 0, y: 0, width: (screenWidth-20)/2, height: (screenWidth/2 - 10)*9/16)
         v.layer.cornerRadius = 5
         v.layer.masksToBounds = true
         return v
     }()
    lazy var avatarImage: UIButton = {
        let avatarImage = UIButton(type: .custom)
        avatarImage.layer.cornerRadius = 12
        avatarImage.layer.masksToBounds = true
        avatarImage.addTarget(self, action: #selector(avartarClick), for: .touchUpInside)
        return avatarImage
    }()
    @objc func avartarClick() {
        avataClickHandler?()
    }
    var avataClickHandler:(() ->Void)?
    private let nickLab: UILabel = {
         let lab = UILabel()
         lab.font = UIFont.systemFont(ofSize: 13)
         lab.textColor = .lightGray
         return lab
     }()
     let desLab: UILabel = {
         let la = UILabel()
         la.textColor = UIColor.white
         la.numberOfLines = 2
         la.font = UIFont.boldSystemFont(ofSize: 14)
         return la
     }()
     private let zanImgView: UIImageView = {
         let imageView = UIImageView()
        imageView.image = getImage("icon_home_like_after")
         imageView.contentMode = .scaleAspectFit
         return imageView
     }()
     private let zanCountLab: UILabel = {
         let titleLab = UILabel()
         titleLab.font = UIFont.systemFont(ofSize: 13)
         titleLab.textColor = .lightGray
         return titleLab
     }()
     let durationLab: UILabel = {
         let la = UILabel()
         la.textColor = .lightGray
         la.font = UIFont.systemFont(ofSize: 13)
         return la
     }()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = ConstValue.kVcViewColor
        backgroundColor = .clear
        contentView.addSubview(shadowV)
        shadowV.addSubview(coverImg)
        shadowV.addSubview(desLab)
        shadowV.addSubview(avatarImage)
        shadowV.addSubview(nickLab)
        shadowV.addSubview(zanImgView)
        shadowV.addSubview(zanCountLab)
        shadowV.addSubview(durationLab)
        layoutSubs()
        zanImgView.addShadow(radius: 1, opacity: 0.8)
    }
     
     required init?(coder: NSCoder) {
         fatalError("init(coder:) has not been implemented")
     }
     
     func setModel(_ model: VideoNew) {
         avatarImage.kfsetHeader(model.user?.avatar)
         coverImg.kfSetHorizontalImageWithUrl(model.cover)
         nickLab.text = model.user?.nick ?? ""
         desLab.text = model.title ?? ""
         zanCountLab.text = getStringWithNumber(model.like ?? 0)
         durationLab.text = PlayerView.formatTimDuration(duration: model.duration ?? 0)
     }
    
     private func layoutSubs() {
         shadowV.snp.makeConstraints { (make) in
            make.leading.equalTo(10)
            make.trailing.equalTo(-10)
            make.top.equalTo(7.5)
            make.bottom.equalTo(-7.5)
         }
         coverImg.snp.makeConstraints { (make) in
             make.leading.top.bottom.equalToSuperview()
             make.width.equalTo((screenWidth-20)/2)
         }
         desLab.snp.makeConstraints { (make) in
             make.leading.equalTo(coverImg.snp.trailing).offset(10)
             make.trailing.equalTo(0)
             make.top.equalTo(5)
         }
         zanImgView.snp.makeConstraints { (make) in
             make.leading.equalTo(desLab)
             make.bottom.equalTo(0)
             make.height.width.equalTo(15)
         }
         zanCountLab.snp.makeConstraints { (make) in
             make.leading.equalTo(zanImgView.snp.trailing).offset(5)
             make.centerY.equalTo(zanImgView)
         }
         durationLab.snp.makeConstraints { (make) in
             make.trailing.equalTo(desLab)
             make.centerY.equalTo(zanCountLab)
         }
         avatarImage.snp.makeConstraints { (make) in
             make.leading.equalTo(desLab)
             make.bottom.equalTo(zanImgView.snp.top).offset(-8)
             make.height.width.equalTo(24)
         }
         nickLab.snp.makeConstraints { (make) in
             make.leading.equalTo(avatarImage.snp.trailing).offset(6)
             make.centerY.equalTo(avatarImage)
         }
     }
}
