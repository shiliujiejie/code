
import UIKit

class PictureDetailCell: UICollectionViewCell {
    static let cellId = "PictureDetailCell"
    var imgV: UIImageView = {
        let v = UIImageView()
        v.backgroundColor = .darkText
        v.contentMode = .scaleAspectFit
        v.clipsToBounds = true
        v.bounds = CGRect(x: 0, y: 0, width: screenWidth, height: screenWidth * 4/3)
        return v
    }()
    let coverLayer: CAGradientLayer = {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.clear.cgColor, UIColor(white: 0.0, alpha: 0.6).cgColor]
        gradientLayer.locations = [0.8, 1.0]
        return gradientLayer
    }()
    let playIcon: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(white: 0.5, alpha: 0.5)
        view.layer.cornerRadius = 22.5
        view.layer.masksToBounds = true
        let img = UIImageView(image: UIImage(named: "pause"))
        img.isUserInteractionEnabled = true
        img.contentMode = .scaleAspectFit
        view.addSubview(img)
        img.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview().offset(2)
            make.height.width.equalTo(18)
        }
        view.isHidden = true
        return view
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(imgV)
        contentView.addSubview(playIcon)
        imgV.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        playIcon.snp.makeConstraints { (make) in
            make.center.equalTo(imgV)
            make.height.width.equalTo(45)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func showCover() {
//        coverLayer.frame = imgV.bounds
//        imgV.layer.insertSublayer(coverLayer, at: 0)
    }
}
