
import UIKit

class ModulesHeaderView: UICollectionReusableView {

    static let reuseId = "ModulesHeaderView"
    
    @IBOutlet weak var titleLab: UILabel!
    @IBOutlet weak var moreLabel: UILabel!
    @IBOutlet weak var arrowRightimg: UIImageView!
    
    @IBOutlet weak var lfcostant: NSLayoutConstraint!
    @IBOutlet weak var tipsView: UIView!
    @IBOutlet weak var moreBtn: UIButton!
    
    var moreActionHandler:(()->())?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        arrowRightimg.image = UIImage(named: "jh_arrow")
    }
    
    @IBAction func moreAction(_ sender: UIButton) {
        moreActionHandler?()
    }
    
    func setHideMore(_ hideMore: Bool) {
        moreBtn.isHidden = hideMore
        moreLabel.isHidden = hideMore
        arrowRightimg.isHidden = hideMore
    }
}

class VideoHeaderView: UICollectionReusableView {
    static let reuseId = "VideoHeaderView"
    lazy var headerView: ModulesHeaderView = {
        if let header = Bundle.main.loadNibNamed("ModulesHeaderView", owner: nil, options: nil)?[0] as? ModulesHeaderView {
            return header
        }
        return ModulesHeaderView()
    }()
    let layout: UICollectionViewFlowLayout = {
        let l = UICollectionViewFlowLayout()
        l.sectionInset = UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
        l.itemSize = LongVideoCell.itemSizeSingle
        return l
    }()
    lazy var collView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: (LongScrollCell.itemWidth)*9/16 + 50), collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.showsHorizontalScrollIndicator = false
        collection.backgroundColor = UIColor.clear
        collection.register(LongVideoCell.classForCoder(), forCellWithReuseIdentifier: LongVideoCell.cellId)
        return collection
    }()
    var itemClickHandler:((_ video: VideoNew) -> Void)?
    var avatarClickHandler:((_ user: CLUserInfo?) ->Void)?
    var moreActionHandler:(() ->Void)?
    var video: VideoNew?
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(headerView)
        addSubview(collView)
        headerView.moreActionHandler = { [weak self] in
            self?.moreActionHandler?()
        }
        headerView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(50)
        }
        collView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(headerView.snp.bottom)
            make.bottom.equalTo(-10)
        }
    }
    func setModels(_ model: VideoNew?) {
        if let vs = model {
            video = vs
            collView.reloadData()
        }
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
extension VideoHeaderView: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LongVideoCell.cellId, for: indexPath) as! LongVideoCell
        if let model = video {
            cell.setModel(model,.itemSizeSingle)
            cell.avataClickHandler = { [weak self] in
                self?.avatarClickHandler?(model.user)
            }
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        if let model = video {
            itemClickHandler?(model)
        }
    }
}

class VideoNoTitlHeaderView: UICollectionReusableView {
    static let reuseId = "VideoNoTitlHeaderView"

    let layout: UICollectionViewFlowLayout = {
        let l = UICollectionViewFlowLayout()
        l.sectionInset = UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
        l.itemSize = LongVideoCell.itemSizeSingle
        return l
    }()
    lazy var collView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: (LongScrollCell.itemWidth)*9/16), collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.showsHorizontalScrollIndicator = false
        collection.backgroundColor = UIColor.clear
        collection.register(LongVideoCell.classForCoder(), forCellWithReuseIdentifier: LongVideoCell.cellId)
        return collection
    }()
    var itemClickHandler:((_ video: VideoNew) -> Void)?
    var avatarClickHandler:((_ user: CLUserInfo?) ->Void)?
    var video: VideoNew?
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(collView)
        collView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(10)
            make.bottom.equalTo(10)
        }
    }
    func setModels(_ model: VideoNew?) {
        if let vs = model {
            video = vs
            collView.reloadData()
        }
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
extension VideoNoTitlHeaderView: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LongVideoCell.cellId, for: indexPath) as! LongVideoCell
        if let model = video {
            cell.setModel(model,.itemSizeSingle)
            cell.avataClickHandler = { [weak self] in
                self?.avatarClickHandler?(model.user)
            }
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        if let model = video {
            itemClickHandler?(model)
        }
    }
}

class AchorHeaderView: UICollectionReusableView {
    static let reuseId = "AchorHeaderView"
    let titleLab: UILabel = {
        let l = UILabel()
        l.font = UIFont.boldSystemFont(ofSize: 16)
        l.textColor = .white
        return l
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(titleLab)
        titleLab.snp.makeConstraints { (make) in
            make.leading.equalTo(12)
            make.centerY.equalToSuperview()
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


class ModuleFootView: UICollectionReusableView {
    static let reuseId = "ModuleFootView"
    lazy var moreBtn: UIButton = {
        let v = UIButton(type: .custom)
        v.setImage(getImage("MoreItem"), for: .normal)
        v.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        v.setTitleColor(rgb(226, 188, 137), for: .normal)
        v.setTitle(" 更多", for: .normal)
        v.backgroundColor = ConstValue.kAppSepLineColor //rgb(30, 31, 49)
        v.borderRadius = 7.5
        v.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return v
    }()
    lazy var changeBtn: UIButton = {
        let v = UIButton(type: .custom)
        v.setImage(getImage("nextPageitem"), for: .normal)
        v.setTitleColor(rgb(226, 188, 137), for: .normal)
        v.setTitle(" 换一换", for: .normal)
        v.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        v.backgroundColor = ConstValue.kAppSepLineColor
        v.borderRadius = 7.5
        v.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return v
    }()
    var actionHandler:((_ index: Int) ->Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(moreBtn)
        addSubview(changeBtn)
        moreBtn.snp.makeConstraints { (make) in
            make.leading.equalTo(10)
            make.trailing.equalTo(self.snp.centerX).offset(-5)
            make.centerY.equalToSuperview()
            make.height.equalTo(40)
        }
        changeBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-10)
            make.centerY.equalToSuperview()
            make.leading.equalTo(moreBtn.snp.trailing).offset(10)
            make.height.equalTo(40)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func buttonClick(_ sender: UIButton) {
        
        if sender == moreBtn {
            tapScaleDownAnimation(sender.imageView!)
            tapScaleDownAnimation(sender.titleLabel!)
            actionHandler?(1)
        } else if sender == changeBtn {
            tapRotationAnimation(sender.imageView!)
            tapScaleDownAnimation(sender.titleLabel!)
            actionHandler?(2)
        }
    }
}


class VipCoinFootView: UICollectionReusableView {
    static let reuseId = "VipCoinFootView"
    let contentv: UIView = {
        let v = UIView()
        v.backgroundColor = ConstValue.kCoverBgColor
        v.borderRadius = 7.5
        return v
    }()
    let headerImg: UIImageView = {
        let v = UIImageView()
        v.isUserInteractionEnabled = true
        v.borderRadius = 19
        v.kfsetHeader(UserModel.share().user?.avatar)
        return v
    }()
    let nameLab: UILabel = {
        let lab = UILabel()
        lab.textColor = .white
        lab.font = UIFont.boldSystemFont(ofSize: 14)
        lab.text = UserModel.share().user?.nick
        return lab
    }()
    let dimondLab: UILabel = {
        let lab = UILabel()
        lab.textColor = rgb(247, 219, 172)
        lab.font = UIFont.boldSystemFont(ofSize: 18)
        lab.text = "钻石余额: \(UserModel.share().user?.coins ?? 0)"
        lab.isHidden = true
        return lab
    }()
    let vipTipsLab: UILabel = {
        let lab = UILabel()
        lab.textColor = .lightGray
        lab.font = UIFont.systemFont(ofSize: 11)
        lab.text = "\(UserModel.share().user?.vip_text ?? "") \(UserModel.share().user?.vip_expired_text ?? "")"
        return lab
    }()
    let vipDimondUpLab: UILabel = {
        let lab = UILabel()
        lab.textColor = .darkText
        lab.textAlignment = .center
        lab.borderRadius = 16
        lab.backgroundColor = UIColor.colorGradientChangeWithSize(size: CGSize(width: 65, height: 32), direction: .level, startColor: rgb(247, 219, 172), endColor: rgb(223, 180, 127))
        lab.font = UIFont.boldSystemFont(ofSize: 11)
        lab.text = "VIP升级"
        return lab
    }()
    lazy var chargeBtn: UIButton = {
        let v = UIButton(type: .custom)
        v.addTarget(self, action: #selector(buttonAction(_:)), for: .touchUpInside)
        return v
    }()
    let countDownLab: UILabel = {
        let lab = UILabel()
        lab.textColor = rgb(247, 207, 154)
        lab.textAlignment = .center
        lab.borderRadius = 22.5
        lab.bordercolor = rgb(247, 219, 172)
        lab.borderWidth = 1.0
        lab.font = UIFont.boldSystemFont(ofSize: 14)
        return lab
    }()
    lazy var coverBtn: UIButton = {
        let v = UIButton(type: .custom)
        v.addTarget(self, action: #selector(buttonAction(_:)), for: .touchUpInside)
        return v
    }()
    var tipsTimer = TipTimerMg()
    var clickAction:((_ actionId: Int) ->Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        addSubview(contentv)
        contentv.addSubview(headerImg)
        contentv.addSubview(nameLab)
        contentv.addSubview(vipTipsLab)
        contentv.addSubview(vipDimondUpLab)
        contentv.addSubview(countDownLab)
        contentv.addSubview(dimondLab)
      
        contentv.addSubview(chargeBtn)
        contentv.addSubview(coverBtn)
        layoutPageSubs()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func buttonAction(_ sender: UIButton) {
        if sender == chargeBtn {
            clickAction?(1)
        } else {
            clickAction?(2)
        }
    }
    
    func setSegIndex(_ segIndex: Int) {
        if segIndex == 0 {
            dimondLab.isHidden = true
            headerImg.isHidden = false
            nameLab.isHidden = false
            vipTipsLab.isHidden = false
            vipDimondUpLab.text = "VIP升级"
        } else if segIndex == 1 {
            dimondLab.isHidden = false
            headerImg.isHidden = true
            nameLab.isHidden = true
            vipTipsLab.isHidden = true
            vipDimondUpLab.text = "充值"
        }
        countDownLab.text = "\(UserModel.share().user?.countdown_intro ?? "")"
        if var time = UserModel.share().user?.countdown_time, time > 0 {
            if let display = UserModel.share().user?.countdown_display, display != 1 {
                countDownLab.text = "\(UserModel.share().user?.countdown_intro ?? "")"
                return
            }
            tipsTimer.releaseTimer()
            if time > 0 {
                countDownLab.text = "\(UserModel.share().user?.countdown_intro ?? "") \(LGConfig.timeDuration(duration: time))"
                tipsTimer.timer = Timer.every(1.0.seconds) { [weak self] in
                    guard let strongSelf = self else { return }
                    time = time - 1
                    if time > 1 {
                        let times1 = LGConfig.timeDuration(duration: time)
                        strongSelf.countDownLab.text = "\(UserModel.share().user?.countdown_intro ?? "") \(times1)"
                    } else {
                        strongSelf.countDownLab.text = "\(UserModel.share().user?.countdown_intro ?? "")"
                        strongSelf.tipsTimer.releaseTimer()
                    }
                }
                RunLoop.current.add(tipsTimer.timer!, forMode: .common)
            } else {
                countDownLab.isHidden = true
                countDownLab.text = "\(UserModel.share().user?.countdown_intro ?? "")"
            }
        }
    }
    
    func layoutPageSubs() {
        contentv.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.bottom.equalToSuperview()
        }
        headerImg.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(12)
            make.height.width.equalTo(38)
        }
        nameLab.snp.makeConstraints { (make) in
            make.leading.equalTo(headerImg.snp.trailing).offset(10)
            make.top.equalTo(headerImg)
            make.height.equalTo(19)
        }
        vipTipsLab.snp.makeConstraints { (make) in
            make.leading.equalTo(nameLab)
            make.top.equalTo(nameLab.snp.bottom)
            make.height.equalTo(19)
        }
        vipDimondUpLab.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.centerY.equalTo(headerImg)
            make.width.equalTo(65)
            make.height.equalTo(32)
        }
        countDownLab.snp.makeConstraints { (make) in
            make.leading.equalTo(headerImg)
            make.trailing.equalTo(vipDimondUpLab)
            make.top.equalTo(headerImg.snp.bottom).offset(20)
            make.height.equalTo(45)
        }
        dimondLab.snp.makeConstraints { (make) in
            make.leading.equalTo(20)
            make.centerY.equalTo(headerImg)
        }
        chargeBtn.snp.makeConstraints { (make) in
            make.edges.equalTo(vipDimondUpLab)
        }
        coverBtn.snp.makeConstraints { (make) in
            make.edges.equalTo(countDownLab)
        }
    }
}
