
import UIKit

enum BannerStype {
    case normal
    case fullWidth
    case bgImage
    case insertion  //穿插
}

/// 用于轮播的BannerCell
class BannerScrollCellNormal: UICollectionViewCell {
    
    static let cellId = "BannerScrollCellNormal"

    /// 普通顶部banner
    static let itemSize = CGSize(width: screenWidth, height: screenWidth*159/340)
  
    private lazy var cycleView: LTAutoScrollView = {
        let view = LTAutoScrollView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: BannerScrollCellNormal.itemSize.height))
        view.glt_timeInterval = 3.0
        view.adjustValue = 8.0
        view.dotDirection = .right
        let layout = LTDotLayout(dotColor: .lightGray, dotSelectColor: .white, dotType: .default)
        /*设置dot的间距*/
        layout.dotMargin = 6
        /* 如果需要改变dot的大小，设置dotWidth的宽度即可 */
        layout.dotWidth = 6
        layout.dotColor = .white
        layout.dotSelectColor = ConstValue.kStypeColor
        /*如需和系统一致，dot放大效果需手动关闭 */
        layout.isScale = false
        
        view.dotLayout = layout
        return view
    }()
    let coverView: UILabel = {
        let v = UILabel()
        v.backgroundColor = .clear
        return v
    }()
    let titleLabel: UILabel = {
        let lab = UILabel()
        lab.textColor = .white
        lab.numberOfLines = 2
        lab.font = UIFont.boldSystemFont(ofSize: 14)
        return lab
    }()
    let coverLayer: CAGradientLayer = {
        let ly = CAGradientLayer()
        ly.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenWidth*159/340)
        ly.colors = [UIColor.clear.cgColor, UIColor(white: 0.0, alpha: 0.5).cgColor]
        ly.locations = [0.75, 1.0]
        return ly
    }()
    var scrollItemClickHandler:((_ index: Int) -> Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.clear
        contentView.backgroundColor = .clear
        contentView.addSubview(cycleView)
        contentView.addSubview(coverView)
        coverView.layer.addSublayer(coverLayer)
        coverView.addSubview(titleLabel)
        cycleView.borderRadius = 5
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
  
    func setBanner(_ banners: [AdHome]?) {
        if let bans = banners, bans.count > 0 {
            cycleView.isHidden = false
            let covers = bans.map { (ad) -> String in
                return ad.cover ?? ""
            }
            if bans.count > 0 {
               titleLabel.text = bans[0].title
            }
            cycleView.images = covers
            cycleView.imageHandle = {(imageView, imageName) in
                imageView.kfSetHorizontalImageWithUrl(imageName)
            }
            cycleView.didSelectItemHandle = { [weak self] index in
                self?.scrollItemClickHandler?(index)
            }
            cycleView.autoDidSelectItemHandle = { [weak self] index in
                self?.titleLabel.text = bans[index].title
            }
        }
    }
    func layoutPageSubviews() {
        cycleView.snp.makeConstraints { (make) in
            make.top.bottom.equalToSuperview()
            make.leading.equalTo(0)
            make.trailing.equalTo(0)
        }
        coverView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        titleLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(11)
            make.trailing.equalTo(-5)
            make.bottom.equalTo(-10)
        }
    }
}

/// 用于轮播的Banner _BgImg
class BannerScrollCellBgImg: UICollectionViewCell {
    static let cellId = "BannerScrollCellBgImg"
    /// 底部带活动图片banner
    static let itemSize = CGSize(width: screenWidth, height: screenWidth*284/375)
 
    let bgimage: UIImageView = {
        let v = UIImageView()
        v.backgroundColor = .clear
        v.isUserInteractionEnabled = true
        v.contentMode = .scaleAspectFit
        return v
    }()
    lazy var coverBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.backgroundColor = .clear
        btn.addTarget(self, action: #selector(coverBtnClick), for: .touchUpInside)
        return btn
    }()
    let coverView: UILabel = {
        let v = UILabel()
        v.backgroundColor = .clear
        return v
    }()
    
    private lazy var cycleView: LTAutoScrollView = {
        let view = LTAutoScrollView(frame: CGRect(x: 15, y: 0, width: screenWidth - 30, height: (screenWidth-30)*159/340))
        view.glt_timeInterval = 3.0
        view.adjustValue = 8.0
        view.dotDirection = .right
        let layout = LTDotLayout(dotColor: .lightGray, dotSelectColor: .white, dotType: .default)
        /*设置dot的间距*/
        layout.dotMargin = 6
        /* 如果需要改变dot的大小，设置dotWidth的宽度即可 */
        layout.dotWidth = 6
        layout.dotColor = .white
        layout.dotSelectColor = ConstValue.kStypeColor
        /*如需和系统一致，dot放大效果需手动关闭 */
        layout.isScale = false
        
        view.dotLayout = layout
        return view
    }()
    let titleLabel: UILabel = {
        let lab = UILabel()
        lab.textColor = .white
        lab.numberOfLines = 2
        lab.font = UIFont.boldSystemFont(ofSize: 14)
        return lab
    }()
    let coverLayer: CAGradientLayer = {
        let ly = CAGradientLayer()
        ly.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenWidth*284/375)
        ly.colors = [UIColor.clear.cgColor, UIColor(white: 0.0, alpha: 0.5).cgColor]
        ly.locations = [0.85, 1.0]
        return ly
    }()
    var scrollItemClickHandler:((_ index: Int) -> Void)?
    var bgCoverClick:(() ->Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.clear
        contentView.backgroundColor = .clear
        contentView.addSubview(bgimage)
        contentView.addSubview(coverBtn)
        contentView.addSubview(cycleView)
        contentView.addSubview(coverView)
        cycleView.corner(byRoundingCorners: [.topLeft, .topRight], radii: 7.5)
        coverView.layer.addSublayer(coverLayer)
        coverView.addSubview(titleLabel)
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setCoverImg(_ imgUrl: String?) {
        bgimage.kfSetHorizontalImageWithUrl(imgUrl)
    }
    func setBanner(_ banners: [AdHome]?) {
        if let bans = banners, bans.count > 0 {
            cycleView.isHidden = false
            let covers = bans.map { (ad) -> String in
                return ad.cover ?? ""
            }
            if bans.count > 0 {
               titleLabel.text = bans[0].title
            }
            cycleView.images = covers
            cycleView.imageHandle = {(imageView, imageName) in
                imageView.kfSetHorizontalImageWithUrl(imageName)
            }
            cycleView.didSelectItemHandle = { [weak self] index in
                self?.scrollItemClickHandler?(index)
            }
            cycleView.autoDidSelectItemHandle = { [weak self] index in
                self?.titleLabel.text = bans[index].title
            }
        } else {
            cycleView.isHidden = true
        }
    }
    @objc func coverBtnClick() {
        bgCoverClick?()
    }
    func layoutPageSubviews() {
        cycleView.snp.makeConstraints { (make) in
            make.height.equalTo((screenWidth-30)*159/340)
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.bottom.equalTo(0)
        }
        coverBtn.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        bgimage.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        coverView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        titleLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(25)
            make.trailing.equalTo(-25)
            make.bottom.equalTo(-10)
        }
    }
}

/// 轮播图Insert
class BannerScrollFullWidth: UICollectionViewCell {
    
    static let cellId = "BannerScrollFullWidth"
 
    /// 左右顶满 banner
    static let itemSize = CGSize(width: screenWidth, height: screenWidth*260/375)
    
    private lazy var cycleView: LTAutoScrollView = {
        let view = LTAutoScrollView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: BannerScrollFullWidth.itemSize.height))
        view.glt_timeInterval = 3.0
        view.adjustValue = 8.0
        view.dotDirection = .right
        let layout = LTDotLayout(dotColor: .lightGray, dotSelectColor: .white, dotType: .default)
        /*设置dot的间距*/
        layout.dotMargin = 6
        /* 如果需要改变dot的大小，设置dotWidth的宽度即可 */
        layout.dotWidth = 6
        layout.dotColor = .white
        layout.dotSelectColor = ConstValue.kStypeColor
        /*如需和系统一致，dot放大效果需手动关闭 */
        layout.isScale = false
        
        view.dotLayout = layout
        return view
    }()
    let coverView: UILabel = {
        let v = UILabel()
        v.backgroundColor = .clear
        return v
    }()
    let titleLabel: UILabel = {
        let lab = UILabel()
        lab.textColor = .white
        lab.numberOfLines = 2
        lab.font = UIFont.boldSystemFont(ofSize: 14)
        return lab
    }()
    let coverLayer: CAGradientLayer = {
        let ly = CAGradientLayer()
        ly.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenWidth*260/375)
        ly.colors = [UIColor.clear.cgColor, UIColor(white: 0.0, alpha: 0.50).cgColor]
        ly.locations = [0.85, 1.0]
        return ly
    }()
    var scrollItemClickHandler:((_ index: Int) -> Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.clear
        contentView.backgroundColor = .clear
        contentView.addSubview(cycleView)
        contentView.addSubview(coverView)
        coverView.layer.addSublayer(coverLayer)
        coverView.addSubview(titleLabel)
        layoutPageSubviews()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setBanner(_ banners: [AdHome]?) {
        if let bans = banners, bans.count > 0 {
            cycleView.isHidden = false
            let covers = bans.map { (ad) -> String in
                return ad.cover ?? ""
            }
            if bans.count > 0 {
               titleLabel.text = bans[0].title
            }
            cycleView.images = covers
            cycleView.imageHandle = {(imageView, imageName) in
                imageView.kfSetHorizontalImageWithUrl(imageName)
            }
            cycleView.didSelectItemHandle = { [weak self] index in
                self?.scrollItemClickHandler?(index)
            }
            cycleView.autoDidSelectItemHandle = { [weak self] index in
                self?.titleLabel.text = bans[index].title
            }
        }
    }
    func layoutPageSubviews() {
        cycleView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        coverView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        titleLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.bottom.equalTo(-10)
        }
    }
}


/// 轮播图Insert
class BannerScrollInsert: UICollectionViewCell {
    
    static let cellId = "BannerScrollInsert"
 
    /// 插入在模块间的banner
    static let itemSize = CGSize(width: screenWidth, height: screenWidth*0.33)
    
    private lazy var cycleView: LTAutoScrollView = {
        let view = LTAutoScrollView(frame: CGRect(x: 0, y: 0, width: screenWidth , height: BannerScrollInsert.itemSize.height))
        view.glt_timeInterval = 3.0
        view.adjustValue = 8.0
        view.dotDirection = .right
        let layout = LTDotLayout(dotColor: .lightGray, dotSelectColor: .white, dotType: .default)
        /*设置dot的间距*/
        layout.dotMargin = 6
        /* 如果需要改变dot的大小，设置dotWidth的宽度即可 */
        layout.dotWidth = 6
        layout.dotColor = .white
        layout.dotSelectColor = ConstValue.kStypeColor
        /*如需和系统一致，dot放大效果需手动关闭 */
        layout.isScale = false
        
        view.dotLayout = layout
        return view
    }()
    var scrollItemClickHandler:((_ index: Int) -> Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.clear
        contentView.backgroundColor = .clear
        contentView.addSubview(cycleView)
        cycleView.borderRadius = 2
        layoutPageSubviews()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setBanner(_ banners: [AdHome]?) {
        if let bans = banners, bans.count > 0 {
            cycleView.isHidden = false
            let covers = bans.map { (ad) -> String in
                return ad.cover ?? ""
            }
            cycleView.images = covers
            cycleView.imageHandle = {(imageView, imageName) in
                imageView.kfSetHorizontalImageWithUrl(imageName)
            }
            cycleView.didSelectItemHandle = { [weak self] index in
                self?.scrollItemClickHandler?(index)
            }
        }
    }
    func layoutPageSubviews() {
        cycleView.snp.makeConstraints { (make) in
            make.leading.equalTo(0)
            make.trailing.equalTo(0)
            make.bottom.top.equalTo(0)
        }
    }
}

//MARK: - VIP 钻石页面 滚动广告
class ADScrollCell: UICollectionViewCell {
    static let cellId = "ADScrollCell"
    private let layout: UICollectionViewFlowLayout = {
        let l = UICollectionViewFlowLayout()
        l.scrollDirection = .horizontal
        l.itemSize = ADModulItemCell.itemSizeScroll
        l.minimumInteritemSpacing = 0
        l.minimumLineSpacing = 5
        l.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        return l
    }()
    lazy var collView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect.zero, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.showsHorizontalScrollIndicator = false
        collection.backgroundColor = UIColor.clear
        collection.register(ADModulItemCell.classForCoder(), forCellWithReuseIdentifier: ADModulItemCell.cellId)
        return collection
    }()
    var itemClickHandler:((_ index: Int) -> Void)?
    var ads = [AdHome]()
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(collView)
        collView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setModels(_ models: [AdHome]?) {
        if let vs =  models {
            ads = vs
            collView.reloadData()
        }
    }
}

extension ADScrollCell: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return ads.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ADModulItemCell.cellId, for: indexPath) as! ADModulItemCell
        cell.setAdModel(model: ads[indexPath.item])
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        itemClickHandler?(indexPath.item)
    }
}

class ADModulItemCell: UICollectionViewCell {
    
    static let cellId = "ADModulItemCell"
    
    static let itemSizeScroll = CGSize(width: (screenWidth - 12)/2.5, height: (screenWidth - 12)/5)
    
    private let imgView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = 5
        imageView.layer.masksToBounds = true
        return imageView
    }()
    let coverView: UIView = {
        let v = UIView()
        v.backgroundColor = UIColor(white: 0, alpha: 0.0)
        return v
    }()
    let titleLab: UILabel = {
        let titleLab = UILabel()
        titleLab.font = UIFont.boldSystemFont(ofSize: 14)
        titleLab.textAlignment = .center
        titleLab.numberOfLines = 2
        titleLab.textColor = .white
        return titleLab
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(imgView)
        imgView.addSubview(coverView)
        contentView.addSubview(titleLab)
        layoutPageViews()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setAdModel(model: AdHome) {
        imgView.kfSetHorizontalImageWithUrl(model.cover)
        titleLab.text = model.title ?? ""
    }
    
    func layoutPageViews() {
        imgView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        coverView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        titleLab.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(5)
            make.bottom.equalTo(-5)
        }
    }
}


class ADRandomCell: UICollectionViewCell {
    
    static let cellId = "ADRandomCell"
    
    static let itemSize = CGSize(width: (screenWidth - 4)/2, height: (screenWidth - 4)/2 * 3/4 + 30)
    
    private let imgView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = 2
        imageView.layer.masksToBounds = true
        return imageView
    }()
    let tipsLab: UILabel = {
        let titleLab = UILabel()
        titleLab.font = UIFont.systemFont(ofSize: 12)
        titleLab.textAlignment = .center
        titleLab.backgroundColor = UIColor(white: 0, alpha: 0.5)
        titleLab.textColor = .white
        titleLab.text = "广告"
        titleLab.borderWidth = 2
        titleLab.bordercolor = .white
        return titleLab
    }()
    let titleLab: UILabel = {
        let titleLab = UILabel()
        titleLab.font = UIFont.systemFont(ofSize: 12)
        titleLab.textColor = .white
        return titleLab
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(imgView)
        contentView.addSubview(tipsLab)
        contentView.addSubview(titleLab)
        layoutPageViews()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setAdModel(model: AdHome) {
        imgView.kfSetHorizontalImageWithUrl(model.cover)
        titleLab.text = model.title ?? ""
    }
    
    func layoutPageViews() {
        imgView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo((screenWidth - 2)/2 * 3/4)
        }
        titleLab.snp.makeConstraints { (make) in
            make.leading.equalTo(1)
            make.trailing.equalTo(-1)
            make.top.equalTo(imgView.snp.bottom).offset(5)
            make.height.equalTo(20)
        }
        tipsLab.snp.makeConstraints { (make) in
            make.leading.equalTo(imgView).offset(5)
            make.bottom.equalTo(imgView).offset(-5)
            make.height.equalTo(20)
            make.width.equalTo(40)
        }
        
    }
}
