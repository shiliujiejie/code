

import UIKit

class SegmentScrollCell: UICollectionViewCell {
    
    static let cellId = "SegmentScrollCell"
    
    let segmentView: SegmentItemView = {
        let segV = SegmentItemView(frame: CGRect.zero)
        segV.backgroundColor = ConstValue.kVcViewColor
        return segV
    }()
    var segmentTapHandler:((_ index: Int) -> Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(segmentView)
        segmentView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        segmentView.segAction = { [weak self] index in
            self?.segmentTapHandler?(index)
        }
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setCitys(_ models: [LFLocalModel]) {
        let citys = models.map { (model) -> String in
            return model.province ?? ""
        }
        segmentView.setTitles(citys)
    }
    func setSonCitys(_ sonCitys: [String]) {
        segmentView.setTitles(sonCitys)
    }
}


class SegItemDoubleView: UICollectionReusableView {
    static let identifier = "SegItemDoubleView"
    static let headerSizeSg = CGSize(width: screenWidth, height: 50)
    static let headerSizeDb = CGSize(width: screenWidth, height: 200)
    let segView1: SegmentItemView = {
        let segV = SegmentItemView(frame: CGRect.zero)
        segV.type = 1
        return segV
    }()
    let segView2: SegmentItemView = {
        let segV = SegmentItemView(frame: CGRect.zero)
        segV.type = 1
        return segV
    }()
    let segView3: SegmentItemView = {
        let segV = SegmentItemView(frame: CGRect.zero)
        segV.type = 1
        return segV
    }()
    let segView4: SegmentItemView = {
        let segV = SegmentItemView(frame: CGRect.zero)
        segV.type = 1
        return segV
    }()
    var firstItemTapHandler:((_ index: Int) -> Void)?
    var secondItemTapHandler:((_ index: Int) -> Void)?
    var thirdItemTapHandler:((_ index: Int) -> Void)?
    var fourthItemTapHandler:((_ index: Int) -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initialize()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initialize()
    }
    private func initialize() {
        addSubview(segView1)
        addSubview(segView2)
        addSubview(segView3)
        addSubview(segView4)
        layoutSegViews()
    }
    
    func setFirstTitles(_ titles: [String]) {
        segView1.setTitles(titles)
        segView1.segAction = { [weak self] index in
            self?.firstItemTapHandler?(index)
        }
    }
    func setSecondTitles(_ titles: [String]) {
        segView2.setTitles(titles)
        segView2.segAction = { [weak self] index in
            self?.secondItemTapHandler?(index)
        }
    }
    func setThirdTitles(_ titles: [String]) {
        segView3.setTitles(titles)
        segView3.segAction = { [weak self] index in
            self?.thirdItemTapHandler?(index)
        }
    }
    func setFourthTitles(_ titles: [String]) {
        segView4.setTitles(titles)
        segView4.segAction = { [weak self] index in
            self?.fourthItemTapHandler?(index)
        }
    }
    func setIndexs(_ firstIndex: Int, _ secondIndex: Int, _ thirdIndex: Int, _ fourthIndex: Int) {
        segView1.setIndex(firstIndex)
        segView2.setIndex(secondIndex)
        segView3.setIndex(thirdIndex)
        segView4.setIndex(fourthIndex)
    }
    
    private func layoutSegViews() {
        segView1.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(5)
            make.height.equalTo(40)
        }
        segView2.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(segView1.snp.bottom).offset(5)
            make.height.equalTo(40)
        }
        segView3.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(segView2.snp.bottom).offset(5)
            make.height.equalTo(40)
        }
        segView4.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(segView3.snp.bottom).offset(5)
            make.height.equalTo(40)
        }
    }
}

class CityChoseTipView: UICollectionReusableView {
    static let identifier = "CityChoseTipView"
    static let headerSizeSg = CGSize(width: screenWidth, height: 36)
    let bgv: UIView = {
        let v = UIView()
        v.backgroundColor = ConstValue.kCoverBgColor
        return v
    }()
    let cityLable: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.systemFont(ofSize: 14)
        lab.textColor = rgb(255 ,239,195)
        return lab
    }()
    let img: UIImageView = {
        let img = UIImageView(image: getImage("chatMeArrow"))
        img.contentMode = .scaleAspectFit
        img.isUserInteractionEnabled = true
        return img
    }()
    lazy var itemBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.addTarget(self, action: #selector(itemClick), for: .touchUpInside)
        return btn
    }()
    var cityItemTapHandler:(() -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initialize()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initialize()
    }
    private func initialize() {
        backgroundColor = ConstValue.kVcViewColor
        addSubview(bgv)
        addSubview(cityLable)
        addSubview(img)
        addSubview(itemBtn)
        layoutSegViews()
    }
    @objc func itemClick() {
        cityItemTapHandler?()
    }
    
    func setTitle(_ title: String) {
        cityLable.text = title
    }
    
    private func layoutSegViews() {
        bgv.snp.makeConstraints { (make) in
            make.top.equalTo(6)
            make.leading.trailing.bottom.equalToSuperview()
        }
        cityLable.snp.makeConstraints { (make) in
            make.center.equalTo(bgv)
        }
        img.snp.makeConstraints { (make) in
            make.leading.equalTo(cityLable.snp.trailing).offset(5)
            make.centerY.equalTo(cityLable)
            make.width.height.equalTo(8)
        }
        itemBtn.snp.makeConstraints { (make) in
            make.edges.equalTo(bgv)
        }
    }
}


class TipInfoItemView: UIView, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    private let customLayout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.sectionInset = UIEdgeInsets.zero
        return layout
    }()
    private lazy var collView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect.zero, collectionViewLayout: customLayout)
        collection.backgroundColor = UIColor.clear
        collection.showsHorizontalScrollIndicator = false
        collection.delegate = self
        collection.dataSource = self
        collection.register(TipInfoItemCell.classForCoder(), forCellWithReuseIdentifier: TipInfoItemCell.cellId)
        return collection
    }()
    
    var titles = [String]()
    var itemColor: UIColor = UIColor(white: 240/255, alpha: 1)
    var textColor = UIColor.white
    var itemClickHandler:(() -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initialize()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func initialize() {
        addSubview(collView)
        layoutSegmentCollection()
    }
    
    func setTitles(_ titles: [String]) {
        self.titles = titles
        collView.reloadData()
    }
   
    private func layoutSegmentCollection() {
        collView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.centerY.equalToSuperview()
            make.height.equalTo(30)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return titles.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let title = titles[indexPath.item]
        let size = UILabel().textSize(text: title, font: UIFont.systemFont(ofSize: 12), maxSize: CGSize(width: 300, height: 25))
        return title.isEmpty ? CGSize.zero : CGSize(width: size.width + 25, height: 25)
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: TipInfoItemCell.cellId, for: indexPath) as! TipInfoItemCell
        cell.titleLabel.text = titles[indexPath.item]
        cell.titleLabel.backgroundColor = itemColor
        cell.titleLabel.textColor = textColor
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: false)
        itemClickHandler?()
    }
}


class TipInfoItemCell: UICollectionViewCell {
    static let cellId = "TipInfoItemCell"
    let titleLabel: UILabel = {
        let lab = UILabel()
        lab.textColor = .white
        lab.font = UIFont.systemFont(ofSize: 12)
        lab.layer.cornerRadius = 3
        lab.textAlignment = .center
        lab.layer.masksToBounds = true
        lab.isUserInteractionEnabled = false
        return lab
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(titleLabel)
        titleLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(2.5)
            make.trailing.equalTo(-2.5)
            make.top.bottom.equalToSuperview()
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
