
import UIKit

class DetailNavBar: UIView {
    
    weak open var delegate: CLNavigationBarDelegate?
    
    let titleLabel: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .left
        lable.textColor = UIColor.white
        lable.font = UIFont.boldSystemFont(ofSize: 15)
        return lable
    }()
    let avatarImg: UIImageView = {
        let image = UIImageView()
        image.contentMode = .scaleAspectFill
        image.layer.cornerRadius = 17.5
        image.layer.masksToBounds = true
        image.isUserInteractionEnabled = true
        return image
    }()
    lazy var userButton: UIButton = {
           let button = UIButton(type: .custom)
           button.addTarget(self, action: #selector(rightAction(_:)), for: .touchUpInside)
           return button
       }()
    lazy var backButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "navBackBlack"), for: .normal)
        button.addTarget(self, action: #selector(backAction), for: .touchUpInside)
        return button
    }()
    lazy var rightButton: UIButton = {
        let button = UIButton(type: .custom)
        button.addTarget(self, action: #selector(rightAction(_:)), for: .touchUpInside)
        button.backgroundColor = ConstValue.kStypeColor
        button.setTitle("关注", for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 12)
        button.layer.cornerRadius = 15
        button.bounds = CGRect(x: 0, y: 0, width: 65, height: 28)
        return button
    }()
    var navBackBlack: Bool = true {
        didSet {
            if navBackBlack {
                backButton.setImage(UIImage(named: "navBackBlack"), for: .normal)
            } else {
                backButton.setImage(UIImage(named: "navBackWhite"), for: .normal)
            }
        }
    }
    var rightActionHandler:((_ id: Int) -> Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setUpUI() {
        addSubview(backButton)
        addSubview(avatarImg) 
        addSubview(titleLabel)
        addSubview(userButton)
        addSubview(rightButton)
        layoutSubs()
    }
    @objc func backAction() {
        delegate?.backAction()
    }
    @objc func rightAction(_ sender: UIButton) {
        if sender == userButton {
            rightActionHandler?(1)
        } else if sender == rightButton {
            tapScaleDownAnimation(sender)
            rightActionHandler?(2)
        }
    }
    private func layoutSubs() {
        backButton.snp.makeConstraints { (make) in
            make.leading.equalTo(5)
            make.top.equalTo(ConstValue.kStatusBarHeight + 5)
            make.bottom.equalToSuperview().offset(-5)
            make.width.equalTo(34)
        }
        avatarImg.snp.makeConstraints { (make) in
            make.leading.equalTo(backButton.snp.trailing).offset(5)
            make.centerY.equalTo(backButton)
            make.height.width.equalTo(35)
        }
        titleLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(avatarImg.snp.trailing).offset(10)
            make.centerY.equalTo(avatarImg)
        }
        userButton.snp.makeConstraints { (make) in
            make.leading.equalTo(avatarImg)
            make.trailing.equalTo(titleLabel)
            make.centerY.equalTo(backButton)
            make.height.equalTo(35)
        }
        rightButton.snp.makeConstraints { (make) in
            make.trailing.equalTo(-12)
            make.centerY.equalTo(backButton)
            make.width.equalTo(65)
            make.height.equalTo(30)
        }
    }
    
}
