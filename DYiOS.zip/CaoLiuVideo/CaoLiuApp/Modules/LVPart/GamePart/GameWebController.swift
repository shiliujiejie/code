import UIKit
import WebKit

class GameWebController: UIViewController {
    
    static let kListener = "JSListener"
    private let estimatedProgressKeyPath = "estimatedProgress"
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .default
    }
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    override var shouldAutorotate: Bool  {
        return true
    }
    private lazy var wkConfig: WKWebViewConfiguration = {
        let config = WKWebViewConfiguration()
        //声明一个WKUserScript对象
        let script = WKUserScript.init(source: "", injectionTime: .atDocumentEnd, forMainFrameOnly: true)
        config.userContentController.addUserScript(script)
        return config
    }()
    private lazy var webView: WKWebView = {
        let webView = WKWebView(frame: CGRect(x: 0, y: 0, width: kScreenWdith, height: kScreenHeight), configuration: wkConfig)
        //webView.navigationDelegate = self
        webView.scrollView.showsHorizontalScrollIndicator = false
        webView.scrollView.backgroundColor = UIColor.white
        webView.scrollView.showsVerticalScrollIndicator = false
        webView.allowsBackForwardNavigationGestures = true
        webView.allowsLinkPreview = true
        webView.addObserver(self, forKeyPath: estimatedProgressKeyPath, options: .new, context: nil)
        webView.isHidden = true
        return webView
    }()
    private lazy var feedButton: ServerButton = {
        let frame = CGRect.init(x: 0, y: statusBarHeight + 10, width: 40, height: 40)
        let button = ServerButton(frame: frame)
        button.backgroundColor = UIColor(white: 0.6, alpha: 0.9)
        button.radiuOfButton = 20.5
        button.paddingOfbutton = 0
        button.alphaOfNormol = 0.5
        button.alphaOfDrag = 1.0
        button.delegate = self
        button.setImage(UIImage(named: "GameMenu"), for: .normal)
        return button
    }()
    lazy var menebutton: CircleMenu = {
        let button = CircleMenu(
            frame: CGRect(x: screenWidth/2 - 25, y: screenHeight/2 - 25, width: 50, height: 50),
            normalIcon:"GameMenu",
            selectedIcon:"GameMenu",
            buttonsCount: 3,
            duration: 1,
            distance: 80)
        button.delegate = self
        button.isHidden = true
        button.layer.cornerRadius = button.frame.size.width / 2.0
        return button
    }()
    private lazy final var progressView: UIProgressView = {
        let progressView = UIProgressView(frame: CGRect(x: 90, y: UIScreen.main.bounds.height/2 - 4, width: screenWidth-180, height: 8))
        progressView.progressViewStyle = .bar
        progressView.tintColor = UIColor.orange
        progressView.trackTintColor = UIColor.lightGray
        progressView.borderRadius = 4
        return progressView
    }()
    let loadingLab: UILabel = {
        let v = UILabel()
        v.textColor = .orange
        v.textAlignment = .center
        v.font = UIFont.boldSystemFont(ofSize: 16)
        v.text = "加载中..."
        //v.isHidden = true
        return v
    }()
    var isFirstLoading: Bool = true
    var gameModel: GameListModel?
    
    private var openUrl: URL?
    lazy var viewModel: GameDataViewModel = {
        let v = GameDataViewModel()
        return v
    }()
    
    var gameExitCallBack:((_ balance: String) ->Void)?
    
    deinit {
        DLog("vc is deinit -- ")    // 出站的时候，这里没走，说明当前控制器没有被释放调，存在内存泄漏
        viewModel.timerHodler.timer?.invalidate()
        viewModel.timerHodler.timer = nil
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        if let delegate = UIApplication.shared.delegate as? AppDelegate {
            delegate.location = .gameDetail
        }
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        view.addSubview(webView)
        view.addSubview(progressView)
        view.addSubview(feedButton)
        view.addSubview(menebutton)
        view.addSubview(loadingLab)
        menebutton.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.height.width.equalTo(50)
        }
        webView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        progressView.snp.makeConstraints { (make) in
            make.leading.equalTo(90)
            make.trailing.equalTo(-90)
            make.centerY.equalToSuperview()
            make.height.equalTo(8)
        }
        loadingLab.snp.makeConstraints { (make) in
            make.leading.equalTo(progressView.snp.leading).offset(0)
            make.bottom.equalTo(progressView.snp.top).offset(-5)
        }
        if #available(iOS 11.0, *) {
            webView.scrollView.contentInsetAdjustmentBehavior = .never
        } else {
            self.automaticallyAdjustsScrollViewInsets = false
        }
        self.webView.scrollView.contentInset = UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
        loadWebUrl()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let delegate = UIApplication.shared.delegate as? AppDelegate {
            delegate.isLandscape = true
        }
        UIApplication.shared.isIdleTimerDisabled = true
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        UIDevice.current.setValue(NSNumber(integerLiteral: UIInterfaceOrientation.landscapeLeft.rawValue), forKey: "orientation")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        UIApplication.shared.isIdleTimerDisabled = false
    }
    /// 加载网页
    private func loadWebUrl() {
        if openUrl != nil {
            webView.load(URLRequest(url: openUrl!))
        }
        viewModel.timerHodler.timer?.invalidate()
        viewModel.timerHodler.timer = nil
        viewModel.timerHodler.timer = Timer.every(30.second) { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.viewModel.loadGameActionData(params: [GameActionApi.kAction: GameActionApi.kPing]) { _ in
            } failure: { (error) in

            }
        }
    }
    
    private func quitGame() {
        viewModel.loadGameActionData(params: [GameActionApi.kAction: GameActionApi.kExit]) { [weak self] b in
            self?.outGame(b)
        } failure: { [weak self] (error) in
            self?.outGame("0.00")
        }
    }
    
    func outGame(_ balance: String) {
        gameExitCallBack?(balance)
        if let delegate = UIApplication.shared.delegate as? AppDelegate {
            delegate.isLandscape = false
        }
        UIDevice.current.setValue(NSNumber(integerLiteral: UIInterfaceOrientation.portrait.rawValue), forKey: "orientation")
        closeBtnClick()
    }
    
    init(url: URL) {
        openUrl = url
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func closeBtnClick() {
        navigationController?.popViewController(animated: false)
    }
}

//MARK: -KVO
extension GameWebController {
    open override func observeValue(forKeyPath keyPath: String?,
                                    of object: Any?,
                                    change: [NSKeyValueChangeKey : Any]?,
                                    context: UnsafeMutableRawPointer?) {
        guard let theKeyPath = keyPath , object as? WKWebView == webView else {
            super.observeValue(forKeyPath: keyPath, of: object, change: change, context: context)
            return
        }
        if isFirstLoading && theKeyPath == estimatedProgressKeyPath {
            updateProgress()
        }
    }
    
    // MARK: Private
    private final func updateProgress() {
        let completed = webView.estimatedProgress == 1.0
        progressView.setProgress(completed ? 0.0 : Float(webView.estimatedProgress), animated: !completed)
        progressView.trackTintColor = completed ? .clear : .lightGray
        if !completed {
            loadingLab.isHidden = false
            loadingLab.snp.updateConstraints { (make) in
                make.leading.equalTo(progressView.snp.leading).offset((UIScreen.main.bounds.width - 180) * CGFloat(webView.estimatedProgress))
            }
        } else {
            webView.isHidden = false
            isFirstLoading = false
            loadingLab.snp.updateConstraints { (make) in
                make.leading.equalTo(progressView.snp.leading).offset(0)
            }
            loadingLab.isHidden = true
            progressView.isHidden = true
            webView.removeObserver(self, forKeyPath: estimatedProgressKeyPath, context: nil)
        }
        UIApplication.shared.isNetworkActivityIndicatorVisible = !completed
        
    }
}

// MARK: - FloatDelegate
extension GameWebController: FloatDelegate {
    
    func singleClick() {
        menebutton.onTap()
    }
    func repeatClick() {
        
    }
}
extension GameWebController: CircleMenuDelegate {
    func circleMenu(_: CircleMenu, willDisplay button: UIButton, atIndex: Int) {
        button.backgroundColor = [UIColor.white, UIColor.white, UIColor.white][atIndex]
        button.setTitleColor([UIColor.darkText, UIColor.red, UIColor.blue][atIndex], for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 11)
        button.setTitle(["充值","退出","刷新"][atIndex], for: .normal)
        button.addShadow(radius: 8, opacity: 0.9, UIColor.darkGray)
    }

    func circleMenu(_: CircleMenu, buttonWillSelected _: UIButton, atIndex: Int) {
        print("button will selected: \(atIndex)")
        if atIndex == 1 {
            showDialog(title: "退出游戏", message: "确认退出游戏", okTitle: "确认退出", cancelTitle: "在玩一会") {
                self.quitGame()
            } cancelHandler: {
            }
        } else if atIndex == 0 {
            if let delegate = UIApplication.shared.delegate as? AppDelegate {
                delegate.isLandscape = false
            }
            UIDevice.current.setValue(NSNumber(integerLiteral: UIInterfaceOrientation.portrait.rawValue), forKey: "orientation")
            let vc = GameChargeController()
            navigationController?.pushViewController(vc, animated: true)
        } else if atIndex == 2 {
            self.webView.reload()
        }
    }

    func circleMenu(_: CircleMenu, buttonDidSelected _: UIButton, atIndex: Int) {
        print("button did selected: \(atIndex)")
    }
}

//MARK: -WKWebView的代理
extension GameWebController: WKNavigationDelegate {
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        decisionHandler(.allow)
    }
    // 开始接收响应
    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        decisionHandler(.allow)
    }
    //用于授权验证的API，与AFN、UIWebView的授权验证API是一样的
    func webView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        completionHandler(.performDefaultHandling ,nil)
    }
    // 开始加载数据
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        webView.isHidden = false
        // self.indicatorView.startAnimating()
    }
    // 当main frame接收到服务重定向时调用
    func webView(_ webView: WKWebView, didReceiveServerRedirectForProvisionalNavigation navigation: WKNavigation!) {
        // 接收到服务器跳转请求之后调用
    }
    // 当内容开始返回时调用
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        webView.evaluateJavaScript("document.body.offsetHeight") { [weak self] (result, error) in
            if self != nil {
                if let webheight = result as? CGFloat {
                    DLog("网页高度= \(webheight)")
                }
            }
        }
    }
    //当main frame导航完成时，会回调
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        
        webView.evaluateJavaScript("document.body.offsetHeight") { [weak self] (result, error) in
            if self != nil {
                if let webheight = result as? CGFloat {
                    DLog("网页高度= \(webheight)")
                }
            }
        }
    }
    // 当web content处理完成时，会回调
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        webView.evaluateJavaScript("document.body.offsetHeight") { [weak self] (result, error) in
            if self != nil {
                if let webheight = result as? CGFloat {
                    DLog("网页高度= \(webheight)")
                }
            }
        }
    }
    
    // 当main frame开始加载数据失败时，会回调
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        
    }
    // 当main frame最后下载数据失败时，会回调
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        
    }
}


