
import UIKit
import Alamofire

class HomeMainController: UIViewController {
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    let segmentBarVC : SegmentBarVC = SegmentBarVC()
    let topBarV = UIView()
    let contentContainerV = UIView()
    let stabar = UIView()
    private var topSegView: HomeTopSegView = {
        guard let view = Bundle.main.loadNibNamed("HomeTopSegView", owner: nil, options: nil)?[0] as? HomeTopSegView else { return HomeTopSegView() }
        view.backgroundColor = UIColor.darkText
        return view
    }()
    var player: PlayerView = {
        let player = PlayerView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight))
        player.controlViewBottomInset = safeAreaBottomHeight + 49
        player.progressHeight = 0.7
        player.minTimeForDragProgress = 20
        player.progressTintColor = UIColor.white
        return player
    }()
    var controllers = [HomeViewController]()
    
    private let viewModel = VideoViewModel()
    var signModel = SignInfo()
    var firstIn = true
    
    /// 签到图片index
    var signIndex: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(updateCoinsInfo), name: Notification.Name.kUserBasicalInformationChanged, object: nil)
        view.backgroundColor = UIColor.clear
        setUpSegmentView()
        segmentBarVC.selectBlock = { [weak self] (index) in
            self?.selectIndex(index: index)
        }
        /// 请求分享数据
        let _ = viewModel.loadShareApi()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isTranslucent = false
        topSegView.diamondLab.text = nil//getStringWithNumber(UserModel.share().user?.coins ?? 0)
        player.play()
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        player.pause()
    }
    
    // 子类重写这个方法
    func selectIndex(index: Int){
        let vc = controllers[index]
        vc.player = self.player
        player.delegate = vc
        vc.playCurrent()
        topSegView.selectedIndex(index)
    }
    
    func setUpSegmentView() {
    
        let vc1 = HomeViewController()
        vc1.vcIndex = 0
        vc1.isRecoment = false
        
        let vc2 = HomeViewController()
        vc2.vcIndex = 1
        vc2.player = self.player
        player.delegate = vc2
        
        let vcs = [vc1, vc2]

        controllers = vcs
        // 添加标题和选择控制器
        segmentBarVC.detaultSelectdIndex = 1
        segmentBarVC.setupTitlesAndChildVCs(childVCs: vcs)
        addContainerV()
        addChild(segmentBarVC)
        segmentBarVC.view.frame = contentContainerV.bounds
        contentContainerV.addSubview(segmentBarVC.view)
    }

    private func addContainerV(){
        topBarV.frame = CGRect(x: 0, y:0, width: UIScreen.main.bounds.width, height: 44)
        topBarV.backgroundColor = UIColor.clear
        view.addSubview(topBarV)
        contentContainerV.frame = CGRect(x: 0, y: 0, width: screenWidth , height: screenHeight)
        view.addSubview(contentContainerV)
        setUpTop()
    }
    
    func setUpTop() {
        view.addSubview(stabar)
        stabar.backgroundColor = UIColor.darkText
        view.addSubview(topSegView)
        topSegView.defaultSelectedIndex = 1
        topSegView.diamondLab.text = nil //getStringWithNumber(UserModel.share().user?.coins ?? 0)
        topSegView.actionHandler = { [weak self] (tag) in
            guard let strongSelf = self else { return }
            if tag == 1 {
                strongSelf.segmentBarVC.segmentBarDidSelected(toIndex: 0, fromIndex: 1)
            } else if tag == 2 {
                strongSelf.segmentBarVC.segmentBarDidSelected(toIndex: 1, fromIndex: 0)
            } else if tag == 3 {
                let v = SearchMainController()
                strongSelf.navigationController?.pushViewController(v, animated: true)
            } else if tag == 4 {
                if UserModel.share().user?.is_vip != "y" {
                    strongSelf.showDialog(title: "温馨提示", message: "\n开通VIP才能发布视频作品哦～\n", okTitle: "充值VIP", cancelTitle: "取消", okHandler: {
                        let vip = VipCardsController()
                        strongSelf.navigationController?.pushViewController(vip, animated: true)
                    }, cancelHandler: nil)
                    return
                }
                strongSelf.choseVideoFromLibrary()
            }
        }
        stabar.snp.makeConstraints { (make) in
            make.top.equalTo(0)
            make.leading.trailing.equalToSuperview()
            make.height.equalTo(statusBarHeight)
        }
        topSegView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(statusBarHeight)
            make.height.equalTo(44)
        }
    }
    @objc func updateCoinsInfo() {
        topSegView.diamondLab.text = nil //getStringWithNumber(UserModel.share().user?.coins ?? 0)
    }
    /// 从相册选择视频
    func choseVideoFromLibrary() {
        UserModel.share().isPushLF = false
        let storyboard: UIStoryboard = UIStoryboard(name: "Thumbnail", bundle: nil)
        let vc: ThumbnailViewController = storyboard.instantiateViewController(withIdentifier: "Thumbnail") as! ThumbnailViewController
        let nav = CLNavigationController.init(rootViewController: vc)
        nav.modalPresentationStyle = .fullScreen
        self.present(nav, animated: true, completion: nil)
    }
}

//MARK: - 签到业务处理
extension HomeMainController {
    
    func signSuccess(_ sign: SignInfo) {
        signModel = sign
        if let user = sign.user_info {
            UserModel.share().user = user
            updateCoinsInfo()
        }
        if sign.is_first == 1 { // 今日第一次
            let signView = SignAlertView(frame: self.view.bounds)
            view.addSubview(signView)
            signView.setSignShort(sign)
            signView.goDetailHandler = { [weak self] in
                guard let strongSelf = self else { return }
                let vc = DailyInController()
                vc.signModel = strongSelf.signModel
                strongSelf.navigationController?.pushViewController(vc, animated: true)
                signView.removeFromSuperview()
            }
        }
        if let sourcePath = LGConfig.sourceFilePath(LGConfig.kDirectSign) {
            if let images = LGConfig.findFiles(path: sourcePath) {
                if images.count < (sign.sign_ini?.maxday ?? 0) {
                    DLog("signSourceFilePath - fileNumber == \(images.count)")
                    download(signIndex)
                } else {
                    DLog("signSourceFilePath --- \(images.count)")
                }
            }
        }
    }
    func download(_ index: Int) {
        if let signDatas = signModel.sign_ini?.ini, signDatas.count > index {
            if let URL = URL(string: signDatas[index].cover ?? "") {
                downLoadImageDataWith(URL)
            }
        }
    }
    
    /// 下载图片
   func downLoadImageDataWith(_ url: URL) {
    }
}

class LGConfig: NSObject {
    
    static let kDirectSign = "SignAlertImgs"
    /// 签到弹框图片 根目录
    class func sourceFilePath(_ directory: String) -> String? {
        let docDir = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        let filePath = (docDir as NSString).appendingPathComponent(directory)
        if !FileManager.default.fileExists(atPath: filePath) {
            do {
                try FileManager.default.createDirectory(atPath: filePath, withIntermediateDirectories: true, attributes: nil)
            } catch {
                DLog(error)
                return nil
            }
        }
        return filePath
    }
    /// 查找文件夹下所有文件
    class func findFiles(path: String) -> [String]? {
        var files = [String]()
        guard let enumerator = FileManager.default.enumerator(atPath: path) else { return nil }
        while let element = enumerator.nextObject() as? String {
            files.append(element)
        }
        return files
    }
    /// 指定类型查找文件夹下文件
    class func findFiles(path: String, filterTypes: [String]) -> [String] {
        do {
            let files = try FileManager.default.contentsOfDirectory(atPath: path)
            if filterTypes.count == 0 {
                return files
            } else {
                let filteredfiles = NSArray(array: files).pathsMatchingExtensions(filterTypes)
                return filteredfiles
            }
        } catch {
            return []
        }
    }
     
    /// 保存下载好的 '图片'  资源到本地沙盒
    class func saveDataToLocal(_ url: String, _ directory: String ,data: Data?) -> Bool {
        guard data != nil, let filePath = self.filePath(url, directory) else {
            return false
        }
        let isSuccess = NSKeyedArchiver.archiveRootObject(data!, toFile: filePath)
        return isSuccess
    }
    
    /// 获取本地缓存 的 图片
    class func getAdDataFromLocal(_ url: String,_ directory: String) -> Data? {
        guard let filePath = self.filePath(url,directory) else {
            return nil
        }
        let data = NSKeyedUnarchiver.unarchiveObject(withFile: filePath) as? Data
        return data
    }
    
    /// 获取本地缓存的  ’图片‘ 文件路径，没有则创建一个
    class func filePath(_ url: String, _ directory: String) -> String? {
        guard let filePath = sourceFilePath(directory) else {
            return nil
        }
        DLog("rootFilePath: == \(filePath)")
        // 把资源路径通过MD5加密后，作为文件的名称进行保存
        return (filePath as NSString).appendingPathComponent(url.md5() + ".data")
    }
    
    /// 本地图片根目录
    class func localImageFilePath() -> String? {
        let docDir = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        let filePath = (docDir as NSString).appendingPathComponent("LocalImgs")
        if !FileManager.default.fileExists(atPath: filePath) {
            do {
                try FileManager.default.createDirectory(atPath: filePath, withIntermediateDirectories: true, attributes: nil)
            } catch {
                print(error)
                return nil
            }
        }
        return filePath
    }
    
    /// 获取本地缓存的  ’图片‘ 文件路径，没有则创建一个
    class func imagePath(_ name: String) -> String? {
        guard let filePath = localImageFilePath() else {
            return nil
        }
        let imageFiles = filePath + "/DYLocalImgs"
       // DLog("imagePathFilePath: == \(filePath)")
        // 把资源路径通过MD5加密后，作为文件的名称进行保存
        return (imageFiles as NSString).appendingPathComponent(name + ".png")
    }
    
}

/// 本地图片这里
extension NSObject {
    class func getImage(_ name: String) -> UIImage?  {
//        guard let imagePath = LGConfig.imagePath(name) else { return nil }
//        let imageUrl = URL(fileURLWithPath: imagePath)
//        if let imageData = try? Data(contentsOf: imageUrl) {
//            let image = UIImage(data: imageData)
//            return image
//        }
        return UIImage(named: "\(name).png")
    }
    func getImage(_ name: String)  -> UIImage? {
//        guard let imagePath = LGConfig.imagePath(name) else { return nil }
//        let imageUrl = URL(fileURLWithPath: imagePath)
//        if let imageData = try? Data(contentsOf: imageUrl) {
//            let image = UIImage(data: imageData)
//            return image
//        }
        return UIImage(named: "\(name).png")
    }
}



