
import UIKit

class DailyInController: CLBaseViewController, CLNavigationBarDelegate {

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.titleLabel.text = nil
        bar.backgroundColor = .clear
        bar.lineView.isHidden = true
        bar.navBackBlack = false
        bar.backButton.isHidden = false
        bar.delegate = self
        return bar
    }()
    lazy var table: UITableView = {
        let ta = UITableView(frame: CGRect.zero, style: .plain)
        ta.showsVerticalScrollIndicator = false
        ta.bounces = false
        ta.allowsSelection = false
        ta.separatorStyle = .none
        ta.delegate = self
        ta.dataSource = self
        ta.register(SignRuleCell.classForCoder(), forCellReuseIdentifier: "signRuleCell")
        return ta
    }()
    let topImage = UIImageView(image: getImage("DailyInBg"))
    let lLabel: UILabel =  {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: 17)
        label.text = "今日登錄獎勵"
        return label
    }()
    let diamondlab: UILabel =  {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.boldSystemFont(ofSize: 45)
        return label
    }()
    let headerTipsview: UIView = {
        let view = UIView()
        view.bounds = CGRect(x: 0, y: 0, width: screenWidth-40, height: 65)
        view.backgroundColor = .white
        view.layer.cornerRadius = 10
//        let corners: UIRectCorner = [.topLeft,.topRight]
//        view.corner(byRoundingCorners: corners, radii: 10)
       
        return view
    }()
    let signDaylab: UILabel =  {
           let label = UILabel()
           label.textColor = .darkText
           label.font = UIFont.boldSystemFont(ofSize: 15)
           return label
       }()
    let header: UIView = UIView()
    let collo: SignCollection = {
        let c = SignCollection.init(frame:CGRect.zero)
        c.layer.cornerRadius = 10
        c.backgroundColor = UIColor.white
       return c
        
    }()
    var count = 0
    var collH: CGFloat = 0
    
    var signModel = SignInfo()
    var signRules = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpDatas()
        
        view.addSubview(table)
        table.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        if #available(iOS 11.0, *) {
            table.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
    
        fixHeaderHeight()
        setUptop()

        view.addSubview(navBar)
        navBar.snp.makeConstraints { (make) in
            make.top.leading.trailing.equalToSuperview()
            make.height.equalTo(safeAreaTopHeight)
        }
        let f = UIView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 40))
        table.tableFooterView = f
        
    }
    
    
    func setUpDatas() {
        diamondlab.text = signModel.sign_info?.coins
        signDaylab.attributedText = TextSpaceManager.configColorString(allString: "已连续签到\(signModel.sign_info?.sign ?? 1)天", attribStr: "\(signModel.sign_info?.sign ?? 1)天", ConstValue.kStypeColor, UIFont.boldSystemFont(ofSize: 15), 1)
        if let helps = signModel.sign_ini?.sign_help, !helps.isEmpty {
            signRules = helps.components(separatedBy: "##")
        }
        if let dmDatas = signModel.sign_ini?.ini {
            count = dmDatas.count
        }
        collo.setUpSign(self.signModel)
    }
    
    func fixHeaderHeight() {
        let width = (screenWidth - 60)/7
        let height = width * 3/2
        let num: Int = count%7
        var ls: Int = count/7
        if num > 0 {
            ls = ls + 1
        }
        let sep = CGFloat((ls - 1) * 10) + CGFloat(30.0)
        let h_h = CGFloat(height) * CGFloat(ls) + sep
        collH = h_h
        header.frame = CGRect(x: 0, y: 0, width: screenWidth, height: 270.0 + h_h + 20.0)
        collo.bounds = CGRect(x: 0, y: 0, width: screenWidth-40, height: h_h)
        table.reloadData()
    }
    func setUptop() {
        header.addSubview(topImage)
        header.addSubview(collo)
        topImage.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(270)
        }
        collo.snp.makeConstraints { (make) in
            make.leading.equalTo(20)
            make.trailing.equalTo(-20)
            make.top.equalTo(topImage.snp.bottom)
            make.height.equalTo(collH)
        }
        
        topImage.addSubview(lLabel)
        topImage.addSubview(diamondlab)
        topImage.addSubview(headerTipsview)
        headerTipsview.addSubview(signDaylab)
       
        lLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(20)
            make.top.equalTo(safeAreaTopHeight + 10)
        }
        diamondlab.snp.makeConstraints { (make) in
            make.leading.equalTo(lLabel)
            make.top.equalTo(lLabel.snp.bottom).offset(8)
        }
        headerTipsview.snp.makeConstraints { (make) in
            make.bottom.equalTo(15)
            make.leading.equalTo(20)
            make.trailing.equalTo(-20)
            make.height.equalTo(65)
        }
        signDaylab.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.bottom.equalTo(-23)
        }
        headerTipsview.addShadow(opacity: 0.6, position: 124, pathWidth: 5, UIColor.lightGray)
        collo.addShadow(opacity: 0.6, position: 234, pathWidth: 5,UIColor.lightGray)
        table.tableHeaderView = header
    }
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
  

}

extension DailyInController: UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return signRules.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 60.0
        return tableView.rowHeight
       
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "signRuleCell", for: indexPath) as! SignRuleCell
        cell.ruleLable.attributedText = TextSpaceManager.getAttributeStringWithString(signRules[indexPath.row], lineSpace: 5)
        return cell
    }
}

class SignRuleCell: UITableViewCell {
   
    let ruleLable: UILabel =  {
           let label = UILabel()
           label.textColor = .lightGray
           label.font = UIFont.systemFont(ofSize: 13)
        label.numberOfLines = 0
           return label
       }()
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.addSubview(ruleLable)
        ruleLable.snp.makeConstraints { (make) in
            make.leading.equalTo(20)
            make.trailing.equalTo(-20)
            make.top.equalTo(8)
            make.bottom.equalTo(-8)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
