
import Foundation

/// 活动弹出框
class ActivityAlertController: UIViewController {
    let imageView: UIImageView = {
        let v = UIImageView()
        v.isUserInteractionEnabled = true
        v.contentMode = .scaleAspectFit
        return v
    }()
    private lazy var iconButton: UIButton = {
        let button = UIButton(type: .custom)
        button.addTarget(self, action: #selector(iconClick), for: .touchUpInside)
        return button
    }()
    
    private lazy var closeButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "alertCloseBtn"), for: .normal)
        button.addTarget(self, action: #selector(closeBtnClick), for: .touchUpInside)
        return button
    }()
    
    var actionClcick:((_ actionId: Int) ->Void)?
    
    private var activityAlert: String = ""
    
    convenience init(activityIcon: String) {
        self.init()
        self.activityAlert = activityIcon
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(white: 0, alpha: 0.7)
        imageView.kfSetHeaderImageWithUrl(activityAlert, placeHolder: nil)
        view.addSubview(imageView)
        view.addSubview(iconButton)
        view.addSubview(closeButton)
        layoutPageSubviews()
    }
    
    @objc private func iconClick() {
        actionClcick?(1)
    }
    @objc private func closeBtnClick() {
        actionClcick?(0)
    }
    private func layoutPageSubviews() {
        imageView.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(statusBarHeight)
            make.bottom.equalTo(-110)
        }
        iconButton.snp.makeConstraints { (make) in
            make.edges.equalTo(imageView)
        }
        closeButton.snp.makeConstraints { (make) in
            make.top.equalTo(imageView.snp.bottom).offset(15)
            make.centerX.equalTo(iconButton)
            make.height.width.equalTo(35)
        }
    }
}
