
import UIKit

class HomeTopSegView: UIView {

    @IBOutlet weak var reconmentBtn: UIButton!
    @IBOutlet weak var searchBtn: UIButton!
    @IBOutlet weak var attentionBtn: UIButton!
    @IBOutlet weak var diamondLab: UILabel!
    @IBOutlet weak var dailyBtn: UIButton!
    var fakeBtn: UIButton?
    
    var actionHandler:((_ segTag: Int) -> Void)?
    
    var defaultSelectedIndex: Int = 0 {
        didSet {
            if defaultSelectedIndex == 0 {
                reconmentBtn.isSelected = true
                fakeBtn = reconmentBtn
            } else {
                attentionBtn.isSelected = true
                fakeBtn = attentionBtn
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        dailyBtn.setImage(getImage("RecordMainIcon"), for: .normal)
        searchBtn.setImage(getImage("communitySeachIcon"), for: .normal)
        diamondLab.addShadow(radius: 5, opacity: 0.8, UIColor.lightGray)
        searchBtn.addShadow(radius: 5, opacity: 0.8, UIColor.lightGray)
    }
    
    @IBAction func segBtnClick(_ sender: UIButton) {
        if sender != fakeBtn {
            sender.isSelected = true
            fakeBtn?.isSelected = false
            fakeBtn = sender
            actionHandler?(sender.tag)
        }
    }
    
    @IBAction func dailyBtnClick(_ sender: UIButton) {
        actionHandler?(sender.tag)
    }
    @IBAction func searchAction(_ sender: UIButton) {
        actionHandler?(sender.tag)
    }
    
    func selectedIndex(_ index: Int) {
        if index == 0 {
            if fakeBtn != reconmentBtn {
                fakeBtn?.isSelected = false
                reconmentBtn.isSelected = true
                fakeBtn = reconmentBtn
            }
        } else if index == 1 {
            if fakeBtn != attentionBtn {
                fakeBtn?.isSelected = false
                attentionBtn.isSelected = true
                fakeBtn = attentionBtn
            }
        }
    }
}


class SignAlertView: UIView {
    
    let picImage: UIImageView = {
        let img = UIImageView()
        img.contentMode = .scaleAspectFit
        img.clipsToBounds = true
        img.isUserInteractionEnabled = true
        return img
    }()
    let titleLa: UILabel = {
        let lab = UILabel()
        lab.textAlignment = .center
        lab.textColor = UIColor.white
        lab.font = UIFont.systemFont(ofSize: 15)
        return lab
    }()
    lazy var diamondBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setImage(getImage("diamond"), for: .normal)
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 17)
        btn.imageEdgeInsets = UIEdgeInsets(top: 4, left: 5, bottom: 4, right: 5)
        return btn
    }()
    let coinlabel: UILabel = {
        let lab = UILabel()
        lab.textAlignment = .center
        lab.textColor = UIColor.white
        lab.font = UIFont.systemFont(ofSize: 17)
        return lab
    }()
    lazy var detailBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.backgroundColor = UIColor(r: 253, g: 184, b: 29)
        btn.layer.cornerRadius = 20
        btn.setTitle("查看详情", for: .normal)
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 17)
        btn.setTitleColor(UIColor(r: 168, g: 63, b: 26), for: .normal)
        btn.addTarget(self, action: #selector(actionClick(_:)), for: .touchUpInside)
        return btn
    }()
    lazy var closeBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setImage(getImage("recordClose"), for: .normal)
        btn.addTarget(self, action: #selector(actionClick(_:)), for: .touchUpInside)
        return btn
    }()
    
    var goDetailHandler:(() ->Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor(white: 0, alpha: 0.7)
        addSubview(picImage)
        addSubview(closeBtn)
        picImage.addSubview(titleLa)
        picImage.addSubview(diamondBtn)
        picImage.addSubview(coinlabel)
        picImage.addSubview(detailBtn)
        layoutPageSub()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func actionClick(_ sender: UIButton) {
        if sender == closeBtn {
            removeFromSuperview()
        } else if sender == detailBtn {
            goDetailHandler?()
        }
    }
    func setSignShort(_ sign: SignInfo) {
        coinlabel.text = "\(sign.sign_info?.coins ?? "")"
        titleLa.text = "已连续签到\(sign.sign_info?.sign ?? 1)天"
        detailBtn.addShadow(radius: 2, opacity: 0.8)
        if let signIndex = sign.sign_info?.sign, let signPics = sign.sign_ini?.ini {
            let models = signPics.filter { (signPic) -> Bool in
                return Int(signPic.day ?? 0) == signIndex
            }
            if models.count > 0 {
                if let url = models[0].cover {
                    if let imageData = LGConfig.getAdDataFromLocal(url, LGConfig.kDirectSign) {
                        let type = UIImage.checkImageDataType(data: imageData)
                        if type == .gif {
                            self.picImage.image = UIImage.gif(data: imageData)
                        } else {
                            self.picImage.image = UIImage(data: imageData)
                        }
                    } else {
                        self.picImage.kfSetHeaderImageWithUrl(url, placeHolder: nil)
                        if let urlPic = URL(string: url) {
                            downloadImage(urlPic)
                        }
                    }
                }
            }
        }
    }
    
    func downloadImage(_ url: URL) {
        ImageDownloader.default.downloadImage(with: url, retrieveImageTask: nil, options: nil, progressBlock: { (reciveData, allData) in
            DLog("Download Progress Image = \(Float64(reciveData)/Float64(allData))")
        }) { (image, error, imageUrl, adData) in
            if adData != nil {
              DLog("今日签到图片——下载成功。\(String(describing: url.absoluteString))")
                if url.absoluteString.hasSuffix(".ceb") { /// 加密走这里
                  if let data = adData as NSData? {
                      if let dataDec = data.aes128DecryptWidthKey(ConstValue.kImageDataDecryptKey) as Data? {
                        let _ = LGConfig.saveDataToLocal(url.absoluteString, LGConfig.kDirectSign ,data: dataDec)
                      }
                  }
                } else {
                    /// 存储文件到本地
                    let _ = LGConfig.saveDataToLocal(url.absoluteString, LGConfig.kDirectSign, data: adData)
                }
            }
        }
    }
    
    func layoutPageSub() {
        picImage.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.centerY.equalTo(self.snp.centerY).offset(-30)
            make.width.equalTo(screenWidth - 80)
            make.height.equalTo((screenWidth - 80) * 3/2)
        }
        closeBtn.snp.makeConstraints { (make) in
            make.top.equalTo(picImage.snp.bottom).offset(20)
            make.centerX.equalToSuperview()
            make.height.width.equalTo(30)
        }
        detailBtn.snp.makeConstraints { (make) in
            make.bottom.equalTo(-20)
            make.centerX.equalToSuperview()
            make.height.equalTo(40)
            make.width.equalTo(140)
        }
        diamondBtn.snp.makeConstraints { (make) in
            make.bottom.equalTo(detailBtn.snp.top).offset(-10)
            make.centerX.equalToSuperview().offset(-15)
            make.height.equalTo(25)
            make.width.equalTo(35)
        }
        coinlabel.snp.makeConstraints { (make) in
            make.leading.equalTo(diamondBtn.snp.trailing)
            make.centerY.equalTo(diamondBtn)
        }
        titleLa.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(diamondBtn.snp.top).offset(-14)
        }
    }
    
}
