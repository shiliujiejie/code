import UIKit


class ModuleMoreTopView: UIView {
    let bgImg: UIImageView = {
         let v = UIImageView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: screenWidth*130/375))
        v.backgroundColor = .black
         return v
     }()
    let titleLab: UILabel = {
         let lab = UILabel()
         lab.font = UIFont.boldSystemFont(ofSize: 21)
         lab.textColor = .white
         return lab
     }()
    let desLab: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.systemFont(ofSize: 13)
        lab.textColor = .lightGray
        lab.numberOfLines = 0
        return lab
    }()
    var favorClickHandler:(() ->Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(bgImg)
        addSubview(titleLab)
        addSubview(desLab)
        layoutSubs()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    private func layoutSubs() {
        bgImg.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(screenWidth*130/375)
        }
        titleLab.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.bottom.equalTo(bgImg).offset(-5)
            make.trailing.equalTo(-15)
        }
        desLab.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(bgImg.snp.bottom).offset(6)
            make.bottom.equalTo(-10)
        }
    }
}


