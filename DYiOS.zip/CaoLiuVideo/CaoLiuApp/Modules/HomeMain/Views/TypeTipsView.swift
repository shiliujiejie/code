
import UIKit


class TypeTipsView: UIView {

    let coverImg: UIView = {
         let v = UIView(frame: CGRect(x: 0, y: 0, width: 60, height: 30))
         v.backgroundColor = UIColor.clear
         return v
     }()
    let titleLab: UILabel = {
         let lab = UILabel()
         lab.font = UIFont.boldSystemFont(ofSize: 15)
         lab.textColor = .white
         return lab
     }()
    lazy var favorBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.layer.cornerRadius = 15
        btn.layer.masksToBounds = true
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 13)
        btn.setBackgroundImage(UIImage.imageFromColor(ConstValue.kStypeColor, frame: CGRect(x: 0, y: 0, width: 75, height: 30)), for: .normal)
        btn.setBackgroundImage(UIImage.imageFromColor(ConstValue.kAppSepLineColor, frame: CGRect(x: 0, y: 0, width: 75, height: 30)), for: .selected)
        btn.setTitle("收藏", for: .normal)
        btn.setTitle("取消收藏", for: .selected)
        btn.addTarget(self, action: #selector(favorClick(_:)), for: .touchUpInside)
        return btn
    }()
    let desLab: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.systemFont(ofSize: 13)
        lab.textColor = .lightGray
        lab.numberOfLines = 0
        return lab
    }()
    var favorClickHandler:(() ->Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(coverImg)
        addSubview(titleLab)
        addSubview(favorBtn)
        addSubview(desLab)
        layoutSubs()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setCovers(_ covers: [String]?) {
        if let imgs = covers, imgs.count > 0 {
            for i in 0 ..< (imgs.count > 3 ? 3 : imgs.count) {
                let v = UIImageView()
                v.backgroundColor = .black
                v.frame = CGRect(x:CGFloat(15*i), y: 0, width: 30, height: 30)
                v.kfsetHeader(imgs[i])
                v.layer.cornerRadius = 15
                v.layer.masksToBounds = true
                coverImg.addSubview(v)
                v.kfsetHeader(imgs[i])
            }
            coverImg.snp.updateConstraints { (make) in
                if imgs.count == 1 {
                    make.width.equalTo(30)
                } else if imgs.count == 2 {
                    make.width.equalTo(45)
                } else {
                    make.width.equalTo(60)
                }
            }
        } else {
            let v = UIImageView()
            v.frame = CGRect(x:0, y: 0, width: 30, height: 30)
            v.backgroundColor = .black
            v.layer.cornerRadius = 15
            v.layer.masksToBounds = true
            coverImg.addSubview(v)
            coverImg.snp.updateConstraints { (make) in
                make.width.equalTo(30)
            }
        }
    }
    
    @objc func favorClick(_ sender: UIButton) {
        tapScaleDownAnimation(sender)
        sender.isSelected = !sender.isSelected
        favorClickHandler?()
    }
    private func layoutSubs() {
        coverImg.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(10)
            make.height.equalTo(30)
            make.width.equalTo(60)
        }
        favorBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.centerY.equalTo(coverImg)
            make.height.equalTo(30)
            make.width.equalTo(75)
        }
        titleLab.snp.makeConstraints { (make) in
            make.leading.equalTo(coverImg.snp.trailing).offset(6)
            make.centerY.equalTo(coverImg)
            make.trailing.equalTo(favorBtn.snp.leading).offset(-6)
        }
        desLab.snp.makeConstraints { (make) in
            make.leading.equalTo(coverImg)
            make.top.equalTo(coverImg.snp.bottom).offset(17)
            make.trailing.equalTo(-10)
        }
    }
}

class TipTypeCollCell: UICollectionViewCell {
    
    static let cellId = "TipTypeCollCell"
    static let itemSize = CGSize(width: screenWidth - 20, height: 85)
    
    let coverImg: UIView = {
        let v = UIView(frame: CGRect(x: 0, y: 0, width: 60, height: 30))
        v.backgroundColor = UIColor.clear
        return v
    }()
    let titleLab: UILabel = {
         let lab = UILabel()
         lab.font = UIFont.boldSystemFont(ofSize: 15)
         lab.textColor = .white
         return lab
     }()
    let selectedImg: UIImageView = {
        let v = UIImageView()
        v.image = getImage("payTypeUnSelected")
        return v
    }()
    lazy var selectedBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.addTarget(self, action: #selector(selectedBtnClick(_:)), for: .touchUpInside)
        return btn
    }()
    let desLab: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.systemFont(ofSize: 13)
        lab.textColor = .white
        lab.numberOfLines = 0
        return lab
    }()
    var selectedClickHandler:((_ selected: Bool) ->Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        contentView.backgroundColor = ConstValue.kCoverBgColor
        contentView.borderRadius = 7.5
        contentView.addSubview(coverImg)
        contentView.addSubview(titleLab)
        contentView.addSubview(selectedImg)
        contentView.addSubview(selectedBtn)
        contentView.addSubview(desLab)
        layoutSubs()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setModel(_ model: SearchHotTips, _ hideSelected: Bool) {
        selectedImg.isHidden = hideSelected
        selectedBtn.isHidden = hideSelected
        titleLab.text = "#\(model.title ?? "")"
        desLab.text = "\(getStringWithNumber(model.join ?? 0))人参与 · \(getStringWithNumber(model.play ?? 0))次播放"
        setCovers(model.cover)
    }
    func setCovers(_ covers: [String]?) {
        for view in coverImg.subviews {
            view.removeFromSuperview()
        }
        if let imgs = covers, imgs.count > 0 {
            for i in 0 ..< (imgs.count > 3 ? 3 : imgs.count) {
                let v = UIImageView()
                v.backgroundColor = .black
                v.frame = CGRect(x:CGFloat(15*i), y: 0, width: 30, height: 30)
                v.kfsetHeader(imgs[i])
                v.borderRadius = 15
                coverImg.addSubview(v)
                v.kfsetHeader(imgs[i])
            }
            coverImg.snp.updateConstraints { (make) in
                if imgs.count == 1 {
                    make.width.equalTo(30)
                } else if imgs.count == 2 {
                    make.width.equalTo(45)
                } else {
                    make.width.equalTo(60)
                }
            }
        } else {
            let v = UIImageView()
            v.frame = CGRect(x:0, y: 0, width: 30, height: 30)
            v.backgroundColor = .black
            v.layer.cornerRadius = 15
            v.layer.masksToBounds = true
            coverImg.addSubview(v)
            coverImg.snp.updateConstraints { (make) in
                make.width.equalTo(30)
            }
        }
    }
    
    @objc func selectedBtnClick(_ sender: UIButton) {
        selectedClickHandler?(!sender.isSelected)
    }
    private func layoutSubs() {
        titleLab.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(10)
            make.height.equalTo(20)
        }
        coverImg.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(titleLab.snp.bottom).offset(12)
            make.height.equalTo(30)
            make.width.equalTo(60)
        }
        selectedImg.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.centerY.equalToSuperview()
            make.height.equalTo(22)
            make.width.equalTo(22)
        }
        selectedBtn.snp.makeConstraints { (make) in
            make.trailing.bottom.top.equalToSuperview()
            make.width.equalTo(45)
        }
        desLab.snp.makeConstraints { (make) in
            make.leading.equalTo(coverImg.snp.trailing).offset(6)
            make.centerY.equalTo(coverImg)
            make.trailing.equalTo(selectedBtn.snp.leading).offset(-5)
        }
    }
}
