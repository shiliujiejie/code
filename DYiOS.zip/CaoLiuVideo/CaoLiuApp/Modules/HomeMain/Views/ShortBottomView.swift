

import UIKit

class ShortBottomView: UIView {
    lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        let collection = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.showsVerticalScrollIndicator = false
        collection.backgroundColor = UIColor.clear
        collection.register(ShareOrFavorItemCell.classForCoder(), forCellWithReuseIdentifier: ShareOrFavorItemCell.cellId)
        return collection
    }()
    var video: VideoNew?
    
    var itemClickHandler:((_ index: Int) ->Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = ConstValue.kCoverBgColor
        addSubview(collectionView)
        layoutPageSubviews()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setModel(_ video: VideoNew?) {
        self.video = video
        collectionView.reloadData()
    }
    private func layoutPageSubviews() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.bottom.equalTo(-safeAreaBottomHeight)
        }
    }
}

// MARK: - UICollectionViewDelegateFlowLayout
extension ShortBottomView: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (screenWidth-30)/2, height: 60)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 15)
    }
}
// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension ShortBottomView: UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShareOrFavorItemCell.cellId, for: indexPath) as! ShareOrFavorItemCell
        cell.contentView.backgroundColor = .clear
        cell.iconImage.image = getImage([video?.is_like == 1 ? "icon_home_like_after" : "favorItemIcon","earnMoneyShareIcon"][indexPath.item])
        cell.titleLable.text = [getStringWithNumber(video?.like ?? 0), "分享"][indexPath.item]
        cell.tipsLable.text = ["喜欢就收藏一下","邀请好友.赚会员"][indexPath.item]
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        itemClickHandler?(indexPath.item)
    }
}


class ShortAdBottomView: UIView {
    
    let tipsLabel: UILabel = {
        let lab = UILabel()
        lab.textColor = UIColor.white
        lab.backgroundColor = rgba(248, 248, 248, 0.2)
        lab.font = UIFont.systemFont(ofSize: 12)
        lab.textAlignment = .center
        lab.text = "广告"
        lab.borderRadius = 5.0
        return lab
    }()
    let titleLabel: UILabel = {
        let lab = UILabel()
        lab.textColor = .white
        lab.numberOfLines = 0
        lab.font = UIFont.systemFont(ofSize: 15)
        return lab
    }()
    let clickLabel: UILabel = {
        let lab = UILabel()
        lab.textColor = .darkText
        lab.textAlignment = .center
        lab.text = "了解一下"
        lab.font = UIFont.boldSystemFont(ofSize: 14)
        lab.backgroundColor = UIColor.colorGradientChangeWithSize(size: CGSize(width: screenWidth - 30, height: 45), direction: .level, startColor: rgb(247, 219, 172), endColor: rgb(223, 180, 127))
        lab.borderRadius = 10
        return lab
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(clickLabel)
        addSubview(titleLabel)
        addSubview(tipsLabel)
        clickLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.bottom.equalTo(-safeAreaBottomHeight - 25)
            make.height.equalTo(45)
        }
        titleLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.bottom.equalTo(clickLabel.snp.top).offset(-10)
        }
        tipsLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.bottom.equalTo(titleLabel.snp.top).offset(-10)
            make.height.equalTo(24)
            make.width.equalTo(46)
            make.top.equalTo(10)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
