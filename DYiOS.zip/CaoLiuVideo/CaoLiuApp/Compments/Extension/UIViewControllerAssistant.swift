
import Foundation
import UIKit

public extension UIViewController {
    
    /// 显示对话框
    func showDialog(title: String?, message: String, okTitle: String?, cancelTitle: String?, okHandler: (() -> Void)?, cancelHandler: (() -> Void)?) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: cancelTitle ?? "" , style: .cancel, handler: { alertAction in
            if let cancelHandler = cancelHandler {
                cancelHandler()
            }
        })
        let OkAction = UIAlertAction(title: okTitle ?? "" , style: .default, handler: { alertAction in
            if let okHandler = okHandler {
                okHandler()
            }
        })
        if cancelTitle != nil {
            alert.addAction(cancelAction)
        }
        if okTitle != nil {
            alert.addAction(OkAction)
        }
        alert.modalPresentationStyle = .fullScreen
        present(alert, animated: true, completion: nil)
    }
    
    func showErrorMessage(_ message: String, cancelHandler: (() -> Void)?) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: UIAlertController.Style.alert)
        let cancelAction = UIAlertAction(title: "确定", style: .cancel, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
            cancelHandler?()
        })
        alert.addAction(cancelAction)
        alert.modalPresentationStyle = .fullScreen
        self.present(alert, animated: true, completion: nil)
        
    }
    
    class func currentViewController(_ baseVC: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
        if let nav = baseVC as? UINavigationController {
            return currentViewController(nav.visibleViewController)
        }
        if let tab = baseVC as? UITabBarController {
            return currentViewController(tab.selectedViewController)
        }
        if let presented = baseVC?.presentedViewController {
            return currentViewController(presented)
        }
        return baseVC
    }
    
    func isVisible() -> Bool {
        return self.isViewLoaded && self.view.window != nil
    }
}

extension NSObject {
    
    func getStringWithNumber(_ number: Int) -> String {
        if number < 100000000 && number >= 10000 {
            return String(format: "%.1f%@", Float(number)/10000.0, "w")
        } else if number >= 100000000 {
            return String(format: "%.1f%@", Float(number)/100000000.0, "y")
        } else {
            return String(format: "%d", number)
        }
    }
    func getShareText(_ comtentSting: String?) -> String? {
        if comtentSting != nil {
            let shareText = "@抖阴小视频 \(comtentSting!) \n 下载地址：\(UserModel.share().authInfo?.config?.sys?.share_url ?? ConstValue.kAppDownLoadLoadUrl))"
            return shareText
        } else {
            return ShareContentItemCell.getDefaultContentString()
        }
    }
    func getCurrentAppVersion() -> String {
        let filePath = Bundle.main.path(forResource: "Info", ofType: "plist")
        let dictionary = NSDictionary(contentsOfFile: filePath!)
        return dictionary!["CFBundleShortVersionString"] as! String
    }
    func getAppBuildVersion() -> String {
        let filePath = Bundle.main.path(forResource: "Info", ofType: "plist")
        let dictionary = NSDictionary(contentsOfFile: filePath!)
        return dictionary!["CFBundleVersion"] as! String
    }
    func tapScaleUpAnimation(_ tapView: UIView) {
        let impliesAnimation = CAKeyframeAnimation(keyPath: "transform.scale")
        impliesAnimation.values = [1.0 ,1.4, 0.9, 1.15, 0.95, 1.02, 1.0]
        impliesAnimation.duration = 0.6
        impliesAnimation.calculationMode = CAAnimationCalculationMode.cubic
        tapView.layer.add(impliesAnimation, forKey: nil)
    }
    func tapScaleDownAnimation(_ tapView: UIView) {
        let impliesAnimation = CAKeyframeAnimation(keyPath: "transform.scale")
        impliesAnimation.values = [1.0 ,0.72, 1.12, 0.92, 1.10, 1.02, 1.0]
        impliesAnimation.duration = 0.6
        impliesAnimation.calculationMode = CAAnimationCalculationMode.cubic
        tapView.layer.add(impliesAnimation, forKey: nil)
    }
    func tapRotationAnimation(_ tapView: UIView) {
        let scaleAnim = CABasicAnimation()
        scaleAnim.keyPath = "transform.rotation.z"
        scaleAnim.duration = 0.35
        scaleAnim.fromValue = 0
        scaleAnim.toValue = 2 * Double.pi
        tapView.layer.add(scaleAnim, forKey: nil)
    }
   
}


// MARK: - 分享
extension UIViewController {
    /// 分享
    func share() {
        let imageToShare = getImage("iconShare")
        var downString = ConstValue.kAppDownLoadLoadUrl
        if let downloadString = AppInfo.share().appInfo?.share_url {
            if downloadString.hasSuffix("/") {
                downString = downloadString
            } else {
                downString = String(format: "%@%@", downloadString, "/")
            }
        }
        if let userInviteCode = UserModel.share().user?.code {
            downString = String(format: "%@%@",downString, userInviteCode)
        } else {
            if let codeSave = UserDefaults.standard.object(forKey: UserDefaults.kUserInviteCode) as? String {
                downString = String(format: "%@%@", downString, codeSave)
            } else {
                downString = String(format: "%@", downString)
            }
        }
        var textShare = "抖阴小视频"
        if let textToShare = AppInfo.share().appInfo?.share_text {
            textShare = textToShare
        }
        let urlToShare = NSURL(string: downString)
        let items = [textShare, imageToShare ?? "DouYin",urlToShare ?? "DouYin"] as [Any]
        let activityVC = UIActivityViewController(activityItems: items, applicationActivities: nil)
        activityVC.excludedActivityTypes = [.copyToPasteboard,.assignToContact, .airDrop, .mail,.message, .openInIBooks, .copyToPasteboard, .print,.saveToCameraRoll, .addToReadingList]
        activityVC.completionWithItemsHandler =  { activity, success, items, error in
            NotificationCenter.default.post(name: Notification.Name.kShareActivityDownNotification, object: nil)
        }
        activityVC.modalPresentationStyle = .fullScreen
        self.present(activityVC, animated: true, completion: { () -> Void in  })
    }
    
    func share(_ image: UIImage) {
        let imageToShare = image
        let items = [imageToShare] as [Any]
        let activityVC = UIActivityViewController(activityItems: items, applicationActivities: nil)
        activityVC.excludedActivityTypes = [.copyToPasteboard,.assignToContact, .airDrop, .mail,.message, .openInIBooks, .copyToPasteboard, .print,.saveToCameraRoll, .addToReadingList]
        activityVC.completionWithItemsHandler =  { activity, success, items, error in
            NotificationCenter.default.post(name: Notification.Name.kShareActivityDownNotification, object: nil)
        }
        activityVC.modalPresentationStyle = .fullScreen
        self.present(activityVC, animated: true, completion: { () -> Void in  })
    }
    
    func shareText(_ text: String) {
        let imageToShare = getImage("iconShare")
        var downString = ConstValue.kAppDownLoadLoadUrl
        if let downloadString = AppInfo.share().appInfo?.share_url {
            if downloadString.hasSuffix("/") {
                downString = downloadString
            } else {
                downString = String(format: "%@%@", downloadString, "/")
            }
        }
        if let userInviteCode = UserModel.share().user?.code {
            downString = String(format: "%@%@",downString, userInviteCode)
        } else {
            if let codeSave = UserDefaults.standard.object(forKey: UserDefaults.kUserInviteCode) as? String {
                downString = String(format: "%@%@", downString, codeSave)
            } else {
                downString = String(format: "%@", downString)
            }
        }
        let urlToShare = NSURL(string: downString)
        let items = [text, imageToShare ?? "dy",urlToShare ?? "https://8dy.me"] as [Any]
        let activityVC = UIActivityViewController(activityItems: items, applicationActivities: nil)
        activityVC.excludedActivityTypes = [.copyToPasteboard,.assignToContact, .airDrop, .mail,.message, .openInIBooks, .copyToPasteboard, .print,.saveToCameraRoll, .addToReadingList]
        activityVC.completionWithItemsHandler =  { activity, success, items, error in
            NotificationCenter.default.post(name: Notification.Name.kShareActivityDownNotification, object: nil)
        }
        activityVC.modalPresentationStyle = .fullScreen
        self.present(activityVC, animated: true, completion: { () -> Void in  })
    }
}


// MARK: - 国际化
extension UIViewController {
    
    class func localStr(_ key: String) -> String {
        let title = NSLocalizedString(key,comment:"default")
        return title
    }
    
    func localStr(_ key: String) -> String {
        let title = NSLocalizedString(key,comment:"default")
        return title
    }
  
    private struct AssociatedKey {
        static var isPush = "isPush"
        static var navBarAnimatedBlock = "navBarAnimatedBlock"
    }
    
    /// 是不是动画隐藏导航栏
    var isNavAnimated: Bool {
        get {
            guard let number: NSNumber = objc_getAssociatedObject(self, &AssociatedKey.isPush) as? NSNumber else {
                return false
            }
            return number.boolValue
        }
        set(value) {
            objc_setAssociatedObject(self, &AssociatedKey.isPush, NSNumber(value: value as Bool), objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }
   
}


