//
//  BaseViewController.swift
//  JXPagingView
//
//  Created by jiaxin on 2018/8/10.
//  Copyright © 2018年 jiaxin. All rights reserved.
//

import UIKit
import JXPagingView
import JXSegmentedView

extension JXPagingListContainerView: JXSegmentedViewListContainer {}

class BasePagerViewController: CLBaseViewController {
    
    lazy var pagingView: JXPagingView = preferredPagingView()
    lazy var userHeaderView: PagingViewTableHeaderView = preferredTableHeaderView()
    let dataSource: JXSegmentedTitleDataSource = JXSegmentedTitleDataSource()
    let indicator = JXSegmentedIndicatorLineView()
    lazy var segmentedView: JXSegmentedView = JXSegmentedView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: CGFloat(headerInSectionHeight)))
    var titles = [String]()
    var tableHeaderViewHeight: Int = 0
    var headerInSectionHeight: Int = 44
    var isNeedHeader = false
    var isNeedFooter = false

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        dataSource.titles = titles
        dataSource.titleSelectedColor = UIColor.white
        dataSource.titleNormalColor = UIColor.lightGray
        dataSource.isTitleColorGradientEnabled = true
        dataSource.isItemSpacingAverageEnabled = false
        dataSource.isTitleZoomEnabled = true
        dataSource.isTitleColorGradientEnabled = true
        dataSource.isTitleZoomEnabled = true

        dataSource.titleNormalFont = UIFont.boldSystemFont(ofSize: 14)
        dataSource.titleSelectedFont = UIFont.boldSystemFont(ofSize: 14)
        dataSource.titleSelectedStrokeWidth = -0.5
       
        segmentedView.backgroundColor = UIColor.clear
        segmentedView.delegate = self
        segmentedView.isContentScrollViewClickTransitionAnimationEnabled = false
        segmentedView.dataSource = dataSource
       
        
        indicator.indicatorWidth = JXSegmentedViewAutomaticDimension
        indicator.lineStyle = .lengthen
        indicator.indicatorHeight = 3.0
        indicator.indicatorWidth = 12
        indicator.indicatorCornerRadius = 1.5
        indicator.verticalOffset = 5.0
        indicator.indicatorColor = .white
        
        segmentedView.indicators = [indicator]
        pagingView.mainTableView.gestureDelegate = self
        pagingView.mainTableView.backgroundColor = UIColor.clear
        self.view.addSubview(pagingView)
        
        segmentedView.listContainer = pagingView.listContainerView
        //扣边返回处理，下面的代码要加上
        pagingView.listContainerView.listCellBackgroundColor = UIColor.clear
        pagingView.listContainerView.scrollView.backgroundColor = UIColor.clear
        pagingView.automaticallyDisplayListVerticalScrollIndicator = false
        if let nav = self.navigationController {
            pagingView.listContainerView.scrollView.panGestureRecognizer.require(toFail: nav.interactivePopGestureRecognizer!)
            pagingView.mainTableView.panGestureRecognizer.require(toFail: nav.interactivePopGestureRecognizer!)
        }
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = (segmentedView.selectedIndex == 0)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)

        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = true
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        pagingView.frame = self.view.bounds
    }

    func preferredTableHeaderView() -> PagingViewTableHeaderView {
        return PagingViewTableHeaderView()
    }

    func preferredPagingView() -> JXPagingView {
        return JXPagingView(delegate: self)
    }
}

extension BasePagerViewController: JXPagingViewDelegate {

    func tableHeaderViewHeight(in pagingView: JXPagingView) -> Int {
        return tableHeaderViewHeight
    }

    func tableHeaderView(in pagingView: JXPagingView) -> UIView {
        return userHeaderView
    }

    func heightForPinSectionHeader(in pagingView: JXPagingView) -> Int {
        return headerInSectionHeight
    }       

    func viewForPinSectionHeader(in pagingView: JXPagingView) -> UIView {
        return segmentedView
    }

    func numberOfLists(in pagingView: JXPagingView) -> Int {
        return titles.count
    }

    func pagingView(_ pagingView: JXPagingView, initListAtIndex index: Int) -> JXPagingViewListViewDelegate {
        let list = ListCollectionViewController()
        return list
    }
    func pagingView(_ pagingView: JXPagingView, mainTableViewDidScroll scrollView: UIScrollView) {
        
    }
}

extension BasePagerViewController: JXSegmentedViewDelegate {
    func segmentedView(_ segmentedView: JXSegmentedView, didSelectedItemAt index: Int) {
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = (index == 0)
    }
    func segmentedView(_ segmentedView: JXSegmentedView, didScrollSelectedItemAt index: Int) {
        
    }
}

extension BasePagerViewController: JXPagingMainTableViewGestureDelegate {
    func mainTableViewGestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        //禁止segmentedView左右滑动的时候，上下和左右都可以滚动
        if otherGestureRecognizer == segmentedView.collectionView.panGestureRecognizer {
            return false
        }
        return gestureRecognizer.isKind(of: UIPanGestureRecognizer.self) && otherGestureRecognizer.isKind(of: UIPanGestureRecognizer.self)
    }
}
