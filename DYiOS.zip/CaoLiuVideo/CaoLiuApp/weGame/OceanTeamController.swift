import UIKit
import SnapKit

class OceanTeamController: UIViewController {
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    private enum ScreenEdge: Int {
        case top = 0
        case right = 1
        case bottom = 2
        case left = 3
    }
    let bgImage: UIImageView = {
        let image = UIImageView(image: UIImage(named: "ocean"))
        image.isUserInteractionEnabled = true
        image.contentMode = .scaleAspectFill
        return image
    }()
    private enum GameState {
        case ready
        case playing
        case gameOver
    }
    private let timedownLabel: UILabel = {
        let v = UILabel()
        v.textColor = UIColor.lightGray
        v.font = UIFont.systemFont(ofSize: 15)
        return v
    }()
    private let startLabel: UILabel = {
        let v = UILabel()
        v.textColor = UIColor.purple
        v.textAlignment = .center
        v.layer.cornerRadius = 10
        v.font = UIFont.systemFont(ofSize: 12)
        v.text = ""
        v.backgroundColor = .clear
        return v
    }()
    private let bestTimeLabel: UILabel = {
        let v = UILabel()
        v.textColor = UIColor.purple
        v.font = UIFont.systemFont(ofSize: 12)
        return v
    }()
    private var displayLink: CADisplayLink?
    private var beginTimestamp: TimeInterval = 0
    private var elapsedTime: TimeInterval = 0
    private var playerView = UILabel(frame: .zero)
    private var playerAnimator: UIViewPropertyAnimator?
    
    private var enemyViews = [UIView]()
    private var enemyAnimators = [UIViewPropertyAnimator]()
    private var enemyTimer: Timer?
    
    private var gameState = GameState.ready
    
    private let colors = [ #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)]
    private let radius: CGFloat = 13
    private let playerAnimationDuration = 5.0
    private let enemySpeed: CGFloat = 55 // points per second
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.colorGradientChangeWithSize(size: CGSize(width: view.bounds.width, height: view.bounds.height), direction: .upwardDiagonalLine, startColor: .white, endColor: .black)
        view.addSubview(bgImage)
        view.addSubview(timedownLabel)
        view.addSubview(startLabel)
        view.addSubview(bestTimeLabel)
        layoutView()
        setupPlayView()
        prepare()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if gameState == .ready {
            start()
        }
        
        if let touchLocation = event?.allTouches?.first?.location(in: view) {
            movePlayView(to: touchLocation)
            moveEnemies(to: touchLocation)
        }
    }
    
    @objc func generateEnemy(timer: Timer) {
        let screenEdge = ScreenEdge.init(rawValue: Int(arc4random_uniform(4)))
        let screenBounds = UIScreen.main.bounds
        var position: CGFloat = 0
        
        switch screenEdge! {
        case .left, .right:
            position = CGFloat(arc4random_uniform(UInt32(screenBounds.height)))
        case .top, .bottom:
            position = CGFloat(arc4random_uniform(UInt32(screenBounds.width)))
        }
    
        let enemyView = UILabel(frame: .zero)
        enemyView.bounds.size = CGSize(width: 30, height: 30)
        enemyView.text = ["🐳","🦈","🐡","🦞","🐢","🧜‍♀️","🦑","🐙","🍤","🐟","🐬","🦀️"][Int(arc4random())%12]
        enemyView.font = UIFont.boldSystemFont(ofSize: 16)
        enemyView.textAlignment = .center
        enemyView.backgroundColor = .clear
        
        switch screenEdge! {
        case .left:
            enemyView.center = CGPoint(x: 0, y: position)
        case .right:
            enemyView.center = CGPoint(x: screenBounds.width, y: position)
        case .top:
            enemyView.center = CGPoint(x: position, y: screenBounds.height)
        case .bottom:
            enemyView.center = CGPoint(x: position, y: 0)
        }
        
        view.addSubview(enemyView)
        
        let duration = getEnemyDuration(enemyView: enemyView)
        let enemyAnimator = UIViewPropertyAnimator(duration: duration,
                                                   curve: .linear,
                                                   animations: { [weak self] in
                                                    if let strongSelf = self {
                                                        enemyView.center = strongSelf.playerView.center
                                                    }
            }
        )
        enemyAnimator.startAnimation()
        enemyAnimators.append(enemyAnimator)
        enemyViews.append(enemyView)
    }
    
    @objc func tick(sender: CADisplayLink) {
        updateCountUpTimer(timestamp: sender.timestamp)
        fixCollision()
    }
    func prepare() {
        getBestTime()
        removeEnemies()
        centerPlayerView()
        popPlayerView()
        startLabel.isHidden = false
        timedownLabel.text = "00:00.00"
        gameState = .ready
    }
    
    func start() {
        startEnemyTimer()
        startDisplayLink()
        startLabel.isHidden = true
        beginTimestamp = 0
        gameState = .playing
    }
    func startEnemyTimer() {
        enemyTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(generateEnemy(timer:)), userInfo: nil, repeats: true)
    }
}

// MARK: -lifecycle
private extension OceanTeamController {
    func setupPlayView() {
        playerView.bounds.size = CGSize(width: 40, height: 40)
        playerView.textColor = .clear
        playerView.backgroundColor = .groupTableViewBackground
        playerView.textAlignment = .center
        playerView.font = UIFont.systemFont(ofSize: 25)
        playerView.text = "🌿"
        playerView.layer.cornerRadius = 20
        playerView.layer.masksToBounds = true
        view.addSubview(playerView)
    }
    
    func gameOver() {
        stop()
        displayGameOverAlert()
    }
    func stop() {
        stopEnemyTimer()
        stopDisplayLink()
        stopAnimators()
        gameState = .gameOver
    }
    
    func stopEnemyTimer() {
        guard let enemyTimer = enemyTimer,
            enemyTimer.isValid else {
                return
        }
        enemyTimer.invalidate()
    }
    
    func startDisplayLink() {
        displayLink = CADisplayLink(target: self, selector: #selector(tick(sender:)))
        displayLink?.add(to: RunLoop.main, forMode: RunLoop.Mode.default)
    }
}



extension OceanTeamController {
    func layoutView() {
        bgImage.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        timedownLabel.snp.makeConstraints { (make) in
            make.trailing.equalTo(-10)
            make.top.equalTo(UIApplication.shared.statusBarFrame.height + 10)
        }
        bestTimeLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(10)
            make.centerY.equalTo(timedownLabel)
        }
        startLabel.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.centerY.equalTo(view.snp.centerY).offset(30)
            make.height.equalTo(40)
            make.width.equalTo(120)
        }
    }
}


// MARK: - timer Lifecycle
private extension OceanTeamController {
    
    
    func stopDisplayLink() {
        displayLink?.isPaused = true
        displayLink?.remove(from: RunLoop.main, forMode: RunLoop.Mode.default)
        displayLink = nil
    }
    
    func getRandomColor() -> UIColor {
        let index = arc4random_uniform(UInt32(colors.count))
        return colors[Int(index)]
    }
    
    func getEnemyDuration(enemyView: UIView) -> TimeInterval {
        let dx = playerView.center.x - enemyView.center.x
        let dy = playerView.center.y - enemyView.center.y
        return TimeInterval(sqrt(dx * dx + dy * dy) / enemySpeed)
    }
    
    func removeEnemies() {
        enemyViews.forEach {
            $0.removeFromSuperview()
        }
        enemyViews = []
    }
    
    func stopAnimators() {
        playerAnimator?.stopAnimation(true)
        playerAnimator = nil
        enemyAnimators.forEach {
            $0.stopAnimation(true)
        }
        enemyAnimators = []
    }
    func fixCollision() {
        enemyViews.forEach {
            guard let playerFrame = playerView.layer.presentation()?.frame,
                let enemyFrame = $0.layer.presentation()?.frame,
                playerFrame.intersects(enemyFrame) else {
                    return
            }
            gameOver()
        }
    }
    func updateCountUpTimer(timestamp: TimeInterval) {
        if beginTimestamp == 0 {
            beginTimestamp = timestamp
        }
        elapsedTime = timestamp - beginTimestamp
        timedownLabel.text = format(timeInterval: elapsedTime)
    }
    
    func format(timeInterval: TimeInterval) -> String {
        let interval = Int(timeInterval)
        let seconds = interval % 60
        let minutes = (interval / 60) % 60
        let milliseconds = Int(timeInterval * 1000) % 1000
        return String(format: "%02d:%02d.%03d", minutes, seconds, milliseconds)
    }
    
    func movePlayView(to touchLocation: CGPoint) {
        playerAnimator = UIViewPropertyAnimator(duration: playerAnimationDuration,
                                                dampingRatio: 0.5,
                                                animations: { [weak self] in
                                                    self?.playerView.center = touchLocation
        })
        playerAnimator?.startAnimation()
    }
    
    func moveEnemies(to touchLocation: CGPoint) {
        for (index, enemyView) in enemyViews.enumerated() {
            let duration = getEnemyDuration(enemyView: enemyView)
            enemyAnimators[index] = UIViewPropertyAnimator(duration: duration,
                                                           curve: .linear,
                                                           animations: {
                                                            enemyView.center = touchLocation
            })
            enemyAnimators[index].startAnimation()
        }
    }
    
    func displayGameOverAlert() {
        let (title, message) = getGameOverTitleAndMessage()
        let alert = UIAlertController(title: "it,s Over", message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: title, style: .default,
                                   handler: { _ in
                                    self.prepare()
        }
        )
        alert.addAction(action)
        self.present(alert, animated: true, completion: nil)
    }
    
    func getGameOverTitleAndMessage() -> (String, String) {
        let elapsedSeconds = Int(elapsedTime) % 60
        setBestTime(with: format(timeInterval: elapsedTime))
        
        switch elapsedSeconds {
        case 0..<10: return ("Try Again", "Seriously, You can try harder")
        case 10..<30: return ("I Will Do Better", "Good, you are getting there ")
        case 30..<60: return ("Play Again", "Very good")
        default:
            return ("Off Cause", "Your are Legend")
        }
    }
    
    func centerPlayerView() {
        playerView.center = view.center
    }
    
    // Copy from IBAnimatable
    func popPlayerView() {
        let animation = CAKeyframeAnimation(keyPath: "transform.scale")
        animation.values = [0, 0.2, -0.2, 0.2, 0]
        animation.keyTimes = [0, 0.2, 0.4, 0.6, 0.8, 1]
        animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
        animation.duration = CFTimeInterval(0.7)
        animation.isAdditive = true
        animation.repeatCount = 1
        animation.beginTime = CACurrentMediaTime()
        playerView.layer.add(animation, forKey: "pop")
    }
    
    func setBestTime(with time:String){
        let defaults = UserDefaults.standard
        defaults.set(time, forKey: "bestTime")
        
    }
    
    func getBestTime(){
        let defaults = UserDefaults.standard
        
        if let time = defaults.value(forKey: "bestTime") as? String {
            self.bestTimeLabel.text = "\(time)"
        }
    }
    
}
