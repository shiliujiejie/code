

import UIKit

class CardPageCell: UICollectionViewCell {

    @IBOutlet weak var backGround: UIView!
    @IBOutlet weak var cardContenter: UIView!
    @IBOutlet weak var BackContenter: UIView!
    @IBOutlet weak var cardImage: UIImageView!
    @IBOutlet weak var cardBackEmpty: UIImageView!
    @IBOutlet weak var cardBackText: UITextView!
    
    @IBOutlet weak var frontContenter: UIView!
    @IBOutlet weak var cardFrontImage: UIImageView!
    @IBOutlet weak var cardTypeLabel: UILabel!
    @IBOutlet weak var cardNumber: UITextView!
    @IBOutlet weak var cardDateLabel: UITextView!
    @IBOutlet weak var cardNameLabel: UITextView!
    @IBOutlet weak var cardTypeImage: UIImageView!
    
    private let cardAnimationMaskLayer = CAShapeLayer()
    private let cardTypeChangeAnimationDuration: TimeInterval = 0.2
    
    static let cellId = "CardPageCell"
    
    var isFrontVisible = true
    
    override func awakeFromNib() {
        super.awakeFromNib()
        backGround.layer.cornerRadius = 5
        backGround.layer.masksToBounds = true
    }
    
    func setCard(card: CardModel) {
        guard let number = card.cardNumber,!number.isEmpty else {return}
        let formattedNumber = addSpacesIfNecessary(to: number)
        cardNumber.text = formattedNumber.isEmpty ? "XXXX XXXX XXXX XXXX" : formattedNumber
        
        let type = CreditCardTypeChecker.type(for: number)
        
        cardTypeLabel.text = type?.rawValue
        cardTypeImage.image = type?.image
        if let backgroundImage = type?.backgroundImage {
            
        }
        cardFrontImage.image = type?.backgroundImage
        cardNameLabel.text = card.cardName
        cardBackText.text = card.cvvc
        cardDateLabel.text = card.date
        //flipCard(using: .transitionFlipFromRight)
        
       // animateCardTypeChange(addingCard: type != nil)
    }
    func flip(animation: UIView.AnimationOptions) {
        flipCard(using: animation)
    }
    
    private func addSpacesIfNecessary(to cardNumber: String) -> String {
        var formatterNumber = ""
        for (index, character) in cardNumber.enumerated() {
            if index % 4 == 0 {
                formatterNumber.append(" \(character)")
            } else {
                formatterNumber.append(character)
            }
        }
        return formatterNumber
    }
   
    
    func animateCardTypeChange(addingCard: Bool) {
        
        if addingCard {
            cardFrontImage.isHidden = false
            cardBackEmpty.isHidden = true
        }
        
        cardAnimationMaskLayer.path = bigCirclePath
        cardAnimationMaskLayer.fillColor = UIColor.black.cgColor
        cardFrontImage.layer.mask = cardAnimationMaskLayer
        
        CATransaction.begin()
        
        let pathAnimation = CABasicAnimation(keyPath: "path")
        if addingCard {
            pathAnimation.fromValue = smallCirclePath
            pathAnimation.toValue = bigCirclePath
        } else {
            pathAnimation.fromValue = bigCirclePath
            pathAnimation.toValue = smallCirclePath
        }
        
        pathAnimation.duration = cardTypeChangeAnimationDuration
        
        CATransaction.setCompletionBlock {
            if !addingCard {
                self.cardFrontImage.isHidden = true
                self.cardBackEmpty.isHidden = false
            }
            self.cardFrontImage.layer.mask = nil
            self.cardAnimationMaskLayer.removeAllAnimations()
        }

        cardAnimationMaskLayer.add(pathAnimation, forKey: "animation")
        CATransaction.commit()
    }
    
    private lazy var smallCirclePath: CGPath = {
        let center = CGPoint(x: 0, y: 0)
        let radius: CGFloat = 1 // if its 0, the animation won't be nice.
        return self.circle(with: center, and: radius).cgPath
    }()
    
    private lazy var bigCirclePath: CGPath = {
        let center = CGPoint(x: self.frontContenter.frame.width / 2,
                             y: self.frontContenter.frame.height / 2)
        return self.circle(with: center, and: self.bigCircleRadius).cgPath
    }()
    
    private lazy var bigCircleRadius: CGFloat = {
        let halfWidth = self.frontContenter.frame.width / 2
        let halfHeight = self.frontContenter.frame.height / 2
        
        let center = CGPoint(x: halfWidth, y: halfHeight)
        
        return √(halfWidth.² + halfHeight.²)
    }()
    
    private func circle(with center: CGPoint, and radius: CGFloat) -> UIBezierPath {
        return UIBezierPath(arcCenter: center,
                            radius: radius,
                            startAngle: 0,
                            endAngle: 2 * .pi,
                            clockwise: true)
    }
    
    fileprivate func flipCard(using direction: UIView.AnimationOptions) {
        UIView.transition(with: cardContenter,
                          duration: 0.4,
                          options: direction,
                          animations: {
                            if self.isFrontVisible {
                                self.frontContenter.isHidden = true
                                self.BackContenter.isHidden = false
                            } else {
                                self.frontContenter.isHidden = false
                                self.BackContenter.isHidden = true
                            }
                          },
                          completion: { completed in
                            if completed {
                                self.isFrontVisible = !self.isFrontVisible
                            }
                          })
    }
    
}
