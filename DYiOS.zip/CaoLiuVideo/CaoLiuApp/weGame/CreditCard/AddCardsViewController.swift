

import UIKit



class CardModel: Codable {
    var cardName: String?
    var cardNumber: String?
    var cvvc: String?
    var date: String?
}
let CardNameKey = "kCardName"
let CardCodeKey = "kCardCode"
let CardDateKey = "kCardDate"
let CardNumKey = "kCardNum"

class AddCardsViewController: UIViewController {

    @IBOutlet fileprivate weak var cardContainer: UIView!
    
    @IBOutlet fileprivate weak var frontContainer: UIView!
    @IBOutlet fileprivate weak var cardTypeLabel: UILabel!
    @IBOutlet fileprivate weak var cardTypeImageView: UIImageView!
    @IBOutlet fileprivate weak var cardNumberTextView: UITextView!
    @IBOutlet fileprivate weak var cardExpiryDateTextView: UITextView!
    @IBOutlet fileprivate weak var cardNameTextView: UITextView!
    @IBOutlet fileprivate weak var securityCodeTextView: UITextView!
    @IBOutlet fileprivate weak var cardFrontOverlayView: UIImageView!
    
    @IBOutlet fileprivate weak var backContainer: UIView!
    @IBOutlet fileprivate weak var cardBackOverlayView: UIImageView!
    
    @IBOutlet weak var save: UIBarButtonItem!
    
    @IBOutlet fileprivate weak var creaditCardForm: CreditCardForm!
    
    fileprivate var selectedFormItemType = InputType.number
    fileprivate var selectedCardType: CreditCardType?
    
    fileprivate var isFrontVisible = true
    
  
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        applyTextFieldTextContainerInsets()

        creaditCardForm.delegate = self
    }
    
    @IBAction func SaveAction(_ sender: UIBarButtonItem) {
        guard let cardName = cardNameTextView.text, !cardName.isEmpty else {
            XSAlert.show(type: .text, text: "Lack of information")
            return
        }
        guard let cardNum = cardNumberTextView.text, !cardName.isEmpty else {
            XSAlert.show(type: .text, text: "Lack of information")
            return
        }
        guard let cardExpiryDate = cardExpiryDateTextView.text, !cardName.isEmpty else {
            XSAlert.show(type: .text, text: "Lack of information")
            return
        }
        guard let cardSecurityCode = securityCodeTextView.text, !cardName.isEmpty else {
            XSAlert.show(type: .text, text: "Lack of information")
            return
        }
        let num: String = cardNum.replacingOccurrences(of: " ", with: "")
        var cardParams = [String: Any]()
        cardParams[CardNameKey] = cardName
        cardParams[CardCodeKey] = cardSecurityCode
        cardParams[CardNumKey] = num
        cardParams[CardDateKey] = cardExpiryDate
        if var cards = UserDefaults.standard.value(forKey: UserDefaults.klocalCards) as? [[String: Any]], cards.count > 0 {
            cards.insert(cardParams, at: 0)
            UserDefaults.standard.setValue(cards, forKey: UserDefaults.klocalCards)
        } else {
            var values = [[String:Any]]()
            values.append(cardParams)
            UserDefaults.standard.setValue(values, forKey: UserDefaults.klocalCards)
        }
        XSAlert.show(type: .text, text: "success")
        navigationController?.popViewController(animated: true)
    }
    private func applyTextFieldTextContainerInsets() {
        cardNumberTextView.textContainerInset = UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 0)
        cardExpiryDateTextView.textContainerInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        cardNameTextView.textContainerInset = UIEdgeInsets(top: 2, left: 5, bottom: 0, right: 0)
        securityCodeTextView.textContainerInset = UIEdgeInsets(top: 6, left: 0, bottom: 0, right: 0)
    }
    
    private let cardAnimationMaskLayer = CAShapeLayer()
    private let cardTypeChangeAnimationDuration: TimeInterval = 0.2
    
    func animateCardTypeChange(addingCard: Bool) {
        
        if addingCard {
            cardFrontOverlayView.isHidden = false
            cardBackOverlayView.isHidden = true
        }
        
        cardAnimationMaskLayer.path = bigCirclePath
        cardAnimationMaskLayer.fillColor = UIColor.black.cgColor
        cardFrontOverlayView.layer.mask = cardAnimationMaskLayer
        
        CATransaction.begin()
        
        let pathAnimation = CABasicAnimation(keyPath: "path")
        if addingCard {
            pathAnimation.fromValue = smallCirclePath
            pathAnimation.toValue = bigCirclePath
        } else {
            pathAnimation.fromValue = bigCirclePath
            pathAnimation.toValue = smallCirclePath
        }
        
        pathAnimation.duration = cardTypeChangeAnimationDuration
        
        CATransaction.setCompletionBlock {
            if !addingCard {
                self.cardFrontOverlayView.isHidden = true
                self.cardBackOverlayView.isHidden = false
            }
            self.cardFrontOverlayView.layer.mask = nil
            self.cardAnimationMaskLayer.removeAllAnimations()
        }

        cardAnimationMaskLayer.add(pathAnimation, forKey: "animation")
        CATransaction.commit()
    }
    
    private lazy var smallCirclePath: CGPath = {
        let center = CGPoint(x: 0, y: 0)
        let radius: CGFloat = 1 // if its 0, the animation won't be nice.
        return self.circle(with: center, and: radius).cgPath
    }()
    
    private lazy var bigCirclePath: CGPath = {
        let center = CGPoint(x: self.frontContainer.frame.width / 2,
                             y: self.frontContainer.frame.height / 2)
        return self.circle(with: center, and: self.bigCircleRadius).cgPath
    }()
    
    private lazy var bigCircleRadius: CGFloat = {
        let halfWidth = self.frontContainer.frame.width / 2
        let halfHeight = self.frontContainer.frame.height / 2
        
        let center = CGPoint(x: halfWidth, y: halfHeight)
        
        return √(halfWidth.² + halfHeight.²)
    }()
    
    private func circle(with center: CGPoint, and radius: CGFloat) -> UIBezierPath {
        return UIBezierPath(arcCenter: center,
                            radius: radius,
                            startAngle: 0,
                            endAngle: 2 * .pi,
                            clockwise: true)
    }
    
    fileprivate func flipCard(using direction: UIView.AnimationOptions) {
        UIView.transition(with: cardContainer,
                          duration: 0.4,
                          options: direction,
                          animations: {
                            if self.isFrontVisible {
                                self.frontContainer.isHidden = true
                                self.backContainer.isHidden = false
                            } else {
                                self.frontContainer.isHidden = false
                                self.backContainer.isHidden = true
                            }
        },
                          completion: { completed in
                            if completed {
                                self.isFrontVisible = !self.isFrontVisible
                            }
        })
    }
}

extension AddCardsViewController : CreditCardFormDelegate {
    func updated(cardName: String) {
        cardNameTextView.text = cardName
    }
    
    func updated(cardExpiryDate: String) {
        cardExpiryDateTextView.text = cardExpiryDate
    }
    
    func updated(cardNumber: String) {
        let formattedNumber = addSpacesIfNecessary(to: cardNumber)
        
        cardNumberTextView.text = formattedNumber.isEmpty ? "XXXX XXXX XXXX XXXX" : formattedNumber
        
        let type = CreditCardTypeChecker.type(for: cardNumber)
        
        if type == selectedCardType {
            return
        }
        
        cardTypeLabel.text = type?.rawValue
        cardTypeImageView.image = type?.image
        if let backgroundImage = type?.backgroundImage {
            cardFrontOverlayView.image = backgroundImage
        }
        
        animateCardTypeChange(addingCard: type != nil)
       
        selectedCardType = type
    }
    
    private func addSpacesIfNecessary(to cardNumber: String) -> String {
        var formatterNumber = ""
        for (index, character) in cardNumber.enumerated() {
            if index % 4 == 0 {
                formatterNumber.append(" \(character)")
            } else {
                formatterNumber.append(character)
            }
        }
        return formatterNumber
    }
    
    func updated(cardSecurityCode: String) {
        securityCodeTextView.text = cardSecurityCode
    }
    
    func selected(_ type: InputType) {
        guard selectedFormItemType != type else { return }
        
        if type == .securityCode {
            flipCard(using: .transitionFlipFromRight)
        } else if selectedFormItemType == .securityCode {
            flipCard(using: .transitionFlipFromLeft)
        }
        selectedFormItemType = type
    }
}

extension CGFloat {
    
    var ²: CGFloat {
        return self * self
    }
}

prefix operator √
prefix func √(a: CGFloat) -> CGFloat {
    return sqrt(a)
}
