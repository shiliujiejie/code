

import UIKit
import SnapKit

var paramCards = [[String: Any]]()



// MARK: - UserDefaults Key
public extension UserDefaults {
    /// 本地存储vip类型key
    static let klocalCards = "klocalCards"
}

class CardListController: UIViewController {
    let tipsLabel: UILabel = {
       let lable  = UILabel()
        lable.textColor =  .lightGray
        lable.textAlignment = .center
        lable.text = "Manager your CreditCards"
        return lable
    }()
    private let layout: CustomFlowLayout = {
        let layout = CustomFlowLayout()
        let w = screenWidth*6/7 - 20
        let h = w * 9/16 + 70
        layout.scrollDirection = .horizontal
        layout.itemSize = CGSize(width: w, height: h)
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 10
        layout.sectionInset = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        return layout
    }()
    lazy var collView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect.zero, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.showsHorizontalScrollIndicator = false
        collection.backgroundColor = UIColor.clear
        collection.register(UINib.init(nibName: "CardPageCell", bundle: Bundle.main), forCellWithReuseIdentifier: CardPageCell.cellId)
        return collection
    }()
    var localCards = [CardModel]()
    override func viewDidLoad() {
        super.viewDidLoad()
       
        view.addSubview(collView)

        collView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
       
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadCards()
    }
    
    func loadCards() {
        //UserDefaults.standard.value(forKey: <#T##String#>)
        if let cards = UserDefaults.standard.value(forKey: UserDefaults.klocalCards) as? [[String: Any]], cards.count > 0 {
            var cardModels = [CardModel]()
            cards.forEach { (param) in
                let card = CardModel()
                card.cardName = param[CardNameKey] as? String
                card.cardNumber = param[CardNumKey] as? String
                card.cvvc = param[CardCodeKey] as? String
                card.date = param[CardDateKey] as? String
                cardModels.append(card)
            }
            localCards = cardModels
            
            collView.reloadData()
            if tipsLabel.superview != nil  {
                tipsLabel.removeFromSuperview()
            }
           
//            for i in 0 ..< paramCards.count {
//                ["4514610800876846","3540123456789012","5538430088888888","5412750012345678","30091234567890"][i]
//            }
        } else {
            view.addSubview(tipsLabel)
            tipsLabel.snp.makeConstraints { (make) in
                make.center.equalToSuperview()
            }
        }
        
    }
    
    @IBAction func addNewCard(_ sender: UIBarButtonItem) {
        
//        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//        if let vc: AddCardsViewController = storyboard.instantiateViewController(withIdentifier: "AddCardsViewController") as? AddCardsViewController {
//            self.navigationController?.pushViewController(vc, animated: true)
//        }
    }
    
}

extension CardListController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return localCards.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CardPageCell.cellId, for: indexPath) as! CardPageCell
        cell.setCard(card: localCards[indexPath.item])
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        if let cell = collectionView.cellForItem(at: indexPath) as? CardPageCell {
            cell.flip(animation: .transitionFlipFromRight)
        }
    }
    
    
}
