//
//  main.swift
//  KouWoPJ
//
//  Created by mac on 3/3/2021.
//  Copyright © 2021 AnakinChen Network Technology. All rights reserved.
//

import Foundation
import UIKit

UIApplicationMain(CommandLine.argc, CommandLine.unsafeArgv, NSStringFromClass(AppDelegate.self), NSStringFromClass(AppDelegate.self))
