
import UIKit
import NicooNetwork
import IQKeyboardManagerSwift
import KeychainSwift

public var uuid: String?

enum LanscapeLocation {
    case videoDetail
    case gameDetail
}

//@UIApplicationMain
class AppDelegate: UIApplication, UIApplicationDelegate {
    
    var window: UIWindow?
    var location: LanscapeLocation = .videoDetail
    var isLandscape = false
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        UploadTask.shareTask().readLocalUploadTasks()
        findServer()
        // 从钥匙串获取用户信息
        getOrSaveUUID()
        // 键盘管理
        setupKeyBoard()
        TBUncaughtExceptionHandler.shared.exceptionLogWithData()
        return true
    }
    
    //  整个项目支持竖屏，播放页面需要横屏
    func application(_ application: UIApplication, supportedInterfaceOrientationsFor window: UIWindow?)
        -> UIInterfaceOrientationMask {
        if location == .videoDetail {
            guard let num = R_PlayerOrietation(rawValue: orientationSupport.rawValue) else {
                return [.portrait]
            }
            return num.getOrientSupports()
        } else if location == .gameDetail {
            if isLandscape {
                return [.landscapeLeft, .landscapeRight]
            }
        }
        return .portrait
    }

    /// service 配置
    private func findServer() {
        NicooServiceFactory.shareInstance.dataSource = self
    }
    
    /// 键盘管理
    private func setupKeyBoard() {
        IQKeyboardManager.shared.enable = true
        IQKeyboardManager.shared.shouldResignOnTouchOutside = true
    }

    /// 保存用户唯一识别码
    private func getOrSaveUUID() {
        UserDefaults.standard.set(true, forKey: UserDefaults.knewUserSatisfiedShow)
        uuid = getUserDeviceFromKeychain()   
    }
    
    private func getUserDeviceFromKeychain() -> String? {
        let keychain = KeychainSwift()
        if let acount = keychain.get(ConstValue.kUserKeychainKey) {
            DLog("acountMsg = \(keychain.accessGroup ?? "没有添加用户群组") acount == \(acount)")
            return acount
        } else {
            let deviceId = UIDevice.current.getIdfv()
            let random = arc4random()%1000000
            let randomAddString = String(format: "%@%d", deviceId, random)
            /// 新用户
            UserDefaults.standard.set(false, forKey: UserDefaults.knewUserSatisfiedShow)
            if let deviceCode = randomAddString.md5() {
                DLog("deviceCode === \(deviceCode )")
                keychain.set(deviceCode, forKey: ConstValue.kUserKeychainKey)
                return deviceCode
            } else {
                keychain.set(deviceId, forKey: ConstValue.kUserKeychainKey)
                return deviceId
            }
        }
    }
    override func sendEvent(_ event: UIEvent) {
        super.sendEvent(event)
        if let sets = event.allTouches, sets.count > 0 {
            let phase: UITouch.Phase = sets.first!.phase
            if phase == UITouch.Phase.began {
              //  DLog("UITouch.Phase.began - \(sets)")
//                let view = sets.first?.view
//                DLog("view is \(view?.classForCoder)")
//                if view is UIButton {
//                    DLog("view is UIButton - \((view as! UIButton).titleLabel?.text ?? "")")
//                } else if view is UICollectionViewCell {
//                    DLog("view is UICollectionViewCell - ")
//                } else if view is UILabel {
//                    DLog("view is UILabel - \((view as! UILabel).text ?? "")")
//                }
            }
        }
    }
    
}


// MARK: - NicooServiceFactoryProtocol
extension AppDelegate: NicooServiceFactoryProtocol {
    
    /// 自定义的服务
    ///
    /// - Returns: 自定义的服务名
    func servicesKindsOfServiceFactory() -> [String : String] {
        return [ConstValue.kXSVideoService: "XSVideoService"]
        
        
    }
    
    /// 自定义的服务所在的命名空间 （如果自定义的服务是组件，命名空间就为 服务组件名）
    ///
    /// - Parameter service: 服务名
    /// - Returns: m命名空间
    func namespaceForService(_ service: String) -> String? {
        switch service {
        case ConstValue.kXSVideoService :
            return "OceanTeam"   // 这里两个服务都在主工程 （如果服务 跟随组件模块， 则需要传入组件所在的命名空间名）
        default:
            return nil
        }
    }
}
