

import UIKit
import NicooNetwork
import Alamofire
import DouYinScan
import Zip

class ViewController: UIViewController {
    
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    private let registerViewModel = RegisterLoginViewModel()
    private let userInfoViewModel = UserInfoViewModel()
    private let apiCheckModel = APICheckViewModel()
    var downLoadRequest: DownloadRequest!
    var progressView: KYCircularProgress  = {
        let v = KYCircularProgress.init(frame: CGRect(x: (screenWidth - 200)/2, y: (screenHeight - 200)/2, width: 200, height: 200), showGuide: true)
        v.guideColor = UIColor.white
        v.colors = [UIColor.purple, UIColor.cyan, UIColor.orange, UIColor.magenta]
        v.lineWidth = 3.0
        v.guideLineWidth = 7.0
        return v
    }()
    let progressLab: UILabel = {
        let lab = UILabel(frame: CGRect(x: (screenWidth - 180)/2, y: (screenHeight - 40)/2, width: 180, height: 40))
        lab.textAlignment = .center
        lab.font = UIFont.boldSystemFont(ofSize: 15)
        lab.textColor = UIColor.systemGreen
        return lab
    }()
    deinit {
        DLog("ViewController  --- release")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        ProdValue.prod().tokenRefeshModel = RegisterLoginViewModel()
        self.loadAppProdUrl()
    }
    
    private func saveDot() {
        let vc = OceanTeamController()
        if let delegate = UIApplication.shared.delegate as? AppDelegate {
            delegate.window?.rootViewController = CLNavigationController(rootViewController: vc)
        }
//        self.showDialog(title: "Warnning", message: "failed to Unzip source Images!", okTitle: "retry", cancelTitle: "cancel", okHandler: {
//            self.saveDot()
//        }) { }
    }
    /// 检测Ip
    private func checkIp() {
        registerViewModel.checkIp(nil) { [weak self]  in
            self?.loadUpdateInfo()
        } failHandler: { [weak self]  (error) in
            self?.saveDot()
        }
    }
    
    /// 检测线路
    private func loadAppProdUrl() {
        XSProgressHUD.showProgress(msg: "线路加载中...", onView: view, animated: false)
        apiCheckModel.checkAPIChannel(succeedHandler: { [weak self] (apiPath) in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            ProdValue.prod().kProdUrlBase = apiPath
            strongSelf.checkIp()
        }) { [weak self] in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            strongSelf.showDialog(title: "线路繁忙", message: "當前线路繁忙，請重新連接或稍後再試。", okTitle: "重新連接", cancelTitle: "取消", okHandler: {
                strongSelf.loadAppProdUrl()
            }) { }
        }
    }

    /// 版本信息
    private func loadUpdateInfo() {
        ///崩溃上传
        registerViewModel.checkUpdateInfo(succeedHandler: { [weak self] in
        ///判断是否当前为最新版本
            guard let strongSelf = self else { return }
            if strongSelf.registerViewModel.versionInfo != nil {
                self?.loadUpdateInfoSuccess(strongSelf.registerViewModel.versionInfo!)
            }
        }) { [weak self] (errorMsg)in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            XSAlert.show(type: .error, text: errorMsg)
        }
    }
    
    /// 设备号注册
    func registerDevice() {
        registerViewModel.registerDevice(succeedHandler: { [weak self] in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            self?.loadUserInfo()
        }) { [weak self]  in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            XSAlert.show(type: .error, text: "系统服务异常，请稍后再试")
        }
    }
    /// 用户信息
    func loadUserInfo() {
        userInfoViewModel.loadUserInfo(params: nil, succeedHandler: {
            [weak self] in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            DLog("到这里，用户信息拿到了 -》 可以进入app了 ")
            strongSelf.addGestureLock()
        }) { [weak self] in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: false)
            XSAlert.show(type: .error, text: "系统服务异常，请稍后再试")
        }
    }
    
    /// 加手势锁
    private func addGestureLock() {
        if GYCircleConst.getGestureWithKey(gestureFinalSaveKey) != nil {
            let gestureVC = GestureViewController()
            // 登錄成功， 进入抖音
            gestureVC.lockLoginSuccess = {
                gestureVC.dismiss(animated: false) {
                    self.loadAdDataOrDownload()
                }
            }
            gestureVC.type = GestureViewControllerType.login
            gestureVC.navBarHiden = true
            gestureVC.modalPresentationStyle = .fullScreen
            present(gestureVC, animated: false, completion: nil)
        } else {
            DLog("暂未设置手势密码,直接进入App")
            loadAdDataOrDownload()
        }
    }
    
    /// 加载广告
    private func loadAdDataOrDownload() {
        if let ad = UserModel.share().authInfo?.startup, let adLink = ad.link, let adPath = ad.cover {
            if let adDataUrl = UserDefaults.standard.string(forKey: UserDefaults.kAdDataUrl), let saveLink = UserDefaults.standard.string(forKey: UserDefaults.kAdLinkUrl) , adDataUrl == adPath, saveLink == adLink {
                DLog("此广告与上次打开时广告相同。")
                // 开屏广告
                let adVC = AdvertiseController()
                adVC.adUrl = adDataUrl
                adVC.adClickOrShowToEndHandler = {
                    adVC.dismiss(animated: false) {
                        self.setVideoRootVC()
                    }
                }
                let nav = CLNavigationController(rootViewController: adVC)
                nav.modalPresentationStyle = .fullScreen
                present(nav, animated: false, completion: nil)
            } else {
                // 开屏广告 - 网络
                let adVC = AdvertiseController()
                adVC.adUrl = adPath
                adVC.adClickOrShowToEndHandler = {
                    adVC.dismiss(animated: false) {
                        self.setVideoRootVC()
                    }
                }
                let nav = CLNavigationController(rootViewController: adVC)
                nav.modalPresentationStyle = .fullScreen
                present(nav, animated: false, completion: nil)
            }
            
        } else {
            /// 进入APp
            setVideoRootVC()
        }
    }
}

// MARK: - 保存版本信息
private extension ViewController {
    
    func loadUpdateInfoSuccess(_ model: AppVersionInfo) {
        AppInfo.share().appInfo = model
        AppInfo.share().userInfoVM = UserInfoViewModel()
        checkAppVersionInfo()
    }
    func checkAppVersionInfo() {
        let appInfo = AppInfo.share()
        guard let versionNew = appInfo.appInfo?.version_code else { return }
        guard let numVersionNew = versionNew.removeAllPoints() else { return }
        guard let numVersionCurrent = ConstValue.kAppVersion.removeAllPoints() else { return }
        if Int(numVersionNew) != nil && Int(numVersionCurrent) != nil && Int(numVersionNew)! > Int(numVersionCurrent)! {
            let controller = AlertManagerController()
            controller.view.backgroundColor = UIColor(white: 0, alpha: 0.7)
            controller.alertType = .updateInfo
            controller.modalPresentationStyle = .overCurrentContext
            controller.commitActionHandler = { [weak self] in
                self?.goAndUpdate(String(format: "%@", appInfo.appInfo?.package_path ?? ""))
                if appInfo.appInfo?.force == .normalUpdate {
                     self?.registerDevice()
                }
            }
            controller.closeActionHandler = {
                /// 设备号注册
                self.registerDevice()
            }
            present(controller, animated: false, completion: nil)
        } else {
            /// 设备号注册
            self.registerDevice()
        }
    }
    func goAndUpdate(_ downLoadUrl: String?) {
        if let urlstring = downLoadUrl {
            let downUrl = String(format: "%@", urlstring)
            if let url = URL(string: downUrl) {
                DLog(downUrl)
                if #available(iOS 10, *) {
                    UIApplication.shared.open(url, options: [:],
                                              completionHandler: {
                                                (success) in
                    })
                } else {
                    UIApplication.shared.openURL(url)
                }
            }
        }
    }
    
}

// MARK: - 开机GIF 动画
private extension ViewController {
    
    /// 线程延时
    private func sleep(_ time: Double,mainCall:@escaping ()->()) {
        let time = DispatchTime.now() + .milliseconds(Int(time * 1000))
        DispatchQueue.main.asyncAfter(deadline: time) {
            mainCall()
        }
    }
    
}


extension UIViewController {
    func showAppVersionInfo() {
        let version = getCurrentAppVersion()
        let build = getAppBuildVersion()
        let days = Date.getDaysFromBeginDayToEndDay(beginDateStr: Date.getCurrentDateStr(), endDateStr: ConstValue.tfEndTime)
        let strcommon = "\n\n如果您的版本号不是最新版,请前往 \(AppInfo.share().appInfo?.package_path ?? AppInfo.share().appInfo?.app_url ?? "") 下载最新版本。\n\n ⚠️下载前请注意，先保存身份二维码"
        let msg = "\n您的 测试App 还有\(days)天到期\(strcommon)"
        showNearDialog(redTitle: "版本号\(version)(\(build))\n\n", message: msg, okTitle: days > 20 ? "知道了" : "去更新", cancelTitle: "保存身份码") {
            if days <= 20 {
                self.goInnerLink("url://\(AppInfo.share().appInfo?.package_path ?? AppInfo.share().appInfo?.app_url ?? "")")
            }
        } cancelHandler: {
            self.saveQRcode()
        }
    }
    func showTFtimeTips() {
        let days = Date.getDaysFromBeginDayToEndDay(beginDateStr: Date.getCurrentDateStr(), endDateStr: ConstValue.tfEndTime)
        DLog("TF--还有 = \(days)天版本到期")
        if days > 20 {
            return
        }
        let version = getCurrentAppVersion()
        let build = getAppBuildVersion()
        let strcommon = "\n您的 测试App 还有\(days)天到期,请前往 官网： \(AppInfo.share().appInfo?.app_url ?? "") 下载更新，\n\n⚠️防止账号丢失，请先保存身份二维码"
        showNearDialog(redTitle: "版本号\(version)(\(build))\n\n", message: strcommon, okTitle: "立即更新", cancelTitle: "保存身份码") {
            self.goInnerLink("url://\(AppInfo.share().appInfo?.package_path ?? "")")
        } cancelHandler: {
            self.saveQRcode()
        }
    }
    
    func saveQRcode() {
        if let QRContent = UserModel.share().user?.account_qrcode_content, !QRContent.isEmpty {
            if let qrImg = ScanWrapper.createCode(codeType: "CIQRCodeGenerator", codeString: QRContent, size: CGSize(width: 120, height: 120), qrColor: UIColor.white, bkColor: UIColor.darkText) {
                UIImageWriteToSavedPhotosAlbum(qrImg, self, nil, nil)
                XSAlert.show(type: .text, text: "身份信息已保存")
            }
        } else {
            XSAlert.show(type: .text, text: "暂无身份信息可保存")
        }
    }
    
    /// 广告点击
    func goInnerLink(_ herf: String, _ key: String? = nil) {
        if key != nil {
            AppInfo.share().uploadUserAction([UploadActionsLogApi.kEvent: UploadActionsLogApi.kAD, UploadActionsLogApi.kEvent_data : "\(key ?? "")||\(herf)"])
        }
        if herf.contains("url://") {
            let urlStrs = herf.components(separatedBy: "url://")
            if urlStrs.count > 1 {
                if let url = URL(string: urlStrs[1]) {
                    if #available(iOS 10, *) {
                        UIApplication.shared.open(url, options: [:],
                                                  completionHandler: {
                                                    (success) in
                        })
                    } else {
                        UIApplication.shared.openURL(url)
                    }
                }
            }
        } else if herf.contains("tag://") {
            let urlStrs = herf.components(separatedBy: "://")
            if urlStrs.count > 1 {
                if let tag_id = Int(urlStrs[1]) {
                    var model = SearchHotTips()
                    model.id = tag_id
                    model.type_id = tag_id
                    if let vcs = navigationController?.viewControllers {
                        let allPlayVcs = vcs.filter { (vc) -> Bool in
                            return vc.isKind(of: TypeVideosController.self)
                        }
                        if allPlayVcs.count > 0 {
                            navigationController?.viewControllers.removeAll(where: { (detailVc) -> Bool in
                                return detailVc.isKind(of: TypeVideosController.self)
                            })
                        }
                        let detail = TypeVideosController()
                        detail.keyMode = model
                        navigationController?.pushViewController(detail, animated: true)
                    }
                }
            }
        } else if herf.contains("type://") {
            let urlStrs = herf.components(separatedBy: "://")
            if urlStrs.count > 1 {
                if let type_id = Int(urlStrs[1]) {
                    let model = ModuleDetailModel()
                    model.id = type_id
                    if let vcs = navigationController?.viewControllers {
                        let allPlayVcs = vcs.filter { (vc) -> Bool in
                            return vc.isKind(of: ModuleMoreController.self)
                        }
                        if allPlayVcs.count > 0 {
                            navigationController?.viewControllers.removeAll(where: { (detailVc) -> Bool in
                                return detailVc.isKind(of: ModuleMoreController.self)
                            })
                        }
                        let detail = ModuleMoreController()
                        detail.detailModel = model
                        navigationController?.pushViewController(detail, animated: true)
                    }
                }
            }
        } else if herf.contains("user://") {
            let urlStrs = herf.components(separatedBy: "://")
            if urlStrs.count > 1 {
                let userCode = urlStrs[1]
                if !userCode.isEmpty {
                    let v = CLUserInfo()
                    v.code = userCode
                    if let vcs = navigationController?.viewControllers {
                        let allPlayVcs = vcs.filter { (vc) -> Bool in
                            return vc.isKind(of: UserMCenterController.self)
                        }
                        if allPlayVcs.count > 0 {
                            navigationController?.viewControllers.removeAll(where: { (detailVc) -> Bool in
                                return detailVc.isKind(of: UserMCenterController.self)
                            })
                        }
                        let userPage = UserMCenterController()
                        userPage.userNew = v
                        userPage.userCode = userCode
                        navigationController?.pushViewController(userPage, animated: true)
                    }
                }
            }
        } else if herf.contains("video://") {
            let urlStrs = herf.components(separatedBy: "://")
            if urlStrs.count > 1 {
                if let videoId = Int(urlStrs[1]) {
                    let v = VideoNew()
                    v.id = videoId
                    if let vcs = navigationController?.viewControllers {
                        let allPlayVcs = vcs.filter { (vc) -> Bool in
                            return vc.isKind(of: VideoDetailController.self)
                        }
                        if allPlayVcs.count > 0 {
                            navigationController?.viewControllers.removeAll(where: { (detailVc) -> Bool in
                                return detailVc.isKind(of: VideoDetailController.self)
                            })
                        }
                        let detail = VideoDetailController()
                        detail.video = v
                        navigationController?.pushViewController(detail, animated: true)
                    }
                }
            }
        } else if herf.contains("buycoins://") {
            let vip = CoinsCardsController()
            vip.isCoins = herf.contains("buycoins://")
            navigationController?.pushViewController(vip, animated: true)
        } else if herf.contains("buyvip://")  {
            let vip = VipCardsController()
            navigationController?.pushViewController(vip, animated: true)
        } else if herf.contains("urlself://") {
            let urlStrs = herf.components(separatedBy: "urlself://")
            if urlStrs.count > 1 {
                guard let adHref = URL(string: urlStrs[1]) else { return }
                let aavc = AAViewController(url: adHref)
                navigationController?.pushViewController(aavc, animated: false)
            }
        } else if herf.contains("game://") {
            if let vcs = navigationController?.viewControllers {
                let allVcs = vcs.filter { (vc) -> Bool in
                    return vc.isKind(of: GameListControlller.self)
                }
                if allVcs.count > 0 {
                    navigationController?.viewControllers.removeAll(where: { (detailVc) -> Bool in
                        return detailVc.isKind(of: GameListControlller.self)
                    })
                }
                let game = GameListControlller()
                game.position = .OnePage
                navigationController?.pushViewController(game, animated: false)
            }
        }
    }
    /// 进入短视频播放页
    func goShortVideoPlayerVC(_ video: VideoNew) {
        if let vcs = navigationController?.viewControllers {
            let allPlayVcs = vcs.filter { (vc) -> Bool in
                return vc.isKind(of: PresentPlayController.self)
            }
            if allPlayVcs.count > 0 {
                navigationController?.viewControllers.removeAll(where: { (detailVc) -> Bool in
                    return detailVc.isKind(of: PresentPlayController.self)
                })
            }
            let controller = PresentPlayController()
            controller.videos = [video]
            controller.currentIndex = 0
            controller.currentPlayIndex = 0
            navigationController?.pushViewController(controller, animated: true)
        }
    }
    /// 进入长视频详情页
   func goLongVideoDetail(_ model: VideoNew) {
        if let vcs = navigationController?.viewControllers {
            let allPlayVcs = vcs.filter { (vc) -> Bool in
                return vc.isKind(of: VideoDetailController.self)
            }
            if allPlayVcs.count > 0 {
                navigationController?.viewControllers.removeAll(where: { (detailVc) -> Bool in
                    return detailVc.isKind(of: VideoDetailController.self)
                })
            }
            let detail = VideoDetailController()
            detail.video = model
            navigationController?.pushViewController(detail, animated: true)
        }
    }
    /// 设置抖音模块为 根控制器
     func setVideoRootVC() {
       let viewController = CLTabBarViewController()
       if let delegate = UIApplication.shared.delegate as? AppDelegate {
           delegate.window?.rootViewController = CLNavigationController(rootViewController: viewController)
       }
    }
}
